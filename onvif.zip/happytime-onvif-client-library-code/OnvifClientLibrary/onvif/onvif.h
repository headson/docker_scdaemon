/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2010-2016, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#ifndef	__H_ONVIF_H__
#define	__H_ONVIF_H__

#include "sys_inc.h"
#include "http.h"
#include "onvif_cm.h"
#include "onvif_act.h"


/***************************************************************************************/

// device type
#define ODT_UNKNOWN     	0
#define ODT_NVT         	1
#define ODT_NVD         	2
#define ODT_NVS         	3
#define ODT_NVA         	4

// device flag
#define FLAG_MANUAL			(1 << 0)	        // manual added device, other auto discovery devices


/***************************************************************************************/
typedef struct
{
    int		type;          	 			        // device type
    char	EndpointReference[100];
	
    onvif_XAddr	XAddr;                          // xaddr, include port host, url
} DEVICE_BINFO;

/***************************************************************************************/

// video source list
typedef struct _ONVIF_VideoSource
{
	struct _ONVIF_VideoSource * next;
	
    onvif_VideoSource VideoSource; 
} ONVIF_VideoSource;

// video source mode list
typedef struct _ONVIF_VideoSourceMode
{
    struct _ONVIF_VideoSourceMode * next;

	onvif_VideoSourceMode	VideoSourceMode;  	
} ONVIF_VideoSourceMode;

// video source configuration list
typedef struct _ONVIF_VideoSourceConfiguration
{
	struct _ONVIF_VideoSourceConfiguration * next;

	onvif_VideoSourceConfiguration Configuration; 
} ONVIF_VideoSourceConfiguration;

// video encoder configuration list
typedef struct _ONVIF_VideoEncoderConfiguration
{    
	struct _ONVIF_VideoEncoderConfiguration * next;	

	onvif_VideoEncoderConfiguration	Configuration;	
} ONVIF_VideoEncoderConfiguration;

// audio source list
typedef struct _ONVIF_AudioSource
{    
	struct _ONVIF_AudioSource * next;
	
    onvif_AudioSource AudioSource;	
} ONVIF_AudioSource;

// audio source configuration list
typedef struct _ONVIF_AudioSourceConfiguration
{    
	struct _ONVIF_AudioSourceConfiguration * next;
	
    onvif_AudioSourceConfiguration 	Configuration;	
} ONVIF_AudioSourceConfiguration;

// audio encoder configuration list
typedef struct _ONVIF_AudioEncoderConfiguration
{
	struct _ONVIF_AudioEncoderConfiguration * next;
	
    onvif_AudioEncoderConfiguration Configuration;
} ONVIF_AudioEncoderConfiguration;

typedef struct _ONVIF_MetadataConfiguration
{
	struct _ONVIF_MetadataConfiguration * next;
	
	onvif_MetadataConfiguration Configuration;
} ONVIF_MetadataConfiguration;

// ptz preset list
typedef struct _ONVIF_PTZPreset
{
    struct _ONVIF_PTZPreset * next;
    
    onvif_PTZPreset	PTZPreset;
} ONVIF_PTZPreset;

// ptz configuration list
typedef struct _ONVIF_PTZConfiguration
{
	struct _ONVIF_PTZConfiguration * next;
	
	onvif_PTZConfiguration  Configuration;
} ONVIF_PTZConfiguration;

// ptz node list
typedef struct _ONVIF_PTZNode
{
	struct _ONVIF_PTZNode * next;

	onvif_PTZNode	PTZNode;	
} ONVIF_PTZNode;

// preset tour list
typedef struct _ONVIF_PresetTour
{
	struct _ONVIF_PresetTour * next;

	onvif_PresetTour    PresetTour;
} ONVIF_PresetTour;

// video analytics configuration list
typedef struct _ONVIF_VideoAnalyticsConfiguration
{
	struct _ONVIF_VideoAnalyticsConfiguration	* next;

	ONVIF_Config 		* rules;					    // video analytics rule configuration
	ONVIF_Config 		* modules;					    // video analytics module configuration

	onvif_SupportedRules  SupportedRules;			    // supported rules
	
	onvif_VideoAnalyticsConfiguration   Configuration;
} ONVIF_VideoAnalyticsConfiguration;

// network interface list
typedef struct _ONVIF_NetworkInterface
{
	struct _ONVIF_NetworkInterface * next;
	
	onvif_NetworkInterface	NetworkInterface; 
} ONVIF_NetworkInterface;

typedef struct 
{
	onvif_NetworkProtocol		    NetworkProtocol;
	onvif_DNSInformation		    DNSInformation;
	onvif_NTPInformation		    NTPInformation;
	onvif_HostnameInformation	    HostnameInformation;
	onvif_NetworkGateway		    NetworkGateway;
	onvif_DiscoveryMode			    DiscoveryMode;
	onvif_NetworkZeroConfiguration  ZeroConfiguration;
	
	ONVIF_NetworkInterface        * interfaces;
} ONVIF_NET;

// user list
typedef struct _ONVIF_User
{
	struct _ONVIF_User * next;

	onvif_User	User;
} ONVIF_User;

// osd configuration list
typedef struct _ONVIF_OSDConfiguration
{
	struct _ONVIF_OSDConfiguration * next;
	
	onvif_OSDConfiguration OSD;
} ONVIF_OSDConfiguration;

typedef struct _ONVIF_Recording
{
	struct _ONVIF_Recording * next;

	onvif_Recording	Recording;
} ONVIF_Recording;

typedef struct _ONVIF_RECORDINGJOB
{	
	struct _ONVIF_RECORDINGJOB * next;

	onvif_RecordingJob	RecordingJob;
} ONVIF_RecordingJob;

typedef struct _ONVIF_NotificationMessage
{
	struct _ONVIF_NotificationMessage * next;

	onvif_NotificationMessage	NotificationMessage;
} ONVIF_NotificationMessage;

typedef struct
{
    BOOL            subscribe;              	// event subscribed flag
    BOOL			event_timer_run;			// event running flag
    
    HTTPSRV         http_srv;
    char            reference_addr[256];    	// event comsumer address
    char            producter_addr[256];    	// event producter address

    int             init_term_time;
    pthread_t  		timer_id;                   // timer id

    unsigned int    notify_nums;                // event notify numbers
    
    ONVIF_NotificationMessage  * notify;        // event notify messages
} ONVIF_EVENT;

typedef struct _ONVIF_Profile
{
    struct _ONVIF_Profile * next;
	
	char 	name[ONVIF_NAME_LEN];               // profile name
    char 	token[ONVIF_TOKEN_LEN];             // profile token
    char 	stream_uri[ONVIF_URI_LEN];          // this profile stream url address
    BOOL 	fixed;                              // Whether able to modify

    /********************************************************/
    
    ONVIF_VideoSourceConfiguration    * video_src_cfg;
    ONVIF_VideoEncoderConfiguration   * video_enc;
	ONVIF_AudioSourceConfiguration    * audio_src_cfg;
	ONVIF_AudioEncoderConfiguration   * audio_enc;
	ONVIF_PTZNode                     * ptz_node;
	ONVIF_PTZConfiguration            * ptz_cfg;
	ONVIF_VideoAnalyticsConfiguration * va_cfg;
} ONVIF_Profile;

typedef struct
{
	unsigned int    local_ip;   				// local ip address to connect to server, network byte order
	
    DEVICE_BINFO    binfo;                      // device basic information

    int             timeType;                   // the device datatime type, 0-local time, 1-utc time
    time_t          devTime;                    // the device datatime
    time_t          getTime;                    // fethe the device datatime time

    // request
	char 			username[32];               // login user name, set by user
	char 			password[32];               // login password, set by user

	BOOL            needAuth;                   // whether need auth, set by onvif stack
	BOOL			authFailed;                 // when login auth failed, set by onvif stack
	ONVIF_RET       errCode;                    // error code, set by onvif stack
	onvif_Fault     fault;                      // the onvif fault, set by onvif stack, valid when errCode is ONVIF_ERR_HttpResponseError, or please skip it
    
    ONVIF_Profile * curProfile;                 // current profile pointer, the default pointer the first profile, user can set it    

    /********************************************************/
    
	ONVIF_VideoSource               * video_src;            // the list of video source
	ONVIF_AudioSource               * audio_src;            // the list of audio source
    ONVIF_Profile                   * profiles;             // the list of profile
	ONVIF_VideoSourceConfiguration  * video_src_cfg;        // the list of video source configuration
	ONVIF_AudioSourceConfiguration  * audio_src_cfg;        // the list of audio source configuration
	ONVIF_VideoEncoderConfiguration * video_enc;            // the list of video encoder configuration
	ONVIF_AudioEncoderConfiguration * audio_enc;            // the list of audio encoder configuration
	ONVIF_PTZNode                   * ptznodes;             // the list of ptz node
	ONVIF_PTZConfiguration          * ptz_cfg;	            // the list of ptz configuration
	
	/********************************************************/
	ONVIF_EVENT                       events;               // event information
    onvif_DeviceInformation	          DeviceInformation;    // device information
    onvif_Capabilities		          Capabilities;         // device capabilities
} ONVIF_DEVICE;


#ifdef __cplusplus
extern "C" {
#endif

ONVIF_API void                                      onvif_free_device(ONVIF_DEVICE * p_dev);

ONVIF_API ONVIF_NetworkInterface                  * onvif_add_NetworkInterface(ONVIF_NetworkInterface ** p_net_inf);
ONVIF_API void                                      onvif_free_NetworkInterfaces(ONVIF_NetworkInterface ** p_net_inf);

ONVIF_API ONVIF_VideoSource                       * onvif_add_VideoSource(ONVIF_VideoSource ** p_v_src);
ONVIF_API void                                      onvif_free_VideoSources(ONVIF_VideoSource ** p_v_src);
ONVIF_API ONVIF_VideoSource                       * onvif_find_VideoSource(ONVIF_DEVICE * p_dev, const char * token);
ONVIF_API ONVIF_VideoSource                       * onvif_get_cur_VideoSource(ONVIF_DEVICE * p_dev);

ONVIF_API ONVIF_VideoSourceMode                   * onvif_add_VideoSourceMode(ONVIF_VideoSourceMode ** p_v_src_mode);
ONVIF_API void                                      onvif_free_VideoSourceModes(ONVIF_VideoSourceMode ** p_v_src_mode);

ONVIF_API ONVIF_AudioSource                       * onvif_add_AudioSource(ONVIF_AudioSource ** p_a_src);
ONVIF_API void                                      onvif_free_AudioSources(ONVIF_AudioSource ** p_a_src);
ONVIF_API ONVIF_AudioSource                       * onvif_find_AudioSource(ONVIF_DEVICE * p_dev, const char * token);

ONVIF_API ONVIF_VideoSourceConfiguration          * onvif_add_VideoSourceConfiguration(ONVIF_VideoSourceConfiguration ** p_v_src_cfg);
ONVIF_API void                                      onvif_free_VideoSourceConfigurations(ONVIF_VideoSourceConfiguration ** p_v_src_cfg);
ONVIF_API ONVIF_VideoSourceConfiguration          * onvif_find_VideoSourceConfiguration(ONVIF_DEVICE * p_dev, const char * token);

ONVIF_API ONVIF_AudioSourceConfiguration          * onvif_add_AudioSourceConfiguration(ONVIF_AudioSourceConfiguration ** p_a_src_cfg);
ONVIF_API void                                      onvif_free_AudioSourceConfigurations(ONVIF_AudioSourceConfiguration ** p_a_src_cfg);
ONVIF_API ONVIF_AudioSourceConfiguration          * onvif_find_AudioSourceConfiguration(ONVIF_DEVICE * p_dev, const char * token);

ONVIF_API ONVIF_VideoEncoderConfiguration         * onvif_add_VideoEncoderConfiguration(ONVIF_VideoEncoderConfiguration ** p_v_enc);
ONVIF_API void                                      onvif_free_VideoEncoderConfigurations(ONVIF_VideoEncoderConfiguration ** p_v_enc);
ONVIF_API ONVIF_VideoEncoderConfiguration         * onvif_find_VideoEncoderConfiguration(ONVIF_DEVICE * p_dev, const char * token);

ONVIF_API ONVIF_AudioEncoderConfiguration         * onvif_add_AudioEncoderConfiguration(ONVIF_AudioEncoderConfiguration ** p_a_enc);
ONVIF_API void                                      onvif_free_AudioEncoderConfigurations(ONVIF_AudioEncoderConfiguration ** p_a_enc);
ONVIF_API ONVIF_AudioEncoderConfiguration         * onvif_find_AudioEncoderConfiguration(ONVIF_DEVICE * p_dev, const char * token);

ONVIF_API ONVIF_MetadataConfiguration             * onvif_add_MetadataConfiguration(ONVIF_MetadataConfiguration ** p_cfg);
ONVIF_API void                                      onvif_free_MetadataConfigurations(ONVIF_MetadataConfiguration ** p_cfg);
ONVIF_API ONVIF_MetadataConfiguration             * onvif_find_MetadataConfiguration(ONVIF_MetadataConfiguration * p_cfg, const char * token);

ONVIF_API ONVIF_VideoEncoder2Configuration        * onvif_add_VideoEncoder2Configuration(ONVIF_VideoEncoder2Configuration ** p_v_enc_cfg);
ONVIF_API void                                      onvif_free_VideoEncoder2Configurations(ONVIF_VideoEncoder2Configuration ** p_v_enc);
ONVIF_API ONVIF_VideoEncoder2Configuration        * onvif_find_VideoEncoder2Configuration(ONVIF_VideoEncoder2Configuration * p_v_enc, const char * token);

ONVIF_API ONVIF_VideoEncoder2ConfigurationOptions * onvif_add_VideoEncoder2ConfigurationOptions(ONVIF_VideoEncoder2ConfigurationOptions ** p_options);
ONVIF_API void                                      onvif_free_VideoEncoder2ConfigurationOptions(ONVIF_VideoEncoder2ConfigurationOptions ** p_options);
ONVIF_API ONVIF_VideoEncoder2ConfigurationOptions * onvif_find_VideoEncoder2ConfigurationOptions(ONVIF_VideoEncoder2ConfigurationOptions * p_options, const char * encoding);

ONVIF_API ONVIF_AudioEncoder2Configuration        * onvif_add_AudioEncoder2Configuration(ONVIF_AudioEncoder2Configuration ** p_cfg);
ONVIF_API void                                      onvif_free_AudioEncoder2Configurations(ONVIF_AudioEncoder2Configuration ** p_cfg);
ONVIF_API ONVIF_AudioEncoder2Configuration        * onvif_find_AudioEncoder2Configuration(ONVIF_AudioEncoder2Configuration * p_cfg, const char * token);

ONVIF_API ONVIF_AudioEncoder2ConfigurationOptions * onvif_add_AudioEncoder2ConfigurationOptions(ONVIF_AudioEncoder2ConfigurationOptions ** p_options);
ONVIF_API void                                      onvif_free_AudioEncoder2ConfigurationOptions(ONVIF_AudioEncoder2ConfigurationOptions ** p_options);
ONVIF_API ONVIF_AudioEncoder2ConfigurationOptions * onvif_find_AudioEncoder2ConfigurationOptions(ONVIF_AudioEncoder2ConfigurationOptions * p_options, const char * encoding);

ONVIF_API ONVIF_Profile                           * onvif_add_Profile(ONVIF_Profile ** p_profile);
ONVIF_API void                                      onvif_free_Profile(ONVIF_Profile * p_profile);
ONVIF_API void                                      onvif_free_Profiles(ONVIF_Profile ** p_profile);
ONVIF_API ONVIF_Profile                           * onvif_find_Profile(ONVIF_DEVICE * p_dev, const char * token);

ONVIF_API ONVIF_MediaProfile                      * onvif_add_MediaProfile(ONVIF_MediaProfile ** p_profile);
ONVIF_API void                                      onvif_free_MediaProfiles(ONVIF_MediaProfile ** p_profile);
ONVIF_API ONVIF_MediaProfile                      * onvif_find_MediaProfile(ONVIF_MediaProfile * p_profile, const char * token);

ONVIF_API ONVIF_PTZNode                           * onvif_add_PTZNode(ONVIF_PTZNode ** p_ptz_node);
ONVIF_API void                                      onvif_free_PTZNodes(ONVIF_PTZNode ** p_ptz_node);
ONVIF_API ONVIF_PTZNode                           * onvif_find_PTZNode(ONVIF_DEVICE * p_dev, const char * token);

ONVIF_API ONVIF_PTZConfiguration                  * onvif_add_PTZConfiguration(ONVIF_PTZConfiguration ** p_ptz_cfg);
ONVIF_API void                                      onvif_free_PTZConfigurations(ONVIF_PTZConfiguration ** p_ptz_cfg);
ONVIF_API ONVIF_PTZConfiguration                  * onvif_find_PTZConfiguration(ONVIF_DEVICE * p_dev, const char * token);

ONVIF_API ONVIF_PTZPreset                         * onvif_add_PTZPreset(ONVIF_PTZPreset ** p_ptz_preset);
ONVIF_API void                                      onvif_free_PTZPresets(ONVIF_PTZPreset ** p_ptz_preset);

ONVIF_API ONVIF_PTZPresetTourSpot                 * onvif_add_PTZPresetTourSpot(ONVIF_PTZPresetTourSpot ** p_ptz_tourspot);
ONVIF_API void                                      onvif_free_PTZPresetTourSpots(ONVIF_PTZPresetTourSpot ** p_ptz_tourspot);

ONVIF_API ONVIF_PresetTour                        * onvif_add_PresetTour(ONVIF_PresetTour ** p_preset_tour);
ONVIF_API void                                      onvif_free_PresetTours(ONVIF_PresetTour ** p_preset_tour);

ONVIF_API ONVIF_NotificationMessage               * onvif_add_NotificationMessage(ONVIF_NotificationMessage ** p_message);
ONVIF_API void                                      onvif_free_NotificationMessage(ONVIF_NotificationMessage * p_message);
ONVIF_API void                                      onvif_free_NotificationMessages(ONVIF_NotificationMessage ** p_message);
ONVIF_API int                                       onvif_get_NotificationMessages_nums(ONVIF_NotificationMessage * p_message);

ONVIF_API void                                      onvif_device_add_NotificationMessages(ONVIF_DEVICE * p_dev, ONVIF_NotificationMessage * p_notify);
ONVIF_API int                                       onvif_device_free_NotificationMessages(ONVIF_DEVICE * p_dev, int nums);

ONVIF_API ONVIF_SimpleItem                        * onvif_add_SimpleItem(ONVIF_SimpleItem ** p_simpleitem);
ONVIF_API void                                      onvif_free_SimpleItems(ONVIF_SimpleItem ** p_simpleitem);
ONVIF_API const char                              * onvif_format_SimpleItem(ONVIF_SimpleItem * p_item);

ONVIF_API ONVIF_ElementItem                       * onvif_add_ElementItem(ONVIF_ElementItem ** p_elementitem);
ONVIF_API void                                      onvif_free_ElementItems(ONVIF_ElementItem ** p_elementitem);

ONVIF_API ONVIF_SimpleItemDescription             * onvif_add_SimpleItemDescription(ONVIF_SimpleItemDescription ** p_item);
ONVIF_API void                                      onvif_free_SimpleItemDescriptions(ONVIF_SimpleItemDescription ** p_item);

ONVIF_API ONVIF_ConfigDescription_Messages        * onvif_add_ConfigDescription_Messages(ONVIF_ConfigDescription_Messages ** p_item);
ONVIF_API void                                      onvif_free_ConfigDescription_Message(ONVIF_ConfigDescription_Messages * p_item);
ONVIF_API void                                      onvif_free_ConfigDescription_Messages(ONVIF_ConfigDescription_Messages ** p_item);

ONVIF_API ONVIF_User                              * onvif_add_User(ONVIF_User ** p_user);
ONVIF_API void                                      onvif_free_Users(ONVIF_User ** p_user);

ONVIF_API ONVIF_OSDConfiguration                  * onvif_add_OSDConfiguration(ONVIF_OSDConfiguration ** p_osd);
ONVIF_API void                                      onvif_free_OSDConfigurations(ONVIF_OSDConfiguration ** p_osd);

ONVIF_API ONVIF_Config                            * onvif_add_Config(ONVIF_Config ** p_config);
ONVIF_API void                                      onvif_free_Config(ONVIF_Config * p_config);
ONVIF_API void                                      onvif_free_Configs(ONVIF_Config ** p_config);
ONVIF_API ONVIF_Config                            * onvif_find_Config(ONVIF_Config ** p_config, const char * name);
ONVIF_API void                                      onvif_remove_Config(ONVIF_Config ** p_config, ONVIF_Config * p_remove);
ONVIF_API ONVIF_Config                            * onvif_get_prev_Config(ONVIF_Config ** p_config, ONVIF_Config * p_found);

ONVIF_API ONVIF_VideoAnalyticsConfiguration       * onvif_add_VideoAnalyticsConfiguration(ONVIF_VideoAnalyticsConfiguration ** p_config);
ONVIF_API void                                      onvif_free_VideoAnalyticsConfiguration(ONVIF_VideoAnalyticsConfiguration * p_config);
ONVIF_API void                                      onvif_free_VideoAnalyticsConfigurations(ONVIF_VideoAnalyticsConfiguration ** p_config);

ONVIF_API ONVIF_ConfigDescription                 * onvif_add_ConfigDescription(ONVIF_ConfigDescription ** p_cfg_desc);
ONVIF_API void                                      onvif_free_ConfigDescription(ONVIF_ConfigDescription * p_cfg_desc);
ONVIF_API void                                      onvif_free_ConfigDescriptions(ONVIF_ConfigDescription ** p_cfg_desc);

ONVIF_API ONVIF_Recording                         * onvif_add_Recording(ONVIF_Recording ** p_recording);
ONVIF_API ONVIF_Recording                         * onvif_find_Recording(ONVIF_Recording ** p_recording, const char * token);
ONVIF_API void                                      onvif_free_Recordings(ONVIF_Recording ** p_recording);

ONVIF_API ONVIF_Track                             * onvif_add_Track(ONVIF_Track ** p_tracks);	
ONVIF_API void                                      onvif_free_Tracks(ONVIF_Track ** p_tracks);
ONVIF_API ONVIF_Track                             * onvif_find_Track(ONVIF_Track	* p_tracks, const char * token);

ONVIF_API ONVIF_RecordingJob                      * onvif_add_RecordingJob(ONVIF_RecordingJob ** p_recordingjob);
ONVIF_API ONVIF_RecordingJob                      * onvif_find_RecordingJob(ONVIF_RecordingJob * p_recordingjob, const char * token);
ONVIF_API void                                      onvif_free_RecordingJobs(ONVIF_RecordingJob ** p_recordingjob);

ONVIF_API ONVIF_TrackAttributes                   * onvif_add_TrackAttributes(ONVIF_TrackAttributes ** p_track);
ONVIF_API void                                      onvif_free_TrackAttributes(ONVIF_TrackAttributes ** p_track);

ONVIF_API ONVIF_RecordingInformation              * onvif_add_RecordingInformation(ONVIF_RecordingInformation ** p_recording);
ONVIF_API void                                      onvif_free_RecordingInformations(ONVIF_RecordingInformation ** p_recording);

ONVIF_API ONVIF_AccessPointInfo                   * onvif_add_AccessPointInfo(ONVIF_AccessPointInfo ** p_info);
ONVIF_API ONVIF_AccessPointInfo                   * onvif_find_AccessPointInfo(ONVIF_AccessPointInfo * p_info, const char * token);
ONVIF_API void                                      onvif_free_AccessPointInfos(ONVIF_AccessPointInfo ** p_info);

ONVIF_API ONVIF_DoorInfo                          * onvif_add_DoorInfo(ONVIF_DoorInfo ** p_info);
ONVIF_API ONVIF_DoorInfo                          * onvif_find_DoorInfo(ONVIF_DoorInfo * p_info, const char * token);
ONVIF_API void                                      onvif_free_DoorInfos(ONVIF_DoorInfo ** p_info);

ONVIF_API ONVIF_AreaInfo                          * onvif_add_AreaInfo(ONVIF_AreaInfo ** p_info);
ONVIF_API ONVIF_AreaInfo                          * onvif_find_AreaInfo(ONVIF_AreaInfo * p_info, const char * token);
ONVIF_API void                                      onvif_free_AreaInfos(ONVIF_AreaInfo ** p_info);

#ifdef __cplusplus
}
#endif

#endif


