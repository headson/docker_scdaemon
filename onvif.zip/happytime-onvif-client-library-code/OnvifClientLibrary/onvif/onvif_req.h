/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2010-2016, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#ifndef ONVIF_REQ_H
#define ONVIF_REQ_H


/*************************************************************************
 *
 * onvif request structure
 *
**************************************************************************/ 

typedef struct
{
	onvif_CapabilityCategory	Category; 				// optional, List of categories to retrieve capability information on
} GetCapabilities_REQ;

typedef struct
{
    BOOL 	IncludeCapability; 							// required, Indicates if the service capabilities (untyped) should be included in the response.
} GetServices_REQ;

typedef struct
{
	int		dummy;
} GetDeviceInformation_REQ;

typedef struct
{
	int		dummy;
} GetUsers_REQ;

typedef struct
{
	onvif_User	User;								 	// required
} CreateUsers_REQ;

typedef struct
{
	char	Username[ONVIF_NAME_LEN];					// required
} DeleteUsers_REQ;

typedef struct
{
	onvif_User	User;								 	// required
} SetUser_REQ;

typedef struct
{
    int		dummy;
} GetRemoteUser_REQ;

typedef struct
{
    uint32	RemoteUserFlag	: 1;					    // Indicates whether the field RemoteUser is valid
	uint32 	Reserved		: 31;
	
    onvif_RemoteUser RemoteUser;                       // optional     
} SetRemoteUser_REQ;

typedef struct
{
	int		dummy;
} GetNetworkInterfaces_REQ;

typedef struct
{
    onvif_NetworkInterface	NetworkInterface;
} SetNetworkInterfaces_REQ;

typedef struct
{
	int		dummy;
} GetNTP_REQ;

typedef struct 
{
	onvif_NTPInformation	NTPInformation;
} SetNTP_REQ;

typedef struct
{
	int		dummy;
} GetHostname_REQ;

typedef struct
{
	char 	Name[ONVIF_NAME_LEN];						// required 
} SetHostname_REQ;

typedef struct
{
    BOOL    FromDHCP;									//  required, True if the hostname shall be obtained via DHCP
} SetHostnameFromDHCP_REQ;

typedef struct
{
	int		dummy;
} GetDNS_REQ;

typedef struct 
{
	onvif_DNSInformation DNSInformation;
} SetDNS_REQ;

typedef struct
{
	int		dummy;
} GetDynamicDNS_REQ;

typedef struct
{
    onvif_DynamicDNSInformation	DynamicDNSInformation;
} SetDynamicDNS_REQ;

typedef struct
{
	int		dummy;
} GetNetworkProtocols_REQ;

typedef struct
{
	onvif_NetworkProtocol	NetworkProtocol;
} SetNetworkProtocols_REQ;

typedef struct
{
	int		dummy;
} GetDiscoveryMode_REQ;

typedef struct
{
	onvif_DiscoveryMode	DiscoveryMode;					// required, Indicator of discovery mode: Discoverable, NonDiscoverable
} SetDiscoveryMode_REQ;

typedef struct
{
	int		dummy;
} GetNetworkDefaultGateway_REQ;

typedef struct
{
	char 	IPv4Address[MAX_GATEWAY][32];				// optional, Sets IPv4 gateway address used as default setting
} SetNetworkDefaultGateway_REQ;

typedef struct
{
    int		dummy;
} GetZeroConfiguration_REQ;

typedef struct
{
    char    InterfaceToken[ONVIF_TOKEN_LEN];            // requied, Unique identifier referencing the physical interface
    BOOL    Enabled;                                    // requied, Specifies if the zero-configuration should be enabled or not
} SetZeroConfiguration_REQ;

typedef struct
{
    int		dummy;
} GetEndpointReference_REQ;

typedef struct
{
	int		dummy;
} GetSystemDateAndTime_REQ;

typedef struct
{
	uint32	UTCDateTimeFlag	: 1;						// Indicates whether the field UTCDateTime is valid
	uint32 	Reserved		: 31;
	
    onvif_SystemDateTime	SystemDateTime;				// required,     
    onvif_DateTime 			UTCDateTime;				// optional, Date and time in UTC. If time is obtained via NTP, UTCDateTime has no meaning
} SetSystemDateAndTime_REQ;

typedef struct
{
	int		dummy;
} SystemReboot_REQ;

typedef struct
{
	onvif_FactoryDefaultType	FactoryDefault;			// required
} SetSystemFactoryDefault_REQ;

typedef struct
{
    onvif_SystemLogType	LogType;						// required, Specifies the type of system log to get
} GetSystemLog_REQ;

typedef struct
{
	int		dummy;
} GetScopes_REQ;

typedef struct
{
	int     sizeScopes;
	char    Scopes[MAX_SCOPE_NUMS][100];
} SetScopes_REQ;

typedef struct
{
	int     sizeScopeItem;	                        
	char    ScopeItem[MAX_SCOPE_NUMS][100];	            // required
} AddScopes_REQ;

typedef struct
{
	int     sizeScopeItem;	                        
	char    ScopeItem[MAX_SCOPE_NUMS][100];	            // required
} RemoveScopes_REQ;

typedef struct
{
    int		dummy;    
} StartFirmwareUpgrade_REQ;

typedef struct
{
    int		dummy;
} GetSystemUris_REQ;

typedef struct
{
    int		dummy;
} StartSystemRestore_REQ;

typedef struct
{
	int		dummy;
} GetVideoSources_REQ;

typedef struct
{
	int		dummy;
} GetAudioSources_REQ;

typedef struct
{
	uint32	TokenFlag : 1;								// Indicates whether the field Token is valid
	uint32  Reserved  : 31;
	
    char    Name[ONVIF_NAME_LEN];						// required, friendly name of the profile to be created
    char    Token[ONVIF_TOKEN_LEN];						// optional, Optional token, specifying the unique identifier of the new profile
} CreateProfile_REQ;

typedef struct
{
    char    ProfileToken[ONVIF_TOKEN_LEN];				// required, this command requests a specific profile
} GetProfile_REQ;

typedef struct
{
	int		dummy;
} GetProfiles_REQ;

typedef struct
{
    char    ProfileToken[ONVIF_TOKEN_LEN];				// required, Reference to the profile where the configuration should be added
    char    ConfigurationToken[ONVIF_TOKEN_LEN];		// required, Contains a reference to the VideoEncoderConfiguration to add
} AddVideoEncoderConfiguration_REQ;

typedef struct
{
    char    ProfileToken[ONVIF_TOKEN_LEN];				// required, Reference to the profile where the configuration should be added
    char    ConfigurationToken[ONVIF_TOKEN_LEN];		// required, Contains a reference to the VideoEncoderConfiguration to add
} AddVideoSourceConfiguration_REQ;

typedef struct
{
    char    ProfileToken[ONVIF_TOKEN_LEN];				// required, Reference to the profile where the configuration should be added
    char    ConfigurationToken[ONVIF_TOKEN_LEN];		// required, Contains a reference to the VideoEncoderConfiguration to add
} AddAudioEncoderConfiguration_REQ;

typedef struct
{
    char    ProfileToken[ONVIF_TOKEN_LEN];				// required, Reference to the profile where the configuration should be added
    char    ConfigurationToken[ONVIF_TOKEN_LEN];		// required, Contains a reference to the VideoEncoderConfiguration to add
} AddAudioSourceConfiguration_REQ;

typedef struct
{
	char 	VideoSourceToken[ONVIF_TOKEN_LEN];			// required, Contains a video source reference for which a video source mode is requested
} GetVideoSourceModes_REQ;

typedef struct 
{
	char	VideoSourceToken[ONVIF_TOKEN_LEN];			// required, Contains a video source reference for which a video source mode is requested
	char	VideoSourceModeToken[ONVIF_TOKEN_LEN];		// required, Indicate video source mode
} SetVideoSourceMode_REQ;

typedef struct
{
    char    ProfileToken[ONVIF_TOKEN_LEN];				// required, Reference to the profile where the configuration should be added
    char    ConfigurationToken[ONVIF_TOKEN_LEN];		// required, Contains a reference to the VideoEncoderConfiguration to add
} AddPTZConfiguration_REQ;

typedef struct
{
    char    ProfileToken[ONVIF_TOKEN_LEN];				// required, Contains a reference to the media profile from which the VideoEncoderConfiguration shall be removed
} RemoveVideoEncoderConfiguration_REQ;

typedef struct
{
    char    ProfileToken[ONVIF_TOKEN_LEN];				// required, Contains a reference to the media profile from which the VideoSourceConfiguration shall be removed
} RemoveVideoSourceConfiguration_REQ;

typedef struct
{
    char    ProfileToken[ONVIF_TOKEN_LEN];				// required, Contains a reference to the media profile from which the AudioEncoderConfiguration shall be removed
} RemoveAudioEncoderConfiguration_REQ;

typedef struct
{
    char    ProfileToken[ONVIF_TOKEN_LEN];				// required, Contains a reference to the media profile from which the AudioSourceConfiguration shall be removed
} RemoveAudioSourceConfiguration_REQ;

typedef struct
{
    char    ProfileToken[ONVIF_TOKEN_LEN];				// required, Contains a reference to the media profile from which the PTZConfiguration shall be removed
} RemovePTZConfiguration_REQ;

typedef struct
{
    char    ProfileToken[ONVIF_TOKEN_LEN];				// required, This element contains a  reference to the profile that should be deleted
} DeleteProfile_REQ;

typedef struct
{
	int		dummy;
} GetVideoSourceConfigurations_REQ;

typedef struct
{
    int		dummy;
} GetVideoEncoderConfigurations_REQ;

typedef struct
{
	int		dummy;
} GetAudioSourceConfigurations_REQ;

typedef struct
{
	int		dummy;
} GetAudioEncoderConfigurations_REQ;

typedef struct
{
    char    ConfigurationToken[ONVIF_TOKEN_LEN];		// required, Token of the requested video source configuration
} GetVideoSourceConfiguration_REQ;

typedef struct
{
    char    ConfigurationToken[ONVIF_TOKEN_LEN];		// required, Token of the requested video encoder configuration
} GetVideoEncoderConfiguration_REQ;

typedef struct
{
    char    ConfigurationToken[ONVIF_TOKEN_LEN];		// required, Token of the requested audio source configuration
} GetAudioSourceConfiguration_REQ;

typedef struct
{
    char    ConfigurationToken[ONVIF_TOKEN_LEN];		// required, Token of the requested audio encoder configuration
} GetAudioEncoderConfiguration_REQ;

typedef struct
{
	onvif_VideoSourceConfiguration	VideoSourceConfiguration;

	BOOL	ForcePersistence;							// required, The ForcePersistence element is obsolete and should always be assumed to be true
} SetVideoSourceConfiguration_REQ;

typedef struct
{
	onvif_VideoEncoderConfiguration	VideoEncoderConfiguration;
	
	BOOL	ForcePersistence;							// required, The ForcePersistence element is obsolete and should always be assumed to be true
} SetVideoEncoderConfiguration_REQ;

typedef struct
{
	onvif_AudioSourceConfiguration	AudioSourceConfiguration;

	BOOL	ForcePersistence;							// required, The ForcePersistence element is obsolete and should always be assumed to be true
} SetAudioSourceConfiguration_REQ;

typedef struct
{
	onvif_AudioEncoderConfiguration	AudioEncoderConfiguration;

	BOOL	ForcePersistence;							// required, The ForcePersistence element is obsolete and should always be assumed to be true
} SetAudioEncoderConfiguration_REQ;

typedef struct
{
	uint32	ProfileTokenFlag 		: 1;				// Indicates whether the field ProfileToken is valid
	uint32	ConfigurationTokenFlag 	: 1;				// Indicates whether the field ConfigurationToken is valid
	uint32  Reserved  				: 30;
	
    char    ProfileToken[ONVIF_TOKEN_LEN];				// optional, Optional ProfileToken that specifies an existing media profile that the options shall be compatible with
    char    ConfigurationToken[ONVIF_TOKEN_LEN];		// optional, Optional video source configurationToken that specifies an existing configuration that the options are intended for
} GetVideoSourceConfigurationOptions_REQ;

typedef struct
{
	uint32	ProfileTokenFlag 		: 1;				// Indicates whether the field ProfileToken is valid
	uint32	ConfigurationTokenFlag 	: 1;				// Indicates whether the field ConfigurationToken is valid
	uint32  Reserved  				: 30;
	
    char    ProfileToken[ONVIF_TOKEN_LEN];				// optional, Optional ProfileToken that specifies an existing media profile that the options shall be compatible with
    char    ConfigurationToken[ONVIF_TOKEN_LEN];		// optional, Optional video encoder configuration token that specifies an existing configuration that the options are intended for	
} GetVideoEncoderConfigurationOptions_REQ;

typedef struct
{
	uint32	ProfileTokenFlag 		: 1;				// Indicates whether the field ProfileToken is valid
	uint32	ConfigurationTokenFlag 	: 1;				// Indicates whether the field ConfigurationToken is valid
	uint32  Reserved  				: 30;
	
    char    ProfileToken[ONVIF_TOKEN_LEN];				// optional, Optional ProfileToken that specifies an existing media profile that the options shall be compatible with
    char    ConfigurationToken[ONVIF_TOKEN_LEN];		// optional, Optional audio source configuration token that specifies an existing configuration that the options are intended for
} GetAudioSourceConfigurationOptions_REQ;

typedef struct
{
	uint32	ProfileTokenFlag 		: 1;				// Indicates whether the field ProfileToken is valid
	uint32	ConfigurationTokenFlag 	: 1;				// Indicates whether the field ConfigurationToken is valid
	uint32  Reserved  				: 30;
	
    char    ProfileToken[ONVIF_TOKEN_LEN];				// optional, Optional ProfileToken that specifies an existing media profile that the options shall be compatible with
    char    ConfigurationToken[ONVIF_TOKEN_LEN];		// optional, Optional audio encoder configuration token that specifies an existing configuration that the options are intended for
} GetAudioEncoderConfigurationOptions_REQ;

typedef struct
{
	char 	ProfileToken[ONVIF_TOKEN_LEN];				// required, The ProfileToken element indicates the media profile to use and will define the configuration of the content of the stream

	onvif_StreamSetup	StreamSetup;					// required, Stream Setup that should be used with the uri
} GetStreamUri_REQ;

typedef struct
{
    char    ProfileToken[ONVIF_TOKEN_LEN];				// required, Contains a Profile reference for which a Synchronization Point is requested
} SetSynchronizationPoint_REQ;

typedef struct
{
    char    ProfileToken[ONVIF_TOKEN_LEN];				// required, The ProfileToken element indicates the media profile to use and will define the source and dimensions of the snapshot
} GetSnapshotUri_REQ;

typedef struct
{
	int		dummy;
} GetNodes_REQ;

typedef struct
{
	char	NodeToken[ONVIF_TOKEN_LEN];					// required, Token of the requested PTZNode
} GetNode_REQ;

typedef struct
{
	char 	ProfileToken[ONVIF_TOKEN_LEN];				// required, A reference to the MediaProfile where the operation should take place
} GetPresets_REQ;

typedef struct
{
	uint32	PresetTokenFlag	: 1;						// Indicates whether the field PresetToken is valid
	uint32	PresetNameFlag 	: 1;						// Indicates whether the field PresetName is valid
	uint32  Reserved  		: 30;
	
    char	ProfileToken[ONVIF_TOKEN_LEN];				// required, A reference to the MediaProfile where the operation should take place
    char	PresetToken[ONVIF_TOKEN_LEN];				// optional, A requested preset token
    char    PresetName[ONVIF_NAME_LEN];					// optional, A requested preset name
} SetPreset_REQ;

typedef struct
{
	char	ProfileToken[ONVIF_TOKEN_LEN];				// required, A reference to the MediaProfile where the operation should take place
    char	PresetToken[ONVIF_TOKEN_LEN];				// required, A requested preset token
} RemovePreset_REQ;

typedef struct
{
	uint32	SpeedFlag 		: 1;						// Indicates whether the field Speed is valid
	uint32  Reserved	 	: 31;
	
	char	ProfileToken[ONVIF_TOKEN_LEN];				// required, A reference to the MediaProfile where the operation should take place
	char	PresetToken[ONVIF_TOKEN_LEN];				// required, A requested preset token

	onvif_PTZSpeed	Speed;								// optional, A requested speed.The speed parameter can only be specified when Speed Spaces are available for the PTZ Node
} GotoPreset_REQ;

typedef struct
{
    uint32	SpeedFlag 		: 1;						// Indicates whether the field Speed is valid
	uint32  Reserved	 	: 31;
	
    char	ProfileToken[ONVIF_TOKEN_LEN];				// required, A reference to the MediaProfile where the operation should take place

    onvif_PTZSpeed	Speed;								// optional, A requested speed.The speed parameter can only be specified when Speed Spaces are available for the PTZ Node
} GotoHomePosition_REQ;

typedef struct
{
    char	ProfileToken[ONVIF_TOKEN_LEN];				// required, A reference to the MediaProfile where the home position should be set
} SetHomePosition_REQ;

typedef struct
{
	char	ProfileToken[ONVIF_TOKEN_LEN];				// required, A reference to the MediaProfile where the PTZStatus should be requested
} GetStatus_REQ;

typedef struct
{
	uint32	TimeoutFlag 	: 1;						// Indicates whether the field Timeout is valid
	uint32  Reserved	 	: 31;
	
	char	ProfileToken[ONVIF_TOKEN_LEN];				// required, A reference to the MediaProfile
	
	onvif_PTZSpeed	Velocity;							// required, A Velocity vector specifying the velocity of pan, tilt and zoom
	
	int		Timeout;									// optional, An optional Timeout parameter, unit is second
} ContinuousMove_REQ;

typedef struct
{
	uint32	SpeedFlag 		: 1;						// Indicates whether the field Speed is valid
	uint32  Reserved	 	: 31;
	
    char	ProfileToken[ONVIF_TOKEN_LEN];				// required, A reference to the MediaProfile
    
    onvif_PTZVector	Translation;						// required, A positional Translation relative to the current position
	onvif_PTZSpeed	Speed;								// optional, An optional Speed parameter
} RelativeMove_REQ;

typedef struct
{
	uint32	SpeedFlag 		: 1;						// Indicates whether the field Speed is valid
	uint32  Reserved	 	: 31;
	
    char	ProfileToken[ONVIF_TOKEN_LEN];				// required, A reference to the MediaProfile

	onvif_PTZVector	Position;							// required, A Position vector specifying the absolute target position
	onvif_PTZSpeed	Speed;								// optional, An optional Speed 
} AbsoluteMove_REQ;

typedef struct
{
	uint32	PanTiltFlag 	: 1;						// Indicates whether the field PanTilt is valid
	uint32	ZoomFlag 		: 1;						// Indicates whether the field Zoom is valid
	uint32  Reserved	 	: 30;
	
	char	ProfileToken[ONVIF_TOKEN_LEN];				// required, A reference to the MediaProfile that indicate what should be stopped

	BOOL	PanTilt;									// optional, Set true when we want to stop ongoing pan and tilt movements.If PanTilt arguments are not present, this command stops these movements
	BOOL	Zoom;										// optional, Set true when we want to stop ongoing zoom movement.If Zoom arguments are not present, this command stops ongoing zoom movement
} PTZStop_REQ;

typedef struct
{
	int		dummy;
} GetConfigurations_REQ;

typedef struct
{
	char	ConfigurationToken[ONVIF_TOKEN_LEN];		// required, Token of the requested PTZConfiguration
} GetConfiguration_REQ;

typedef struct
{
	onvif_PTZConfiguration  PTZConfiguration;	        // required
	
	BOOL    ForcePersistence;	                        // required, Flag that makes configuration persistent. Example: User wants the configuration to exist after reboot
} SetConfiguration_REQ;

typedef struct
{
	char	ConfigurationToken[ONVIF_TOKEN_LEN];		// required, Token of an existing configuration that the options are intended for
} GetConfigurationOptions_REQ;

typedef struct
{
    char    ProfileToken[ONVIF_TOKEN_LEN];	            // required
} GetPresetTours_REQ;

typedef struct
{
    char    ProfileToken[ONVIF_TOKEN_LEN];	            // required
	char    PresetTourToken[ONVIF_TOKEN_LEN];	        // required
} GetPresetTour_REQ;

typedef struct
{
    char    ProfileToken[ONVIF_TOKEN_LEN];	            // required
	char    PresetTourToken[ONVIF_TOKEN_LEN];	        // optional
} GetPresetTourOptions_REQ;

typedef struct
{
    char    ProfileToken[ONVIF_TOKEN_LEN];	            // required
} CreatePresetTour_REQ;

typedef struct
{
    char    ProfileToken[ONVIF_TOKEN_LEN];	            // required
    
	onvif_PresetTour    PresetTour;	                    // required
} ModifyPresetTour_REQ;

typedef struct
{
    char    ProfileToken[ONVIF_TOKEN_LEN];	            // required
	char    PresetTourToken[ONVIF_TOKEN_LEN];	        // required
	
	onvif_PTZPresetTourOperation Operation;	            // required
} OperatePresetTour_REQ;

typedef struct
{
    char    ProfileToken[ONVIF_TOKEN_LEN];	            // required
	char    PresetTourToken[ONVIF_TOKEN_LEN];	        // required
} RemovePresetTour_REQ;


typedef struct
{
	int		dummy;
} GetEventProperties_REQ;

typedef struct
{
	int		TerminationTime;
} Renew_REQ;

typedef struct
{
	int		dummy;
} Unsubscribe_REQ;

typedef struct
{
    uint32  FiltersFlag : 1;
    uint32 	Reserved    : 31;
    
	char	ConsumerReference[256];
	int		InitialTerminationTime;         			// InitialTerminationTime, unit is second

	onvif_EventFilter   Filter;
} Subscribe_REQ;

typedef struct
{
    uint32  FiltersFlag : 1;
    uint32 	Reserved    : 31;
    
	int		InitialTerminationTime;         			// InitialTerminationTime, unit is second

	onvif_EventFilter   Filter;
} CreatePullPointSubscription_REQ;

typedef struct
{
    int     Timeout;	                                // required, Maximum time to block until this method returns, unit is second
	int     MessageLimit;	                            // required, Upper limit for the number of messages to return at once. A server implementation may decide to return less messages
} PullMessages_REQ;

typedef struct
{
	char	PostUrl[200];
	
    ONVIF_NotificationMessage * notify;
} Notify_REQ;

typedef struct
{
	char	VideoSourceToken[ONVIF_TOKEN_LEN];			// required
} GetImagingSettings_REQ;

typedef struct
{
	uint32  ForcePersistenceFlag : 1;					// Indicates whether the field ForcePersistence is valid
	uint32	Reserved			 : 31;
	
	char	VideoSourceToken[ONVIF_TOKEN_LEN];			// required
	BOOL	ForcePersistence;							// optional

	onvif_ImagingSettings	ImagingSettings;			// required
} SetImagingSettings_REQ;

typedef struct
{
	char	VideoSourceToken[ONVIF_TOKEN_LEN];			// required, Reference token to the VideoSource for which the imaging parameter options are requested
} GetOptions_REQ;

typedef struct
{
    char    VideoSourceToken[ONVIF_TOKEN_LEN];	        // required, Reference to the VideoSource for the requested move (focus) operation
    
	onvif_FocusMove Focus;								// required, Content of the requested move (focus) operation
} img_Move_REQ;

typedef struct
{
    char    VideoSourceToken[ONVIF_TOKEN_LEN];	        // required, Reference to the VideoSource
} img_Stop_REQ;

typedef struct
{
    char    VideoSourceToken[ONVIF_TOKEN_LEN];	        // required, Reference to the VideoSource
} img_GetStatus_REQ;

typedef struct
{
    char    VideoSourceToken[ONVIF_TOKEN_LEN];	        // required, Reference to the VideoSource
} img_GetMoveOptions_REQ;

// recording
typedef struct
{
	onvif_RecordingConfiguration RecordingConfiguration;// required, Initial configuration for the recording
} CreateRecording_REQ;

typedef struct
{
    char    RecordingToken[ONVIF_TOKEN_LEN];	        // required, 
} DeleteRecording_REQ;

typedef struct
{
    int		dummy;
} GetRecordings_REQ;

typedef struct
{
    char	RecordingToken[ONVIF_TOKEN_LEN];		    // required, Token of the recording that shall be changed
	
	onvif_RecordingConfiguration RecordingConfiguration;// required, The new configuration
} SetRecordingConfiguration_REQ;

typedef struct
{
    char    RecordingToken[ONVIF_TOKEN_LEN];	        // required, 
} GetRecordingConfiguration_REQ;

typedef struct
{
    char    RecordingToken[ONVIF_TOKEN_LEN];	        // required, 
} GetRecordingOptions_REQ;

typedef struct
{
    char	RecordingToken[ONVIF_TOKEN_LEN];		    // required, Identifies the recording to which a track shall be added
	
	onvif_TrackConfiguration TrackConfiguration;	    // required, The configuration of the new track
} CreateTrack_REQ;

typedef struct
{
    char 	RecordingToken[ONVIF_TOKEN_LEN];		    // required, Token of the recording the track belongs to
	char 	TrackToken[ONVIF_TOKEN_LEN];			    // required, Token of the track to be deleted
} DeleteTrack_REQ;

typedef struct
{
    char 	RecordingToken[ONVIF_TOKEN_LEN];		    // required, Token of the recording the track belongs to
	char 	TrackToken[ONVIF_TOKEN_LEN];			    // required, Token of the track
} GetTrackConfiguration_REQ;

typedef struct
{
    char 	RecordingToken[ONVIF_TOKEN_LEN];		    // required, Token of the recording the track belongs to
	char 	TrackToken[ONVIF_TOKEN_LEN];			    // required, Token of the track to be modified
	
	onvif_TrackConfiguration	TrackConfiguration;	    // required, New configuration for the track
} SetTrackConfiguration_REQ;

typedef struct
{
	onvif_RecordingJobConfiguration	JobConfiguration;   // required, The initial configuration of the new recording job
} CreateRecordingJob_REQ;

typedef struct
{
    char    JobToken[ONVIF_TOKEN_LEN];	                // required
} DeleteRecordingJob_REQ;

typedef struct
{
    int		dummy;
} GetRecordingJobs_REQ;

typedef struct
{
    char	JobToken[ONVIF_TOKEN_LEN];				    // required, Token of the job to be modified
	
	onvif_RecordingJobConfiguration	JobConfiguration;   // required, New configuration of the recording job
} SetRecordingJobConfiguration_REQ;

typedef struct
{
    char    JobToken[ONVIF_TOKEN_LEN];	                // required
} GetRecordingJobConfiguration_REQ;

typedef struct
{
    char 	JobToken[ONVIF_TOKEN_LEN];			        // required, Token of the recording job
	char 	Mode[16];							        // required, The new mode for the recording job, The only valid values for Mode shall be "Idle" or "Active"
} SetRecordingJobMode_REQ;

typedef struct
{
    char    JobToken[ONVIF_TOKEN_LEN];	                // required
} GetRecordingJobState_REQ;

typedef struct
{
	onvif_StreamSetup	StreamSetup;
	
    char 	RecordingToken[ONVIF_TOKEN_LEN]; 			// required. The identifier of the recording to be streamed
} GetReplayUri_REQ;

typedef struct
{
	int		dummy;
} GetRecordingSummary_REQ;

typedef struct
{
	char 	RecordingToken[ONVIF_TOKEN_LEN];			// Required
} GetRecordingInformation_REQ;

typedef struct
{
	char 	RecordingTokens[10][ONVIF_TOKEN_LEN]; 		// optional
	time_t	Time;										// required
} GetMediaAttributes_REQ;

typedef struct
{
	uint32  MaxMatchesFlag 	: 1;						// Indicates whether the field MaxMatches is valid
	uint32	Reserved		: 31;
	
	char	IncludedSources[10][ONVIF_TOKEN_LEN];		// optional,  A list of sources that are included in the scope. If this list is included, only data from one of these sources shall be searched
	char	IncludedRecordings[10][ONVIF_TOKEN_LEN];	// optional,  A list of recordings that are included in the scope. If this list is included, only data from one of these recordings shall be searched
	char	RecordingInformationFilter[256];			// optional,  An xpath expression used to specify what recordings to search. Only those recordings with an RecordingInformation structure that matches the filter shall be searched
	int		MaxMatches;									// optional, The search will be completed after this many matches. If not specified, the search will continue until reaching the endpoint or until the session expires
	int		KeepAliveTime;								// required, The time the search session will be kept alive after responding to this and subsequent requests. A device shall support at least values up to ten seconds
} FindRecordings_REQ;

typedef struct
{	
	uint32  MinResultsFlag 	: 1;						// Indicates whether the field MinResults is valid
	uint32  MaxResultsFlag 	: 1;						// Indicates whether the field MaxResults is valid
	uint32  WaitTimeFlag 	: 1;						// Indicates whether the field WaitTime is valid
	uint32	Reserved		: 29;
	
	char	SearchToken[ONVIF_TOKEN_LEN];				// required, The search session to get results from
	int		MinResults;									// optional, The minimum number of results to return in one response
	int		MaxResults;									// optional, The maximum number of results to return in one response
	int		WaitTime;									// optional, The maximum time before responding to the request, even if the MinResults parameter is not fulfilled
} GetRecordingSearchResults_REQ;

typedef struct
{
	uint32  EndPointFlag 		: 1;					// Indicates whether the field EndPoint is valid
	uint32  MaxMatchesFlag 		: 1;					// Indicates whether the field MaxMatches is valid
	uint32	Reserved			: 30;
	
	time_t	StartPoint;									// required, The point of time where the search will start
	time_t	EndPoint;									// optional, The point of time where the search will stop. This can be a time before the StartPoint, in which case the search is performed backwards in time
	char	IncludedSources[10][ONVIF_TOKEN_LEN];		// optional,  A list of sources that are included in the scope. If this list is included, only data from one of these sources shall be searched
	char	IncludedRecordings[10][ONVIF_TOKEN_LEN];	// optional,  A list of recordings that are included in the scope. If this list is included, only data from one of these recordings shall be searched
	char	RecordingInformationFilter[256];			// optional,  An xpath expression used to specify what recordings to search. Only those recordings with an RecordingInformation structure that matches the filter shall be searched
	BOOL	IncludeStartState;							// required, Setting IncludeStartState to true means that the server should return virtual events representing the start state for any recording included in the scope. Start state events are limited to the topics defined in the SearchFilter that have the IsProperty flag set to true
	int		MaxMatches;									// optional, The search will be completed after this many matches. If not specified, the search will continue until reaching the endpoint or until the session expires
	int		KeepAliveTime;								// required, The time the search session will be kept alive after responding to this and subsequent requests. A device shall support at least values up to ten seconds
} FindEvents_REQ;

typedef struct
{
	uint32  MinResultsFlag 	: 1;						// Indicates whether the field MinResults is valid
	uint32  MaxResultsFlag 	: 1;						// Indicates whether the field MaxResults is valid
	uint32  WaitTimeFlag 	: 1;						// Indicates whether the field WaitTime is valid
	uint32	Reserved		: 29;
	
	char	SearchToken[ONVIF_TOKEN_LEN];				// required, The search session to get results from
	int		MinResults;									// optional, The minimum number of results to return in one response
	int		MaxResults;									// optional, The maximum number of results to return in one response
	int		WaitTime;									// optional, The maximum time before responding to the request, even if the MinResults parameter is not fulfilled
} GetEventSearchResults_REQ;

typedef struct
{
	char	SearchToken[ONVIF_TOKEN_LEN];				// required, The search session to get the state from
} GetSearchState_REQ;

typedef struct
{
	char	SearchToken[ONVIF_TOKEN_LEN];				// required, The search session to end
} EndSearch_REQ;

typedef struct
{
	uint32	ConfigurationTokenFlag	: 1;				// Indicates whether the field ConfigurationToken is valid	
	uint32  Reserved				: 31;				
	
	char 	ConfigurationToken[ONVIF_TOKEN_LEN];		// optional, Token of the Video Source Configuration, which has OSDs associated with are requested. If token not exist, request all available OSDs
} GetOSDs_REQ;

typedef struct
{
	char 	OSDToken[ONVIF_TOKEN_LEN];					// required, The GetOSD command fetches the OSD configuration if the OSD token is known
} GetOSD_REQ;

typedef struct
{
	onvif_OSDConfiguration	OSD;						// required, Contains the modified OSD configuration
} SetOSD_REQ;

typedef struct
{
	char 	ConfigurationToken[ONVIF_TOKEN_LEN];		// required, Video Source Configuration Token that specifies an existing video source configuration that the options shall be compatible with
} GetOSDOptions_REQ;

typedef struct
{
	onvif_OSDConfiguration	OSD;						// required, Contain the initial OSD configuration for create
} CreateOSD_REQ;

typedef struct
{
	char	OSDToken[ONVIF_TOKEN_LEN];					// required, This element contains a reference to the OSD configuration that should be deleted
} DeleteOSD_REQ;


typedef struct
{
    int		dummy;
} GetVideoAnalyticsConfigurations_REQ;

typedef struct
{
    char 	ProfileToken[ONVIF_TOKEN_LEN];				// required, Reference to the profile where the configuration should be added
	char 	ConfigurationToken[ONVIF_TOKEN_LEN];		// required, Contains a reference to the VideoAnalyticsConfiguration to add
} AddVideoAnalyticsConfiguration_REQ;

typedef struct
{
    char 	ConfigurationToken[ONVIF_TOKEN_LEN];		// required, The requested video analytics configuration
} GetVideoAnalyticsConfiguration_REQ;

typedef struct
{
    onvif_VideoAnalyticsConfiguration	Configuration;	// required, Contains the modified video analytics configuration. The configuration shall exist in the device

	BOOL 	ForcePersistence;							// required, The ForcePersistence element is obsolete and should always be assumed to be true
} SetVideoAnalyticsConfiguration_REQ;

typedef struct
{
    char 	ProfileToken[ONVIF_TOKEN_LEN];				// required, Contains a reference to the media profile from which the VideoAnalyticsConfiguration shall be removed
} RemoveVideoAnalyticsConfiguration_REQ;

typedef struct
{
    char 	ConfigurationToken[ONVIF_TOKEN_LEN];		// required, References an existing Video Analytics configuration. The list of available tokens can be obtained
														//	via the Media service GetVideoAnalyticsConfigurations method
} GetSupportedRules_REQ;

typedef struct
{
    char 	ConfigurationToken[ONVIF_TOKEN_LEN];		// required, Reference to an existing VideoAnalyticsConfiguration

	ONVIF_Config * Rule;								// required
} CreateRules_REQ;

typedef struct
{
    char 	ConfigurationToken[ONVIF_TOKEN_LEN];		// required, Reference to an existing VideoAnalyticsConfiguration

	int 	sizeRuleName;
	char 	RuleName[10][ONVIF_NAME_LEN];				// required, References the specific rule to be deleted (e.g. "MyLineDetector"). 
} DeleteRules_REQ;

typedef struct
{
    char	ConfigurationToken[ONVIF_TOKEN_LEN];		// required, Reference to an existing VideoAnalyticsConfiguration
} GetRules_REQ;

typedef struct
{
    char 	ConfigurationToken[ONVIF_TOKEN_LEN];		// required, Reference to an existing VideoAnalyticsConfiguration

	ONVIF_Config * Rule;								// required 
} ModifyRules_REQ;

typedef struct
{
    char 	ConfigurationToken[ONVIF_TOKEN_LEN];		// required, Reference to an existing VideoAnalyticsConfiguration

	ONVIF_Config * AnalyticsModule;						// required 
} CreateAnalyticsModules_REQ;

typedef struct
{
    char 	ConfigurationToken[ONVIF_TOKEN_LEN];		// required, Reference to an existing Video Analytics configuration

	int 	sizeAnalyticsModuleName;
	char 	AnalyticsModuleName[10][ONVIF_NAME_LEN];	//required, name of the AnalyticsModule to be deleted
} DeleteAnalyticsModules_REQ;

typedef struct
{
    char 	ConfigurationToken[ONVIF_TOKEN_LEN];		// required, Reference to an existing VideoAnalyticsConfiguration
} GetAnalyticsModules_REQ;

typedef struct
{
    char 	ConfigurationToken[ONVIF_TOKEN_LEN];		// required, Reference to an existing VideoAnalyticsConfiguration
	
	ONVIF_Config * AnalyticsModule;						// required 
} ModifyAnalyticsModules_REQ;

// onvif media service 2 interfaces

#define TR2_MAX_TYPE            10
#define TR2_MAX_CONFIGURATION   10

typedef struct 
{
    uint32  ConfigurationTokenFlag  : 1;
    uint32  ProfileTokenFlag        : 1;
    uint32  Reserved                : 30;
    
    char    ConfigurationToken[ONVIF_TOKEN_LEN];	        // optional, Token of the requested configuration
	char    ProfileToken[ONVIF_TOKEN_LEN];	                // optional, Contains the token of an existing media profile the configurations shall be compatible with
} tr2_GetConfiguration;

typedef struct 
{
	char    Name[ONVIF_NAME_LEN];	                        // required, friendly name of the profile to be created
    
	int     sizeConfiguration;
	onvif_ConfigurationRef  Configuration[TR2_MAX_CONFIGURATION];   // optional, Optional set of configurations to be assigned to the profile
} tr2_CreateProfile_REQ;

typedef struct 
{
    uint32  TokenFlag   : 1;
    uint32  Reserved    : 31;
    
	char    Token[ONVIF_TOKEN_LEN];							// optional, Optional token of the requested profile

	int     sizeType;	
	char    Type[TR2_MAX_TYPE][32];	                        // optional, The types shall be provided as defined by tr2:ConfigurationEnumeration
	                                                        //      All, VideoSource, VideoEncoder, AudioSource, AudioEncoder, AudioOutput,
                                        					//      AudioDecoder, Metadata, Analytics, PTZ
} tr2_GetProfiles_REQ;

typedef struct 
{
    uint32  NameFlag    : 1;
    uint32  Reserved    : 31;
    
	char    ProfileToken[ONVIF_TOKEN_LEN];	                // required, Reference to the profile where the configuration should be added
	char    Name[ONVIF_NAME_LEN];	                        // optional, Optional item. If present updates the Name property of the profile

	int     sizeConfiguration;	
	onvif_ConfigurationRef  Configuration[TR2_MAX_CONFIGURATION];   // optional, List of configurations to be added
} tr2_AddConfiguration_REQ;

typedef struct 
{
	char    ProfileToken[ONVIF_TOKEN_LEN];	                // required, This element contains a  reference to the media profile

	int     sizeConfiguration;
	onvif_ConfigurationRef  Configuration[TR2_MAX_CONFIGURATION];	// required, List of configurations to be removed
} tr2_RemoveConfiguration_REQ;

typedef struct 
{
	char    Token[ONVIF_TOKEN_LEN];	                        // required, This element contains a  reference to the profile that should be deleted
} tr2_DeleteProfile_REQ;

typedef struct 
{
	tr2_GetConfiguration    GetConfiguration;
} tr2_GetVideoEncoderConfigurations_REQ;

typedef struct 
{
	tr2_GetConfiguration    GetConfiguration;
} tr2_GetVideoSourceConfigurations_REQ;

typedef struct 
{
	tr2_GetConfiguration    GetConfiguration;
} tr2_GetAudioEncoderConfigurations_REQ;

typedef struct 
{
	tr2_GetConfiguration    GetConfiguration;
} tr2_GetAudioSourceConfigurations_REQ;

typedef struct 
{
	tr2_GetConfiguration    GetConfiguration;
} tr2_GetAnalyticsConfigurations_REQ;

typedef struct 
{
	tr2_GetConfiguration    GetConfiguration;
} tr2_GetMetadataConfigurations_REQ;

typedef struct 
{
	tr2_GetConfiguration    GetConfiguration;
} tr2_GetAudioOutputConfigurations_REQ;

typedef struct 
{
	tr2_GetConfiguration    GetConfiguration;
} tr2_GetAudioDecoderConfigurations_REQ;

typedef struct
{
    onvif_VideoEncoder2Configuration    Configuration;      // Contains the modified video encoder configuration. The configuration shall exist in the device
} tr2_SetVideoEncoderConfiguration_REQ;

typedef struct 
{
	onvif_VideoSourceConfiguration      Configuration;	    // required, Contains the modified video source configuration. The configuration shall exist in the device
} tr2_SetVideoSourceConfiguration_REQ;

typedef struct 
{
	onvif_AudioEncoder2Configuration    Configuration;	    // required, Contains the modified audio encoder configuration. The configuration shall exist in the device
} tr2_SetAudioEncoderConfiguration_REQ;

typedef struct 
{
	onvif_AudioSourceConfiguration      Configuration;	    // required, Contains the modified audio source configuration. The configuration shall exist in the device
} tr2_SetAudioSourceConfiguration_REQ;

typedef struct 
{
	onvif_MetadataConfiguration Configuration;	            // required, Contains the modified metadata configuration. The configuration shall exist in the device
} tr2_SetMetadataConfiguration_REQ;

typedef struct 
{
	onvif_AudioOutputConfiguration  Configuration;	        // required, Contains the modified audio output configuration. The configuration shall exist in the device
} tr2_SetAudioOutputConfiguration_REQ;

typedef struct 
{
	tr2_GetConfiguration    GetConfiguration;
} tr2_GetVideoSourceConfigurationOptions_REQ;

typedef struct 
{
	tr2_GetConfiguration    GetConfiguration;
} tr2_GetVideoEncoderConfigurationOptions_REQ;

typedef struct 
{
	tr2_GetConfiguration    GetConfiguration;
} tr2_GetAudioSourceConfigurationOptions_REQ;

typedef struct 
{
	tr2_GetConfiguration    GetConfiguration;
} tr2_GetAudioEncoderConfigurationOptions_REQ;

typedef struct 
{
	tr2_GetConfiguration    GetConfiguration;
} tr2_GetMetadataConfigurationOptions_REQ;

typedef struct 
{
	tr2_GetConfiguration    GetConfiguration;
} tr2_GetAudioOutputConfigurationOptions_REQ;

typedef struct 
{
	tr2_GetConfiguration    GetConfiguration;
} tr2_GetAudioDecoderConfigurationOptions_REQ;

typedef struct 
{
	char    ConfigurationToken[ONVIF_TOKEN_LEN];	        // required, Token of the video source configuration
} tr2_GetVideoEncoderInstances_REQ;

typedef struct 
{
	char    Protocol[32];									// required, Defines the network protocol
	                                                        //  RtspUnicast, RtspMulticast, RTSP, RtspOverHttp
	char    ProfileToken[ONVIF_TOKEN_LEN];	                // required, The ProfileToken element indicates the media profile to use and will define the configuration of the content of the stream
} tr2_GetStreamUri_REQ;

typedef struct 
{
	char    ProfileToken[ONVIF_TOKEN_LEN];	                // required, Contains a Profile reference for which a Synchronization Point is requested
} tr2_SetSynchronizationPoint_REQ;

// end of onvif media 2 interfaces

typedef struct
{
    uint32  LimitFlag           : 1;
    uint32  StartReferenceFlag  : 1;
    uint32  Reserved            : 30;
    
    int     Limit;	                                        // optional, Maximum number of entries to return. If not specified, less than one or higher than what the device supports, the number of items is determined by the device
	char    StartReference[256];	                        // optional, Start returning entries from this start reference. If not specified, entries shall start from the beginning of the dataset
} GetAccessPointInfoList_REQ;

typedef struct
{
    char    token[ACCESS_CTRL_MAX_LIMIT][ONVIF_TOKEN_LEN];  // Tokens of AccessPointInfo items to get    
} GetAccessPointInfo_REQ;

typedef struct
{
    uint32  LimitFlag           : 1;
    uint32  StartReferenceFlag  : 1;
    uint32  Reserved            : 30;
    
    int     Limit;	                                        // optional, Maximum number of entries to return. If not specified, or higher than what the device supports, the number of items shall be determined by the device
	char    StartReference[256];	                        // optional, Start returning entries from this start reference. If not specified, entries shall start from the beginning of the dataset
} GetDoorInfoList_REQ;

typedef struct
{
    char    token[DOOR_CTRL_MAX_LIMIT][ONVIF_TOKEN_LEN];    // Tokens of DoorInfo items to get 
} GetDoorInfo_REQ;

typedef struct
{
    uint32  LimitFlag           : 1;
    uint32  StartReferenceFlag  : 1;
    uint32  Reserved            : 30;
    
    int     Limit;	                                        // optional, Maximum number of entries to return. If not specified, or higher than what the device supports, the number of items shall be determined by the device
	char    StartReference[256];	                        // optional, Start returning entries from this start reference. If not specified, entries shall start from the beginning of the dataset
} GetAreaInfoList_REQ;

typedef struct
{
    char    token[ACCESS_CTRL_MAX_LIMIT][ONVIF_TOKEN_LEN];  // Tokens of DoorInfo items to get 
} GetAreaInfo_REQ;

typedef struct
{
    char    Token[ONVIF_TOKEN_LEN];                         // required, Token of AccessPoint instance to get AccessPointState for
} GetAccessPointState_REQ;

typedef struct
{
    char    Token[ONVIF_TOKEN_LEN];	                        // required, Token of the Door instance to get the state for
} GetDoorState_REQ;

typedef struct
{
    uint32  UseExtendedTimeFlag : 1;
    uint32  AccessTimeFlag      : 1;
    uint32  OpenTooLongTimeFlag : 1;
    uint32  PreAlarmTimeFlag    : 1;
    uint32  Reserved            : 28;
    
	char    Token[ONVIF_TOKEN_LEN];	                        // required, Token of the Door instance to control
	BOOL    UseExtendedTime;	                            // optional, Indicates that the configured extended time should be used
	int     AccessTime;	                                    // optional, overrides AccessTime if specified
	int     OpenTooLongTime;	                            // optional, overrides OpenTooLongTime if specified (DOTL)
	int     PreAlarmTime;	                                // optional, overrides PreAlarmTime if specified
} AccessDoor_REQ;

typedef struct
{
    char    Token[ONVIF_TOKEN_LEN];	                        // required, Token of the Door instance to control
} LockDoor_REQ;

typedef struct
{
    char    Token[ONVIF_TOKEN_LEN];	                        // required, Token of the Door instance to control
} UnlockDoor_REQ;

typedef struct
{
    char    Token[ONVIF_TOKEN_LEN];	                        // required, Token of the Door instance to control
} DoubleLockDoor_REQ;

typedef struct
{
    char    Token[ONVIF_TOKEN_LEN];	                        // required, Token of the Door instance to control
} BlockDoor_REQ;

typedef struct
{
    char    Token[ONVIF_TOKEN_LEN];	                        // required, Token of the Door instance to control
} LockDownDoor_REQ;

typedef struct
{
    char    Token[ONVIF_TOKEN_LEN];	                        // required, Token of the Door instance to control
} LockDownReleaseDoor_REQ;

typedef struct
{
    char    Token[ONVIF_TOKEN_LEN];	                        // required, Token of the Door instance to control
} LockOpenDoor_REQ;

typedef struct
{
    char    Token[ONVIF_TOKEN_LEN];	                        // required, Token of the Door instance to control
} LockOpenReleaseDoor_REQ;

typedef struct
{
    char    Token[ONVIF_TOKEN_LEN];                         // required, Token of the AccessPoint instance to enable
} EnableAccessPoint_REQ;

typedef struct
{
    char    Token[ONVIF_TOKEN_LEN];                         // required, Token of the AccessPoint instance to disable
} DisableAccessPoint_REQ;


#endif // end of ONVIF_REQ_H


