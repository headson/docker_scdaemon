/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2010-2016, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#include "soap.h"
#include "soap_parser.h"


BOOL onvif_GetCapabilities_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node;
	GetCapabilities_RES * p_res;

	p_node = xml_node_soap_get(p_xml, "GetCapabilitiesResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

	p_res = (GetCapabilities_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }

	return parse_GetCapabilities(p_node, p_res);
}

BOOL onvif_GetServices_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node;
	XMLN * p_Service;
	GetServices_RES * p_res;

	p_node = xml_node_soap_get(p_xml, "GetServicesResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetServices_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }

	p_Service = xml_node_soap_get(p_node, "Service");
	while (p_Service)
	{
	    XMLN * p_Namespace = xml_node_soap_get(p_Service, "Namespace");
    	if (p_Namespace && p_Namespace->data)
    	{
    	    if (strstr(p_Namespace->data, "device"))
    	    {
    	        parse_DeviceService(p_Service, &p_res->Capabilities.device);
    	    }
    	    else if (strstr(p_Namespace->data, "ver10/media"))
    	    {
    	    	p_res->Capabilities.media.support = parse_MediaService(p_Service, &p_res->Capabilities.media);
    	    }
    	    else if (strstr(p_Namespace->data, "ver20/media"))
    	    {
    	        p_res->Capabilities.media2.support = parse_MediaService2(p_Service, &p_res->Capabilities.media2);
    	    }
    	    else if (strstr(p_Namespace->data, "events"))
    	    {
    	        p_res->Capabilities.events.support = parse_EventsService(p_Service, &p_res->Capabilities.events);
    	    }
    	    else if (strstr(p_Namespace->data, "ptz"))
    	    {
    	        p_res->Capabilities.ptz.support = parse_PTZService(p_Service, &p_res->Capabilities.ptz);
    	    }
    	    else if (strstr(p_Namespace->data, "imaging"))
    	    {
    	        p_res->Capabilities.image.support = parse_ImagingService(p_Service, &p_res->Capabilities.image);
    	    }  
    	    else if (strstr(p_Namespace->data, "analytics"))
    	    {
    	        p_res->Capabilities.analytics.support = parse_AnalyticsService(p_Service, &p_res->Capabilities.analytics);
    	    }
    	    
#ifdef PROFILE_C_SUPPORT    	    
    	    else if (strstr(p_Namespace->data, "recording"))
    	    {
    	        p_res->Capabilities.recording.support = parse_RecordingService(p_Service, &p_res->Capabilities.recording);
    	    }
    	    else if (strstr(p_Namespace->data, "search"))
    	    {
    	        p_res->Capabilities.search.support = parse_SearchService(p_Service, &p_res->Capabilities.search);
    	    }
    	    else if (strstr(p_Namespace->data, "replay"))
    	    {
    	        p_res->Capabilities.replay.support = parse_ReplayService(p_Service, &p_res->Capabilities.replay);
    	    }
#endif // end of PROFILE_C_SUPPORT 	  

#ifdef PROFILE_C_SUPPORT    	    
    	    else if (strstr(p_Namespace->data, "accesscontrol"))
    	    {
    	        p_res->Capabilities.accesscontrol.support = parse_AccessControlService(p_Service, &p_res->Capabilities.accesscontrol);
    	    }
    	    else if (strstr(p_Namespace->data, "doorcontrol"))
    	    {
    	        p_res->Capabilities.doorcontrol.support = parse_DoorControlService(p_Service, &p_res->Capabilities.doorcontrol);
    	    }
#endif    	    
    	}

    	p_Service = p_Service->next;
	}

	return TRUE;
}

BOOL onvif_GetDeviceInformation_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetDeviceInformation_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetDeviceInformationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

	p_res = (GetDeviceInformation_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}
    
	return parse_GetDeviceInformation(p_node, p_res);
}

BOOL onvif_GetUsers_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node;
	XMLN * p_User;
	GetUsers_RES * p_res;

	p_node = xml_node_soap_get(p_xml, "GetUsersResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetUsers_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
    
	memset(p_res, 0, sizeof(GetUsers_RES));
	
    p_User = xml_node_soap_get(p_node, "User");
    while (p_User)
    {
		ONVIF_User * p_user = onvif_add_User(&p_res->User);
    	if (p_user)
    	{
	        if (parse_User(p_User, &p_user->User) == FALSE)
	        {
	            onvif_free_Users(&p_res->User);
	            return FALSE;
	        }
        }

        p_User = p_User->next;
    }
    
    return TRUE;
}

BOOL onvif_CreateUsers_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "CreateUsersResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	return TRUE;
}

BOOL onvif_DeleteUsers_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "DeleteUsersResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	return TRUE;
}

BOOL onvif_SetUser_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "SetUserResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	return TRUE;
}

BOOL onvif_GetRemoteUser_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    GetRemoteUser_RES * p_res;
    XMLN * p_node = xml_node_soap_get(p_xml, "GetRemoteUserResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}
	
	p_res = (GetRemoteUser_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
	
	return parse_GetRemoteUser(p_node, p_res);
}

BOOL onvif_SetRemoteUser_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node = xml_node_soap_get(p_xml, "SetRemoteUserResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	return TRUE;
}

BOOL onvif_GetNetworkInterfaces_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node;
	XMLN * p_NetworkInterfaces;
	GetNetworkInterfaces_RES * p_res;
	
	p_node = xml_node_soap_get(p_xml, "GetNetworkInterfacesResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}

	p_res = (GetNetworkInterfaces_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}
	
	p_NetworkInterfaces = xml_node_soap_get(p_node, "NetworkInterfaces");
	while (p_NetworkInterfaces)
	{
		ONVIF_NetworkInterface * p_net_inf = onvif_add_NetworkInterface(&p_res->NetworkInterfaces);
		if (NULL != p_net_inf)
		{
			const char * p_token = xml_attr_get(p_NetworkInterfaces, "token");
			if (p_token)
			{
				strncpy(p_net_inf->NetworkInterface.token, p_token, sizeof(p_net_inf->NetworkInterface.token)-1);
			}
			
			if (parse_NetworkInterface(p_NetworkInterfaces, &p_net_inf->NetworkInterface) == FALSE)
	        {
	            onvif_free_NetworkInterfaces(&p_res->NetworkInterfaces);
	            return FALSE;
	        }	
		}

		p_NetworkInterfaces = p_NetworkInterfaces->next;
	}
        
	return TRUE;
}

BOOL onvif_SetNetworkInterfaces_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node;
	SetNetworkInterfaces_RES * p_res;

	p_node = xml_node_soap_get(p_xml, "SetNetworkInterfacesResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}

	p_res = (SetNetworkInterfaces_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }

    memset(p_res, 0, sizeof(SetNetworkInterfaces_RES));
    
	return parse_SetNetworkInterfaces(p_node, p_res);
}

BOOL onvif_GetNTP_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node;
	GetNTP_RES * p_res;
	
	p_node = xml_node_soap_get(p_xml, "GetNTPResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

	p_res = (GetNTP_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }

	return parse_GetNTP(p_node, p_res);
}

BOOL onvif_SetNTP_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "SetNTPResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}
	
	return TRUE;
}

BOOL onvif_GetHostname_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetHostname_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetHostnameResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

	p_res = (GetHostname_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }

	return parse_GetHostname(p_node, p_res);
}

BOOL onvif_SetHostname_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "SetHostnameResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}
	
	return TRUE;
}

BOOL onvif_SetHostnameFromDHCP_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	SetHostnameFromDHCP_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "SetHostnameFromDHCPResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}

	p_res = (SetHostnameFromDHCP_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
    
	return parse_SetHostnameFromDHCP(p_node, p_res);
}
	
BOOL onvif_GetDNS_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{	
	GetDNS_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetDNSResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

	p_res = (GetDNS_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }

	return parse_GetDNS(p_node, p_res);
}
	
BOOL onvif_SetDNS_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "SetDNSResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}
	
	return TRUE;
}
	
BOOL onvif_GetDynamicDNS_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetDynamicDNS_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetDynamicDNSResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

	p_res = (GetDynamicDNS_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }

	return parse_GetDynamicDNS(p_node, p_res);
}
	
BOOL onvif_SetDynamicDNS_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "SetDynamicDNSResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}
	
	return TRUE;
}

BOOL onvif_GetNetworkProtocols_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetNetworkProtocols_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetNetworkProtocolsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

	p_res = (GetNetworkProtocols_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }

	return parse_GetNetworkProtocols(p_node, p_res);
}

BOOL onvif_SetNetworkProtocols_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "SetNetworkProtocolsResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}
	
	return TRUE;
}
	
BOOL onvif_GetDiscoveryMode_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetDiscoveryMode_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetDiscoveryModeResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

	p_res = (GetDiscoveryMode_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }

	return parse_GetDiscoveryMode(p_node, p_res);
}

BOOL onvif_SetDiscoveryMode_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "SetDiscoveryModeResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}
	
	return TRUE;
}
	
BOOL onvif_GetNetworkDefaultGateway_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetNetworkDefaultGateway_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetNetworkDefaultGatewayResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

	p_res = (GetNetworkDefaultGateway_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }

	return parse_GetNetworkDefaultGateway(p_node, p_res);
}

BOOL onvif_SetNetworkDefaultGateway_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "SetNetworkDefaultGatewayResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}
	
	return TRUE;
}

BOOL onvif_GetZeroConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    GetZeroConfiguration_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetZeroConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

	p_res = (GetZeroConfiguration_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }

    memset(p_res, 0, sizeof(GetZeroConfiguration_RES));

	return parse_GetZeroConfiguration(p_node, p_res);
}

BOOL onvif_SetZeroConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node = xml_node_soap_get(p_xml, "SetZeroConfigurationResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}
	
	return TRUE;
}

BOOL onvif_GetEndpointReference_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    GetEndpointReference_RES * p_res;
    XMLN * p_node = xml_node_soap_get(p_xml, "GetEndpointReferenceResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}
	
	p_res = (GetEndpointReference_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
	
	return parse_GetEndpointReference(p_node, p_res);
}

BOOL onvif_GetSystemDateAndTime_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetSystemDateAndTime_RES * p_res;
    XMLN * p_node = xml_node_soap_get(p_xml, "GetSystemDateAndTimeResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetSystemDateAndTime_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
	
	return parse_GetSystemDateAndTime(p_node, p_res);
}

BOOL onvif_SetSystemDateAndTime_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "SetSystemDateAndTimeResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	return TRUE;
}

BOOL onvif_SystemReboot_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "SystemRebootResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	return TRUE;
}

BOOL onvif_SetSystemFactoryDefault_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "SetSystemFactoryDefaultResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	return TRUE;
}


BOOL onvif_GetSystemLog_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	return TRUE;
}
		
BOOL onvif_GetScopes_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetScopes_RES * p_res;
	
	XMLN * p_node = xml_node_soap_get(p_xml, "GetScopesResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

	p_res = (GetScopes_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
	
	return parse_GetScopes(p_node, p_res);
}
		
BOOL onvif_SetScopes_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "SetScopesResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	return TRUE;
}
		
BOOL onvif_AddScopes_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "AddScopesResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	return TRUE;
}
		
BOOL onvif_RemoveScopes_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "RemoveScopesResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	return TRUE;
}

BOOL onvif_StartFirmwareUpgrade_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node;
    StartFirmwareUpgrade_RES * p_res;
    
    p_node = xml_node_soap_get(p_xml, "StartFirmwareUpgradeResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (StartFirmwareUpgrade_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }

    return parse_StartFirmwareUpgrade(p_node, p_res);
}

BOOL onvif_GetSystemUris_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node;
    GetSystemUris_RES * p_res;
    
    p_node = xml_node_soap_get(p_xml, "GetSystemUrisResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetSystemUris_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }

    return parse_GetSystemUris(p_node, p_res);
}

BOOL onvif_StartSystemRestore_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node;
    StartSystemRestore_RES * p_res;
    
    p_node = xml_node_soap_get(p_xml, "StartSystemRestoreResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (StartSystemRestore_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }

    return parse_StartSystemRestore(p_node, p_res);
}

BOOL onvif_GetVideoSources_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node;
	XMLN * p_VideoSources;
	GetVideoSources_RES * p_res;

	p_node = xml_node_soap_get(p_xml, "GetVideoSourcesResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetVideoSources_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
	
    p_VideoSources = xml_node_soap_get(p_node, "VideoSources");
    while (p_VideoSources)
    {
		ONVIF_VideoSource * p_v_src = onvif_add_VideoSource(&p_res->VideoSources);
    	if (p_v_src)
    	{
    		const char * p_token = xml_attr_get(p_VideoSources, "token");
    		if (p_token)
    		{
	        	strncpy(p_v_src->VideoSource.token, p_token, sizeof(p_v_src->VideoSource.token)-1);
			}
			
	        if (parse_VideoSource(p_VideoSources, &p_v_src->VideoSource) == FALSE)
	        {
	            onvif_free_VideoSources(&p_res->VideoSources);
	            return FALSE;
	        }
        }

        p_VideoSources = p_VideoSources->next;
    }
    
	return TRUE;
}
		
BOOL onvif_GetAudioSources_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node;
	XMLN * p_AudioSources;
	GetAudioSources_RES * p_res;

	p_node = xml_node_soap_get(p_xml, "GetAudioSourcesResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetAudioSources_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
	
    p_AudioSources = xml_node_soap_get(p_node, "AudioSources");
    while (p_AudioSources)
    {
		ONVIF_AudioSource * p_a_src = onvif_add_AudioSource(&p_res->AudioSources);
    	if (p_a_src)
    	{
    		const char * p_token = xml_attr_get(p_AudioSources, "token");
    		if (p_token)
    		{
	        	strncpy(p_a_src->AudioSource.token, p_token, sizeof(p_a_src->AudioSource.token)-1);
			}
			
	        if (parse_AudioSource(p_AudioSources, &p_a_src->AudioSource) == FALSE)
	        {
	            onvif_free_AudioSources(&p_res->AudioSources);
	            return FALSE;
	        }
        }

        p_AudioSources = p_AudioSources->next;
    }
    
	return TRUE;
}
		
BOOL onvif_CreateProfile_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node;
	XMLN * p_Profile;
	CreateProfile_RES * p_res;

	p_node = xml_node_soap_get(p_xml, "CreateProfileResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (CreateProfile_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
    
	memset(p_res, 0, sizeof(CreateProfile_RES));
	
    p_Profile = xml_node_soap_get(p_node, "Profile");
    if (p_Profile)
    {
    	const char * p_fixed;
		const char * p_token;

		p_fixed = xml_attr_get(p_Profile, "fixed");
    	if (p_fixed)
    	{
        	p_res->Profile.fixed = parse_Bool(p_fixed);
        }

        p_token = xml_attr_get(p_Profile, "token");
        if (p_token)
        {
        	strncpy(p_res->Profile.token, p_token, sizeof(p_res->Profile.token)-1);
		}
		
        if (parse_Profile(p_Profile, &p_res->Profile) == FALSE)
        {
            return FALSE;
        }
    }
    
    return TRUE;
}
		
BOOL onvif_GetProfile_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node;
	XMLN * p_Profile;
	GetProfile_RES * p_res;

	p_node = xml_node_soap_get(p_xml, "GetProfileResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetProfile_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
    
	memset(p_res, 0, sizeof(GetProfile_RES));
	
    p_Profile = xml_node_soap_get(p_node, "Profile");
    if (p_Profile)
    {
    	const char * p_fixed;
		const char * p_token;

		p_fixed = xml_attr_get(p_Profile, "fixed");
    	if (p_fixed)
    	{
        	p_res->Profile.fixed = parse_Bool(p_fixed);
        }

        p_token = xml_attr_get(p_Profile, "token");
        if (p_token)
        {
        	strncpy(p_res->Profile.token, p_token, sizeof(p_res->Profile.token)-1);
		}
		
        if (parse_Profile(p_Profile, &p_res->Profile) == FALSE)
        {
        	onvif_free_Profile(&p_res->Profile);
            return FALSE;
        }
    }
    
    return TRUE;
}

BOOL onvif_GetProfiles_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node;
	XMLN * p_Profiles;
	GetProfiles_RES * p_res;

	p_node = xml_node_soap_get(p_xml, "GetProfilesResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetProfiles_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
    
	memset(p_res, 0, sizeof(GetProfiles_RES));
	
    p_Profiles = xml_node_soap_get(p_node, "Profiles");
    while (p_Profiles)
    {
		ONVIF_Profile * p_profile = onvif_add_Profile(&p_res->Profiles);
    	if (p_profile)
    	{
    		const char * p_fixed;
			const char * p_token;

			p_fixed = xml_attr_get(p_Profiles, "fixed");
    		if (p_fixed)
    		{
	        	p_profile->fixed = parse_Bool(p_fixed);
	        }

	        p_token = xml_attr_get(p_Profiles, "token");
	        if (p_token)
	        {
	        	strncpy(p_profile->token, p_token, sizeof(p_profile->token)-1);
			}
			
	        if (parse_Profile(p_Profiles, p_profile) == FALSE)
	        {
	            onvif_free_Profiles(&p_res->Profiles);
	            return FALSE;
	        }
        }

        p_Profiles = p_Profiles->next;
    }
    
    return TRUE;
}		


BOOL onvif_AddVideoEncoderConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "AddVideoEncoderConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
		
BOOL onvif_AddVideoSourceConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node = xml_node_soap_get(p_xml, "AddVideoSourceConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
		
BOOL onvif_AddAudioEncoderConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node = xml_node_soap_get(p_xml, "AddAudioEncoderConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
		
BOOL onvif_AddAudioSourceConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "AddAudioSourceConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}

BOOL onvif_GetVideoSourceModes_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_VideoSourceModes;
	GetVideoSourceModes_RES * p_res;
	
	XMLN * p_node = xml_node_soap_get(p_xml, "GetVideoSourceModesResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetVideoSourceModes_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
    
	memset(p_res, 0, sizeof(GetVideoSourceModes_RES));

	p_VideoSourceModes = xml_node_soap_get(p_node, "VideoSourceModes");
    while (p_VideoSourceModes)
    {
		ONVIF_VideoSourceMode * p_v_src_mode = onvif_add_VideoSourceMode(&p_res->VideoSourceModes);
    	if (p_v_src_mode)
    	{
			const char * p_token;
			const char * p_Enabled;

			p_token = xml_attr_get(p_VideoSourceModes, "token");
	        if (p_token)
	        {
	        	strncpy(p_v_src_mode->VideoSourceMode.token, p_token, sizeof(p_v_src_mode->VideoSourceMode.token)-1);
			}
			
			p_Enabled = xml_attr_get(p_VideoSourceModes, "Enabled");
    		if (p_Enabled)
    		{
	        	p_v_src_mode->VideoSourceMode.Enabled = parse_Bool(p_Enabled);
	        }
			
	        if (parse_VideoSourceMode(p_VideoSourceModes, &p_v_src_mode->VideoSourceMode) == FALSE)
	        {
	            onvif_free_VideoSourceModes(&p_res->VideoSourceModes);
	            return FALSE;
	        }
        }

        p_VideoSourceModes = p_VideoSourceModes->next;
    }

	return TRUE;
}

BOOL onvif_SetVideoSourceMode_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	SetVideoSourceMode_RES * p_res;
	
	XMLN * p_node = xml_node_soap_get(p_xml, "SetVideoSourceModeResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (SetVideoSourceMode_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
    
	memset(p_res, 0, sizeof(SetVideoSourceMode_RES));

	return parse_SetVideoSourceMode(p_node, p_res);
}

BOOL onvif_AddPTZConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "AddPTZConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
		
BOOL onvif_RemoveVideoEncoderConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "RemoveVideoEncoderConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
		
BOOL onvif_RemoveVideoSourceConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node = xml_node_soap_get(p_xml, "RemoveVideoSourceConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
		
BOOL onvif_RemoveAudioEncoderConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node = xml_node_soap_get(p_xml, "RemoveAudioEncoderConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
		
BOOL onvif_RemoveAudioSourceConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node = xml_node_soap_get(p_xml, "RemoveAudioSourceConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
		
BOOL onvif_RemovePTZConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node = xml_node_soap_get(p_xml, "RemovePTZConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
		
BOOL onvif_DeleteProfile_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node = xml_node_soap_get(p_xml, "DeleteProfileResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
		
BOOL onvif_GetVideoSourceConfigurations_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node;
	XMLN * p_Configurations;
	GetVideoSourceConfigurations_RES * p_res;

	p_node = xml_node_soap_get(p_xml, "GetVideoSourceConfigurationsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetVideoSourceConfigurations_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
	
    p_Configurations = xml_node_soap_get(p_node, "Configurations");
    while (p_Configurations)
    {
		ONVIF_VideoSourceConfiguration * p_v_src_cfg = onvif_add_VideoSourceConfiguration(&p_res->Configurations);
    	if (p_v_src_cfg)
    	{
    		const char * p_token = xml_attr_get(p_Configurations, "token");
    		if (p_token)
    		{
	        	strncpy(p_v_src_cfg->Configuration.token, p_token, sizeof(p_v_src_cfg->Configuration.token)-1);
			}
			
	        if (parse_VideoSourceConfiguration(p_Configurations, &p_v_src_cfg->Configuration) == FALSE)
	        {
	            onvif_free_VideoSourceConfigurations(&p_res->Configurations);
	            return FALSE;
	        }
        }

        p_Configurations = p_Configurations->next;
    }
    
    return TRUE;
}


BOOL onvif_GetVideoEncoderConfigurations_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node;
	XMLN * p_Configurations;
	GetVideoEncoderConfigurations_RES * p_res;

	p_node = xml_node_soap_get(p_xml, "GetVideoEncoderConfigurationsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetVideoEncoderConfigurations_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
	
    p_Configurations = xml_node_soap_get(p_node, "Configurations");
    while (p_Configurations)
    {
		ONVIF_VideoEncoderConfiguration * p_v_enc = onvif_add_VideoEncoderConfiguration(&p_res->Configurations);
    	if (p_v_enc)
    	{
    	    const char * p_token;

    		p_token = xml_attr_get(p_Configurations, "token");
    		if (p_token)
    		{
	        	strncpy(p_v_enc->Configuration.token, p_token, sizeof(p_v_enc->Configuration.token)-1);
			}
			
	        if (parse_VideoEncoderConfiguration(p_Configurations, &p_v_enc->Configuration) == FALSE)
	        {
	            onvif_free_VideoEncoderConfigurations(&p_res->Configurations);
	            return FALSE;
	        }
        }

        p_Configurations = p_Configurations->next;
    }
    
    return TRUE;
}

BOOL onvif_GetAudioSourceConfigurations_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node;
	XMLN * p_Configurations;
	GetAudioSourceConfigurations_RES * p_res;

	p_node = xml_node_soap_get(p_xml, "GetAudioSourceConfigurationsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetAudioSourceConfigurations_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
	
    p_Configurations = xml_node_soap_get(p_node, "Configurations");
    while (p_Configurations)
    {
		ONVIF_AudioSourceConfiguration * p_a_src_cfg = onvif_add_AudioSourceConfiguration(&p_res->Configurations);
    	if (p_a_src_cfg)
    	{
    		const char * p_token = xml_attr_get(p_Configurations, "token");
    		if (p_token)
    		{
	        	strncpy(p_a_src_cfg->Configuration.token, p_token, sizeof(p_a_src_cfg->Configuration.token)-1);
	        }	

	        if (parse_AudioSourceConfiguration(p_Configurations, &p_a_src_cfg->Configuration) == FALSE)
	        {
	            onvif_free_AudioSourceConfigurations(&p_res->Configurations);
	            return FALSE;
	        }
        }

        p_Configurations = p_Configurations->next;
    }
    
    return TRUE;
}
		
BOOL onvif_GetAudioEncoderConfigurations_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node;
	XMLN * p_Configurations;
	GetAudioEncoderConfigurations_RES * p_res;

	p_node = xml_node_soap_get(p_xml, "GetAudioEncoderConfigurationsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetAudioEncoderConfigurations_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
	
    p_Configurations = xml_node_soap_get(p_node, "Configurations");
    while (p_Configurations)
    {
		ONVIF_AudioEncoderConfiguration * p_a_enc = onvif_add_AudioEncoderConfiguration(&p_res->Configurations);
    	if (p_a_enc)
    	{
    		const char * p_token = xml_attr_get(p_Configurations, "token");
    		if (p_token)
    		{
	        	strncpy(p_a_enc->Configuration.token, p_token, sizeof(p_a_enc->Configuration.token)-1);
	        }

	        if (parse_AudioEncoderConfiguration(p_Configurations, &p_a_enc->Configuration) == FALSE)
	        {
	            onvif_free_AudioEncoderConfigurations(&p_res->Configurations);
	            return FALSE;
	        }
        }

        p_Configurations = p_Configurations->next;
    }
    
    return TRUE;
}
		
BOOL onvif_GetVideoSourceConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node;
	XMLN * p_Configuration;
	GetVideoSourceConfiguration_RES * p_res;

	p_node = xml_node_soap_get(p_xml, "GetVideoSourceConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetVideoSourceConfiguration_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
	
    p_Configuration = xml_node_soap_get(p_node, "Configuration");
    if (p_Configuration)
    {
    	const char * p_token = xml_attr_get(p_Configuration, "token");
    	if (p_token)
    	{
        	strncpy(p_res->Configuration.token, p_token, sizeof(p_res->Configuration.token)-1);
        }	

        if (parse_VideoSourceConfiguration(p_Configuration, &p_res->Configuration) == FALSE)
        {
            return FALSE;
        }
    }
    else
    {
    	return FALSE;
    }
    
    return TRUE;
}
		
BOOL onvif_GetVideoEncoderConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node;
	XMLN * p_Configuration;
	GetVideoEncoderConfiguration_RES * p_res;

	p_node = xml_node_soap_get(p_xml, "GetVideoEncoderConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetVideoEncoderConfiguration_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
	
    p_Configuration = xml_node_soap_get(p_node, "Configuration");
    if (p_Configuration)
    {
    	const char * p_token = xml_attr_get(p_Configuration, "token");
    	if (p_token)
    	{
        	strncpy(p_res->Configuration.token, p_token, sizeof(p_res->Configuration.token)-1);
        }	

        if (parse_VideoEncoderConfiguration(p_Configuration, &p_res->Configuration) == FALSE)
        {
            return FALSE;
        }
    }
    else
    {
    	return FALSE;
    }
    
    return TRUE;
}
		
BOOL onvif_GetAudioSourceConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node;
	XMLN * p_Configuration;
	GetAudioSourceConfiguration_RES * p_res;

	p_node = xml_node_soap_get(p_xml, "GetAudioSourceConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetAudioSourceConfiguration_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
	
    p_Configuration = xml_node_soap_get(p_node, "Configuration");
    if (p_Configuration)
    {
    	const char * p_token = xml_attr_get(p_Configuration, "token");
    	if (p_token)
    	{
        	strncpy(p_res->Configuration.token, p_token, sizeof(p_res->Configuration.token)-1);
        }	

        if (parse_AudioSourceConfiguration(p_Configuration, &p_res->Configuration) == FALSE)
        {
            return FALSE;
        }
    }
    else
    {
    	return FALSE;
    }
    
    return TRUE;
}
		
BOOL onvif_GetAudioEncoderConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node;
	XMLN * p_Configuration;
	GetAudioEncoderConfiguration_RES * p_res;

	p_node = xml_node_soap_get(p_xml, "GetAudioEncoderConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetAudioEncoderConfiguration_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
	
    p_Configuration = xml_node_soap_get(p_node, "Configuration");
    if (p_Configuration)
    {
    	const char * p_token = xml_attr_get(p_Configuration, "token");
    	if (p_token)
    	{
        	strncpy(p_res->Configuration.token, p_token, sizeof(p_res->Configuration.token)-1);
        }	

        if (parse_AudioEncoderConfiguration(p_Configuration, &p_res->Configuration) == FALSE)
        {
            return FALSE;
        }
    }
    else
    {
    	return FALSE;
    }
    
    return TRUE;
}
		
BOOL onvif_SetVideoSourceConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "SetVideoSourceConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
		
BOOL onvif_SetVideoEncoderConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "SetVideoEncoderConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}

BOOL onvif_SetAudioSourceConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "SetAudioSourceConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
		
BOOL onvif_SetAudioEncoderConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "SetAudioEncoderConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
		
BOOL onvif_GetVideoSourceConfigurationOptions_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    GetVideoSourceConfigurationOptions_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetVideoSourceConfigurationOptionsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetVideoSourceConfigurationOptions_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

	memset(p_res, 0, sizeof(GetVideoSourceConfigurationOptions_RES));

	return parse_GetVideoSourceConfigurationOptions(p_node, p_res);
}
		
BOOL onvif_GetVideoEncoderConfigurationOptions_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetVideoEncoderConfigurationOptions_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetVideoEncoderConfigurationOptionsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetVideoEncoderConfigurationOptions_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

    memset(p_res, 0, sizeof(GetVideoEncoderConfigurationOptions_RES));

	return parse_GetVideoEncoderConfigurationOptions(p_node, p_res);
}

BOOL onvif_GetAudioSourceConfigurationOptions_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "GetAudioSourceConfigurationOptionsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
		
BOOL onvif_GetAudioEncoderConfigurationOptions_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetAudioEncoderConfigurationOptions_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetAudioEncoderConfigurationOptionsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    p_res = (GetAudioEncoderConfigurationOptions_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

    memset(p_res, 0, sizeof(GetAudioEncoderConfigurationOptions_RES));

	return parse_GetAudioEncoderConfigurationOptions(p_node, p_res);
}

BOOL onvif_GetStreamUri_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetStreamUri_RES * p_res;
    XMLN * p_node = xml_node_soap_get(p_xml, "GetStreamUriResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	p_res = (GetStreamUri_RES *)argv;
	if (NULL == p_res)
	{
	    return FALSE;
	}
	
	memset(p_res, 0, sizeof(GetStreamUri_RES));
	
    return parse_GetStreamUri(p_node, p_res);
}

BOOL onvif_SetSynchronizationPoint_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "SetSynchronizationPointResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	return TRUE;
}
		
BOOL onvif_GetSnapshotUri_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetSnapshotUri_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetSnapshotUriResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	p_res = (GetSnapshotUri_RES *)argv;
	if (NULL == p_res)
	{
	    return FALSE;
	}
	
	memset(p_res, 0, sizeof(GetSnapshotUri_RES));
	
    return parse_GetSnapshotUri(p_node, p_res);
}
		
BOOL onvif_GetNodes_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node;
	XMLN * p_PTZNode;
	GetNodes_RES * p_res;

	p_node = xml_node_soap_get(p_xml, "GetNodesResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetNodes_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
    
	memset(p_res, 0, sizeof(GetNodes_RES));
	
    p_PTZNode = xml_node_soap_get(p_node, "PTZNode");
    while (p_PTZNode)
    {
		ONVIF_PTZNode * p_ptz_node = onvif_add_PTZNode(&p_res->PTZNode);
    	if (p_ptz_node)
    	{
    		const char * p_FixedHomePosition;
			const char * p_token;

			p_FixedHomePosition = xml_attr_get(p_PTZNode, "FixedHomePosition");
    		if (p_FixedHomePosition)
    		{
    			p_res->PTZNode->PTZNode.FixedHomePositionFlag = 1;
    			p_res->PTZNode->PTZNode.FixedHomePosition =  parse_Bool(p_FixedHomePosition);
    		}

    		p_token = xml_attr_get(p_PTZNode, "token");
    		if (p_token)
    		{
	        	strncpy(p_ptz_node->PTZNode.token, p_token, sizeof(p_ptz_node->PTZNode.token)-1);
			}
			
	        if (parse_PTZNode(p_PTZNode, &p_ptz_node->PTZNode) == FALSE)
	        {
	            onvif_free_PTZNodes(&p_res->PTZNode);
	            return FALSE;
	        }
        }

        p_PTZNode = p_PTZNode->next;
    }
    
    return TRUE;
}
    	
BOOL onvif_GetNode_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node;
	XMLN * p_PTZNode;
	GetNode_RES * p_res;

	p_node = xml_node_soap_get(p_xml, "GetNodeResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetNode_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
    
	memset(p_res, 0, sizeof(GetNode_RES));
	
    p_PTZNode = xml_node_soap_get(p_node, "PTZNode");
    if (p_PTZNode)
    {
    	const char * p_FixedHomePosition;
		const char * p_token;

		p_FixedHomePosition = xml_attr_get(p_PTZNode, "FixedHomePosition");
    	if (p_FixedHomePosition)
    	{
    		p_res->PTZNode.FixedHomePositionFlag = 1;
			p_res->PTZNode.FixedHomePosition =  parse_Bool(p_FixedHomePosition);
		}

		p_token = xml_attr_get(p_PTZNode, "token");
		if (p_token)
		{
        	strncpy(p_res->PTZNode.token, p_token, sizeof(p_res->PTZNode.token)-1);
        }	

        if (parse_PTZNode(p_PTZNode, &p_res->PTZNode) == FALSE)
        {
            return FALSE;
        }
    }
    
    return TRUE;
}		

BOOL onvif_GetPresets_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node;
	XMLN * p_Preset;
	GetPresets_RES * p_res;

	p_node = xml_node_soap_get(p_xml, "GetPresetsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetPresets_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }

    p_Preset = xml_node_soap_get(p_node, "Preset");
    while (p_Preset)
    {		
    	ONVIF_PTZPreset * p_ptz_preset = onvif_add_PTZPreset(&p_res->PTZPresets);
    	if (p_ptz_preset)
    	{
	    	const char * p_token;

	    	p_token = xml_attr_get(p_Preset, "token");
	    	if (p_token)
	    	{
	        	strncpy(p_ptz_preset->PTZPreset.token, p_token, sizeof(p_ptz_preset->PTZPreset.token)-1);
	        }	

	        if (parse_Preset(p_Preset, &p_ptz_preset->PTZPreset) == FALSE)
	        {
	        	onvif_free_PTZPresets(&p_res->PTZPresets);
	            return FALSE;
	        }
		}
		
        p_Preset = p_Preset->next;
    }
    
    return TRUE;
}

BOOL onvif_SetPreset_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	SetPreset_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "SetPresetResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	p_res = (SetPreset_RES *)argv;
	if (NULL == p_res)
	{
	    return FALSE;
	}
	
	memset(p_res, 0, sizeof(SetPreset_RES));
	
    return parse_SetPreset(p_node, p_res);
}

BOOL onvif_RemovePreset_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "RemovePresetResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	return TRUE;
}

BOOL onvif_GotoPreset_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{	
	XMLN * p_node = xml_node_soap_get(p_xml, "GotoPresetResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	return TRUE;
}

BOOL onvif_GotoHomePosition_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "GotoHomePositionResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	return TRUE;
}

BOOL onvif_SetHomePosition_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "SetHomePositionResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	return TRUE;
}

BOOL onvif_GetStatus_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{	
	GetStatus_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetStatusResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

	p_res = (GetStatus_RES *)argv;
	if (NULL == p_res)
	{
	    return FALSE;
	}
	
	memset(p_res, 0, sizeof(GetStatus_RES));
	
    return parse_GetStatus(p_node, p_res);
}

BOOL onvif_ContinuousMove_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "ContinuousMoveResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	return TRUE;
}

BOOL onvif_RelativeMove_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "RelativeMoveResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	return TRUE;
}
		
BOOL onvif_AbsoluteMove_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "AbsoluteMoveResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	return TRUE;
}

BOOL onvif_ptz_Stop_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "StopResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	return TRUE;
}

BOOL onvif_GetConfigurations_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{	
	XMLN * p_node;
	XMLN * p_PTZConfiguration;
	GetConfigurations_RES * p_res;

	p_node = xml_node_soap_get(p_xml, "GetConfigurationsResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}

	p_res = (GetConfigurations_RES *) argv;
	if (NULL == p_res)
	{
	    return TRUE;
	}
	
	p_PTZConfiguration = xml_node_soap_get(p_node, "PTZConfiguration");
	while (p_PTZConfiguration)
	{
		ONVIF_PTZConfiguration * p_ptz_cfg = onvif_add_PTZConfiguration(&p_res->PTZConfiguration);
		if (p_ptz_cfg)
		{
			const char * p_token = xml_attr_get(p_PTZConfiguration, "token");
			if (p_token)
			{
    			strncpy(p_ptz_cfg->Configuration.token, p_token, sizeof(p_ptz_cfg->Configuration.token)-1);
    		}

    		if (parse_PTZConfiguration(p_PTZConfiguration, &p_ptz_cfg->Configuration) == FALSE)
            {
                onvif_free_PTZConfigurations(&p_res->PTZConfiguration);
                return FALSE;
            }		
        }

        p_PTZConfiguration = p_PTZConfiguration->next;
	}
        
	return TRUE;
} 

BOOL onvif_GetConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node;
	XMLN * p_PTZConfiguration;
	GetConfiguration_RES * p_res;

	p_node = xml_node_soap_get(p_xml, "GetConfigurationResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}

	p_res = (GetConfiguration_RES *) argv;
	if (NULL == p_res) 
	{
	    return TRUE;
	}
	
	p_PTZConfiguration = xml_node_soap_get(p_node, "PTZConfiguration");
	if (p_PTZConfiguration)
	{
		const char * p_token = xml_attr_get(p_PTZConfiguration, "token");
		if (p_token)
		{
			strncpy(p_res->PTZConfiguration.token, p_token, sizeof(p_res->PTZConfiguration.token)-1);
		}

		if (parse_PTZConfiguration(p_PTZConfiguration, &p_res->PTZConfiguration) == FALSE)
        {
            return FALSE;
        }		
	}
	
	return TRUE;
}
		
BOOL onvif_SetConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "SetConfigurationResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}
	
	return TRUE;
}

BOOL onvif_GetConfigurationOptions_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetConfigurationOptions_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetConfigurationOptionsResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}
	
	p_res = (GetConfigurationOptions_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

	memset(p_res, 0, sizeof(GetConfigurationOptions_RES));
	
	return parse_GetConfigurationOptions(p_xml, p_res);
}

BOOL onvif_GetPresetTours_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetPresetTours_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetPresetToursResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}
	
	p_res = (GetPresetTours_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

	memset(p_res, 0, sizeof(GetPresetTours_RES));
	
	return parse_GetPresetTours(p_xml, p_res);
}

BOOL onvif_GetPresetTour_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetPresetTour_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetPresetTourResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}
	
	p_res = (GetPresetTour_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

	memset(p_res, 0, sizeof(GetPresetTour_RES));
	
	return parse_GetPresetTour(p_xml, p_res);
}

BOOL onvif_GetPresetTourOptions_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetPresetTourOptions_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetPresetTourOptionsResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}
	
	p_res = (GetPresetTourOptions_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

	memset(p_res, 0, sizeof(GetPresetTourOptions_RES));
	
	return parse_GetPresetTourOptions(p_xml, p_res);
}

BOOL onvif_CreatePresetTour_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	CreatePresetTour_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "CreatePresetTourResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}
	
	p_res = (CreatePresetTour_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

	memset(p_res, 0, sizeof(CreatePresetTour_RES));
	
	return parse_CreatePresetTour(p_xml, p_res);
}

BOOL onvif_ModifyPresetTour_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "ModifyPresetTourResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}

	return TRUE;
}

BOOL onvif_OperatePresetTour_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "OperatePresetTourResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}

	return TRUE;
}

BOOL onvif_RemovePresetTour_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "RemovePresetTourResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}

	return TRUE;
}


BOOL onvif_GetEventProperties_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	return TRUE;
}
    
BOOL onvif_Renew_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "RenewResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}

	return TRUE;
}
    
BOOL onvif_Unsubscribe_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node = xml_node_soap_get(p_xml, "UnsubscribeResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}
	
	return TRUE;
}
    
BOOL onvif_Subscribe_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	Subscribe_RES * p_res;
    XMLN * p_node = xml_node_soap_get(p_xml, "SubscribeResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}

	p_res = (Subscribe_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

	memset(p_res, 0, sizeof(Subscribe_RES));
	
	return parse_Subscribe(p_node, p_res);
}

BOOL onvif_CreatePullPointSubscription_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	CreatePullPointSubscription_RES * p_res;
    XMLN * p_node = xml_node_soap_get(p_xml, "CreatePullPointSubscriptionResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}

	p_res = (CreatePullPointSubscription_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

	memset(p_res, 0, sizeof(CreatePullPointSubscription_RES));
	
	return parse_CreatePullPointSubscription(p_node, p_res);
}

BOOL onvif_PullMessages_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	PullMessages_RES * p_res;
    XMLN * p_node = xml_node_soap_get(p_xml, "PullMessagesResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}

	p_res = (PullMessages_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

	memset(p_res, 0, sizeof(PullMessages_RES));
	
	return parse_PullMessages(p_node, p_res);
}
    	
BOOL onvif_GetImagingSettings_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node;
	XMLN * p_ImagingSettings;
	GetImagingSettings_RES * p_res;

	p_node = xml_node_soap_get(p_xml, "GetImagingSettingsResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}
	
	p_res = (GetImagingSettings_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

	p_ImagingSettings = xml_node_soap_get(p_node, "ImagingSettings");
	if (NULL == p_ImagingSettings)
	{
		return FALSE;
	}
	
	return parse_ImagingSettings(p_ImagingSettings, &p_res->ImagingSettings);
}
    
BOOL onvif_SetImagingSettings_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node = xml_node_soap_get(p_xml, "SetImagingSettingsResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}
	
	return TRUE;
}

BOOL onvif_GetOptions_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetOptions_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetOptionsResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}
	
	p_res = (GetOptions_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

	memset(p_res, 0, sizeof(GetOptions_RES));
	
	return parse_GetOptions(p_node, p_res);
}

BOOL onvif_img_Move_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node = xml_node_soap_get(p_xml, "MoveResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}
	
	return TRUE;
}
  
BOOL onvif_img_Stop_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node = xml_node_soap_get(p_xml, "StopResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}
	
	return TRUE;
}
     
BOOL onvif_img_GetStatus_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    img_GetStatus_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetStatusResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}
	
	p_res = (img_GetStatus_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

	memset(p_res, 0, sizeof(img_GetStatus_RES));
	
	return parse_img_GetStatus(p_node, p_res);
}
 
BOOL onvif_img_GetMoveOptions_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    img_GetMoveOptions_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetMoveOptionsResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}
	
	p_res = (img_GetMoveOptions_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

	memset(p_res, 0, sizeof(img_GetMoveOptions_RES));
	
	return parse_img_GetMoveOptions(p_node, p_res);
}
 
BOOL onvif_GetOSDs_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node;
	XMLN * p_OSDs;
	GetOSDs_RES * p_res;

	p_node = xml_node_soap_get(p_xml, "GetOSDsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetOSDs_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
    
	memset(p_res, 0, sizeof(GetOSDs_RES));
	
    p_OSDs = xml_node_soap_get(p_node, "OSDs");
    while (p_OSDs)
    {
		ONVIF_OSDConfiguration * p_osd = onvif_add_OSDConfiguration(&p_res->OSDs);
    	if (p_osd)
    	{
			const char * p_token;

	        p_token = xml_attr_get(p_OSDs, "token");
	        if (p_token)
	        {
	        	strncpy(p_osd->OSD.token, p_token, sizeof(p_osd->OSD.token)-1);
			}
			
	        if (parse_OSDConfiguration(p_OSDs, &p_osd->OSD) == FALSE)
	        {
	            onvif_free_OSDConfigurations(&p_res->OSDs);
	            return FALSE;
	        }
        }

        p_OSDs = p_OSDs->next;
    }
    
    return TRUE;
}

BOOL onvif_GetOSD_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node;
	XMLN * p_OSD;
	GetOSD_RES * p_res;

	p_node = xml_node_soap_get(p_xml, "GetOSDResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetOSD_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
    
	memset(p_res, 0, sizeof(GetOSD_RES));
	
    p_OSD = xml_node_soap_get(p_node, "OSD");
    if (p_OSD)
    {
		const char * p_token;

        p_token = xml_attr_get(p_OSD, "token");
        if (p_token)
        {
        	strncpy(p_res->OSD.token, p_token, sizeof(p_res->OSD.token)-1);
		}
		
        if (parse_OSDConfiguration(p_OSD, &p_res->OSD) == FALSE)
        {
            return FALSE;
        }
    }
    
    return TRUE;
}

BOOL onvif_SetOSD_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "SetOSDResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
	
    return TRUE;
}

BOOL onvif_GetOSDOptions_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetOSDOptions_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetOSDOptionsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetOSDOptions_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
    
	memset(p_res, 0, sizeof(GetOSDOptions_RES));
	
    return parse_GetOSDOptions(p_node, p_res);
}

BOOL onvif_CreateOSD_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	CreateOSD_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "CreateOSDResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (CreateOSD_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
    
	memset(p_res, 0, sizeof(CreateOSD_RES));
	
    return parse_CreateOSD(p_node, p_res);
}

BOOL onvif_DeleteOSD_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "DeleteOSDResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
	
    return TRUE;
}

BOOL onvif_GetVideoAnalyticsConfigurations_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetVideoAnalyticsConfigurations_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetVideoAnalyticsConfigurationsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

	p_res = (GetVideoAnalyticsConfigurations_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
    
	memset(p_res, 0, sizeof(GetVideoAnalyticsConfigurations_RES));	
	
    return parse_GetVideoAnalyticsConfigurations(p_node, p_res);
}

BOOL onvif_AddVideoAnalyticsConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "AddVideoAnalyticsConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
	
    return TRUE;
}

BOOL onvif_GetVideoAnalyticsConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetVideoAnalyticsConfiguration_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetVideoAnalyticsConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
	
    p_res = (GetVideoAnalyticsConfiguration_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
    
	memset(p_res, 0, sizeof(GetVideoAnalyticsConfiguration_RES));	
	
    return parse_VideoAnalyticsConfiguration(p_node, &p_res->Configuration);
}

BOOL onvif_RemoveVideoAnalyticsConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "RemoveVideoAnalyticsConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
	
    return TRUE;
}

BOOL onvif_SetVideoAnalyticsConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "SetVideoAnalyticsConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
	
    return TRUE;
}

BOOL onvif_GetSupportedRules_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetSupportedRules_RES * p_res = (GetSupportedRules_RES *)argv;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetSupportedRulesResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
	
    if (NULL == p_res)
    {
    	return TRUE;
    }
    
	memset(p_res, 0, sizeof(GetSupportedRules_RES));	
	
    return parse_GetSupportedRules(p_node, p_res);
}

BOOL onvif_CreateRules_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "CreateRulesResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
	
    return TRUE;
}

BOOL onvif_DeleteRules_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "DeleteRulesResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
	
    return TRUE;
}

BOOL onvif_GetRules_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetRules_RES * p_res = (GetRules_RES *)argv;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetRulesResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    if (NULL == p_res)
    {
    	return TRUE;
    }
    
	memset(p_res, 0, sizeof(GetRules_RES));	
	
    return parse_GetRules(p_node, p_res);
}

BOOL onvif_ModifyRules_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "ModifyRulesResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
	
    return TRUE;
}

BOOL onvif_CreateAnalyticsModules_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "CreateAnalyticsModulesResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
	
    return TRUE;
}

BOOL onvif_DeleteAnalyticsModules_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "DeleteAnalyticsModulesResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
	
    return TRUE;
}

BOOL onvif_GetAnalyticsModules_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetAnalyticsModules_RES * p_res = (GetAnalyticsModules_RES *)argv;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetAnalyticsModulesResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
	
    if (NULL == p_res)
    {
    	return TRUE;
    }
    
	memset(p_res, 0, sizeof(GetAnalyticsModules_RES));	
	
    return parse_GetAnalyticsModules(p_node, p_res);
}

BOOL onvif_ModifyAnalyticsModules_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "ModifyAnalyticsModulesResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
	
    return TRUE;
}


BOOL onvif_tr2_GetVideoEncoderConfigurations_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_Configurations;
	tr2_GetVideoEncoderConfigurations_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetVideoEncoderConfigurationsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (tr2_GetVideoEncoderConfigurations_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

	memset(p_res, 0, sizeof(tr2_GetVideoEncoderConfigurationOptions_RES));

	p_Configurations = xml_node_soap_get(p_node, "Configurations");
    while (p_Configurations && soap_strcmp(p_Configurations->name, "Configurations") == 0)
    {
		ONVIF_VideoEncoder2Configuration * p_v_enc = onvif_add_VideoEncoder2Configuration(&p_res->Configurations);
    	if (p_v_enc)
    	{
	        if (parse_VideoEncoder2Configuration(p_Configurations, &p_v_enc->Configuration) == FALSE)
	        {
	            onvif_free_VideoEncoder2Configurations(&p_res->Configurations);
	            return FALSE;
	        }
        }

        p_Configurations = p_Configurations->next;
    }

    return TRUE;
}

BOOL onvif_tr2_GetVideoEncoderConfigurationOptions_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    tr2_GetVideoEncoderConfigurationOptions_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetVideoEncoderConfigurationOptionsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (tr2_GetVideoEncoderConfigurationOptions_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

    memset(p_res, 0, sizeof(tr2_GetVideoEncoderConfigurationOptions_RES));

	return parse_tr2_GetVideoEncoderConfigurationOptions(p_node, p_res);
}

BOOL onvif_tr2_SetVideoEncoderConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "SetConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}

BOOL onvif_tr2_GetProfiles_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node;
	XMLN * p_Profiles;
	tr2_GetProfiles_RES * p_res;

	p_node = xml_node_soap_get(p_xml, "GetProfilesResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (tr2_GetProfiles_RES *) argv;
    if (NULL == p_res)
    {
    	return TRUE;
    }
    
	memset(p_res, 0, sizeof(tr2_GetProfiles_RES));
	
    p_Profiles = xml_node_soap_get(p_node, "Profiles");
    while (p_Profiles)
    {
		ONVIF_MediaProfile * p_profile = onvif_add_MediaProfile(&p_res->Profiles);
    	if (p_profile)
    	{
    		const char * p_fixed;
			const char * p_token;

			p_fixed = xml_attr_get(p_Profiles, "fixed");
    		if (p_fixed)
    		{
	        	p_profile->MediaProfile.fixed = parse_Bool(p_fixed);
	        }

	        p_token = xml_attr_get(p_Profiles, "token");
	        if (p_token)
	        {
	        	strncpy(p_profile->MediaProfile.token, p_token, sizeof(p_profile->MediaProfile.token)-1);
			}
			
	        if (parse_MediaProfile(p_Profiles, &p_profile->MediaProfile) == FALSE)
	        {
	            onvif_free_MediaProfiles(&p_res->Profiles);
	            return FALSE;
	        }
        }

        p_Profiles = p_Profiles->next;
    }
    
    return TRUE;
}
 
BOOL onvif_tr2_CreateProfile_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	tr2_CreateProfile_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "CreateProfileResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (tr2_CreateProfile_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

    memset(p_res, 0, sizeof(tr2_CreateProfile_RES));

	return parse_tr2_CreateProfile(p_node, p_res);
}
 
BOOL onvif_tr2_DeleteProfile_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "DeleteProfileResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
 
BOOL onvif_tr2_GetStreamUri_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	tr2_GetStreamUri_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetStreamUriResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (tr2_GetStreamUri_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

    memset(p_res, 0, sizeof(tr2_GetStreamUri_RES));

	return parse_tr2_GetStreamUri(p_node, p_res);
}
 
BOOL onvif_tr2_GetVideoSourceConfigurations_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_Configurations;
	tr2_GetVideoSourceConfigurations_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetVideoSourceConfigurationsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (tr2_GetVideoSourceConfigurations_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

	memset(p_res, 0, sizeof(tr2_GetVideoSourceConfigurations_RES));

	p_Configurations = xml_node_soap_get(p_node, "Configurations");
    while (p_Configurations && soap_strcmp(p_Configurations->name, "Configurations") == 0)
    {
		ONVIF_VideoSourceConfiguration * p_v_src_cfg = onvif_add_VideoSourceConfiguration(&p_res->Configurations);
    	if (p_v_src_cfg)
    	{
    		const char * p_token = xml_attr_get(p_Configurations, "token");
    		if (p_token)
    		{
	        	strncpy(p_v_src_cfg->Configuration.token, p_token, sizeof(p_v_src_cfg->Configuration.token)-1);
			}
			
	        if (parse_VideoSourceConfiguration(p_Configurations, &p_v_src_cfg->Configuration) == FALSE)
	        {
	            onvif_free_VideoSourceConfigurations(&p_res->Configurations);
	            return FALSE;
	        }
        }

        p_Configurations = p_Configurations->next;
    }

    return TRUE;
}
 
BOOL onvif_tr2_GetVideoSourceConfigurationOptions_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	tr2_GetVideoSourceConfigurationOptions_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetVideoSourceConfigurationOptionsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (tr2_GetVideoSourceConfigurationOptions_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

	memset(p_res, 0, sizeof(tr2_GetVideoSourceConfigurationOptions_RES));

	return parse_GetVideoSourceConfigurationOptions(p_node, (GetVideoSourceConfigurationOptions_RES*)p_res);
}
 
BOOL onvif_tr2_SetVideoSourceConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "SetConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
 
BOOL onvif_tr2_SetSynchronizationPoint_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "SetSynchronizationPointResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
 
BOOL onvif_tr2_GetMetadataConfigurations_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_Configurations;
	tr2_GetMetadataConfigurations_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetMetadataConfigurationsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (tr2_GetMetadataConfigurations_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

	memset(p_res, 0, sizeof(tr2_GetMetadataConfigurations_RES));

	p_Configurations = xml_node_soap_get(p_node, "Configurations");
    while (p_Configurations && soap_strcmp(p_Configurations->name, "Configurations") == 0)
    {
		ONVIF_MetadataConfiguration * p_cfg = onvif_add_MetadataConfiguration(&p_res->Configurations);
    	if (p_cfg)
    	{
    		const char * p_token = xml_attr_get(p_Configurations, "token");
    		if (p_token)
    		{
	        	strncpy(p_cfg->Configuration.token, p_token, sizeof(p_cfg->Configuration.token)-1);
			}
			
	        if (parse_MetadataConfiguration(p_Configurations, &p_cfg->Configuration) == FALSE)
	        {
	            onvif_free_MetadataConfigurations(&p_res->Configurations);
	            return FALSE;
	        }
        }

        p_Configurations = p_Configurations->next;
    }

    return TRUE;	
}
 
BOOL onvif_tr2_GetMetadataConfigurationOptions_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "GetMetadataConfigurationOptionsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	return TRUE;
}
 
BOOL onvif_tr2_SetMetadataConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "SetConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
 
BOOL onvif_tr2_GetAudioEncoderConfigurations_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_Configurations;
	tr2_GetAudioEncoderConfigurations_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetAudioEncoderConfigurationsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (tr2_GetAudioEncoderConfigurations_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

	memset(p_res, 0, sizeof(tr2_GetAudioEncoderConfigurations_RES));

	p_Configurations = xml_node_soap_get(p_node, "Configurations");
    while (p_Configurations && soap_strcmp(p_Configurations->name, "Configurations") == 0)
    {
		ONVIF_AudioEncoder2Configuration * p_cfg = onvif_add_AudioEncoder2Configuration(&p_res->Configurations);
    	if (p_cfg)
    	{
    		const char * p_token = xml_attr_get(p_Configurations, "token");
    		if (p_token)
    		{
	        	strncpy(p_cfg->Configuration.token, p_token, sizeof(p_cfg->Configuration.token)-1);
			}
			
	        if (parse_AudioEncoder2Configuration(p_Configurations, &p_cfg->Configuration) == FALSE)
	        {
	            onvif_free_AudioEncoder2Configurations(&p_res->Configurations);
	            return FALSE;
	        }
        }

        p_Configurations = p_Configurations->next;
    }

    return TRUE;
}
 
BOOL onvif_tr2_GetAudioSourceConfigurations_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_Configurations;
	tr2_GetAudioSourceConfigurations_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetAudioSourceConfigurationsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (tr2_GetAudioSourceConfigurations_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

	memset(p_res, 0, sizeof(tr2_GetAudioSourceConfigurations_RES));

	p_Configurations = xml_node_soap_get(p_node, "Configurations");
    while (p_Configurations && soap_strcmp(p_Configurations->name, "Configurations") == 0)
    {
		ONVIF_AudioSourceConfiguration * p_cfg = onvif_add_AudioSourceConfiguration(&p_res->Configurations);
    	if (p_cfg)
    	{
    		const char * p_token = xml_attr_get(p_Configurations, "token");
    		if (p_token)
    		{
	        	strncpy(p_cfg->Configuration.token, p_token, sizeof(p_cfg->Configuration.token)-1);
			}
			
	        if (parse_AudioSourceConfiguration(p_Configurations, &p_cfg->Configuration) == FALSE)
	        {
	            onvif_free_AudioSourceConfigurations(&p_res->Configurations);
	            return FALSE;
	        }
        }

        p_Configurations = p_Configurations->next;
    }

    return TRUE;
}
 
BOOL onvif_tr2_GetAudioSourceConfigurationOptions_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "GetAudioSourceConfigurationOptionsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    return TRUE;
}
 
BOOL onvif_tr2_SetAudioSourceConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "SetConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
 
BOOL onvif_tr2_SetAudioEncoderConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "SetConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
 
BOOL onvif_tr2_GetAudioEncoderConfigurationOptions_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	tr2_GetAudioEncoderConfigurationOptions_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetAudioEncoderConfigurationOptionsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (tr2_GetAudioEncoderConfigurationOptions_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

    memset(p_res, 0, sizeof(tr2_GetAudioEncoderConfigurationOptions_RES));

	return parse_tr2_GetAudioEncoderConfigurationOptions(p_node, p_res);
}
 
BOOL onvif_tr2_AddConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "AddConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
 
BOOL onvif_tr2_RemoveConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "RemoveConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
 
BOOL onvif_tr2_GetVideoEncoderInstances_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	tr2_GetVideoEncoderInstances_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetVideoEncoderInstancesResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (tr2_GetVideoEncoderInstances_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

    memset(p_res, 0, sizeof(tr2_GetVideoEncoderInstances_RES));

	return parse_tr2_GetVideoEncoderInstances(p_node, p_res);
} 

#ifdef PROFILE_G_SUPPORT

BOOL onvif_CreateRecording_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    CreateRecording_RES * p_res;
    XMLN * p_node = xml_node_soap_get(p_xml, "CreateRecordingResponse");
	if (NULL == p_node)
	{
		return FALSE;
	}
	
	p_res = (CreateRecording_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

    memset(p_res, 0, sizeof(CreateRecording_RES));

	return parse_CreateRecording(p_node, p_res);
}
  
BOOL onvif_DeleteRecording_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node = xml_node_soap_get(p_xml, "DeleteRecordingResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
    
BOOL onvif_GetRecordings_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    GetRecordings_RES * p_res;
    XMLN * p_node = xml_node_soap_get(p_xml, "GetRecordingsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    p_res = (GetRecordings_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

    memset(p_res, 0, sizeof(GetRecordings_RES));

	return parse_GetRecordings(p_node, p_res);
}
 
BOOL onvif_SetRecordingConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node = xml_node_soap_get(p_xml, "SetRecordingConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
 
BOOL onvif_GetRecordingConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    GetRecordingConfiguration_RES * p_res;
    XMLN * p_node = xml_node_soap_get(p_xml, "GetRecordingConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    p_res = (GetRecordingConfiguration_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

    memset(p_res, 0, sizeof(GetRecordingConfiguration_RES));

	return parse_GetRecordingConfiguration(p_node, p_res);
}
 
BOOL onvif_GetRecordingOptions_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    GetRecordingOptions_RES * p_res;
    XMLN * p_node = xml_node_soap_get(p_xml, "GetRecordingOptionsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    p_res = (GetRecordingOptions_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

    memset(p_res, 0, sizeof(GetRecordingOptions_RES));

	return parse_GetRecordingOptions(p_node, p_res);
}
 
BOOL onvif_CreateTrack_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    CreateTrack_RES * p_res;
    XMLN * p_node = xml_node_soap_get(p_xml, "CreateTrackResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    p_res = (CreateTrack_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

    memset(p_res, 0, sizeof(CreateTrack_RES));

	return parse_CreateTrack(p_node, p_res);
}
 
BOOL onvif_DeleteTrack_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node = xml_node_soap_get(p_xml, "DeleteTrackResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
 
BOOL onvif_GetTrackConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    GetTrackConfiguration_RES * p_res;
    XMLN * p_node = xml_node_soap_get(p_xml, "GetTrackConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    p_res = (GetTrackConfiguration_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

    memset(p_res, 0, sizeof(GetTrackConfiguration_RES));

	return parse_GetTrackConfiguration(p_node, p_res);
}
 
BOOL onvif_SetTrackConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node = xml_node_soap_get(p_xml, "SetTrackConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
 
BOOL onvif_CreateRecordingJob_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    CreateRecordingJob_RES * p_res;
    XMLN * p_node = xml_node_soap_get(p_xml, "CreateRecordingJobResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    p_res = (CreateRecordingJob_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

    memset(p_res, 0, sizeof(CreateRecordingJob_RES));

	return parse_CreateRecordingJob(p_node, p_res);
}
 
BOOL onvif_DeleteRecordingJob_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node = xml_node_soap_get(p_xml, "DeleteRecordingJobResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
 
BOOL onvif_GetRecordingJobs_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    GetRecordingJobs_RES * p_res;
    XMLN * p_node = xml_node_soap_get(p_xml, "GetRecordingJobsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    p_res = (GetRecordingJobs_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

    memset(p_res, 0, sizeof(GetRecordingJobs_RES));

	return parse_GetRecordingJobs(p_node, p_res);
}
 
BOOL onvif_SetRecordingJobConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    SetRecordingJobConfiguration_RES * p_res;
    XMLN * p_node = xml_node_soap_get(p_xml, "SetRecordingJobConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    p_res = (SetRecordingJobConfiguration_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

    memset(p_res, 0, sizeof(SetRecordingJobConfiguration_RES));

	return parse_SetRecordingJobConfiguration(p_node, p_res);
}
 
BOOL onvif_GetRecordingJobConfiguration_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    GetRecordingJobConfiguration_RES * p_res;
    XMLN * p_node = xml_node_soap_get(p_xml, "GetRecordingJobConfigurationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    p_res = (GetRecordingJobConfiguration_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

    memset(p_res, 0, sizeof(GetRecordingJobConfiguration_RES));

	return parse_GetRecordingJobConfiguration(p_node, p_res);
}
 
BOOL onvif_SetRecordingJobMode_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    XMLN * p_node = xml_node_soap_get(p_xml, "SetRecordingJobModeResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
 
BOOL onvif_GetRecordingJobState_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    GetRecordingJobState_RES * p_res;
    XMLN * p_node = xml_node_soap_get(p_xml, "GetRecordingJobStateResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    p_res = (GetRecordingJobState_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

    memset(p_res, 0, sizeof(GetRecordingJobState_RES));

	return parse_GetRecordingJobState(p_node, p_res);
}
 
BOOL onvif_GetReplayUri_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetReplayUri_RES * p_res;
    XMLN * p_node = xml_node_soap_get(p_xml, "GetReplayUriResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	p_res = (GetReplayUri_RES *)argv;
	if (NULL == p_res)
	{
	    return FALSE;
	}
	
	memset(p_res, 0, sizeof(GetReplayUri_RES));
	
    return parse_GetReplayUri(p_node, p_res);
}

BOOL onvif_GetRecordingSummary_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetRecordingSummary_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetRecordingSummaryResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	p_res = (GetRecordingSummary_RES *)argv;
	if (NULL == p_res)
	{
	    return FALSE;
	}
	
	memset(p_res, 0, sizeof(GetRecordingSummary_RES));
	
    return parse_GetRecordingSummary(p_node, p_res);
}

BOOL onvif_GetRecordingInformation_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetRecordingInformation_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetRecordingInformationResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	p_res = (GetRecordingInformation_RES *)argv;
	if (NULL == p_res)
	{
	    return FALSE;
	}
	
	memset(p_res, 0, sizeof(GetRecordingInformation_RES));
	
    return parse_GetRecordingInformation(p_node, p_res);
}

BOOL onvif_GetMediaAttributes_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetMediaAttributes_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetMediaAttributesResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	p_res = (GetMediaAttributes_RES *)argv;
	if (NULL == p_res)
	{
	    return FALSE;
	}
	
	memset(p_res, 0, sizeof(GetMediaAttributes_RES));
	
    return parse_GetMediaAttributes(p_node, p_res);
}

BOOL onvif_FindRecordings_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	FindRecordings_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "FindRecordingsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	p_res = (FindRecordings_RES *)argv;
	if (NULL == p_res)
	{
	    return FALSE;
	}
	
	memset(p_res, 0, sizeof(FindRecordings_RES));
	
    return parse_FindRecordings(p_node, p_res);
}

BOOL onvif_GetRecordingSearchResults_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetRecordingSearchResults_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetRecordingSearchResultsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	p_res = (GetRecordingSearchResults_RES *)argv;
	if (NULL == p_res)
	{
	    return FALSE;
	}
	
	memset(p_res, 0, sizeof(GetRecordingSearchResults_RES));
	
    return parse_GetRecordingSearchResults(p_node, p_res);
}

BOOL onvif_FindEvents_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	FindEvents_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "FindEventsResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	p_res = (FindEvents_RES *)argv;
	if (NULL == p_res)
	{
	    return FALSE;
	}
	
	memset(p_res, 0, sizeof(FindEvents_RES));
	
    return parse_FindEvents(p_node, p_res);
}

BOOL onvif_GetEventSearchResults_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	return TRUE;
}

BOOL onvif_GetSearchState_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetSearchState_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetSearchStateResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	p_res = (GetSearchState_RES *)argv;
	if (NULL == p_res)
	{
	    return FALSE;
	}
	
	memset(p_res, 0, sizeof(GetSearchState_RES));
	
    return parse_GetSearchState(p_node, p_res);
}

BOOL onvif_EndSearch_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	EndSearch_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "EndSearchResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
	p_res = (EndSearch_RES *)argv;
	if (NULL == p_res)
	{
	    return FALSE;
	}
	
	memset(p_res, 0, sizeof(EndSearch_RES));
	
    return parse_EndSearch(p_node, p_res);
}


#endif // end of PROFILE_G_SUPPORT

#ifdef PROFILE_C_SUPPORT

BOOL onvif_GetAccessPointInfoList_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetAccessPointInfoList_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetAccessPointInfoListResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetAccessPointInfoList_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

    memset(p_res, 0, sizeof(GetAccessPointInfoList_RES));

	return parse_GetAccessPointInfoList(p_node, p_res);
}
   
BOOL onvif_GetAccessPointInfo_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetAccessPointInfo_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetAccessPointInfoResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetAccessPointInfo_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

    memset(p_res, 0, sizeof(GetAccessPointInfo_RES));

	return parse_GetAccessPointInfo(p_node, p_res);
}
 
BOOL onvif_GetDoorInfoList_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetDoorInfoList_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetDoorInfoListResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetDoorInfoList_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

    memset(p_res, 0, sizeof(GetDoorInfoList_RES));

	return parse_GetDoorInfoList(p_node, p_res);
}
 
BOOL onvif_GetDoorInfo_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetDoorInfo_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetDoorInfoResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetDoorInfo_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

    memset(p_res, 0, sizeof(GetDoorInfo_RES));

	return parse_GetDoorInfo(p_node, p_res);
}
 
BOOL onvif_GetAreaInfoList_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetAreaInfoList_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetAreaInfoListResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetAreaInfoList_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

    memset(p_res, 0, sizeof(GetAreaInfoList_RES));

	return parse_GetAreaInfoList(p_node, p_res);
}
 
BOOL onvif_GetAreaInfo_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetAreaInfo_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetAreaInfoResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetAreaInfo_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

    memset(p_res, 0, sizeof(GetAreaInfo_RES));

	return parse_GetAreaInfo(p_node, p_res);
}
 
BOOL onvif_GetAccessPointState_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
    GetAccessPointState_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetAccessPointStateResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetAccessPointState_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

    memset(p_res, 0, sizeof(GetAccessPointState_RES));

	return parse_GetAccessPointState(p_node, p_res);
}
 
BOOL onvif_GetDoorState_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	GetDoorState_RES * p_res;
	XMLN * p_node = xml_node_soap_get(p_xml, "GetDoorStateResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }

    p_res = (GetDoorState_RES *) argv;
	if (NULL == p_res)
	{
		return TRUE;
	}

    memset(p_res, 0, sizeof(GetDoorState_RES));

	return parse_GetDoorState(p_node, p_res);
}
 
BOOL onvif_AccessDoor_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "AccessDoorResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
 
BOOL onvif_LockDoor_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "LockDoorResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
 
BOOL onvif_UnlockDoor_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "UnlockDoorResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
 
BOOL onvif_DoubleLockDoor_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "DoubleLockDoorResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
 
BOOL onvif_BlockDoor_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "BlockDoorResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
 
BOOL onvif_LockDownDoor_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "LockDownDoorResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
 
BOOL onvif_LockDownReleaseDoor_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "LockDownReleaseDoorResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
 
BOOL onvif_LockOpenDoor_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "LockOpenDoorResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
 
BOOL onvif_LockOpenReleaseDoor_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "LockOpenReleaseDoorResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
 
BOOL onvif_EnableAccessPoint_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "EnableAccessPointResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}
 
BOOL onvif_DisableAccessPoint_rly(XMLN * p_xml, ONVIF_DEVICE * p_dev, void * argv)
{
	XMLN * p_node = xml_node_soap_get(p_xml, "DisableAccessPointResponse");
    if (NULL == p_node)
    {
        return FALSE;
    }
    
    return TRUE;
}

#endif // end of PROFILE_C_SUPPORT


BOOL onvif_rly_handler(XMLN * p_xml, eOnvifAction act, ONVIF_DEVICE * p_dev, void * argv)
{
    BOOL ret = FALSE;
    
    switch(act)
	{
	case eGetCapabilities:
        ret = onvif_GetCapabilities_rly(p_xml, p_dev, argv);
        break;

    case eGetServices:
        ret = onvif_GetServices_rly(p_xml, p_dev, argv);
        break;
        
	case eGetDeviceInformation:
		ret = onvif_GetDeviceInformation_rly(p_xml, p_dev, argv);
		break;

	case eGetUsers:
		ret = onvif_GetUsers_rly(p_xml, p_dev, argv);
		break;

	case eCreateUsers:
		ret = onvif_CreateUsers_rly(p_xml, p_dev, argv);
		break;

	case eDeleteUsers:
		ret = onvif_DeleteUsers_rly(p_xml, p_dev, argv);
		break;

	case eSetUser:
		ret = onvif_SetUser_rly(p_xml, p_dev, argv);
		break;

    case eGetRemoteUser:
		ret = onvif_GetRemoteUser_rly(p_xml, p_dev, argv);
		break;

	case eSetRemoteUser:
		ret = onvif_SetRemoteUser_rly(p_xml, p_dev, argv);
		break;
		
	case eGetNetworkInterfaces:
        ret = onvif_GetNetworkInterfaces_rly(p_xml, p_dev, argv);
        break;

	case eSetNetworkInterfaces:
        ret = onvif_SetNetworkInterfaces_rly(p_xml, p_dev, argv);
        break;

	case eGetNTP:
		ret = onvif_GetNTP_rly(p_xml, p_dev, argv);
		break;

	case eSetNTP:
		ret = onvif_SetNTP_rly(p_xml, p_dev, argv);
		break;

	case eGetHostname:
		ret = onvif_GetHostname_rly(p_xml, p_dev, argv);
		break;

	case eSetHostname:
		ret = onvif_SetHostname_rly(p_xml, p_dev, argv);
		break;

	case eSetHostnameFromDHCP:
		ret = onvif_SetHostnameFromDHCP_rly(p_xml, p_dev, argv);
		break;
		
	case eGetDNS:
		ret = onvif_GetDNS_rly(p_xml, p_dev, argv);
		break;
		
	case eSetDNS:
		ret = onvif_SetDNS_rly(p_xml, p_dev, argv);
		break;	
		
	case eGetDynamicDNS:
		ret = onvif_GetDynamicDNS_rly(p_xml, p_dev, argv);
		break;
		
	case eSetDynamicDNS:
		ret = onvif_SetDynamicDNS_rly(p_xml, p_dev, argv);
		break;

	case eGetNetworkProtocols:
		ret = onvif_GetNetworkProtocols_rly(p_xml, p_dev, argv);
		break;

	case eSetNetworkProtocols:
		ret = onvif_SetNetworkProtocols_rly(p_xml, p_dev, argv);
		break;
		
	case eGetDiscoveryMode:
		ret = onvif_GetDiscoveryMode_rly(p_xml, p_dev, argv);
		break;

	case eSetDiscoveryMode:
		ret = onvif_SetDiscoveryMode_rly(p_xml, p_dev, argv);
		break;
		
	case eGetNetworkDefaultGateway:
		ret = onvif_GetNetworkDefaultGateway_rly(p_xml, p_dev, argv);
		break;

	case eSetNetworkDefaultGateway:
		ret = onvif_SetNetworkDefaultGateway_rly(p_xml, p_dev, argv);
		break;
		
    case eGetZeroConfiguration:
        ret = onvif_GetZeroConfiguration_rly(p_xml, p_dev, argv);
        break;
        
	case eSetZeroConfiguration:
	    ret = onvif_SetZeroConfiguration_rly(p_xml, p_dev, argv);
	    break;

	case eGetEndpointReference:
	    ret = onvif_GetEndpointReference_rly(p_xml, p_dev, argv);
	    break;
	    
	case eGetSystemDateAndTime:
		ret = onvif_GetSystemDateAndTime_rly(p_xml, p_dev, argv);
		break;
		
	case eSetSystemDateAndTime:
		ret = onvif_SetSystemDateAndTime_rly(p_xml, p_dev, argv);
		break;
		
	case eSystemReboot:
		ret = onvif_SystemReboot_rly(p_xml, p_dev, argv);
		break;

	case eSetSystemFactoryDefault:
		ret = onvif_SetSystemFactoryDefault_rly(p_xml, p_dev, argv);
		break;
		
	case eGetSystemLog:
		ret = onvif_GetSystemLog_rly(p_xml, p_dev, argv);
		break;
		
	case eGetScopes:
		ret = onvif_GetScopes_rly(p_xml, p_dev, argv);
		break;
		
	case eSetScopes:
		ret = onvif_SetScopes_rly(p_xml, p_dev, argv);
		break;
		
	case eAddScopes:
		ret = onvif_AddScopes_rly(p_xml, p_dev, argv);
		break;
		
	case eRemoveScopes:
		ret = onvif_RemoveScopes_rly(p_xml, p_dev, argv);
		break;

	case eStartFirmwareUpgrade:
	    ret = onvif_StartFirmwareUpgrade_rly(p_xml, p_dev, argv);
	    break;

	case eGetSystemUris:
	    ret = onvif_GetSystemUris_rly(p_xml, p_dev, argv);
	    break;
	    
	case eStartSystemRestore:
	    ret = onvif_StartSystemRestore_rly(p_xml, p_dev, argv);
	    break;
	    
	case eGetVideoSources:
		ret = onvif_GetVideoSources_rly(p_xml, p_dev, argv);
		break;
		
	case eGetAudioSources:
		ret = onvif_GetAudioSources_rly(p_xml, p_dev, argv);
		break;
		
	case eCreateProfile:
		ret = onvif_CreateProfile_rly(p_xml, p_dev, argv);
		break;
		
	case eGetProfile:
		ret = onvif_GetProfile_rly(p_xml, p_dev, argv);
		break;
		
	case eGetProfiles:
		ret = onvif_GetProfiles_rly(p_xml, p_dev, argv);
		break;
		
	case eAddVideoEncoderConfiguration:
		ret = onvif_AddVideoEncoderConfiguration_rly(p_xml, p_dev, argv);
		break;
		
	case eAddVideoSourceConfiguration:
		ret = onvif_AddVideoSourceConfiguration_rly(p_xml, p_dev, argv);
		break;
		
	case eAddAudioEncoderConfiguration:
		ret = onvif_AddAudioEncoderConfiguration_rly(p_xml, p_dev, argv);
		break;
		
	case eAddAudioSourceConfiguration:
		ret = onvif_AddAudioSourceConfiguration_rly(p_xml, p_dev, argv);
		break;

	case eGetVideoSourceModes:
		ret = onvif_GetVideoSourceModes_rly(p_xml, p_dev, argv);
		break;

	case eSetVideoSourceMode:
		ret = onvif_SetVideoSourceMode_rly(p_xml, p_dev, argv);
		break;
		
	case eAddPTZConfiguration:
		ret = onvif_AddPTZConfiguration_rly(p_xml, p_dev, argv);
		break;
		
	case eRemoveVideoEncoderConfiguration:
		ret = onvif_RemoveVideoEncoderConfiguration_rly(p_xml, p_dev, argv);
		break;
		
	case eRemoveVideoSourceConfiguration:
		ret = onvif_RemoveVideoSourceConfiguration_rly(p_xml, p_dev, argv);
		break;
		
	case eRemoveAudioEncoderConfiguration:
		ret = onvif_RemoveAudioEncoderConfiguration_rly(p_xml, p_dev, argv);
		break;
		
	case eRemoveAudioSourceConfiguration:
		ret = onvif_RemoveAudioSourceConfiguration_rly(p_xml, p_dev, argv);
		break;
		
	case eRemovePTZConfiguration:
		ret = onvif_RemovePTZConfiguration_rly(p_xml, p_dev, argv);
		break;
		
	case eDeleteProfile:
		ret = onvif_DeleteProfile_rly(p_xml, p_dev, argv);
		break;
		
	case eGetVideoSourceConfigurations:
		ret = onvif_GetVideoSourceConfigurations_rly(p_xml, p_dev, argv);
		break;
		
	case eGetVideoEncoderConfigurations:	
		ret = onvif_GetVideoEncoderConfigurations_rly(p_xml, p_dev, argv);
		break;
		
	case eGetAudioSourceConfigurations:
		ret = onvif_GetAudioSourceConfigurations_rly(p_xml, p_dev, argv);
		break;
		
	case eGetAudioEncoderConfigurations:
		ret = onvif_GetAudioEncoderConfigurations_rly(p_xml, p_dev, argv);
		break;
		
	case eGetVideoSourceConfiguration:
		ret = onvif_GetVideoSourceConfiguration_rly(p_xml, p_dev, argv);
		break;
		
	case eGetVideoEncoderConfiguration:
		ret = onvif_GetVideoEncoderConfiguration_rly(p_xml, p_dev, argv);
		break;
		
	case eGetAudioSourceConfiguration:
		ret = onvif_GetAudioSourceConfiguration_rly(p_xml, p_dev, argv);
		break;
		
	case eGetAudioEncoderConfiguration:
		ret = onvif_GetAudioEncoderConfiguration_rly(p_xml, p_dev, argv);
		break;
		
	case eSetVideoSourceConfiguration:
		ret = onvif_SetVideoSourceConfiguration_rly(p_xml, p_dev, argv);
		break;
		
	case eSetVideoEncoderConfiguration:
		ret = onvif_SetVideoEncoderConfiguration_rly(p_xml, p_dev, argv);
		break;
		
	case eSetAudioSourceConfiguration:
		ret = onvif_SetAudioSourceConfiguration_rly(p_xml, p_dev, argv);
		break;
		
	case eSetAudioEncoderConfiguration:
		ret = onvif_SetAudioEncoderConfiguration_rly(p_xml, p_dev, argv);
		break;
		
	case eGetVideoSourceConfigurationOptions:
		ret = onvif_GetVideoSourceConfigurationOptions_rly(p_xml, p_dev, argv);
		break;
		
	case eGetVideoEncoderConfigurationOptions:
		ret = onvif_GetVideoEncoderConfigurationOptions_rly(p_xml, p_dev, argv);
		break;
		
	case eGetAudioSourceConfigurationOptions:
		ret = onvif_GetAudioSourceConfigurationOptions_rly(p_xml, p_dev, argv);
		break;
		
	case eGetAudioEncoderConfigurationOptions:
		ret = onvif_GetAudioEncoderConfigurationOptions_rly(p_xml, p_dev, argv);
		break;
		
	case eGetStreamUri:
		ret = onvif_GetStreamUri_rly(p_xml, p_dev, argv);
		break;
		
	case eSetSynchronizationPoint:
		ret = onvif_SetSynchronizationPoint_rly(p_xml, p_dev, argv);
		break;
		
	case eGetSnapshotUri:
		ret = onvif_GetSnapshotUri_rly(p_xml, p_dev, argv);
		break;
		
    case eGetNodes:
    	ret = onvif_GetNodes_rly(p_xml, p_dev, argv);
    	break;
    	
	case eGetNode:
		ret = onvif_GetNode_rly(p_xml, p_dev, argv);
		break;
		
	case eGetPresets:
		ret = onvif_GetPresets_rly(p_xml, p_dev, argv);
		break;
		
	case eSetPreset:
		ret = onvif_SetPreset_rly(p_xml, p_dev, argv);
		break;
		
	case eRemovePreset:
		ret = onvif_RemovePreset_rly(p_xml, p_dev, argv);
		break;
		
	case eGotoPreset:
		ret = onvif_GotoPreset_rly(p_xml, p_dev, argv);
		break;
		
	case eGotoHomePosition:
		ret = onvif_GotoHomePosition_rly(p_xml, p_dev, argv);
		break;
		
	case eSetHomePosition:
		ret = onvif_SetHomePosition_rly(p_xml, p_dev, argv);
		break;
		
	case eGetStatus:
		ret = onvif_GetStatus_rly(p_xml, p_dev, argv);
		break;
		
	case eContinuousMove:
        ret = onvif_ContinuousMove_rly(p_xml, p_dev, argv);
        break;
        
	case eRelativeMove:
		ret = onvif_RelativeMove_rly(p_xml, p_dev, argv);
		break;
		
	case eAbsoluteMove:
		ret = onvif_AbsoluteMove_rly(p_xml, p_dev, argv);
		break;
		
	case ePTZStop:
        ret = onvif_ptz_Stop_rly(p_xml, p_dev, argv);
        break;
        
	case eGetConfigurations:
        ret = onvif_GetConfigurations_rly(p_xml, p_dev, argv);
        break;
        
	case eGetConfiguration:
		ret = onvif_GetConfiguration_rly(p_xml, p_dev, argv);
		break;
		
	case eSetConfiguration:
		ret = onvif_SetConfiguration_rly(p_xml, p_dev, argv);
		break;
			
	case eGetConfigurationOptions:
        ret = onvif_GetConfigurationOptions_rly(p_xml, p_dev, argv);
        break;

	case eGetPresetTours:
        ret = onvif_GetPresetTours_rly(p_xml, p_dev, argv);
        break;
        
	case eGetPresetTour:
        ret = onvif_GetPresetTour_rly(p_xml, p_dev, argv);
        break;
        
	case eGetPresetTourOptions:
        ret = onvif_GetPresetTourOptions_rly(p_xml, p_dev, argv);
        break;
        
	case eCreatePresetTour:
        ret = onvif_CreatePresetTour_rly(p_xml, p_dev, argv);
        break;
        
	case eModifyPresetTour:
        ret = onvif_ModifyPresetTour_rly(p_xml, p_dev, argv);
        break;
        
	case eOperatePresetTour:
        ret = onvif_OperatePresetTour_rly(p_xml, p_dev, argv);
        break;
        
	case eRemovePresetTour:
        ret = onvif_RemovePresetTour_rly(p_xml, p_dev, argv);
        break;
    
	case eGetEventProperties:
        ret = onvif_GetEventProperties_rly(p_xml, p_dev, argv);
        break;
    
	case eRenew:
        ret = onvif_Renew_rly(p_xml, p_dev, argv);
        break;
    
	case eUnsubscribe:
        ret = onvif_Unsubscribe_rly(p_xml, p_dev, argv);
        break;
    
	case eSubscribe:
        ret = onvif_Subscribe_rly(p_xml, p_dev, argv);
        break;

    case eCreatePullPointSubscription:
    	ret = onvif_CreatePullPointSubscription_rly(p_xml, p_dev, argv);
    	break;
    	
    case ePullMessages:
    	ret = onvif_PullMessages_rly(p_xml, p_dev, argv);
    	break;
    	
	case eGetImagingSettings:
        ret = onvif_GetImagingSettings_rly(p_xml, p_dev, argv);
        break;
    
	case eSetImagingSettings:
        ret = onvif_SetImagingSettings_rly(p_xml, p_dev, argv);
        break; 

	case eGetOptions:
		ret = onvif_GetOptions_rly(p_xml, p_dev, argv);
        break;

    case eimgMove:
		ret = onvif_img_Move_rly(p_xml, p_dev, argv);
        break;
        
	case eimgStop:
		ret = onvif_img_Stop_rly(p_xml, p_dev, argv);
        break;
        
	case eimgGetStatus:
		ret = onvif_img_GetStatus_rly(p_xml, p_dev, argv);
        break;
        
	case eimgGetMoveOptions:
		ret = onvif_img_GetMoveOptions_rly(p_xml, p_dev, argv);
        break;
        
    case eGetOSDs:
    	ret = onvif_GetOSDs_rly(p_xml, p_dev, argv);
    	break;
    	
	case eGetOSD:
		ret = onvif_GetOSD_rly(p_xml, p_dev, argv);
		break;
		
	case eSetOSD:
		ret = onvif_SetOSD_rly(p_xml, p_dev, argv);
		break;
		
	case eGetOSDOptions:
		ret = onvif_GetOSDOptions_rly(p_xml, p_dev, argv);
		break;
		
	case eCreateOSD:
		ret = onvif_CreateOSD_rly(p_xml, p_dev, argv);
		break;
		
	case eDeleteOSD:
		ret = onvif_DeleteOSD_rly(p_xml, p_dev, argv);
		break;
	
	case eGetVideoAnalyticsConfigurations:
		ret = onvif_GetVideoAnalyticsConfigurations_rly(p_xml, p_dev, argv);
		break;
		
	case eAddVideoAnalyticsConfiguration:
		ret = onvif_AddVideoAnalyticsConfiguration_rly(p_xml, p_dev, argv);
		break;
		
	case eGetVideoAnalyticsConfiguration:
		ret = onvif_GetVideoAnalyticsConfiguration_rly(p_xml, p_dev, argv);
		break;
		
	case eRemoveVideoAnalyticsConfiguration:
		ret = onvif_RemoveVideoAnalyticsConfiguration_rly(p_xml, p_dev, argv);
		break;
		
	case eSetVideoAnalyticsConfiguration:
		ret = onvif_SetVideoAnalyticsConfiguration_rly(p_xml, p_dev, argv);
		break;
		
	case eGetSupportedRules:
		ret = onvif_GetSupportedRules_rly(p_xml, p_dev, argv);
		break;
		
	case eCreateRules:
		ret = onvif_CreateRules_rly(p_xml, p_dev, argv);
		break;
		
	case eDeleteRules:
		ret = onvif_DeleteRules_rly(p_xml, p_dev, argv);
		break;
		
	case eGetRules:
		ret = onvif_GetRules_rly(p_xml, p_dev, argv);
		break;
		
	case eModifyRules:
		ret = onvif_ModifyRules_rly(p_xml, p_dev, argv);
		break;
		
	case eCreateAnalyticsModules:
		ret = onvif_CreateAnalyticsModules_rly(p_xml, p_dev, argv);
		break;
		
	case eDeleteAnalyticsModules:
		ret = onvif_DeleteAnalyticsModules_rly(p_xml, p_dev, argv);
		break;
		
	case eGetAnalyticsModules:
		ret = onvif_GetAnalyticsModules_rly(p_xml, p_dev, argv);
		break;
		
	case eModifyAnalyticsModules:
		ret = onvif_ModifyAnalyticsModules_rly(p_xml, p_dev, argv);
		break;

	case etr2GetVideoEncoderConfigurations:
		ret = onvif_tr2_GetVideoEncoderConfigurations_rly(p_xml, p_dev, argv);
		break;
		
	case etr2SetVideoEncoderConfiguration:
		ret = onvif_tr2_SetVideoEncoderConfiguration_rly(p_xml, p_dev, argv);
		break;
		
	case etr2GetVideoEncoderConfigurationOptions:
		ret = onvif_tr2_GetVideoEncoderConfigurationOptions_rly(p_xml, p_dev, argv);
		break;

	case etr2GetProfiles:
		ret = onvif_tr2_GetProfiles_rly(p_xml, p_dev, argv);
		break;
		
    case etr2CreateProfile:
		ret = onvif_tr2_CreateProfile_rly(p_xml, p_dev, argv);
		break;
		
    case etr2DeleteProfile:
		ret = onvif_tr2_DeleteProfile_rly(p_xml, p_dev, argv);
		break;
		
    case etr2GetStreamUri:
		ret = onvif_tr2_GetStreamUri_rly(p_xml, p_dev, argv);
		break;
		 
    case etr2GetVideoSourceConfigurations:
		ret = onvif_tr2_GetVideoSourceConfigurations_rly(p_xml, p_dev, argv);
		break;
		 
    case etr2GetVideoSourceConfigurationOptions:
		ret = onvif_tr2_GetVideoSourceConfigurationOptions_rly(p_xml, p_dev, argv);
		break;
		 
    case etr2SetVideoSourceConfiguration:
		ret = onvif_tr2_SetVideoSourceConfiguration_rly(p_xml, p_dev, argv);
		break;
		 
    case etr2SetSynchronizationPoint:
		ret = onvif_tr2_SetSynchronizationPoint_rly(p_xml, p_dev, argv);
		break;
		 
    case etr2GetMetadataConfigurations:
		ret = onvif_tr2_GetMetadataConfigurations_rly(p_xml, p_dev, argv);
		break;
		 
    case etr2GetMetadataConfigurationOptions:
		ret = onvif_tr2_GetMetadataConfigurationOptions_rly(p_xml, p_dev, argv);
		break;
		 
    case etr2SetMetadataConfiguration:
		ret = onvif_tr2_SetMetadataConfiguration_rly(p_xml, p_dev, argv);
		break;
		 
    case etr2GetAudioEncoderConfigurations:
		ret = onvif_tr2_GetAudioEncoderConfigurations_rly(p_xml, p_dev, argv);
		break;
		 
    case etr2GetAudioSourceConfigurations:
		ret = onvif_tr2_GetAudioSourceConfigurations_rly(p_xml, p_dev, argv);
		break;
		 
    case etr2GetAudioSourceConfigurationOptions:
		ret = onvif_tr2_GetAudioSourceConfigurationOptions_rly(p_xml, p_dev, argv);
		break;
		 
    case etr2SetAudioSourceConfiguration:
		ret = onvif_tr2_SetAudioSourceConfiguration_rly(p_xml, p_dev, argv);
		break;
		 
    case etr2SetAudioEncoderConfiguration:
		ret = onvif_tr2_SetAudioEncoderConfiguration_rly(p_xml, p_dev, argv);
		break;
		 
    case etr2GetAudioEncoderConfigurationOptions:
		ret = onvif_tr2_GetAudioEncoderConfigurationOptions_rly(p_xml, p_dev, argv);
		break;
		 
    case etr2AddConfiguration:
		ret = onvif_tr2_AddConfiguration_rly(p_xml, p_dev, argv);
		break;
		 
    case etr2RemoveConfiguration:
		ret = onvif_tr2_RemoveConfiguration_rly(p_xml, p_dev, argv);
		break;
		 
    case etr2GetVideoEncoderInstances:
		ret = onvif_tr2_GetVideoEncoderInstances_rly(p_xml, p_dev, argv);
		break;		 

#ifdef PROFILE_G_SUPPORT
    case eCreateRecording:
        ret = onvif_CreateRecording_rly(p_xml, p_dev, argv);
        break;
          
    case eDeleteRecording:
        ret = onvif_DeleteRecording_rly(p_xml, p_dev, argv);
        break;
        
    case eGetRecordings:
        ret = onvif_GetRecordings_rly(p_xml, p_dev, argv);
        break;
        
    case eSetRecordingConfiguration:
        ret = onvif_SetRecordingConfiguration_rly(p_xml, p_dev, argv);
        break;
        
    case eGetRecordingConfiguration:
        ret = onvif_GetRecordingConfiguration_rly(p_xml, p_dev, argv);
        break;
        
    case eGetRecordingOptions:
        ret = onvif_GetRecordingOptions_rly(p_xml, p_dev, argv);
        break;
        
    case eCreateTrack:
        ret = onvif_CreateTrack_rly(p_xml, p_dev, argv);
        break;
        
    case eDeleteTrack:
        ret = onvif_DeleteTrack_rly(p_xml, p_dev, argv);
        break;
        
    case eGetTrackConfiguration:
        ret = onvif_GetTrackConfiguration_rly(p_xml, p_dev, argv);
        break;
        
    case eSetTrackConfiguration:
        ret = onvif_SetTrackConfiguration_rly(p_xml, p_dev, argv);
        break;
        
    case eCreateRecordingJob:
        ret = onvif_CreateRecordingJob_rly(p_xml, p_dev, argv);
        break;
        
    case eDeleteRecordingJob:
        ret = onvif_DeleteRecordingJob_rly(p_xml, p_dev, argv);
        break;
        
    case eGetRecordingJobs:
        ret = onvif_GetRecordingJobs_rly(p_xml, p_dev, argv);
        break;
        
    case eSetRecordingJobConfiguration:
        ret = onvif_SetRecordingJobConfiguration_rly(p_xml, p_dev, argv);
        break;
        
    case eGetRecordingJobConfiguration:
        ret = onvif_GetRecordingJobConfiguration_rly(p_xml, p_dev, argv);
        break;
        
    case eSetRecordingJobMode:
        ret = onvif_SetRecordingJobMode_rly(p_xml, p_dev, argv);
        break;
        
    case eGetRecordingJobState:
        ret = onvif_GetRecordingJobState_rly(p_xml, p_dev, argv);
        break;        

    case eGetReplayUri:
		ret = onvif_GetReplayUri_rly(p_xml, p_dev, argv);
        break;

    case eGetRecordingSummary:
		ret = onvif_GetRecordingSummary_rly(p_xml, p_dev, argv);
        break;

	case eGetRecordingInformation:
    	ret = onvif_GetRecordingInformation_rly(p_xml, p_dev, argv);
        break;
        
	case eGetMediaAttributes:
    	ret = onvif_GetMediaAttributes_rly(p_xml, p_dev, argv);
        break;
        
	case eFindRecordings:
    	ret = onvif_FindRecordings_rly(p_xml, p_dev, argv);
        break;
        
	case eGetRecordingSearchResults:
    	ret = onvif_GetRecordingSearchResults_rly(p_xml, p_dev, argv);
        break;
        
	case eFindEvents:
    	ret = onvif_FindEvents_rly(p_xml, p_dev, argv);
        break;
        
	case eGetEventSearchResults:
    	ret = onvif_GetEventSearchResults_rly(p_xml, p_dev, argv);
        break;
        
	case eGetSearchState:
    	ret = onvif_GetSearchState_rly(p_xml, p_dev, argv);
        break;
        
	case eEndSearch:
    	ret = onvif_EndSearch_rly(p_xml, p_dev, argv);
        break;   

#endif // end o PROFILE_G_SUPPORT

#ifdef PROFILE_C_SUPPORT
    case eGetAccessPointInfoList:
		ret = onvif_GetAccessPointInfoList_rly(p_xml, p_dev, argv);
		break;
		  
    case eGetAccessPointInfo:
		ret = onvif_GetAccessPointInfo_rly(p_xml, p_dev, argv);
		break;
		
    case eGetDoorInfoList:
		ret = onvif_GetDoorInfoList_rly(p_xml, p_dev, argv);
		break;
		
    case eGetDoorInfo:
		ret = onvif_GetDoorInfo_rly(p_xml, p_dev, argv);
		break;
		
    case eGetAreaInfoList:
		ret = onvif_GetAreaInfoList_rly(p_xml, p_dev, argv);
		break;
		
    case eGetAreaInfo:
		ret = onvif_GetAreaInfo_rly(p_xml, p_dev, argv);
		break;
		
    case eGetAccessPointState:
		ret = onvif_GetAccessPointState_rly(p_xml, p_dev, argv);
		break;
		
    case eGetDoorState:
		ret = onvif_GetDoorState_rly(p_xml, p_dev, argv);
		break;
		
    case eAccessDoor:
		ret = onvif_AccessDoor_rly(p_xml, p_dev, argv);
		break;
		
    case eLockDoor:
		ret = onvif_LockDoor_rly(p_xml, p_dev, argv);
		break;
		
    case eUnlockDoor:
		ret = onvif_UnlockDoor_rly(p_xml, p_dev, argv);
		break;
		
    case eDoubleLockDoor:
		ret = onvif_DoubleLockDoor_rly(p_xml, p_dev, argv);
		break;
		
    case eBlockDoor:
		ret = onvif_BlockDoor_rly(p_xml, p_dev, argv);
		break;
		
    case eLockDownDoor:
		ret = onvif_LockDownDoor_rly(p_xml, p_dev, argv);
		break;
		
    case eLockDownReleaseDoor:
		ret = onvif_LockDownReleaseDoor_rly(p_xml, p_dev, argv);
		break;
		
    case eLockOpenDoor:
		ret = onvif_LockOpenDoor_rly(p_xml, p_dev, argv);
		break;
		
    case eLockOpenReleaseDoor:
		ret = onvif_LockOpenReleaseDoor_rly(p_xml, p_dev, argv);
		break;
		
    case eEnableAccessPoint:
		ret = onvif_EnableAccessPoint_rly(p_xml, p_dev, argv);
		break;
		
    case eDisableAccessPoint:
		ret = onvif_DisableAccessPoint_rly(p_xml, p_dev, argv);
		break;		
#endif // end of PROFILE_C_SUPPORT

	default:
	    break;
	}

	return ret;
}






