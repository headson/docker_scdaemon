/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2010-2016, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/
#ifndef ONVIF_API_H
#define ONVIF_API_H

#include "sys_inc.h"
#include "onvif.h"
#include "onvif_cln.h"

#ifdef __cplusplus
extern "C" {
#endif

ONVIF_API BOOL GetCapabilities(ONVIF_DEVICE * p_dev);
ONVIF_API BOOL GetServices(ONVIF_DEVICE * p_dev);
ONVIF_API BOOL GetSystemDateAndTime(ONVIF_DEVICE * p_dev);
ONVIF_API BOOL GetDeviceInformation(ONVIF_DEVICE * p_dev);
ONVIF_API BOOL GetProfiles(ONVIF_DEVICE * p_dev);
ONVIF_API BOOL GetStreamUris(ONVIF_DEVICE * p_dev);
ONVIF_API BOOL GetVideoSourceConfigurations(ONVIF_DEVICE * p_dev);
ONVIF_API BOOL GetAudioSourceConfigurations(ONVIF_DEVICE * p_dev);
ONVIF_API BOOL GetVideoEncoderConfigurations(ONVIF_DEVICE * p_dev);
ONVIF_API BOOL GetAudioEncoderConfigurations(ONVIF_DEVICE * p_dev);
ONVIF_API BOOL GetNodes(ONVIF_DEVICE * p_dev);
ONVIF_API BOOL GetConfigurations(ONVIF_DEVICE * p_dev);
ONVIF_API BOOL GetVideoSources(ONVIF_DEVICE * p_dev);
ONVIF_API BOOL GetAudioSources(ONVIF_DEVICE * p_dev);
ONVIF_API BOOL GetImagingSettings(ONVIF_DEVICE * p_dev);
ONVIF_API BOOL Subscribe(ONVIF_DEVICE * p_dev, int index);
ONVIF_API BOOL Unsubscribe(ONVIF_DEVICE * p_dev);

/**
 * @desc Get the device snapshot
 * @param 
 *  p_buf  [out] return the snapshot buffer
 *  buflen [out] return the snapshot buffer length
 *
 * @note if call success, the caller should call FreeSnapshotBuff to free the snapshot buffer
 *
 */
ONVIF_API BOOL GetSnapshot(ONVIF_DEVICE * p_dev, const char * profile_token, unsigned char ** p_buf, int * buflen);

/**
 * @desc Free the snapshot buffer
 * @param 
 *  p_buf the snapshot buffer
 *
 */
ONVIF_API void FreeSnapshotBuff(unsigned char * p_buf);

/**
 * @desc Firmware upgrade
 * @param 
 *  filename the upgrade filename
 *
 */
ONVIF_API BOOL FirmwareUpgrade(ONVIF_DEVICE * p_dev, const char * filename);

/**
 * @desc backup system settings
 * @param 
 *  filename , save as system backup
 *
 */
ONVIF_API BOOL SystemBackup(ONVIF_DEVICE * p_dev, const char * filename);

/**
 * @desc restore system settings
 * @param 
 *  filename the system backup filename
 *
 */
ONVIF_API BOOL SystemRestore(ONVIF_DEVICE * p_dev, const char * filename);

#ifdef __cplusplus
}
#endif

#endif



