
/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2010-2016, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#ifndef ONVIF_COMM_H
#define ONVIF_COMM_H

/***************************************************************************************/
#define ONVIF_TOKEN_LEN   	    100
#define ONVIF_NAME_LEN    	    100
#define ONVIF_URI_LEN     	    300
#define ONVIF_SCOPE_LEN		    128

#define MAX_PTZ_PRESETS         100 
#define MAX_DNS_SERVER		    2
#define MAX_SEARCHDOMAIN	    4
#define MAX_NTP_SERVER		    2
#define MAX_SERVER_PORT		    4
#define MAX_GATEWAY			    2
#define MAX_RES_NUMS		    32
#define MAX_SCOPE_NUMS		    100
#define MAX_USERS			    10
#define MAX_IP_ADDRS		    4

/* Floating point precision */
#define FPP					    0.01

#define ACCESS_CTRL_MAX_LIMIT   10
#define DOOR_CTRL_MAX_LIMIT     10

/***************************************************************************************/
typedef enum 
{
	ONVIF_OK = 0,
	ONVIF_ERR_ConnFailure = -1,	
	ONVIF_ERR_MallocFailure = -2,
	ONVIF_ERR_NotSupportHttps = -3,
	ONVIF_ERR_RecvTimeout = -4,
	ONVIF_ERR_InvalidContentType = -5,
	ONVIF_ERR_NullContent = -6,
	ONVIF_ERR_ParseFailed = -7,
	ONVIF_ERR_HandleFailed = -8,
	ONVIF_ERR_HttpResponseError = -9,
	
} ONVIF_RET;

/***************************************************************************************/

typedef enum 
{
	CapabilityCategory_Invalid = -1,
	CapabilityCategory_All = 0, 
	CapabilityCategory_Analytics = 1, 
	CapabilityCategory_Device = 2, 
	CapabilityCategory_Events = 3, 
	CapabilityCategory_Imaging = 4, 
	CapabilityCategory_Media = 5, 
	CapabilityCategory_PTZ = 6,
	CapabilityCategory_Recording = 7,
	CapabilityCategory_Search = 8,
	CapabilityCategory_Replay = 9,
	CapabilityCategory_AccessControl = 10,
	CapabilityCategory_DoorControl = 11,
	CapabilityCategory_DeviceIO = 12,
	CapabilityCategory_Media2 = 13,
} onvif_CapabilityCategory;

typedef enum 
{
	FactoryDefaultType_Hard = 0, 
	FactoryDefaultType_Soft = 1
} onvif_FactoryDefaultType;

typedef enum 
{
	SystemLogType_System = 0,
	SystemLogType_Access = 1
} onvif_SystemLogType;

typedef enum  
{
    VideoEncoding_Unknown = -1,
	VideoEncoding_JPEG = 0, 
	VideoEncoding_MPEG4 = 1, 
	VideoEncoding_H264 = 2,
	VideoEncoding_H265 = 3
} onvif_VideoEncoding;

typedef enum  
{
    AudioEncoding_Unknown = -1,
	AudioEncoding_G711 = 0, 
	AudioEncoding_G726 = 1, 
	AudioEncoding_AAC = 2
} onvif_AudioEncoding;

typedef enum H264Profile 
{
	H264Profile_Baseline = 0, 
	H264Profile_Main = 1, 
	H264Profile_Extended = 2, 
	H264Profile_High = 3
} onvif_H264Profile;

typedef enum  
{
	Mpeg4Profile_SP = 0,
	Mpeg4Profile_ASP = 1
} onvif_Mpeg4Profile;

typedef enum  
{
	UserLevel_Administrator = 0, 
	UserLevel_Operator = 1,
	UserLevel_User = 2, 
	UserLevel_Anonymous = 3,
	UserLevel_Extended = 4
} onvif_UserLevel;

typedef enum MoveStatus 
{
	MoveStatus_IDLE = 0, 
	MoveStatus_MOVING = 1, 
	MoveStatus_UNKNOWN = 2
} onvif_MoveStatus;

// OSD type
typedef enum 
{
	OSDType_Text = 0,
	OSDType_Image = 1,
	OSDType_Extended =2
} onvif_OSDType;

// OSD position type
typedef enum
{
	OSDPosType_UpperLeft = 0,
	OSDPosType_UpperRight = 1,
	OSDPosType_LowerLeft = 2,
	OSDPosType_LowerRight = 3,
	OSDPosType_Custom = 4
} onvif_OSDPosType;

typedef enum
{
	OSDTextType_Plain,								    // The Plain type means the OSD is shown as a text string which defined in the "PlainText" item
	OSDTextType_Date,								    // The Date type means the OSD is shown as a date, format of which should be present in the "DateFormat" item
	OSDTextType_Time,								    // The Time type means the OSD is shown as a time, format of which should be present in the "TimeFormat" item
	OSDTextType_DateAndTime,						    // The DateAndTime type means the OSD is shown as date and time, format of which should be present in the "DateFormat" and the "TimeFormat" item
} onvif_OSDTextType;

// BacklightCompensation mode
typedef enum 
{
	BacklightCompensationMode_OFF = 0, 				    // Backlight compensation is disabled
	BacklightCompensationMode_ON = 1				    // Backlight compensation is enabled
} onvif_BacklightCompensationMode;

// Exposure mode
typedef enum  
{
	ExposureMode_AUTO = 0, 
	ExposureMode_MANUAL = 1
} onvif_ExposureMode;

// Exposure Priority
typedef enum  
{
	ExposurePriority_LowNoise = 0, 
	ExposurePriority_FrameRate = 1
} onvif_ExposurePriority;

// AutoFocus Mode
typedef enum 
{
	AutoFocusMode_AUTO = 0, 
	AutoFocusMode_MANUAL = 1
} onvif_AutoFocusMode;

typedef enum  
{
	WideDynamicMode_OFF = 0, 
	WideDynamicMode_ON = 1
} onvif_WideDynamicMode;

typedef enum  
{
	IrCutFilterMode_ON = 0,
	IrCutFilterMode_OFF = 1, 
	IrCutFilterMode_AUTO = 2
} onvif_IrCutFilterMode;

typedef enum WhiteBalanceMode 
{
	WhiteBalanceMode_AUTO = 0, 
	WhiteBalanceMode_MANUAL = 1
} onvif_WhiteBalanceMode;

typedef enum onvif_EFlipMode 
{
	EFlipMode_OFF = 0, 
	EFlipMode_ON = 1, 
	EFlipMode_Extended = 2
} onvif_EFlipMode;

typedef enum 
{
	ReverseMode_OFF = 0, 
	ReverseMode_ON = 1, 
	ReverseMode_AUTO = 2, 
	ReverseMode_Extended = 3
} onvif_ReverseMode;

typedef enum  
{
	DiscoveryMode_Discoverable = 0, 
	DiscoveryMode_NonDiscoverable = 1
} onvif_DiscoveryMode;

typedef enum  
{
	SetDateTimeType_Manual = 0, 
	SetDateTimeType_NTP = 1
} onvif_SetDateTimeType;

typedef enum  
{
	StreamType_Invalid = -1,
	StreamType_RTP_Unicast = 0,
	StreamType_RTP_Multicast = 1
} onvif_StreamType;

typedef enum  
{
	TransportProtocol_Invalid = -1,
	TransportProtocol_UDP = 0, 
	TransportProtocol_TCP = 1, 
	TransportProtocol_RTSP = 2, 
	TransportProtocol_HTTP = 3
} onvif_TransportProtocol;

typedef enum
{
	TrackType_Invalid = -1,
	TrackType_Video = 0, 
	TrackType_Audio = 1, 
	TrackType_Metadata = 2,
	TrackType_Extended = 3
} onvif_TrackType;

typedef enum
{
	DynamicDNSType_NoUpdate = 0, 
	DynamicDNSType_ClientUpdates = 1, 
	DynamicDNSType_ServerUpdates = 2
} onvif_DynamicDNSType;

typedef enum
{
	PropertyOperation_Invalid = -1,
	PropertyOperation_Initialized = 0,
	PropertyOperation_Deleted = 1, 
	PropertyOperation_Changed = 2
} onvif_PropertyOperation;

typedef enum 
{ 
	RecordingStatus_Initiated = 0, 
	RecordingStatus_Recording = 1, 
	RecordingStatus_Stopped = 2, 
	RecordingStatus_Removing = 3, 
	RecordingStatus_Removed = 4, 
	RecordingStatus_Unknown = 5 
} onvif_RecordingStatus;

typedef enum
{
	SearchState_Queued = 0, 						    // The search is queued and not yet started.
	SearchState_Searching = 1,						    // The search is underway and not yet completed
	SearchState_Completed = 2,						    // The search has been completed and no new results will be found
	SearchState_Unknown = 3							    // The state of the search is unknown. (This is not a valid response from GetSearchState.)
} onvif_SearchState;

typedef enum 
{
    RotateMode_OFF = 0, 
    RotateMode_ON = 1, 
    RotateMode_AUTO = 2
} onvif_RotateMode;

typedef enum
{
    ScopeDefinition_Fixed = 0, 
    ScopeDefinition_Configurable = 1
} onvif_ScopeDefinition;

// The physical state of a Door
typedef enum  
{
    DoorPhysicalState_Unknown = 0,                      // Value is currently unknown (possibly due to initialization or monitors not giving a conclusive result)
    DoorPhysicalState_Open = 1,                         // Door is open
    DoorPhysicalState_Closed = 2,                       // Door is closed
    DoorPhysicalState_Fault = 3                         // Door monitor fault is detected
} onvif_DoorPhysicalState;

// The physical state of a Lock (including Double Lock)
typedef enum  
{
    LockPhysicalState_Unknown = 0,                      // Value is currently not known
    LockPhysicalState_Locked = 1,                       // Lock is activated
    LockPhysicalState_Unlocked = 2,                     // Lock is not activated
    LockPhysicalState_Fault = 3                         // Lock fault is detected
} onvif_LockPhysicalState;

// Describes the state of a Door with regard to alarms
typedef enum  
{
    DoorAlarmState_Normal = 0,                          // No alarm
    DoorAlarmState_DoorForcedOpen = 1,                  // Door is forced open
    DoorAlarmState_DoorOpenTooLong = 2                  // Door is held open too long
} onvif_DoorAlarmState;

// Describes the state of a Tamper detector
typedef enum  
{
    DoorTamperState_Unknown = 0,                        // Value is currently not known
    DoorTamperState_NotInTamper = 1,                    // No tampering is detected
    DoorTamperState_TamperDetected = 2                  // Tampering is detected
} onvif_DoorTamperState;

// Describes the state of a Door fault
typedef enum  
{
    DoorFaultState_Unknown = 0,                         // Fault state is unknown
    DoorFaultState_NotInFault = 1,                      // No fault is detected
    DoorFaultState_FaultDetected = 2                    // Fault is detected
} onvif_DoorFaultState;

// DoorMode parameters describe current Door mode from a logical perspective
typedef enum  
{
    DoorMode_Unknown = 0,                               // The Door is in an Unknown state
    DoorMode_Locked = 1,                                // The Door is in a Locked state. In this mode the device shall provide momentary access using the AccessDoor method if supported by the Door instance
    DoorMode_Unlocked = 2,                              // The Door is in an Unlocked (Permanent Access) state. Alarms related to door timing operations such as open too long or forced are masked in this mode
    DoorMode_Accessed = 3,                              // The Door is in an Accessed state (momentary/temporary access). Alarms related to timing operations such as "door forced" are masked in this mode
    DoorMode_Blocked = 4,                               // The Door is in a Blocked state (Door is locked, and AccessDoor requests are ignored, i.e., it is not possible for door to go to Accessed state)
    DoorMode_LockedDown = 5,                            // The Door is in a LockedDown state (Door is locked) until released using the LockDownReleaseDoor command. AccessDoor, LockDoor, UnlockDoor, BlockDoor and 
                                                        //  LockOpenDoor requests are ignored, i.e., it is not possible for door to go to Accessed, Locked, Unlocked, Blocked or LockedOpen state    
    DoorMode_LockedOpen = 6,                            // The Door is in a LockedOpen state (Door is unlocked) until released using the LockOpenReleaseDoor command. AccessDoor, LockDoor, UnlockDoor, BlockDoor and 
                                                        //  LockDownDoor requests are ignored, i.e., it is not possible for door to go to Accessed, Locked, Unlocked, Blocked or LockedDown state
    DoorMode_DoubleLocked = 7                           // The Door is in a Double Locked state - for doors with multiple locks. If the door does not have any DoubleLock, this shall be treated as a normal Locked mode. 
                                                        //  When changing to an Unlocked mode from the DoubleLocked mode, the door may first go to Locked state before unlocking
} onvif_DoorMode;

typedef enum
{
    RelayMode_Monostable = 0,                           //  After setting the state, the relay returns to its idle state after the specified time
    RelayMode_Bistable = 1,                             // After setting the state, the relay remains in this state
} onvif_RelayMode;

typedef enum
{
    RelayIdleState_closed = 0,                          // means that the relay is closed when the relay state is set to 'inactive' through the trigger command and open when the state is set to 'active' through the same command
    RelayIdleState_open = 1,                            // means that the relay is open when the relay state is set to 'inactive' through the trigger command and closed when the state is set to 'active' through the same command    
} onvif_RelayIdleState;

typedef enum  
{
    RelayLogicalState_active = 0,                       // 
    RelayLogicalState_inactive = 1,                     // 
} onvif_RelayLogicalState;

typedef enum  
{
    DigitalIdleState_closed = 0, 
    DigitalIdleState_open = 1,
} onvif_DigitalIdleState;

typedef enum  
{
    ParityBit_None = 0,
    ParityBit_Even = 1, 
    ParityBit_Odd = 2, 
    ParityBit_Mark = 3, 
    ParityBit_Space = 4, 
    ParityBit_Extended = 5
} onvif_ParityBit;

typedef enum  
{
    SerialPortType_RS232 = 0, 
    SerialPortType_RS422HalfDuplex = 1, 
    SerialPortType_RS422FullDuplex = 2, 
    SerialPortType_RS485HalfDuplex = 3, 
    SerialPortType_RS485FullDuplex = 4, 
    SerialPortType_Generic = 5
} onvif_SerialPortType;

typedef enum 
{
    PTZPresetTourOperation_Start = 0, 
    PTZPresetTourOperation_Stop = 1, 
    PTZPresetTourOperation_Pause = 2, 
    PTZPresetTourOperation_Extended = 3
} onvif_PTZPresetTourOperation;

typedef enum 
{
    PTZPresetTourState_Idle = 0, 
    PTZPresetTourState_Touring = 1,
    PTZPresetTourState_Paused = 2, 
    PTZPresetTourState_Extended = 3
} onvif_PTZPresetTourState;

typedef enum 
{
    PTZPresetTourDirection_Forward = 0,
    PTZPresetTourDirection_Backward = 1,
    PTZPresetTourDirection_Extended = 2
} onvif_PTZPresetTourDirection;

typedef enum 
{
    Dot11AuthAndMangementSuite_None = 0, 
    Dot11AuthAndMangementSuite_Dot1X = 1, 
    Dot11AuthAndMangementSuite_PSK = 2, 
    Dot11AuthAndMangementSuite_Extended = 3
} onvif_Dot11AuthAndMangementSuite;

typedef enum 
{
    Dot11Cipher_CCMP = 0, 
    Dot11Cipher_TKIP = 1, 
    Dot11Cipher_Any = 2, 
    Dot11Cipher_Extended = 3
} onvif_Dot11Cipher ;

typedef enum  
{
    Dot11SignalStrength_None = 0, 
    Dot11SignalStrength_VeryBad = 1, 
    Dot11SignalStrength_Bad = 2, 
    Dot11SignalStrength_Good = 3, 
    Dot11SignalStrength_VeryGood = 4, 
    Dot11SignalStrength_Extended = 5
} onvif_Dot11SignalStrength;

typedef enum 
{
    Dot11StationMode_Ad_hoc = 0, 
    Dot11StationMode_Infrastructure = 1, 
    Dot11StationMode_Extended = 2
} onvif_Dot11StationMode;

typedef enum 
{
    Dot11SecurityMode_None = 0, 
    Dot11SecurityMode_WEP = 1, 
    Dot11SecurityMode_PSK = 2, 
    Dot11SecurityMode_Dot1X = 3, 
    Dot11SecurityMode_Extended = 4
} onvif_Dot11SecurityMode;


/***************************************************************************************/
typedef struct
{
    char    Code[128];
    char    Subcode[128];
    char    Reason[256];
} onvif_Fault;

typedef struct
{
	int		https;										// https connection
    int     port;           						    // onvif port
    char    host[24];       						    // ip of xaddrs
    char    url[128];       						    // /onvif/device_service
} onvif_XAddr;

typedef struct
{
	int     Major;	                                    // required
	int     Minor;	                                    // required
} onvif_Version;

typedef struct 
{
    float 	Min;									    // required
    float 	Max;									    // required
} onvif_FloatRange;

typedef struct
{
	float	x;										    // required
	float	y;										    // required
} onvif_Vector;

typedef struct 
{
	int     sizeItems;
	int     Items[10];	                                // optional
} onvif_IntList;

typedef struct 
{
	int     sizeItems;
	float   Items[10];	                                // optional
} onvif_FloatList;

typedef struct 
{
	int     sizeItems;
	
	onvif_ParityBit Items[10];	                        // optional
} onvif_ParityBitList;

/* device capabilities */
typedef struct
{
	// network capabilities
	uint32	IPFilter 			: 1; 				    // Indicates support for IP filtering
	uint32	ZeroConfiguration 	: 1; 				    // Indicates support for zeroconf
	uint32	IPVersion6			: 1; 				    // Indicates support for IPv6
	uint32 	DynDNS 				: 1; 				    // Indicates support for dynamic DNS configuration
	uint32  Dot11Configuration  : 1; 				    // Indicates support for IEEE 802.11 configuration
	uint32  HostnameFromDHCP    : 1; 				    // Indicates support for retrieval of hostname from DHCP
	uint32  DHCPv6              : 1; 				    // Indicates support for Stateful IPv6 DHCP

	// system capabilities
	uint32 	DiscoveryResolve 	: 1; 				    // Indicates support for WS Discovery resolve requests
	uint32 	DiscoveryBye 		: 1; 				    // Indicates support for WS-Discovery Bye
	uint32 	RemoteDiscovery 	: 1; 				    // Indicates support for remote discovery
	uint32 	SystemBackup 		: 1; 				    // Indicates support for system backup through MTOM
	uint32 	SystemLogging 		: 1; 				    // Indicates support for retrieval of system logging through MTOM
	uint32 	FirmwareUpgrade 	: 1; 				    // Indicates support for firmware upgrade through MTOM
	uint32  HttpFirmwareUpgrade : 1; 				    // Indicates support for system backup through MTOM
	uint32  HttpSystemBackup    : 1; 				    // Indicates support for system backup through HTTP
	uint32  HttpSystemLogging   : 1; 				    // Indicates support for retrieval of system logging through HTTP
	uint32  HttpSupportInformation : 1; 			    // Indicates support for retrieving support information through HTTP
    uint32  StorageConfiguration: 1;                    // Indicates support for storage configuration interfaces

    // scurity capabilities
    uint32  TLS10               : 1; 				    // Indicates support for TLS 1.0
    uint32  TLS11               : 1; 				    // Indicates support for TLS 1.1
    uint32  TLS12               : 1; 				    // Indicates support for TLS 1.2
    uint32  OnboardKeyGeneration: 1; 				    // Indicates support for onboard key generation
    uint32  AccessPolicyConfig  : 1; 				    // Indicates support for access policy configuration
    uint32  DefaultAccessPolicy : 1; 				    // Indicates support for the ONVIF default access policy
    uint32  Dot1X               : 1; 				    // Indicates support for IEEE 802.1X configuration
    uint32  RemoteUserHandling  : 1; 				    // Indicates support for remote user configuration. Used when accessing another device
    uint32  X509Token           : 1; 				    // Indicates support for WS-Security X.509 token
    uint32  SAMLToken           : 1; 				    // Indicates support for WS-Security SAML token
    uint32  KerberosToken       : 1; 				    // Indicates support for WS-Security Kerberos token
    uint32  UsernameToken       : 1; 				    // Indicates support for WS-Security Username token
    uint32  HttpDigest          : 1; 				    // Indicates support for WS over HTTP digest authenticated communication layer
    uint32  RELToken            : 1; 				    // Indicates support for WS-Security REL token

    // IO 
    int     InputConnectors;	                        // optional, 
	int     RelayOutputs;	                            // optional, 
	
	int     Dot1XConfigurations;    				    // Indicates the maximum number of Dot1X configurations supported by the device
	int     NTP;                    				    // Maximum number of NTP servers supported by the devices SetNTP command
	int     SupportedEAPMethods;    				    // EAP Methods supported by the device. 
	                                				    // The int values refer to the <a href="http://www.iana.org/assignments/eap-numbers/eap-numbers.xhtml">IANA EAP Registry</a>
	int     MaxUsers;               				    // The maximum number of users that the device supports
    int     MaxUserNameLength;                          // Maximum number of characters supported for the username by CreateUsers
    int     MaxPasswordLength;                          // Maximum number of characters supported for the password by CreateUsers and SetUser

	// misc capabilities
    char    AuxiliaryCommands[100]; 				    // Lists of commands supported by SendAuxiliaryCommand

    onvif_Version   Version;                            // required
    onvif_XAddr	    XAddr;
} onvif_DevicesCapabilities;

/* media capabilities */
typedef struct
{
    uint32  SnapshotUri         : 1; 				    // Indicates if GetSnapshotUri is supported
    uint32  Rotation            : 1; 				    // Indicates whether or not Rotation feature is supported
    uint32  VideoSourceMode     : 1; 				    // Indicates the support for changing video source mode
    uint32  OSD                 : 1; 				    // Indicates if OSD is supported
    uint32  EXICompression      : 1;                    // Indicates the support for the Efficient XML Interchange (EXI) binary XML format
	uint32	RTPMulticast 		: 1; 				    // Indicates support for RTP multicast
	uint32	RTP_TCP				: 1; 				    // Indicates support for RTP over TCP
	uint32	RTP_RTSP_TCP		: 1; 				    // Indicates support for RTP/RTSP/TCP
	uint32  NonAggregateControl : 1; 				    // Indicates support for non aggregate RTSP control
	uint32  NoRTSPStreaming     : 1; 				    // Indicates the device does not support live media streaming via RTSP
	uint32  support				: 1; 				    // Indication if the device supports media service
	uint32	reserved			: 21;

	int     MaximumNumberOfProfiles; 				    // Maximum number of profiles supported

    onvif_Version   Version;                            // required
    onvif_XAddr	    XAddr;
} onvif_MediaCapabilities;

/* PTZ capabilities */
typedef struct
{
    uint32  EFlip               : 1;	 			    // Indicates whether or not EFlip is supported
    uint32  Reverse             : 1; 				    // Indicates whether or not reversing of PT control direction is supported
    uint32  GetCompatibleConfigurations : 1; 		    // Indicates support for the GetCompatibleConfigurations command    
    uint32  MoveStatus          : 1;                    // Indicates that the PTZVector includes MoveStatus information
    uint32  StatusPosition      : 1;                    // Indicates that the PTZVector includes Position information
    uint32  support				: 1; 				    // Indication if the device supports ptz service
	uint32	reserved 			: 26;

    onvif_Version   Version;                            // required    
    onvif_XAddr	    XAddr;
} onvif_PTZCapabilities;

/* event capabilities */
typedef struct
{
	uint32	WSSubscriptionPolicySupport	: 1; 		    // Indicates that the WS Subscription policy is supported
	uint32	WSPullPointSupport 	: 1; 				    // Indicates that the WS Pull Point is supported
	uint32	WSPausableSubscriptionManagerInterfaceSupport : 1; // Indicates that the WS Pausable Subscription Manager Interface is supported
	uint32  PersistentNotificationStorage : 1; 		    // Indication if the device supports persistent notification storage
	uint32  support				: 1; 				    // Indication if the device supports events service
	uint32	reserved 			: 27;

	int     MaxNotificationProducers; 				    // Maximum number of supported notification producers as defined by WS-BaseNotification
	int     MaxPullPoints;            				    // Maximum supported number of notification pull points

    onvif_Version   Version;                            // required
    onvif_XAddr	    XAddr;
} onvif_EventCapabilities;

/* image capabilities */
typedef struct
{
    uint32  ImageStabilization  : 1; 				    // Indicates whether or not Image Stabilization feature is supported
	uint32  support				: 1; 				    // Indication if the device supports image service
	uint32	reserved 			: 30;

    onvif_Version   Version;                            // required
    onvif_XAddr	    XAddr;
} onvif_ImagingCapabilities;

/* analytics capabilities*/
typedef struct
{
	uint32  RuleSupport			: 1;				    // Indication that the device supports the rules interface and the rules syntax
	uint32  AnalyticsModuleSupport : 1;				    // Indication that the device supports the scene analytics module interface
	uint32  CellBasedSceneDescriptionSupported : 1;	    // Indication that the device produces the cell based scene description
	uint32  support				: 1; 				    // Indication if the device supports Analytics service
	uint32	reserved 			: 28;

    onvif_Version   Version;                            // required
	onvif_XAddr     XAddr;
} onvif_AnalyticsCapabilities;

/* recording capabilities */
typedef struct
{
    uint32  ReceiverSource      : 1;
    uint32  MediaProfileSource  : 1;
    uint32  DynamicRecordings   : 1; 				    // Indication if the device supports dynamic creation and deletion of recordings
    uint32  DynamicTracks       : 1; 				    // Indication if the device supports dynamic creation and deletion of tracks
    uint32  Options             : 1; 				    // Indication if the device supports the GetRecordingOptions command
    uint32  MetadataRecording   : 1; 				    // Indication if the device supports recording metadata
    uint32  JPEG                : 1; 				    // Indication if supports JPEG encoding
    uint32  MPEG4               : 1; 				    // Indication if supports MPEG4 encoding
    uint32  H264                : 1; 				    // Indication if supports H264 encoding
    uint32  G711                : 1; 				    // Indication if supports G711 encoding
    uint32  G726                : 1; 				    // Indication if supports G726 encoding
    uint32  AAC                 : 1; 				    // Indication if supports AAC encoding
    uint32  support				: 1; 				    // Indication if the device supports recording service
	uint32	reserved 			: 19;

	uint32  MaxStringLength;
	float   MaxRate;            					    // Maximum supported bit rate for all tracks of a recording in kBit/s
	float   MaxTotalRate;       					    // Maximum supported bit rate for all recordings in kBit/s.
    int     MaxRecordings;      					    // Maximum number of recordings supported.
    int     MaxRecordingJobs;   					    // Maximum total number of supported recording jobs by the device

    onvif_Version   Version;                            // required    
	onvif_XAddr	    XAddr;
} onvif_RecordingCapabilities;

/* search capabilities */
typedef struct
{
    uint32  MetadataSearch      : 1;
    uint32  GeneralStartEvents  : 1; 				    // Indicates support for general virtual property events in the FindEvents method
    uint32  support				: 1; 				    // Indication if the device supports search service
	uint32	reserved 			: 29;

    onvif_Version   Version;                            // required
	onvif_XAddr	    XAddr;
} onvif_SearchCapabilities;

/* replay capabilities */
typedef struct
{
    uint32  ReversePlayback     : 1; 				    // Indicator that the Device supports reverse playback as defined in the ONVIF Streaming Specification
    uint32  RTP_RTSP_TCP        : 1; 				    // Indicates support for RTP/RTSP/TCP
    uint32  support				: 1; 				    // Indication if the device supports replay service
	uint32	reserved 			: 29;

	onvif_FloatRange	SessionTimeoutRange; 		    // The minimum and maximum valid values supported as session timeout in seconds

    onvif_Version   Version;                            // required
	onvif_XAddr	    XAddr;
} onvif_ReplayCapabilities;

/* accesscontrol capabilities */
typedef struct
{
    uint32  support				: 1; 				    // Indication if the device supports accesscontrol service
	uint32	reserved 			: 31;
	
    int     MaxLimit;                                   // The maximum number of entries returned by a single GetList request. 
                                                        //  The device shall never return more than this number of entities in a single response
	
	onvif_Version   Version;                            // required
	onvif_XAddr	    XAddr;
} onvif_AccessControlCapabilities;

/* doorcontrol capabilities */
typedef struct
{
    uint32  support				: 1; 				    // Indication if the device supports doorcontrol service
	uint32	reserved 			: 31;
	
    int     MaxLimit;                                   // The maximum number of entries returned by a single Get<Entity>List or Get<Entity> request. 
                                                        //  The device shall never return more than this number of entities in a single response
	
	onvif_Version   Version;                            // required
	onvif_XAddr	    XAddr;
} onvif_DoorControlCapabilities;

typedef struct 
{
	uint32  VideoSourcesFlag	: 1; 				    // Indicates whether the field VideoSources is valid
	uint32  VideoOutputsFlag	: 1; 				    // Indicates whether the field VideoSources is valid
	uint32  AudioSourcesFlag	: 1; 				    // Indicates whether the field VideoSources is valid
	uint32  AudioOutputsFlag	: 1; 				    // Indicates whether the field VideoSources is valid
	uint32  RelayOutputsFlag	: 1; 				    // Indicates whether the field VideoSources is valid
	uint32  SerialPortsFlag		: 1; 				    // Indicates whether the field VideoSources is valid
	uint32  DigitalInputsFlag	: 1; 				    // Indicates whether the field VideoSources is valid
	uint32  DigitalInputOptionsFlag	: 1; 				// Indicates whether the field VideoSources is valid
	uint32  support				: 1; 				    // Indication if the device supports deviceIO service
	uint32	reserved 			: 23;
	
	int 	VideoSources;								// optional, Number of video sources (defaults to none)
	int 	VideoOutputs;								// optional, Number of video outputs (defaults to none)
	int 	AudioSources;								// optional, Number of audio sources (defaults to none)
	int 	AudioOutputs;								// optional, Number of audio outputs (defaults to none)
	int 	RelayOutputs;								// optional, Number of relay outputs (defaults to none)
	int 	SerialPorts;								// optional, Number of serial ports (defaults to none)
	int 	DigitalInputs;								// optional, Number of digital inputs (defaults to none)
	BOOL 	DigitalInputOptions;						// optional, Indicates support for DigitalInput configuration of the idle state (defaults to false)

	onvif_Version   Version;                            // required
	onvif_XAddr	    XAddr;
} onvif_DeviceIOCapabilities;

typedef struct 
{
    uint32  MaximumNumberOfProfilesFlag : 1;            // Indicates whether the field MaximumNumberOfProfiles is valid
    uint32  ConfigurationsSupportedFlag : 1;            // Indicates whether the field ConfigurationsSupported is valid
    uint32  Reserved                    : 30;
    
	int     MaximumNumberOfProfiles;	                // optional, Maximum number of profiles supported
	char    ConfigurationsSupported[256];               // optional, Enumerates the configurations supported
} onvif_ProfileCapabilities;

typedef struct 
{
    uint32  RTSPStreamingFlag               : 1;        // Indicates whether the field RTSPStreaming is valid
    uint32  RTPMulticastFlag                : 1;        // Indicates whether the field RTPMulticast is valid
    uint32  RTP_USCORERTSP_USCORETCPFlag    : 1;        // Indicates whether the field RTP_USCORERTSP_USCORETCP is valid
    uint32  NonAggregateControlFlag         : 1;        // Indicates whether the field NonAggregateControl is valid
    uint32  Reserved                        : 28;
    
	BOOL    RTSPStreaming;	                            // optional, Indicates support for live media streaming via RTSP
	BOOL    RTPMulticast;	                            // optional, Indicates support for RTP multicast
	BOOL    RTP_USCORERTSP_USCORETCP;	                // optional, Indicates support for RTP/RTSP/TCP
	BOOL    NonAggregateControl;	                    // optional, Indicates support for non aggregate RTSP control
} onvif_StreamingCapabilities;

typedef struct 
{
	BOOL    TKIP;	                                    // required
	BOOL    ScanAvailableNetworks;	                    // required
	BOOL    MultipleConfiguration;	                    // required
	BOOL    AdHocStationMode;	                        // required
	BOOL    WEP;	                                    // required
} onvif_Dot11Capabilities;

typedef struct 
{
    uint32  SnapshotUriFlag     : 1;                    // Indicates whether the field SnapshotUri is valid
    uint32  RotationFlag        : 1;                    // Indicates whether the field Rotation is valid
    uint32  VideoSourceModeFlag : 1;                    // Indicates whether the field VideoSourceMode is valid
    uint32  OSDFlag             : 1;                    // Indicates whether the field OSD is valid
    uint32  support				: 1; 				    // Indication if the device supports media service2
    uint32  Reserved            : 27;
    
	onvif_ProfileCapabilities   ProfileCapabilities;	// required, Media profile capabilities
	onvif_StreamingCapabilities StreamingCapabilities;	// required, Streaming capabilities

	BOOL    SnapshotUri;	                            // optional, Indicates if GetSnapshotUri is supported
	BOOL    Rotation;	                                // optional, Indicates whether or not Rotation feature is supported
	BOOL    VideoSourceMode;	                        // optional, Indicates the support for changing video source mode
	BOOL    OSD;	                                    // optional, Indicates if OSD is supported

	onvif_Version   Version;                            // required
	onvif_XAddr	    XAddr;
} onvif_MediaCapabilities2;

typedef struct
{
	onvif_DevicesCapabilities	device;     		    // The capabilities for the device service is returned in the Capabilities element
    onvif_MediaCapabilities		media;      		    // The capabilities for the media service is returned in the Capabilities element    

    onvif_MediaCapabilities2    media2;                 // The capabilities for the media service2 is returned in the Capabilities element

	onvif_EventCapabilities		events;     		    // The capabilities for the event service is returned in the Capabilities element
	onvif_ImagingCapabilities	image;      		    // The capabilities for the imaging service is returned in the Capabilities element


    onvif_PTZCapabilities		ptz;        		    // The capabilities for the PTZ service is returned in the Capabilities element


	onvif_AnalyticsCapabilities	analytics;			    // The capabilities for the analytics service is returned in the Capabilities element



	onvif_RecordingCapabilities	recording;  		    // The capabilities for the recording service is returned in the Capabilities element
	onvif_SearchCapabilities	search;     		    // The capabilities for the search service is returned in the Capabilities element
	onvif_ReplayCapabilities	replay;     		    // The capabilities for the replay service is returned in the Capabilities element
	

    onvif_AccessControlCapabilities accesscontrol;      // The capabilities for the accesscontrol service is returned in the Capabilities element
    onvif_DoorControlCapabilities   doorcontrol;        // The capabilities for the doorcontrol service is returned in the Capabilities element


	onvif_DeviceIOCapabilities	deviceIO;				// The capabilities for the deviceIO service is returned in the Capabilities element

} onvif_Capabilities;

typedef struct
{
	char 	Manufacturer[64];						    // required, The manufactor of the device
	char 	Model[64];								    // required, The device model
	char 	FirmwareVersion[64];					    // required, The firmware version in the device
	char 	SerialNumber[64];						    // required, The serial number of the device
	char 	HardwareId[64];							    // required, The hardware ID of the device
} onvif_DeviceInformation;

typedef struct 
{
	int 	Width;									    // required
	int 	Height;									    // required
} onvif_VideoResolution;

typedef struct
{
	int		Min;									    // required								
	int 	Max;									    // required
} onvif_IntRange;

typedef struct
{
	int     x;	                                        // required 
	int     y;	                                        // required 
	int     width;	                                    // required 
	int     height;	                                    // required 
} onvif_IntRectangle;

typedef struct
{
	float   bottom;	                                    // required
	float   top;	                                    // required
	float   right;	                                    // required
	float   left;	                                    // required
} onvif_Rectangle;

typedef struct
{
	uint32	LevelFlag	: 1;						    // Indicates whether the field Level is valid
	uint32  Reserved	: 31;
	
    onvif_BacklightCompensationMode	Mode;               // required, Backlight compensation mode (on/off)
    float   Level;                                      // optional, Optional level parameter (unit unspecified)
} onvif_BacklightCompensation;

typedef struct
{
	uint32	PriorityFlag		: 1;				    // Indicates whether the field Priority is valid
	uint32	MinExposureTimeFlag	: 1;				    // Indicates whether the field MinExposureTime is valid
	uint32	MaxExposureTimeFlag	: 1;				    // Indicates whether the field MaxExposureTime is valid
	uint32	MinGainFlag			: 1;				    // Indicates whether the field MinGain is valid
	uint32	MaxGainFlag			: 1;				    // Indicates whether the field MaxGain is valid
	uint32	MinIrisFlag			: 1;				    // Indicates whether the field MinIris is valid
	uint32	MaxIrisFlag			: 1;				    // Indicates whether the field MaxIris is valid
	uint32	ExposureTimeFlag	: 1;				    // Indicates whether the field ExposureTime is valid
	uint32	GainFlag			: 1;				    // Indicates whether the field Gain is valid
	uint32	IrisFlag			: 1;				    // Indicates whether the field Iris is valid
	uint32  Reserved			: 22;
	
    onvif_ExposureMode		Mode;                       // required, Auto - Enabled the exposure algorithm on the device; Manual - Disabled exposure algorithm on the device
    onvif_ExposurePriority 	Priority;                   // optional, The exposure priority mode (low noise/framerate)
    onvif_Rectangle         Window;                     // required, 
    
    float   MinExposureTime;	                        // optional, Minimum value of exposure time range allowed to be used by the algorithm
	float   MaxExposureTime;	                        // optional, Maximum value of exposure time range allowed to be used by the algorithm
	float   MinGain;	                                // optional, Minimum value of the sensor gain range that is allowed to be used by the algorithm
	float   MaxGain;	                                // optional, Maximum value of the sensor gain range that is allowed to be used by the algorithm
	float   MinIris;	                                // optional, Minimum value of the iris range allowed to be used by the algorithm
	float   MaxIris;	                                // optional, Maximum value of the iris range allowed to be used by the algorithm
	float   ExposureTime;	                            // optional, The fixed exposure time used by the image sensor
	float   Gain;	                                    // optional, The fixed gain used by the image sensor (dB)
	float   Iris;	                                    // optional, The fixed attenuation of input light affected by the iris (dB). 0dB maps to a fully opened iris
} onvif_Exposure;

typedef struct
{
	uint32	DefaultSpeedFlag	: 1;				    // Indicates whether the field DefaultSpeed is valid
	uint32	NearLimitFlag		: 1;				    // Indicates whether the field NearLimit is valid
	uint32	FarLimitFlag		: 1;				    // Indicates whether the field FarLimit is valid	
	uint32  Reserved			: 29;
	
    onvif_AutoFocusMode	AutoFocusMode;                  // required, Mode of auto fucus
    
    float   DefaultSpeed;	                            // optional, 
	float   NearLimit;	                                // optional, Parameter to set autofocus near limit (unit: meter)
	float   FarLimit;	                                // optional, Parameter to set autofocus far limit (unit: meter)
} onvif_FocusConfiguration;

typedef struct
{
	uint32	LevelFlag	: 1;						    // Indicates whether the field Level is valid
	uint32  Reserved	: 31;
	
    onvif_WideDynamicMode	Mode;                       // required, Wide dynamic range mode (on/off), 0-OFF, 1-ON
    float   Level;	                                    // optional, Optional level parameter (unit unspecified)
} onvif_WideDynamicRange; 

typedef struct
{
	uint32	CrGainFlag	: 1;						    // Indicates whether the field CrGain is valid
	uint32	CbGainFlag	: 1;						    // Indicates whether the field CbGain is valid
	uint32  Reserved	: 30;
	
    onvif_WhiteBalanceMode	Mode;	                    // required, 'AUTO' or 'MANUAL'
    
	float   CrGain;	                                    // optional, Rgain (unitless)
	float   CbGain;	                                    // optional, Bgain (unitless)
} onvif_WhiteBalance; 

typedef struct
{
	uint32	BacklightCompensationFlag	: 1;		    // Indicates whether the field BacklightCompensation is valid
	uint32	BrightnessFlag				: 1;		    // Indicates whether the field Brightness is valid
	uint32	ColorSaturationFlag			: 1;		    // Indicates whether the field ColorSaturation is valid
	uint32	ContrastFlag				: 1;		    // Indicates whether the field Contrast is valid
	uint32	ExposureFlag				: 1;		    // Indicates whether the field Exposure is valid
	uint32	FocusFlag					: 1;		    // Indicates whether the field Focus is valid
	uint32	IrCutFilterFlag				: 1;		    // Indicates whether the field IrCutFilter is valid
	uint32	SharpnessFlag				: 1;		    // Indicates whether the field Sharpness is valid
	uint32	WideDynamicRangeFlag		: 1;		    // Indicates whether the field WideDynamicRange is valid
	uint32	WhiteBalanceFlag			: 1;		    // Indicates whether the field WhiteBalance is valid
	uint32  Reserved					: 22;
	
	onvif_BacklightCompensation BacklightCompensation;  // optional, Enabled/disabled BLC mode (on/off)
	float   Brightness;                                 // optional, Image brightness (unit unspecified)
	float   ColorSaturation;                            // optional, Color saturation of the image (unit unspecified)
	float   Contrast;                                   // optional, Contrast of the image (unit unspecified)
	onvif_Exposure Exposure;                            // optional, Exposure mode of the device
	onvif_FocusConfiguration 	Focus;                  // optional, Focus configuration
    onvif_IrCutFilterMode    	IrCutFilter;            // optional, Infrared Cutoff Filter settings	
	float   Sharpness;                                  // optional, Sharpness of the Video image
	onvif_WideDynamicRange 		WideDynamicRange;       // optional, WDR settings
	onvif_WhiteBalance 			WhiteBalance;           // optional, White balance settings	
} onvif_ImagingSettings;

typedef struct
{
    uint32	Mode_ON	    : 1;                		    // Indicates whether mode ON is valid
	uint32 	Mode_OFF	: 1;                		    // Indicates whether mode OFF is valid
	uint32  LevelFlag	: 1;						    // Indicates whether the field LevelFlag is valid
	uint32 	Reserved    : 29;
	
    onvif_FloatRange	Level;                   	    // optional, Level range of BacklightCompensation
} onvif_BacklightCompensationOptions;

typedef struct
{
    uint32	Mode_AUTO           : 1;        		    // Indicates whether mode AUTO is valid
	uint32	Mode_MANUAL         : 1;        		    // Indicates whether mode Manual is valid
    uint32	Priority_LowNoise   : 1;       	 		    // Indicates whether Priority LowNoise is valid
	uint32	Priority_FrameRate  : 1;        		    // Indicates whether Priority FrameRate is valid
	uint32	MinExposureTimeFlag	: 1;				    // Indicates whether the field MinExposureTime is valid
	uint32	MaxExposureTimeFlag	: 1;				    // Indicates whether the field MaxExposureTime is valid
	uint32	MinGainFlag			: 1;				    // Indicates whether the field MinGain is valid
	uint32	MaxGainFlag			: 1;				    // Indicates whether the field MaxGain is valid
	uint32	MinIrisFlag			: 1;				    // Indicates whether the field MinIris is valid
	uint32	MaxIrisFlag			: 1;				    // Indicates whether the field MaxIris is valid
	uint32	ExposureTimeFlag	: 1;				    // Indicates whether the field ExposureTime is valid
	uint32	GainFlag			: 1;				    // Indicates whether the field Gain is valid
	uint32	IrisFlag			: 1;				    // Indicates whether the field Iris is valid
	uint32	Reserved            : 19;

	onvif_FloatRange	MinExposureTime;        	    // optional, Valid range of the Minimum ExposureTime
    onvif_FloatRange	MaxExposureTime;          	    // optional, Valid range of the Maximum ExposureTime
    onvif_FloatRange	MinGain;                  	    // optional, Valid range of the Minimum Gain
    onvif_FloatRange	MaxGain;                 	    // optional, Valid range of the Maximum Gain
    onvif_FloatRange	MinIris;                 	    // optional, Valid range of the Minimum Iris
    onvif_FloatRange	MaxIris;                 	    // optional, Valid range of the Maximum Iris
    onvif_FloatRange	ExposureTime;            	    // optional, Valid range of the ExposureTime
    onvif_FloatRange	Gain;                   	    // optional, Valid range of the Gain
    onvif_FloatRange	Iris;                    	    // optional, Valid range of the Iris
} onvif_ExposureOptions;

typedef struct
{
    uint32	AutoFocusModes_AUTO	    : 1;    		    // Indicates whether mode aUTO is valid
	uint32 	AutoFocusModes_MANUAL   : 1;   	 		    // Indicates whether mode Manual is valid
	uint32	DefaultSpeedFlag		: 1;			    // Indicates whether the field DefaultSpeed is valid
	uint32	NearLimitFlag			: 1;			    // Indicates whether the field NearLimit is valid
	uint32	FarLimitFlag			: 1;			    // Indicates whether the field FarLimit is valid
	uint32 	Reserved                : 27;

	onvif_FloatRange	DefaultSpeed;          		    // optional, Valid range of DefaultSpeed
	onvif_FloatRange	NearLimit;              	    // optional, Valid range of NearLimit
	onvif_FloatRange	FarLimit;               	    // optional, Valid range of FarLimit
} onvif_FocusOptions;

typedef struct
{
    uint32 	Mode_ON	    : 1;                		    // Indicates whether mode ON is valid
	uint32 	Mode_OFF	: 1;                		    // Indicates whether mode OFF is valid
	uint32	LevelFlag	: 1;						    // Indicates whether the field Level is valid
	uint32 	Reserved    : 29;
	
    onvif_FloatRange	Level;                 		    // optional, Valid range of Level
} onvif_WideDynamicRangeOptions;

typedef struct
{
    uint32	Mode_AUTO 	: 1;        				    // Indicates whether mode AUDO is valid
	uint32	Mode_MANUAL	: 1;        				    // Indicates whether mode Manual is valid
	uint32	YrGainFlag	: 1;						    // Indicates whether the field CrGain is valid
	uint32	YbGainFlag	: 1;						    // Indicates whether the field CbGain is valid
	uint32 	Reserved	: 28;

	onvif_FloatRange	YrGain;                 	    // optional, Valid range of YrGain
	onvif_FloatRange	YbGain;                  	    // optional, Valid range of YbGain
} onvif_WhiteBalanceOptions;

typedef struct
{
	uint32	IrCutFilterMode_ON	    	: 1; 		    // Indicates whether IrCutFilter mode ON is valid
	uint32 	IrCutFilterMode_OFF			: 1; 		    // Indicates whether IrCutFilter mode OFF is valid
	uint32 	IrCutFilterMode_AUTO		: 1; 		    // Indicates whether IrCutFilter mode AUTO is valid
	uint32	BacklightCompensationFlag	: 1;		    // Indicates whether the field BacklightCompensation is valid	
	uint32	BrightnessFlag				: 1;		    // Indicates whether the field Brightness is valid
	uint32  ColorSaturationFlag			: 1;		    // Indicates whether the field ColorSaturation is valid
	uint32  ContrastFlag				: 1;		    // Indicates whether the field Contrast is valid
	uint32  ExposureFlag				: 1;		    // Indicates whether the field Exposure is valid
	uint32  FocusFlag					: 1;		    // Indicates whether the field Focus is valid
	uint32  SharpnessFlag				: 1;		    // Indicates whether the field Sharpness is valid
	uint32  WideDynamicRangeFlag		: 1;		    // Indicates whether the field WideDynamicRange is valid
	uint32  WhiteBalanceFlag			: 1;		    // Indicates whether the field WhiteBalance is valid
	uint32 	Reserved    				: 20;
	
    onvif_BacklightCompensationOptions  BacklightCompensation;  // optional, Valid range of Backlight Compensation
    
    onvif_FloatRange      	Brightness;          	    // optional, Valid range of Brightness
    onvif_FloatRange      	ColorSaturation;    	    // optional, alid range of Color Saturation
    onvif_FloatRange      	Contrast;            	    // optional, Valid range of Contrast

    onvif_ExposureOptions   Exposure;           	    // optional, Valid range of Exposure    
    onvif_FocusOptions      Focus;              	    // optional, Valid range of Focus

    onvif_FloatRange      	Sharpness;           	    // optional, Valid range of Sharpness
    
    onvif_WideDynamicRangeOptions   WideDynamicRange;   // optional, Valid range of WideDynamicRange
    onvif_WhiteBalanceOptions		WhiteBalance;	    // optional, Valid range of WhiteBalance
} onvif_ImagingOptions;

typedef struct 
{
	uint32	ErrorFlag	: 1; 						    // Indicates whether the field Error is valid
	uint32	Reserved 	: 31;
	
	float 	Position;								    // required, Status of focus position
	onvif_MoveStatus	MoveStatus;					    // required, Status of focus MoveStatus
	char 	Error[100];								    // optional, Error status of focus
} onvif_FocusStatus;

typedef struct 
{
	uint32	FocusStatusFlag	: 1; 					    // Indicates whether the field FocusStatus is valid
	uint32	Reserved 		: 31;
	
	onvif_FocusStatus	FocusStatus;				    // optional, Status of focus
} onvif_ImagingStatus;

typedef struct 
{
    uint32  SpeedFlag   : 1;
    uint32  Reserved    : 31;
    
	onvif_FloatRange    Position;	                    // required, Valid ranges of the position
	onvif_FloatRange    Speed;	                        // optional, Valid ranges of the speed
} onvif_AbsoluteFocusOptions;

typedef struct 
{
    uint32  SpeedFlag   : 1;
    uint32  Reserved    : 31;
    
	onvif_FloatRange    Distance;	                    // required, valid ranges of the distance
	onvif_FloatRange    Speed;	                        // optional, Valid ranges of the speed
} onvif_RelativeFocusOptions20;

typedef struct 
{
	onvif_FloatRange    Speed;	                        // required, Valid ranges of the speed
} onvif_ContinuousFocusOptions;

typedef struct 
{
    uint32  AbsoluteFlag    : 1;
    uint32  RelativeFlag    : 1;
    uint32  ContinuousFlag  : 1;
    uint32  Reserved        : 29;
    
	onvif_AbsoluteFocusOptions      Absolute;	        // optional, Valid ranges for the absolute control
	onvif_RelativeFocusOptions20    Relative;	        // optional, Valid ranges for the relative control
	onvif_ContinuousFocusOptions    Continuous;	        // optional, Valid ranges for the continuous control
} onvif_MoveOptions20;

typedef struct
{
	uint32		SpeedFlag	: 1;						// Indicates whether the field Speed is valid
	uint32  	Reserved	: 31;
	
	float		Position;								// required, Position parameter for the absolute focus control
	float		Speed;									// optional, Speed parameter for the absolute focus control
} onvif_AbsoluteFocus;

typedef struct
{
	uint32		SpeedFlag	: 1;						// Indicates whether the field Speed is valid
	uint32  	Reserved	: 31;
	
	float		Distance;								// required, Distance parameter for the relative focus control
	float		Speed;									// optional, Speed parameter for the relative focus control
} onvif_RelativeFocus;

typedef struct
{
	float		Speed;									// required, Speed parameter for the Continuous focus control
} onvif_ContinuousFocus;

typedef struct
{
	uint32		AbsoluteFlag	: 1;					// Indicates whether the field Absolute is valid
	uint32		RelativeFlag	: 1;					// Indicates whether the field Relative is valid
	uint32		ContinuousFlag	: 1;					// Indicates whether the field Continuous is valid
	uint32  	Reserved		: 29;
	
	onvif_AbsoluteFocus	    Absolute;			    	// optional, Parameters for the absolute focus control
	onvif_RelativeFocus	    Relative;			    	// optional, Parameters for the relative focus control
	onvif_ContinuousFocus	Continuous;			    	// optional, Parameter for the continuous focus control
} onvif_FocusMove;


typedef struct
{	
	uint32  PasswordFlag	: 1;		    		    // Indicates whether the field Password is valid
	uint32	Reserved		: 31;
	
	char 	Username[ONVIF_NAME_LEN];				    // required 
	char 	Password[ONVIF_NAME_LEN];				    // optional
	
	onvif_UserLevel UserLevel;						    // required 
} onvif_User;

typedef struct 
{
    uint32  PasswordFlag	: 1;		    		    // Indicates whether the field Password is valid
	uint32	Reserved		: 31;
	
	char    Username[ONVIF_NAME_LEN];	                // required
	char    Password[ONVIF_NAME_LEN];	                // optional
	
	BOOL    UseDerivedPassword;	                        // required 
} onvif_RemoteUser;

typedef struct
{
	uint32	ImagingSettingsFlag	: 1; 				    // Indicates whether the field ImagingSettings is valid
	uint32	Reserved 			: 31;
	
    char    token[ONVIF_TOKEN_LEN];	                    // required
	float   Framerate;	                                // required, Frame rate in frames per second
	
	onvif_VideoResolution   Resolution;	                // required, Horizontal and vertical resolution 
	onvif_ImagingSettings	ImagingSettings;		    // optional
} onvif_VideoSource;

typedef struct
{
	uint32  DescriptionFlag		: 1;				    // Indicates whether the field Description is valid
	uint32  VideoEncoding_JPEG 	: 1;				    // Indication JPEG encoding is supported for this video source
	uint32  VideoEncoding_MPEG4 : 1;				    // Indication MPEG4 encoding is supported for this video source
	uint32  VideoEncoding_H264 	: 1;				    // Indication H264 encoding is supported for this video source
	uint32  Enabled				: 1;				    //optional, Indication of whether this mode is active. If active this value is true. In case of non-indication, it means as false. 
													    //	The value of true shall be had by only one video source mode		
	uint32 	Reboot				: 1;				    // required, After setting the mode if a device starts to reboot this value is true. If a device change the mode without rebooting this value is false.
													    //	If true, configured parameters may not be guaranteed by the device after rebooting													
	uint32  Reserved			: 26;													
	
	float 	MaxFramerate;							    // required, Max frame rate in frames per second for this video source mode
	
	char 	Description[128];						    // optional, Informative description of this video source mode. This field should be described in English
	char 	token[ONVIF_TOKEN_LEN];					    // required, Indicate token for video source mode

	onvif_VideoResolution	MaxResolution;			    // required, Max horizontal and vertical resolution for this video source mode
} onvif_VideoSourceMode;

typedef struct
{
    uint32  DegreeFlag  : 1;				            // Indicates whether the field Degree is valid
    uint32  Reserved    : 31;
    
	onvif_RotateMode    Mode;	                        // required, Parameter to enable/disable Rotation feature
	
	int     Degree;	                                    // optional, Optional parameter to configure how much degree of clockwise rotation of image  for On mode. Omitting this parameter for On mode means 180 degree rotation
} onvif_Rotate;

typedef struct 
{
    uint32  RotateFlag  : 1;				            // Indicates whether the field Rotate is valid
    uint32  Reserved    : 31;
    
	onvif_Rotate    Rotate;	                            // optional, Optional element to configure rotation of captured image
} onvif_VideoSourceConfigurationExtension;

typedef struct
{
    uint32  ExtensionFlag		: 1;				    // Indicates whether the field Extension is valid
    uint32  Reserved			: 31;
    
	char 	Name[ONVIF_NAME_LEN];					    // required, User readable name. Length up to 64 characters
	int 	UseCount;								    // required, Number of internal references currently using this configuration. This parameter is read-only and cannot be changed by a set request
	char 	token[ONVIF_TOKEN_LEN];					    // required, Token that uniquely refernces this configuration. Length up to 64 characters
	char 	SourceToken[ONVIF_TOKEN_LEN];			    // required, Reference to the physical input

	onvif_IntRectangle	Bounds;					        // required, Rectangle specifying the Video capturing area. The capturing area shall not be larger than the whole Video source area	
	onvif_VideoSourceConfigurationExtension Extension;  // optional
} onvif_VideoSourceConfiguration;


typedef struct
{
	onvif_IntRange  XRange;	                            // required
	onvif_IntRange  YRange;	                            // required
	onvif_IntRange  WidthRange;	                        // required
	onvif_IntRange  HeightRange;	                    // required
} onvif_IntRectangleRange;

typedef struct 
{
    uint32	RotateMode_OFF	: 1; 				        // Indicates whether the mode RotateMode_OFF is valid
    uint32	RotateMode_ON	: 1; 				        // Indicates whether the mode RotateMode_ON is valid
    uint32	RotateMode_AUTO : 1; 				        // Indicates whether the mode RotateMode_AUTO is valid
    uint32	DegreeListFlag  : 1; 				        // Indicates whether the field DegreeListFlag is valid
	uint32	Reserved 		: 28;

	int     sizeDegreeList;
	int     DegreeList[10];	                            // optional 
} onvif_RotateOptions;

typedef struct
{
    uint32	RotateFlag	: 1; 				            // Indicates whether the field Rotate is valid
	uint32	Reserved    : 31;
	
	onvif_RotateOptions     Rotate;	                    // optional 
} onvif_VideoSourceConfigurationOptionsExtension;

typedef struct
{
    uint32	ExtensionFlag	: 1; 				        // Indicates whether the field Extension is valid
	uint32	Reserved        : 31;
	
	onvif_IntRectangleRange BoundsRange;	            // required 

	int     sizeVideoSourceTokensAvailable;
	char    VideoSourceTokensAvailable[10][ONVIF_TOKEN_LEN];    // required

	onvif_VideoSourceConfigurationOptionsExtension  Extension;	// optional
} onvif_VideoSourceConfigurationOptions;

typedef struct
{
    uint32	ConstantBitRateFlag	: 1; 			        // Indicates whether the field ConstantBitRate is valid
	uint32	Reserved            : 31;
    
	int		FrameRateLimit;							    // required, Maximum output framerate in fps. If an EncodingInterval is provided the resulting encoded framerate will be reduced by the given factor
	int		EncodingInterval;						    // required, Interval at which images are encoded and transmitted. (A value of 1 means that every frame is encoded, a value of 2 means that every 2nd frame is encoded ...)
	int		BitrateLimit;							    // required, the maximum output bitrate in kbps
	BOOL    ConstantBitRate;                            // optional, Enforce constant bitrate
} onvif_VideoRateControl;

typedef struct
{
	int		GovLength;								    // required, Determines the interval in which the I-Frames will be coded. An entry of 1 indicates I-Frames are continuously generated. 
													    //	An entry of 2 indicates that every 2nd image is an I-Frame, and 3 only every 3rd frame, etc. The frames in between are coded as P or B Frames.
	onvif_Mpeg4Profile	Mpeg4Profile;				    // required, the Mpeg4 profile, either simple profile (SP) or advanced simple profile (ASP)													
} onvif_Mpeg4Configuration;

typedef struct
{
	int		GovLength;								    // required, Group of Video frames length. Determines typically the interval in which the I-Frames will be coded. An entry of 1 indicates I-Frames are continuously generated. 
													    //	An entry of 2 indicates that every 2nd image is an I-Frame, and 3 only every 3rd frame, etc. The frames in between are coded as P or B Frames
	onvif_H264Profile	H264Profile;				    // required, the H.264 profile, either baseline, main, extended or high
} onvif_H264Configuration;

typedef struct
{
	char	IPv4Address[32];						    // required, The multicast address
	int		Port;									    // required, The RTP mutlicast destination port. A device may support RTCP. In this case the port value shall be even to allow the corresponding RTCP stream to be mapped
													    //	to the next higher (odd) destination port number as defined in the RTSP specification
	int		TTL;									    // required, In case of IPv6 the TTL value is assumed as the hop limit. Note that for IPV6 and administratively scoped IPv4 multicast the primary use for hop limit / TTL is 
													    //    to prevent packets from (endlessly) circulating and not limiting scope. In these cases the address contains the scope
	BOOL	AutoStart;								    // required, Read only property signalling that streaming is persistant. Use the methods StartMulticastStreaming and StopMulticastStreaming to switch its state													
} onvif_MulticastConfiguration;

typedef struct
{
	uint32	RateControlFlag	: 1;					    // Indicates whether the field RateControl is valid
	uint32	MPEG4Flag		: 1;					    // Indicates whether the field MPEG4 is valid
	uint32	H264Flag		: 1;					    // Indicates whether the field H264 is valid
	uint32 	Reserved		: 29;
	
	char 	Name[ONVIF_NAME_LEN];					    // required, User readable name. Length up to 64 characters
	int 	UseCount;								    // required, Number of internal references currently using this configuration. This parameter is read-only and cannot be changed by a set request
	char 	token[ONVIF_TOKEN_LEN];					    // required, Token that uniquely refernces this configuration. Length up to 64 characters

	onvif_VideoEncoding		    Encoding;		        // required, Used video codec, either Jpeg, H.264 or Mpeg4
	onvif_VideoResolution	    Resolution;		        // required, Configured video resolution

	int		Quality;								    // required, Relative value for the video quantizers and the quality of the video. A high value within supported quality range means higher quality

	onvif_VideoRateControl	    RateControl;	        // optional, Optional element to configure rate control related parameters
	onvif_Mpeg4Configuration	MPEG4;			        // optional, Optional element to configure Mpeg4 related parameters
	onvif_H264Configuration	    H264;			        // optional, Optional element to configure H.264 related parameters
	
	onvif_MulticastConfiguration    Multicast;	        // required, Defines the multicast settings that could be used for video streaming
	
	int		SessionTimeout;							    // required, The rtsp session timeout for the related video stream, unit is second
} onvif_VideoEncoderConfiguration;

typedef struct 
{
	char    token[ONVIF_TOKEN_LEN];	            	    // required
	int     Channels;	                                // required, number of available audio channels. (1: mono, 2: stereo)
} onvif_AudioSource;

typedef struct
{
	char 	Name[ONVIF_NAME_LEN];					    // required, User readable name. Length up to 64 characters
	int 	UseCount;								    // required, Number of internal references currently using this configuration. This parameter is read-only and cannot be changed by a set request
	char 	token[ONVIF_TOKEN_LEN];					    // required, Token that uniquely refernces this configuration. Length up to 64 characters
	
	char 	SourceToken[ONVIF_TOKEN_LEN];			    // required, Token of the Audio Source the configuration applies to
} onvif_AudioSourceConfiguration;


typedef struct
{
	char 	Name[ONVIF_NAME_LEN];					    // required, User readable name. Length up to 64 characters
	int 	UseCount;								    // required, Number of internal references currently using this configuration. This parameter is read-only and cannot be changed by a set request
	char 	token[ONVIF_TOKEN_LEN];					    // required, Token that uniquely refernces this configuration. Length up to 64 characters
	
	onvif_AudioEncoding Encoding;					    // required, Audio codec used for encoding the audio input (either G.711, G.726 or AAC)

	int		Bitrate;								    // required, The output bitrate in kbps
	int		SampleRate;								    // required, The output sample rate in kHz

	onvif_MulticastConfiguration    Multicast;	        // required, Defines the multicast settings that could be used for video streaming

	int		SessionTimeout;							    // required, The rtsp session timeout for the related audio stream, unit is second
} onvif_AudioEncoderConfiguration;

typedef struct 
{
	onvif_AudioEncoding Encoding;	                    // required, The enoding used for audio data (either G.711, G.726 or AAC)
	
	onvif_IntList   BitrateList;	                    // required, List of supported bitrates in kbps for the specified Encoding
	onvif_IntList   SampleRateList;	                    // required, List of supported Sample Rates in kHz for the specified Encoding
} onvif_AudioEncoderConfigurationOption;

typedef struct
{
    int     sizeOptions;                                // required, valid Options numbers                           
    onvif_AudioEncoderConfigurationOption   Options[3]; // optional, list of supported AudioEncoderConfigurations
} onvif_AudioEncoderConfigurationOptions;

typedef struct
{
	onvif_VideoResolution	ResolutionsAvailable[MAX_RES_NUMS];	// required, List of supported image sizes

	onvif_IntRange	FrameRateRange;					    // required, Supported frame rate in fps (frames per second)
	onvif_IntRange	EncodingIntervalRange;			    // required, Supported encoding interval range. The encoding interval corresponds to the number of frames devided by the encoded frames. An encoding interval value of "1" means that all frames are encoded
} onvif_JpegOptions;

typedef struct
{	
	uint32 	Mpeg4Profile_SP 	: 1;				    // required, Indicates whether the SP profile is valid
	uint32 	Mpeg4Profile_ASP 	: 1;				    // required, Indicates whether the ASP profile is valid
	uint32 	Reserverd			: 30;

	onvif_VideoResolution	ResolutionsAvailable[MAX_RES_NUMS];	// required, List of supported image sizes

	onvif_IntRange	GovLengthRange;					    // required, Supported group of Video frames length. This value typically corresponds to the I-Frame distance
	onvif_IntRange	FrameRateRange;					    // required, Supported frame rate in fps (frames per second)
	onvif_IntRange	EncodingIntervalRange;			    // required, Supported encoding interval range. The encoding interval corresponds to the number of frames devided by the encoded frames. An encoding interval value of "1" means that all frames are encoded	
} onvif_Mpeg4Options;

typedef struct
{
	uint32 	H264Profile_Baseline	: 1;			    // required, Indicates whether the Baseline profile is valid				
	uint32 	H264Profile_Main 		: 1;			    // required, Indicates whether the Main profile is valid	
	uint32 	H264Profile_Extended 	: 1;			    // required, Indicates whether the Extended profile is valid	
	uint32 	H264Profile_High		: 1;			    // required, Indicates whether the High profile is valid	
	uint32 	Reserverd				: 28;

	onvif_VideoResolution	ResolutionsAvailable[MAX_RES_NUMS];	// required, List of supported image sizes
	
	onvif_IntRange	GovLengthRange;					    // required, Supported group of Video frames length. This value typically corresponds to the I-Frame distance
	onvif_IntRange	FrameRateRange;					    // required, Supported frame rate in fps (frames per second)
	onvif_IntRange	EncodingIntervalRange;			    // required, Supported encoding interval range. The encoding interval corresponds to the number of frames devided by the encoded frames. An encoding interval value of "1" means that all frames are encoded	
} onvif_H264Options;

typedef struct
{
    onvif_JpegOptions   JpegOptions;                    // required 
	onvif_IntRange      BitrateRange;	                // required 
} onvif_JpegOptions2;   

typedef struct
{
    onvif_Mpeg4Options  Mpeg4Options;                   // required
	onvif_IntRange      BitrateRange;	                // required 
} onvif_Mpeg4Options2;

typedef struct
{
    onvif_H264Options   H264Options;                    // required
    onvif_IntRange      BitrateRange;	                // required 	
} onvif_H264Options2;

typedef struct 
{
    uint32	JPEGFlag 	    : 1;				        // Indicates whether the field JPEG is valid
	uint32	MPEG4Flag 	    : 1;				        // Indicates whether the field MPEG4 is valid
	uint32	H264Flag 	    : 1;				        // Indicates whether the field H264 is valid
	uint32	Reserved 	    : 29;
	
    onvif_JpegOptions2  JPEG;	                        // optional 
	onvif_Mpeg4Options2 MPEG4;	                        // optional 
	onvif_H264Options2  H264;	                        // optional 
} onvif_VideoEncoderOptionsExtension;

typedef struct 
{
	uint32	JPEGFlag 	    : 1;				        // Indicates whether the field JPEG is valid
	uint32	MPEG4Flag 	    : 1;				        // Indicates whether the field MPEG4 is valid
	uint32	H264Flag 	    : 1;				        // Indicates whether the field H264 is valid
	uint32	ExtensionFlag 	: 1;				        // Indicates whether the field Extension is valid
	uint32	Reserved 	    : 28;				
	
	onvif_IntRange		QualityRange;		            // required, Range of the quality values. A high value means higher quality
	
	onvif_JpegOptions 	JPEG;				            // optional, Optional JPEG encoder settings ranges
	onvif_Mpeg4Options	MPEG4;				            // optional, Optional MPEG-4 encoder settings ranges
	onvif_H264Options	H264;				            // optional, Optional H.264 encoder settings ranges	

	onvif_VideoEncoderOptionsExtension  Extension;	    // optional 
} onvif_VideoEncoderConfigurationOptions;

typedef struct 
{
	BOOL 	Status;									    // required, True if the metadata stream shall contain the PTZ status (IDLE, MOVING or UNKNOWN)
	BOOL 	Position;								    // required, True if the metadata stream shall contain the PTZ position 
} onvif_PTZFilter;

typedef struct 
{
	uint32	AnalyticsFlag 	: 1;				        // Indicates whether the field Analytics is valid
	uint32	PTZStatusFlag 	: 1;				        // Indicates whether the field PTZStatus is valid
	uint32	Reserved 		: 30;
	
	char 	Name[ONVIF_NAME_LEN];					    // required , User readable name. Length up to 64 characters
	int 	UseCount;								    // required, Number of internal references currently using this configuration. This parameter is read-only and cannot be changed by a set request 
	char 	token[ONVIF_TOKEN_LEN];					    // required, Token that uniquely refernces this configuration. Length up to 64 characters 
	BOOL 	Analytics;								    // optional, Defines whether the streamed metadata will include metadata from the analytics engines (video, cell motion, audio etc.) 
	int 	SessionTimeout;							    // required, The rtsp session timeout for the related audio stream, unit is second
	
	onvif_PTZFilter 		PTZStatus;				    // optional, optional element to configure which PTZ related data is to include in the metadata stream 
	
	onvif_MulticastConfiguration Multicast;			    // required, efines the multicast settings that could be used for video streaming
} onvif_MetadataConfiguration;

typedef struct 
{
	uint32	PanTiltPositionSupportedFlag	: 1;	    // Indicates whether the field PanTiltPositionSupported is valid
	uint32	ZoomPositionSupportedFlag 		: 1;	    // Indicates whether the field ZoomPositionSupported is valid
	uint32	Reserved 						: 30;
	
	BOOL 	PanTiltStatusSupported;					    // required, True if the device is able to stream pan or tilt status information
	BOOL 	ZoomStatusSupported;					    // required, True if the device is able to stream zoom status inforamtion
	BOOL 	PanTiltPositionSupported;				    // optional, True if the device is able to stream the pan or tilt position
	BOOL 	ZoomPositionSupported;					    // optional, True if the device is able to stream zoom position information
} onvif_PTZStatusFilterOptions;

typedef struct 
{
	onvif_PTZStatusFilterOptions PTZStatusFilterOptions;// required, This message contains the metadata configuration options. If a metadata configuration is specified, 
													    //   the options shall concern that particular configuration. If a media profile is specified, the options shall be compatible with that media profile. 
													    //   If no tokens are specified, the options shall be considered generic for the device
} onvif_MetadataConfigurationOptions;

typedef struct
{
	uint32	PosFlag		: 1;						    // Indicates whether the field Pos is valid
	uint32  Reserved	: 31;
	
	onvif_OSDPosType	Type;						    // required, For OSD position type

	onvif_Vector		Pos;						    // Optional, when Type is Custom, this field is valid
} onvif_OSDPosConfiguration;


typedef struct
{
	uint32  ColorspaceFlag  : 1;					    // Indicates whether the field Colorspace is valid
	uint32	TransparentFlag	: 1;					    // Indicates whether the field Transparent is valid
	uint32 	Reserved		: 30;
	
	float	X;										    // required, 
	float	Y;										    // required, 
	float	Z;										    // required, 

	int		Transparent;							    // Optional, The value range of "Transparent" could be defined by vendors only should follow this rule: the minimum value means non-transparent and the maximum value maens fully transparent
	char 	Colorspace[256];						    // Optional, support the following colorspace
													    // 	http://www.onvif.org/ver10/colorspace/YCbCr
													    //	http://www.onvif.org/ver10/colorspace/CIELUV
													    // 	http://www.onvif.org/ver10/colorspace/CIELAB 
													    // 	http://www.onvif.org/ver10/colorspace/HSV
} onvif_OSDColor;

typedef struct
{
	uint32	DateFormatFlag		: 1;				    // Indicates whether the field DateFormat is valid
	uint32	TimeFormatFlag		: 1;				    // Indicates whether the field TimeFormat is valid
	uint32	FontSizeFlag		: 1;				    // Indicates whether the field FontSize is valid
	uint32	FontColorFlag		: 1;				    // Indicates whether the field FontColor is valid
	uint32	BackgroundColorFlag	: 1;				    // Indicates whether the field BackgroundColor is valid
	uint32	PlainTextFlag		: 1;				    // Indicates whether the field PlainText is valid
	uint32 	Reserved			: 26;
	
	onvif_OSDTextType	Type;						    // required, 
	
	char	DateFormat[64];							    // Optional, List of supported OSD date formats. This element shall be present when the value of Type field has Date or DateAndTime. The following DateFormat are defined:
													    /*
    														M/d/yyyy - e.g. 3/6/2013
    														MM/dd/yyyy - e.g. 03/06/2013
    														dd/MM/yyyy - e.g. 06/03/2013
    														yyyy/MM/dd - e.g. 2013/03/06
    														yyyy-MM-dd - e.g. 2013-06-03
    														dddd, MMMM dd, yyyy - e.g. Wednesday, March 06, 2013
    														MMMM dd, yyyy - e.g. March 06, 2013
    														dd MMMM, yyyy - e.g. 06 March, 2013
													    */
	char	TimeFormat[64];							    // Optional, List of supported OSD time formats. This element shall be present when the value of Type field has Time or DateAndTime. The following TimeFormat are defined:
													    /*
    														h:mm:ss tt - e.g. 2:14:21 PM
    														hh:mm:ss tt - e.g. 02:14:21 PM
    														H:mm:ss - e.g. 14:14:21
    														HH:mm:ss - e.g. 14:14:21
													    */

	int		FontSize;								    // Optional, Font size of the text in pt
	
	onvif_OSDColor	FontColor;						    // Optional, Font color of the text
	onvif_OSDColor	BackgroundColor;				    // Optional, Background color of the text
	
	char	PlainText[256];							    // Optional, The content of text to be displayed	
} onvif_OSDTextConfiguration;

typedef struct
{
	char	ImgPath[256];							    // required, The URI of the image which to be displayed
} onvif_OSDImgConfiguration;

typedef struct
{
	uint32	TextStringFlag	: 1;					    // Indicates whether the field TextString is valid
	uint32	ImageFlag		: 1;					    // Indicates whether the field Image is valid
	uint32 	Reserved		: 30;
	
	char	token[ONVIF_TOKEN_LEN];					    // required, OSD config token
	char	VideoSourceConfigurationToken[ONVIF_TOKEN_LEN];	// required, Reference to the video source configuration

	onvif_OSDType	Type;							    // required, Type of OSD
	
	onvif_OSDPosConfiguration	Position;			    // required, Position configuration of OSD
	onvif_OSDTextConfiguration 	TextString;			    // Optional, Text configuration of OSD. It shall be present when the value of Type field is Text
	onvif_OSDImgConfiguration	Image;				    // Optional, Image configuration of OSD. It shall be present when the value of Type field is Image
} onvif_OSDConfiguration;

typedef struct 
{
	uint32 	ImageFlag		: 1;					    // Indicates whether the field Image is valid
	uint32 	PlainTextFlag	: 1;					    // Indicates whether the field PlainText is valid
	uint32 	DateFlag		: 1;					    // Indicates whether the field Date is valid
	uint32 	TimeFlag		: 1;					    // Indicates whether the field Time is valid
	uint32 	DateAndTimeFlag	: 1;					    // Indicates whether the field DateAndTime is valid
	uint32 	Reserved		: 27;
	
	int 	Total;									    // required 
	int 	Image;									    // optional
	int 	PlainText;								    // optional
	int 	Date;									    // optional
	int 	Time;									    // optional
	int 	DateAndTime;							    // optional
} onvif_MaximumNumberOfOSDs;

typedef struct 
{
	uint32  ColorspaceFlag	: 1;					    // Indicates whether the field Colorspace is valid
	uint32  Reserved		: 31;					
	
	float 	X;										    // required, 
	float 	Y;										    // required, 
	float 	Z;										    // required, 
	
	char 	Colorspace[128];						    // optional, 
} onvif_Color;

typedef struct
{
	onvif_FloatRange 	X;							    // required
	onvif_FloatRange 	Y;							    // required
	onvif_FloatRange 	Z;							    // required 

	char 	Colorspace[128];						    // required
} onvif_ColorspaceRange;

typedef struct 
{
	int				ColorListSize;	
	onvif_Color 	ColorList[10];					    // optional, List the supported color

	int						ColorspaceRangeSize;
	onvif_ColorspaceRange	ColorspaceRange[10];	    // optional, Define the rang of color supported
} onvif_ColorOptions;

typedef struct 
{
	uint32  ColorFlag		: 1;					    // Indicates whether the field Color is valid
	uint32  TransparentFlag	: 1;					    // Indicates whether the field Transparent is valid
	uint32  Reserved		: 30;
	
	onvif_ColorOptions 	Color;						    // optional, Optional list of supported colors 
	onvif_IntRange 		Transparent;				    // optional, Range of the transparent level. Larger means more tranparent
} onvif_OSDColorOptions;

typedef struct 
{
	uint32	OSDTextType_Plain		: 1;			    // Indicates whether support OSD text type plain
	uint32  OSDTextType_Date		: 1;			    // Indicates whether support OSD text type date
	uint32  OSDTextType_Time		: 1;			    // Indicates whether support OSD text type time
	uint32  OSDTextType_DateAndTime	: 1;			    // Indicates whether support OSD text type dateandtime
	uint32  FontSizeRangeFlag		: 1;			    // Indicates whether the field FontSizeRange is valid
	uint32  FontColorFlag			: 1;			    // Indicates whether the field FontColor is valid	
	uint32  BackgroundColorFlag		: 1;			    // Indicates whether the field BackgroundColor is valid
	uint32  Reserved				: 25;
	
	onvif_IntRange	FontSizeRange;					    // optional, range of the font size value

	int		DateFormatSize;
	char 	DateFormat[10][64];						    // optional, List of supported date format

	int		TimeFormatSize;
	char 	TimeFormat[10][64];						    // optional, List of supported time format
	
	onvif_OSDColorOptions	FontColor;				    // optional, List of supported font color
	onvif_OSDColorOptions 	BackgroundColor;		    // optional, List of supported background color
} onvif_OSDTextOptions;

typedef struct 
{
	int 	ImagePathSize;	
	char 	ImagePath[10][256];						    // required, List of avaiable uris of image
} onvif_OSDImgOptions;

typedef struct 
{
	uint32	OSDType_Text			: 1;			    // Indicates whether support OSD text type
	uint32  OSDType_Image			: 1;			    // Indicates whether support OSD image type
	uint32  OSDType_Extended		: 1;			    // Indicates whether support OSD extended type
	uint32  OSDPosType_UpperLeft	: 1;			    // Indicates whether support OSD position UpperLeft type
	uint32  OSDPosType_UpperRight	: 1;			    // Indicates whether support OSD position UpperRight type
	uint32 	OSDPosType_LowerLeft	: 1;			    // Indicates whether support OSD position LowerLeft type
	uint32  OSDPosType_LowerRight	: 1;			    // Indicates whether support OSD position LowerRight type
	uint32  OSDPosType_Custom		: 1;			    // Indicates whether support OSD position Custom type
	uint32  TextOptionFlag			: 1;			    // Indicates whether the field TextOption is valid
	uint32	ImageOptionFlag			: 1;			    // Indicates whether the field ImageOption is valid
	uint32 	Reserved				: 22;
	
	onvif_MaximumNumberOfOSDs MaximumNumberOfOSDs;	    // required, The maximum number of OSD configurations supported for the specificate video source configuration. 
													    //   If a device limits the number of instances by OSDType, it should indicate the supported number via the related attribute
	onvif_OSDTextOptions	TextOption;				    // optional, Option of the OSD text configuration. This element shall be returned if the device is signaling the support for Text
	onvif_OSDImgOptions 	ImageOption;			    // optional, Option of the OSD image configuration. This element shall be returned if the device is signaling the support for Image
} onvif_OSDConfigurationOptions;

typedef struct
{
	float	x;										    // required
} onvif_Vector1D;

typedef struct 
{
	uint32	PanTiltFlag	: 1;						    // Indicates whether the field PanTilt is valid
	uint32	ZoomFlag	: 1;						    // Indicates whether the field Zoom is valid
	uint32 	Reserved	: 30;
	
	onvif_Vector 	PanTilt;						    // optional, Pan and tilt position. The x component corresponds to pan and the y component to tilt
	onvif_Vector1D	Zoom;							    // optional, A zoom position
} onvif_PTZVector;

typedef struct 
{
	uint32	PanTiltFlag	: 1;						    // Indicates whether the field PanTilt is valid
	uint32	ZoomFlag	: 1;						    // Indicates whether the field Zoom is valid
	uint32 	Reserved	: 30;
	
	onvif_Vector 	PanTilt;						    // optional, Pan and tilt speed. The x component corresponds to pan and the y component to tilt. If omitted in a request, the current (if any) PanTilt movement should not be affected
	onvif_Vector1D	Zoom;							    // optional, A zoom speed. If omitted in a request, the current (if any) Zoom movement should not be affected
} onvif_PTZSpeed;

typedef struct 
{
	uint32	PTZPositionFlag	: 1;					    // Indicates whether the field PTZPosition is valid
	uint32 	Reserved		: 31;
	
	char 	Name[ONVIF_NAME_LEN];					    // required, A list of preset position name
	char 	token[ONVIF_TOKEN_LEN];					    // required

	onvif_PTZVector	PTZPosition;					    // optional, A list of preset position
} onvif_PTZPreset;

typedef struct 
{
	onvif_FloatRange 	XRange;						    // required 
	onvif_FloatRange	YRange;						    // required 
} onvif_PanTiltLimits;

typedef struct 
{
	onvif_FloatRange 	XRange;						    // required 
} onvif_ZoomLimits;

typedef struct onvif_PTControlDirection
{
	uint32	EFlipFlag	: 1;						    // Indicates whether the field EFlip is valid
	uint32	ReverseFlag	: 1;						    // Indicates whether the field Reverse is valid
	uint32 	Reserved	: 30;
	
	onvif_EFlipMode		EFlip;						    // optional, Optional element to configure related parameters for E-Flip
	onvif_ReverseMode	Reverse;					    // optional, Optional element to configure related parameters for reversing of PT Control Direction
} onvif_PTControlDirection;

typedef struct 
{
	uint32	PTControlDirectionFlag	: 1;			    // Indicates whether the field PTControlDirection is valid
	uint32 	Reserved				: 31;
	
	onvif_PTControlDirection	PTControlDirection;	    // optional, Optional element to configure PT Control Direction related features
} onvif_PTZConfigurationExtension;

typedef struct
{
	uint32	DefaultPTZSpeedFlag		: 1;			    // Indicates whether the field DefaultPTZSpeed is valid
	uint32	DefaultPTZTimeoutFlag	: 1;			    // Indicates whether the field DefaultPTZTimeout is valid
	uint32	PanTiltLimitsFlag		: 1;			    // Indicates whether the field PanTiltLimits is valid
	uint32	ZoomLimitsFlag			: 1;			    // Indicates whether the field ZoomLimits is valid
	uint32	ExtensionFlag			: 1;			    // Indicates whether the field Extension is valid
	uint32	MoveRampFlag		    : 1;			    // Indicates whether the field MoveRamp is valid
	uint32	PresetRampFlag			: 1;			    // Indicates whether the field PresetRamp is valid
	uint32	PresetTourRampFlag	    : 1;			    // Indicates whether the field PresetTourRamp is valid
	uint32 	Reserved				: 24;
	
	char 	Name[ONVIF_NAME_LEN];					    // required 
	int 	UseCount;								    // required 
	char 	token[ONVIF_TOKEN_LEN];					    // required 
	char 	NodeToken[ONVIF_TOKEN_LEN];				    // required, A mandatory reference to the PTZ Node that the PTZ Configuration belongs to
	
	onvif_PTZSpeed		DefaultPTZSpeed;			    // optional, If the PTZ Node supports absolute or relative PTZ movements, it shall specify corresponding default Pan/Tilt and Zoom speeds
	int					DefaultPTZTimeout;			    // optional, If the PTZ Node supports continuous movements, it shall specify a default timeout, after which the movement stops 
	onvif_PanTiltLimits	PanTiltLimits;				    // optional, The Pan/Tilt limits element should be present for a PTZ Node that supports an absolute Pan/Tilt. If the element is present it signals the support for configurable Pan/Tilt limits. 
													    //	If limits are enabled, the Pan/Tilt movements shall always stay within the specified range. The Pan/Tilt limits are disabled by setting the limits to �CINF or +INF 
	onvif_ZoomLimits 	ZoomLimits;					    // optional, The Zoom limits element should be present for a PTZ Node that supports absolute zoom. If the element is present it signals the supports for configurable Zoom limits. 
													    //	If limits are enabled the zoom movements shall always stay within the specified range. The Zoom limits are disabled by settings the limits to -INF and +INF
	
	onvif_PTZConfigurationExtension	Extension;		    // optional 

	int     MoveRamp;	                                // optional, The optional acceleration ramp used by the device when moving
	int     PresetRamp;	                                // optional, The optional acceleration ramp used by the device when recalling presets
	int     PresetTourRamp;	                            // optional, The optional acceleration ramp used by the device when executing PresetTours
} onvif_PTZConfiguration;

typedef struct 
{
	// Indicates which preset tour operations are available for this PTZ Node
	
	uint32	PTZPresetTourOperation_Start	: 1;
	uint32	PTZPresetTourOperation_Stop		: 1;
	uint32	PTZPresetTourOperation_Pause	: 1;
	uint32	PTZPresetTourOperation_Extended	: 1;
	uint32	Reserved						: 28;	
	
	int 	MaximumNumberOfPresetTours;				    // required, Indicates number of preset tours that can be created. Required preset tour operations shall be available for this PTZ Node if one or more preset tour is supported
} onvif_PTZPresetTourSupported;

typedef struct 
{
	uint32	SupportedPresetTourFlag	: 1;			    // Indicates whether the field SupportedPresetTour is valid
	uint32 	Reserved				: 31;
	
	onvif_PTZPresetTourSupported	SupportedPresetTour;// optional, Detail of supported Preset Tour feature
} onvif_PTZNodeExtension;

typedef struct 
{
	onvif_FloatRange 	XRange;						    // required 
	onvif_FloatRange	YRange;						    // required 
} onvif_Space2DDescription;

typedef struct 
{
	onvif_FloatRange 	XRange;						    // required 
} onvif_Space1DDescription;

typedef struct 
{
    uint32	AbsolutePanTiltPositionSpaceFlag	: 1;			// Indicates whether the field AbsolutePanTiltPositionSpace is valid
    uint32	AbsoluteZoomPositionSpaceFlag	    : 1;			// Indicates whether the field AbsoluteZoomPositionSpace is valid
    uint32	RelativePanTiltTranslationSpaceFlag	: 1;			// Indicates whether the field RelativePanTiltTranslationSpace is valid
    uint32	RelativeZoomTranslationSpaceFlag	: 1;			// Indicates whether the field RelativeZoomTranslationSpace is valid
    uint32	ContinuousPanTiltVelocitySpaceFlag	: 1;			// Indicates whether the field ContinuousPanTiltVelocitySpace is valid
    uint32	ContinuousZoomVelocitySpaceFlag	    : 1;			// Indicates whether the field ContinuousZoomVelocitySpace is valid
    uint32	PanTiltSpeedSpaceFlag	            : 1;			// Indicates whether the field PanTiltSpeedSpace is valid
    uint32	ZoomSpeedSpaceFlag	                : 1;			// Indicates whether the field ZoomSpeedSpace is valid
	uint32 	Reserved				            : 24;
	
	onvif_Space2DDescription	AbsolutePanTiltPositionSpace;	// optional, The Generic Pan/Tilt Position space is provided by every PTZ node that supports absolute Pan/Tilt, since it does not relate to a specific physical range. 
																//	Instead, the range should be defined as the full range of the PTZ unit normalized to the range -1 to 1 resulting in the following space description
	onvif_Space1DDescription	AbsoluteZoomPositionSpace;		// optional, The Generic Zoom Position Space is provided by every PTZ node that supports absolute Zoom, since it does not relate to a specific physical range. 
																//	Instead, the range should be defined as the full range of the Zoom normalized to the range 0 (wide) to 1 (tele). 
																//	There is no assumption about how the generic zoom range is mapped to magnification, FOV or other physical zoom dimension
	onvif_Space2DDescription	RelativePanTiltTranslationSpace;// optional, The Generic Pan/Tilt translation space is provided by every PTZ node that supports relative Pan/Tilt, since it does not relate to a specific physical range. 
																//	Instead, the range should be defined as the full positive and negative translation range of the PTZ unit normalized to the range -1 to 1, 
																//	where positive translation would mean clockwise rotation or movement in right/up direction resulting in the following space description 
	onvif_Space1DDescription	RelativeZoomTranslationSpace;	// optional, The Generic Zoom Translation Space is provided by every PTZ node that supports relative Zoom, since it does not relate to a specific physical range. 
																//	Instead, the corresponding absolute range should be defined as the full positive and negative translation range of the Zoom normalized to the range -1 to1, 
																//	where a positive translation maps to a movement in TELE direction. The translation is signed to indicate direction (negative is to wide, positive is to tele). 
																//	There is no assumption about how the generic zoom range is mapped to magnification, FOV or other physical zoom dimension. This results in the following space description
	onvif_Space2DDescription	ContinuousPanTiltVelocitySpace;	// optional, The generic Pan/Tilt velocity space shall be provided by every PTZ node, since it does not relate to a specific physical range. 
																//	Instead, the range should be defined as a range of the PTZ unit��s speed normalized to the range -1 to 1, where a positive velocity would map to clockwise 
																//	rotation or movement in the right/up direction. A signed speed can be independently specified for the pan and tilt component resulting in the following space description 
	onvif_Space1DDescription	ContinuousZoomVelocitySpace;	// optional, The generic zoom velocity space specifies a zoom factor velocity without knowing the underlying physical model. The range should be normalized from -1 to 1, 
																//	where a positive velocity would map to TELE direction. A generic zoom velocity space description resembles the following
	onvif_Space1DDescription	PanTiltSpeedSpace;				// optional, The speed space specifies the speed for a Pan/Tilt movement when moving to an absolute position or to a relative translation. 
																//	In contrast to the velocity spaces, speed spaces do not contain any directional information. The speed of a combined Pan/Tilt 
																//	movement is represented by a single non-negative scalar value
	onvif_Space1DDescription	ZoomSpeedSpace;					// optional, The speed space specifies the speed for a Zoom movement when moving to an absolute position or to a relative translation. 
																//	In contrast to the velocity spaces, speed spaces do not contain any directional information 
} onvif_PTZSpaces;

typedef struct 
{
	uint32  NameFlag				: 1;			    // Indicates whether the field Name is valid
	uint32	ExtensionFlag			: 1;			    // Indicates whether the field Extension is valid
	uint32	FixedHomePositionFlag	: 1;			    // Indicates whether the field FixedHomePosition is valid
	uint32	Reserved				: 29;	
	
	char 	token[ONVIF_TOKEN_LEN];					    // required 
	char 	Name[ONVIF_NAME_LEN];					    // optional, A unique identifier that is used to reference PTZ Nodes
	
	onvif_PTZSpaces 		SupportedPTZSpaces;		    // required, A list of Coordinate Systems available for the PTZ Node. For each Coordinate System, the PTZ Node MUST specify its allowed range
	
	int 	MaximumNumberOfPresets;					    // required, All preset operations MUST be available for this PTZ Node if one preset is supported 
	BOOL 	HomeSupported;							    // required, A boolean operator specifying the availability of a home position. If set to true, the Home Position Operations MUST be available for this PTZ Node 
	
	onvif_PTZNodeExtension 	Extension;				    // optional 
	
	BOOL 	FixedHomePosition;						    // optional, Indication whether the HomePosition of a Node is fixed or it can be changed via the SetHomePosition command
} onvif_PTZNode;


typedef struct 
{
	// Supported options for EFlip feature	
    uint32  EFlipMode_OFF           : 1;
	uint32  EFlipMode_ON            : 1;
	uint32  EFlipMode_Extended      : 1;

	// Supported options for Reverse feature
	uint32  ReverseMode_OFF         : 1;
	uint32  ReverseMode_ON          : 1;
	uint32  ReverseMode_AUTO        : 1;
	uint32  ReverseMode_Extended    : 1;
	uint32  Reserved                : 25;
} onvif_PTControlDirectionOptions;

typedef struct 
{
    uint32  PTControlDirectionFlag  : 1;		        // Indicates whether the field PTControlDirection is valid
	uint32	Reserved				: 31;

	onvif_PTZSpaces Spaces;							    // required, 
	onvif_IntRange  PTZTimeout;	               		    // required, A timeout Range within which Timeouts are accepted by the PTZ Node
	onvif_PTControlDirectionOptions PTControlDirection;	// optional,  
} onvif_PTZConfigurationOptions;

typedef struct 
{
	uint32  PanTiltFlag	: 1;		    			    // Indicates whether the field PanTilt is valid
	uint32  ZoomFlag  	: 1;		    			    // Indicates whether the field Zoom is valid
	uint32	Reserved	: 30;
	
	onvif_MoveStatus 	PanTilt;					    // optional 
	onvif_MoveStatus 	Zoom;						    // optional 
} onvif_PTZMoveStatus;

typedef struct 
{
	uint32  PositionFlag	: 1;		    		    // Indicates whether the field Position is valid
	uint32  MoveStatusFlag	: 1;		    		    // Indicates whether the field MoveStatus is valid
	uint32  ErrorFlag		: 1;		    		    // Indicates whether the field MoveStatus is valid
	uint32	Reserved		: 29;
	
	onvif_PTZVector 	Position;					    // optional, Specifies the absolute position of the PTZ unit together with the Space references. The default absolute spaces of the corresponding PTZ configuration MUST be referenced within the Position element
	onvif_PTZMoveStatus MoveStatus;					    // optional, Indicates if the Pan/Tilt/Zoom device unit is currently moving, idle or in an unknown state
	
	char 	Error[100];								    // optional, States a current PTZ error
	time_t 	UtcTime;								    // required, Specifies the UTC time when this status was generated 
} onvif_PTZStatus;


typedef struct 
{
    uint32  PresetTokenFlag	: 1;		    		    // Indicates whether the field PresetToken is valid
	uint32  HomeFlag	    : 1;		    		    // Indicates whether the field Home is valid
	uint32  PTZPositionFlag : 1;		    		    // Indicates whether the field PTZPosition is valid
	uint32	Reserved		: 29;
	
	char    PresetToken[ONVIF_TOKEN_LEN];               // optional, Option to specify the preset position with Preset Token defined in advance
	BOOL    Home;                                       // optional, Option to specify the preset position with the home position of this PTZ Node. "False" to this parameter shall be treated as an invalid argument
	
	onvif_PTZVector PTZPosition;                        // optional, Option to specify the preset position with vector of PTZ node directly    
} onvif_PTZPresetTourPresetDetail;

typedef struct 
{
    uint32  SpeedFlag	    : 1;		    		    // Indicates whether the field Speed is valid
	uint32  StayTimeFlag    : 1;		    		    // Indicates whether the field StayTime is valid
	uint32	Reserved		: 30;
	
	onvif_PTZPresetTourPresetDetail PresetDetail;	    // required, Detail definition of preset position of the tour spot
	onvif_PTZSpeed  Speed;	                            // optional, Optional parameter to specify Pan/Tilt and Zoom speed on moving toward this tour spot
	
	int     StayTime;	                                // optional, Optional parameter to specify time duration of staying on this tour sport
} onvif_PTZPresetTourSpot;

typedef struct _ONVIF_PTZPresetTourSpot
{
    struct _ONVIF_PTZPresetTourSpot * next;

    onvif_PTZPresetTourSpot PTZPresetTourSpot;
} ONVIF_PTZPresetTourSpot;

typedef struct 
{
    uint32  CurrentTourSpotFlag : 1;		            // Indicates whether the field CurrentTourSpot is valid
	uint32	Reserved		    : 31;
	
	onvif_PTZPresetTourState    State;	                // required, Indicates state of this preset tour by Idle/Touring/Paused
	onvif_PTZPresetTourSpot     CurrentTourSpot;	    // optional, Indicates a tour spot currently staying
} onvif_PTZPresetTourStatus;

typedef struct 
{
    uint32  RecurringTimeFlag	    : 1;		        // Indicates whether the field RecurringTime is valid
	uint32  RecurringDurationFlag   : 1;		        // Indicates whether the field RecurringDuration is valid
	uint32  DirectionFlag		    : 1;		        // Indicates whether the field Direction is valid
	uint32  RandomPresetOrderFlag   : 1;		        // Indicates whether the field RandomPresetOrder is valid
	uint32	Reserved	            : 28;
	
	int     RecurringTime;	                            // optional, Optional parameter to specify how many times the preset tour is recurred
	int     RecurringDuration;	                        // optional, Optional parameter to specify how long time duration the preset tour is recurred

	onvif_PTZPresetTourDirection    Direction;	        // optional, Optional parameter to choose which direction the preset tour goes. Forward shall be chosen in case it is omitted

	BOOL RandomPresetOrder;	                            // optional, Execute presets in random order. If set to true and Direction is also present, Direction will be ignored and presets of the Tour will be recalled randomly
} onvif_PTZPresetTourStartingCondition;

typedef struct
{
    char    Name[ONVIF_NAME_LEN];	                    // optional, Readable name of the preset tour
    char    token[ONVIF_TOKEN_LEN];	                    // required, Unique identifier of this preset tour

    BOOL    AutoStart;                                  // required, Auto Start flag of the preset tour. True allows the preset tour to be activated always
    
	onvif_PTZPresetTourStatus   Status;	                // required, Read only parameters to indicate the status of the preset tour
		                            
	onvif_PTZPresetTourStartingCondition    StartingCondition;  // required, Parameters to specify the detail behavior of the preset tour

	ONVIF_PTZPresetTourSpot *   TourSpot;	            // optional, A list of detail of touring spots including preset positions
	
} onvif_PresetTour;

typedef struct
{
    int     Min;	                                    // required, unit is second
	int     Max;	                                    // required, unit is second
} onvif_DurationRange;

typedef struct 
{
    uint32  RecurringTimeFlag	            : 1;        // Indicates whether the field RecurringTime is valid
	uint32  RecurringDurationFlag           : 1;        // Indicates whether the field RecurringDuration is valid
    uint32  PTZPresetTourDirection_Forward  : 1;        // 
    uint32  PTZPresetTourDirection_Backward : 1;        // 
    uint32  PTZPresetTourDirection_Extended : 1;        // 
    uint32  Reserved                        : 27;
    
	onvif_IntRange          RecurringTime;	            // optional, Supported range of Recurring Time
	onvif_DurationRange     RecurringDuration;	        // optional, Supported range of Recurring Duration
} onvif_PTZPresetTourStartingConditionOptions;

typedef struct 
{
    uint32  HomeFlag	                : 1;            // Indicates whether the field Home is valid
	uint32  PanTiltPositionSpaceFlag    : 1;            // Indicates whether the field PanTiltPositionSpace is valid
    uint32  ZoomPositionSpaceFlag       : 1;            // Indicates whether the field ZoomPositionSpace is valid
    uint32  Reserved                    : 29;
    
	int     sizePresetToken;	
	char    PresetToken[10][ONVIF_TOKEN_LEN];	        // optional, A list of available Preset Tokens for tour spots
	
	BOOL    Home;	                                    // optional, An option to indicate Home postion for tour spots
	
	onvif_Space2DDescription    PanTiltPositionSpace;   // optional, Supported range of Pan and Tilt for tour spots
	onvif_Space1DDescription    ZoomPositionSpace;	    // optional, Supported range of Zoom for a tour spot
} onvif_PTZPresetTourPresetDetailOptions;

typedef struct 
{
	onvif_PTZPresetTourPresetDetailOptions  PresetDetail;   // required, Supported options for detail definition of preset position of the tour spot
	onvif_DurationRange     StayTime;	                // required, Supported range of stay time for a tour spot
} onvif_PTZPresetTourSpotOptions;

typedef struct
{
	BOOL    AutoStart;	                                // required, Indicates whether or not the AutoStart is supported
	
	onvif_PTZPresetTourStartingConditionOptions StartingCondition;  // required, Supported options for Preset Tour Starting Condition
	onvif_PTZPresetTourSpotOptions  TourSpot;	        // required, Supported options for Preset Tour Spot
} onvif_PTZPresetTourOptions;


typedef struct 
{
	uint32  NameFlag	: 1;		    			    // Indicates whether the field Name is valid
	uint32  MTUFlag		: 1;		    			    // Indicates whether the field MTU is valid
	uint32	Reserved	: 30;
	
	char 	Name[ONVIF_NAME_LEN];					    // optional, Network interface name, for example eth0
	char 	HwAddress[32];							    // required, Network interface MAC address
	int 	MTU;									    // optional, Maximum transmission unit
} onvif_NetworkInterfaceInfo;

typedef struct 
{
	char 	Address[32];							    // required 
	int 	PrefixLength;							    // required 
	
	BOOL 	DHCP;									    // required, Indicates whether or not DHCP is used
} onvif_IPv4Configuration;

typedef struct 
{
	BOOL 	Enabled;								    // required, Indicates whether or not IPv4 is enabled
	
	onvif_IPv4Configuration	Config;					    // required, IPv4 configuration
} onvif_IPv4NetworkInterface;

typedef struct 
{
    uint32  KeyFlag         : 1;                        // Indicates whether the field Key is valid
    uint32  PassphraseFlag  : 1;                        // Indicates whether the field Passphrase is valid
    uint32  Reserved        : 30;   
    
	char    Key[256];	                                // optional, hexBinary, 
	                                                    // According to IEEE802.11-2007 H.4.1 the RSNA PSK consists of 256 bits, 
	                                                    //  or 64 octets when represented in hex
					                                    // Either Key or Passphrase shall be given, 
					                                    //  if both are supplied Key shall be used by the device and Passphrase ignored.
	char    Passphrase[128];	                        // optional,
	                                                    // According to IEEE802.11-2007 H.4.1 a pass-phrase is 
	                                                    //  a sequence of between 8 and 63 ASCII-encoded characters and
					                                    //  each character in the pass-phrase must have an encoding in the range of 32 to 126 (decimal),inclusive.
					                                    //  If only Passpharse is supplied the Key shall be derived using the algorithm described in 
					                                    //  IEEE802.11-2007 section H.4
} onvif_Dot11PSKSet;

typedef struct 
{
    uint32  AlgorithmFlag   : 1;                        // Indicates whether the field Algorithm is valid
    uint32  PSKFlag         : 1;                        // Indicates whether the field PSK is valid
    uint32  Dot1XFlag       : 1;                        // // Indicates whether the field Dot1X is valid
    uint32  Reserved        : 29;
    
	onvif_Dot11SecurityMode Mode;	                    // required
	onvif_Dot11Cipher       Algorithm;	                // optional
	onvif_Dot11PSKSet       PSK;	                    // optional
	
	char    Dot1X[ONVIF_TOKEN_LEN];	                    // optional
} onvif_Dot11SecurityConfiguration;

typedef struct 
{
	char    SSID[32];	                                // required, hexBinary
	
	onvif_Dot11StationMode Mode;	                    // required
	
	char    Alias[32];	                                // required	
	int     Priority;	                                // required, range is 0-31
	
	onvif_Dot11SecurityConfiguration    Security;	    // required element of type ns2:Dot11SecurityConfiguration */
} onvif_Dot11Configuration;

typedef struct
{
    int     InterfaceType;	                            // required, tt:IANA-IfTypes, Integer indicating interface type, for example: 6 is ethernet
                                                        //  ieee80211(71)
                                                        //  For valid numbers, please refer to http://www.iana.org/assignments/ianaiftype-mib
	int     sizeDot11;	                                // sequence of elements <Dot11>
	onvif_Dot11Configuration    Dot11[4];	            // optional
} onvif_NetworkInterfaceExtension;

typedef struct 
{
	uint32  InfoFlag	    : 1;		    		    // Indicates whether the field Info is valid
	uint32  IPv4Flag	    : 1;		    	        // Indicates whether the field IPv4 is valid
	uint32  ExtensionFlag	: 1;		    		    // Indicates whether the field Extension is valid
	uint32	Reserved	    : 29;
	
	char 	token[ONVIF_TOKEN_LEN];					    // required 
	BOOL 	Enabled;								    // required, Indicates whether or not an interface is enabled
	
	onvif_NetworkInterfaceInfo	Info;				    // optional, Network interface information
	onvif_IPv4NetworkInterface 	IPv4;				    // optional, IPv4 network interface configuration
	onvif_NetworkInterfaceExtension Extension;	        // optional,
} onvif_NetworkInterface;

typedef struct
{
	BOOL 	HTTPFlag;								    // Indicates if the http protocol required
	BOOL 	HTTPEnabled;							    // Indicates if the http protocol is enabled or not
	BOOL 	HTTPSFlag;								    // Indicates if the https protocol required
	BOOL 	HTTPSEnabled;							    // Indicates if the https protocol is enabled or not
	BOOL 	RTSPFlag;								    // Indicates if the rtsp protocol required
	BOOL 	RTSPEnabled;							    // Indicates if the rtsp protocol is enabled or not

	int  	HTTPPort[MAX_SERVER_PORT];				    // The port that is used by the protocol
	int  	HTTPSPort[MAX_SERVER_PORT];				    // The port that is used by the protocol
	int  	RTSPPort[MAX_SERVER_PORT];				    // The port that is used by the protocol
} onvif_NetworkProtocol;

typedef struct 
{
	uint32  SearchDomainFlag	: 1;		    	    // Indicates whether the field Name is valid
	uint32	Reserved			: 31;
	
	BOOL 	FromDHCP;								    // required, Indicates whether or not DNS information is retrieved from DHCP 
	char 	SearchDomain[MAX_SEARCHDOMAIN][64];		    // optional, Search domain
	char	DNSServer[MAX_DNS_SERVER][32];			    // required
} onvif_DNSInformation;

typedef struct
{
	onvif_DynamicDNSType	Type;					    // required 
	
	char 	Name[ONVIF_NAME_LEN];					    // optional 
	int		TTL;									    // optional
} onvif_DynamicDNSInformation;

typedef struct 
{
	BOOL 	FromDHCP;								    // required, Indicates if NTP information is to be retrieved by using DHCP
	char	NTPServer[MAX_NTP_SERVER][32];			    // required
} onvif_NTPInformation;

typedef struct 
{
	uint32  NameFlag	: 1;		    			    // Indicates whether the field Name is valid
	uint32	Reserved	: 31;
	
	BOOL	FromDHCP;								    // required, Indicates whether the hostname is obtained from DHCP or not
	BOOL	RebootNeeded;							    // required, Indicates whether or not a reboot is required after configuration updates
	char 	Name[100];								    // optional, Indicates the hostname
} onvif_HostnameInformation;

typedef struct 
{
	char	IPv4Address[MAX_GATEWAY][32];			    // required, IPv4 address string	
} onvif_NetworkGateway;

typedef struct 
{
	char    InterfaceToken[ONVIF_TOKEN_LEN];	        // required, Unique identifier of network interface
	BOOL    Enabled;	                                // required, Indicates whether the zero-configuration is enabled or not
	int     sizeAddresses;	                            // sequence of elements <Addresses>
	char    Addresses[4][32];	                        // optional, The zero-configuration IPv4 address(es)
} onvif_NetworkZeroConfiguration;

typedef struct 
{
    uint32  BSSIDFlag           : 1;
    uint32  PairCipherFlag      : 1;
    uint32  GroupCipherFlag     : 1;
    uint32  SignalStrengthFlag  : 1;
    uint32  Reserved            : 28;
    
	char    SSID[32];	                                // required, hexBinary
	char    BSSID[64];	                                // optional
	
	onvif_Dot11Cipher           PairCipher;	            // optional 
	onvif_Dot11Cipher           GroupCipher;	        // optional 
	onvif_Dot11SignalStrength   SignalStrength;	        // optional 
	
	char    ActiveConfigAlias[32];	                    // required 	
} onvif_Dot11Status;

typedef struct 
{
    uint32  BSSIDFlag           : 1;
    uint32  SignalStrengthFlag  : 1;
    uint32  Reserved            : 31;
    
	char    SSID[32];	                                // required, hexBinary
	char    BSSID[64];	                                // optional

	int     sizeAuthAndMangementSuite;	                // sequence of elements <AuthAndMangementSuite>
	onvif_Dot11AuthAndMangementSuite    AuthAndMangementSuite[4];	// optional

	int     sizePairCipher;	                            // sequence of elements <PairCipher> 
	onvif_Dot11Cipher   PairCipher[4];	                // optional

	int     sizeGroupCipher;	                        // sequence of elements <GroupCipher>
	onvif_Dot11Cipher   GroupCipher[4];	                // optional
	
	onvif_Dot11SignalStrength   SignalStrength;	        // optional
} onvif_Dot11AvailableNetworks;

typedef struct 
{
	char 	TZ[128];								    // required, Posix timezone string
} onvif_TimeZone;

typedef struct
{
	int		Hour;									    // Range is 0 to 23
	int		Minute;									    // Range is 0 to 59
	int		Second;									    // Range is 0 to 61 (typically 59)
} onvif_Time;

typedef struct
{
	int		Year;									    // 
	int		Month;									    // Range is 1 to 12
	int		Day;									    // Range is 1 to 31
} onvif_Date;

typedef struct
{
	onvif_Time	Time;								    // required 
	onvif_Date  Date;								    // required 
} onvif_DateTime;

typedef struct 
{
	uint32  TimeZoneFlag	: 1;		    		    // Indicates whether the field TimeZone is valid
	uint32	Reserved		: 31;
	
	BOOL 	DaylightSavings;						    // required, Informative indicator whether daylight savings is currently on/off
	
	onvif_SetDateTimeType 	DateTimeType;			    // required, Indicates if the time is set manully or through NTP	
	onvif_TimeZone			TimeZone;				    // optional, Timezone information in Posix format 
} onvif_SystemDateTime;

typedef struct 
{
	onvif_ScopeDefinition   ScopeDef;	                // required
	
	char    ScopeItem[128];	                            // required
} onvif_Scope;

typedef struct 
{
	onvif_TransportProtocol Protocol;				    // required, Defines the network protocol for streaming, either UDP=RTP/UDP, RTSP=RTP/RTSP/TCP or HTTP=RTP/RTSP/HTTP/TCP 
} onvif_Transport;

typedef struct 
{
	onvif_StreamType	Stream;						    // required, Defines if a multicast or unicast stream is requested
	onvif_Transport 	Transport;					    // required 
} onvif_StreamSetup;

typedef struct
{
	char 	SourceId[128];							    // required, Identifier for the source chosen by the client that creates the structure.
													    //	This identifier is opaque to the device. Clients may use any type of URI for this field. A device shall support at least 128 characters
	char 	Name[64];								    // required, Informative user readable name of the source, e.g. "Camera23". A device shall support at least 20 characters
	char 	Location[100];							    // required, Informative description of the physical location of the source, e.g. the coordinates on a map
	char 	Description[128];						    // required, Informative description of the source
	char 	Address[128];							    // required, URI provided by the service supplying data to be recorded. A device shall support at least 128 characters
} onvif_RecordingSourceInformation;

typedef struct
{
	uint32  MaximumRetentionTimeFlag : 1;			    // Indicates whether the field MaximumRetentionTime is valid
	uint32  Reserved 				 : 31;
	
	onvif_RecordingSourceInformation	Source;		    // required, Information about the source of the recording
	char 	Content[256];							    // required, Informative description of the source
	uint32 	MaximumRetentionTime;					    // optional, specifies the maximum time that data in any track within the
													    //	recording shall be stored. The device shall delete any data older than the maximum retention
													    //	time. Such data shall not be accessible anymore. If the MaximumRetentionPeriod is set to 0,
													    //	the device shall not limit the retention time of stored data, except by resource constraints.
													    //	Whatever the value of MaximumRetentionTime, the device may automatically delete
													    //	recordings to free up storage space for new recordings.
													    //  unit is second
} onvif_RecordingConfiguration;

typedef struct 
{
	onvif_TrackType	TrackType;						    // required, Type of the track. It shall be equal to the strings "Video", "Audio" or "Metadata"
	
	char 	Description[100];						    // required, Informative description of the track
} onvif_TrackConfiguration;

typedef struct 
{
	uint32  TypeFlag : 1;							    // Indicates whether the field Type is valid
	uint32  Reserved : 31;
	
	char 	Token[ONVIF_TOKEN_LEN];					    // required,
	char 	Type[256];								    // optional, default is "http://www.onvif.org/ver10/schema/Receiver", "http://www.onvif.org/ver10/schema/Profile"
} onvif_SourceReference;

typedef struct 
{
	char 	SourceTag[64];							    // required, If the received RTSP stream contains multiple tracks of the same type, the
													    //	SourceTag differentiates between those Tracks. This field can be ignored in case of recording a local source
	char 	Destination[ONVIF_TOKEN_LEN];			    // required, The destination is the tracktoken of the track to which the device shall store the received data
} onvif_RecordingJobTrack;

typedef struct 
{
	uint32  SourceTokenFlag 		: 1;			    // Indicates whether the field SourceToken is valid
	uint32  AutoCreateReceiverFlag 	: 1;			    // Indicates whether the field AutoCreateReceiver is valid
	uint32  Reserved 				: 30;
	
	onvif_SourceReference	SourceToken;			    // optional, This field shall be a reference to the source of the data. The type of the source
													    //	is determined by the attribute Type in the SourceToken structure. If Type is
													    //	http://www.onvif.org/ver10/schema/Receiver, the token is a ReceiverReference. In this case
													    //	the device shall receive the data over the network. If Type is
													    //	http://www.onvif.org/ver10/schema/Profile, the token identifies a media profile, instructing the
													    //	device to obtain data from a profile that exists on the local device
	BOOL 	AutoCreateReceiver;						    // optional, If this field is TRUE, and if the SourceToken is omitted, the device
													    //	shall create a receiver object (through the receiver service) and assign the
													    //	ReceiverReference to the SourceToken field. When retrieving the RecordingJobConfiguration
													    //	from the device, the AutoCreateReceiver field shall never be present

	int 	sizeTracks;
	
	onvif_RecordingJobTrack	Tracks[5];				    // optional, List of tracks associated with the recording
} onvif_RecordingJobSource;

typedef struct 
{
	char 	RecordingToken[ONVIF_TOKEN_LEN];		    // required, Identifies the recording to which this job shall store the received data
	char 	Mode[16];								    // required, The mode of the job. If it is idle, nothing shall happen. If it is active, the device shall try to obtain data from the receivers. 
													    //	A client shall use GetRecordingJobState to determine if data transfer is really taking place
													    //   The only valid values for Mode shall be "Idle" or "Active"
	int 	Priority;								    // required, This shall be a non-negative number. If there are multiple recording jobs that store data to
													    //	the same track, the device will only store the data for the recording job with the highest
													    //	priority. The priority is specified per recording job, but the device shall determine the priority
													    //	of each track individually. If there are two recording jobs with the same priority, the device
													    //	shall record the data corresponding to the recording job that was activated the latest
	int 	sizeSource;
	
	onvif_RecordingJobSource	Source[5];			    // optional, Source of the recording
} onvif_RecordingJobConfiguration;

typedef struct 
{
	uint32  ErrorFlag	: 1;						    // Indicates whether the field Error is valid
	uint32  Reserved	: 31;
	
	char 	SourceTag[64];							    // required, Identifies the track of the data source that provides the data
	char 	Destination[ONVIF_TOKEN_LEN];			    // required, Indicates the destination track
	char 	Error[100];								    // optional, Optionally holds an implementation defined string value that describes the error. The string should be in the English language
	char 	State[16];								    // required, Provides the job state of the track. 
													    //	The valid values of state shall be "Idle", "Active" and "Error". If state equals "Error", the Error field may be filled in with an implementation defined value
} onvif_RecordingJobStateTrack;

typedef struct 
{
	onvif_SourceReference	SourceToken;			    // required, Identifies the data source of the recording job
	char 	State[16];								    // required, Holds the aggregated state over all substructures of RecordingJobStateSource
													    // 	Idle : All state values in sub-nodes are "Idle"
													    // 	PartiallyActive : The state of some sub-nodes are "active" and some sub-nodes are "idle"
													    //	Active : The state of all sub-nodes is "Active"
													    //	Error : At least one of the sub-nodes has state "Error"
	int 	sizeTrack;
	
	onvif_RecordingJobStateTrack	Track[5];		    // optional, 
} onvif_RecordingJobStateSource;

typedef struct 
{
	char 	RecordingToken[ONVIF_TOKEN_LEN];		    // required, Identification of the recording that the recording job records to
	char 	State[16];								    // required, Holds the aggregated state over the whole RecordingJobInformation structure
													    // 	Idle : All state values in sub-nodes are "Idle"
													    // 	PartiallyActive : The state of some sub-nodes are "active" and some sub-nodes are "idle"
													    //	Active : The state of all sub-nodes is "Active"
													    //	Error : At least one of the sub-nodes has state "Error"
	
	int 	sizeSources;
	
	onvif_RecordingJobStateSource	Sources[5];		    // optional, Identifies the data source of the recording job
} onvif_RecordingJobStateInformation;

typedef struct
{
	uint32  SpareFlag				: 1;			    // Indicates whether the field Spare is valid
	uint32  CompatibleSourcesFlag	: 1;			    // Indicates whether the field CompatibleSources is valid
	uint32  Reserved				: 30;
	
	int 	Spare;									    // optional, Number of spare jobs that can be created for the recording
	char 	CompatibleSources[160];					    // optional, A device that supports recording of a restricted set of Media Service Profiles returns the list of profiles that can be recorded on the given Recording
} onvif_JobOptions;

typedef struct
{
	uint32  SpareTotalFlag		: 1;				    // Indicates whether the field SpareTotal is valid
	uint32  SpareVideoFlag		: 1;				    // Indicates whether the field SpareVideo is valid
	uint32  SpareAudioFlag		: 1;				    // Indicates whether the field SpareAudio is valid
	uint32  SpareMetadataFlag	: 1;				    // Indicates whether the field SpareMetadata is valid
	uint32  Reserved			: 28;
	
	int 	SpareTotal;								    // optional, Total spare number of tracks that can be added to this recording
	int 	SpareVideo;								    // optional, Number of spare Video tracks that can be added to this recording
	int 	SpareAudio;								    // optional, Number of spare Aduio tracks that can be added to this recording
	int 	SpareMetadata;							    // optional, Number of spare Metadata tracks that can be added to this recording
} onvif_TrackOptions;

typedef struct
{
	onvif_JobOptions	Job;						    // required, 
	onvif_TrackOptions	Track;						    // required, 
} onvif_RecordingOptions;

typedef struct
{
	char 	TrackToken[ONVIF_TOKEN_LEN];			    // required
	
	onvif_TrackConfiguration 	Configuration;		    // required
} onvif_Track;

typedef struct _ONVIF_Track
{
	struct _ONVIF_Track * next;

	onvif_Track	Track;
} ONVIF_Track;

typedef struct 
{
	char 	RecordingToken[ONVIF_TOKEN_LEN];		    // required
	
	onvif_RecordingConfiguration 	Configuration;	    // required
	
	ONVIF_Track	* Tracks;
} onvif_Recording;

typedef struct
{
	char 	JobToken[ONVIF_TOKEN_LEN];				    // required
	
	onvif_RecordingJobConfiguration	JobConfiguration;	// required
} onvif_RecordingJob;

typedef struct 
{
	char 	Name[32];									// required, Item name
	char 	Value[ONVIF_TOKEN_LEN];						// required, Item value. The type is defined in the corresponding description
} onvif_SimpleItem;

typedef struct _ONVIF_SimpleItem
{
	struct _ONVIF_SimpleItem * next;

	onvif_SimpleItem SimpleItem;						// Value name pair as defined by the corresponding description
} ONVIF_SimpleItem;

typedef struct
{
    uint32  AnyFlag   : 1;
    uint32  Reserverd : 31;
    
	char 	Name[32];									// required, Item name
	char  * Any;                                        // optional
} onvif_ElementItem;

typedef struct _ONVIF_ElementItem
{
	struct _ONVIF_ElementItem * next;

	onvif_ElementItem ElementItem;						// Value name pair as defined by the corresponding description
} ONVIF_ElementItem;

typedef struct 
{
	ONVIF_SimpleItem	* SimpleItem;					// optional
	ONVIF_ElementItem	* ElementItem;					// optional
} onvif_ItemList;

typedef struct
{
	uint32  PropertyOperationFlag	: 1;				// Indicates whether the field PropertyOperation is valid
	uint32  SourceFlag				: 1;				// Indicates whether the field Source is valid
	uint32  KeyFlag					: 1;				// Indicates whether the field Key is valid
	uint32  DataFlag				: 1;				// Indicates whether the field Data is valid
	uint32  Reserved				: 28;
	
	time_t UtcTime;										// required
	
	onvif_ItemList	Source;								// optional, Token value pairs that triggered this message. Typically only one item is present
	onvif_ItemList	Key;								// optional element of type tt:ItemList */
	onvif_ItemList	Data;								// optional element of type tt:ItemList */
	
	onvif_PropertyOperation	PropertyOperation;			// optional 
} onvif_Message;

typedef struct
{
	char	ConsumerAddress[256];						// required, 
	char 	ProducterAddress[256];						// required, 

	char	Dialect[256];								// required, 
	char	Topic[256];									// required, 

	onvif_Message	Message;							// required
} onvif_NotificationMessage;

typedef struct 
{
	time_t 	DataFrom;									// required, The earliest point in time where there is recorded data on the device
	time_t 	DataUntil;									// required, The most recent point in time where there is recorded data on the device
	int 	NumberRecordings;							// required, The device contains this many recordings
} onvif_RecordingSummary;

typedef struct 
{
	char 	TrackToken[ONVIF_TOKEN_LEN];				// required, 
	
	onvif_TrackType TrackType;							// required, Type of the track: "Video", "Audio" or "Metadata".
														//	The track shall only be able to hold data of that type
	
	char 	Description[100];							// required, Informative description of the contents of the track
	time_t 	DataFrom;									// required, The start date and time of the oldest recorded data in the track
	time_t 	DataTo;										// required, The stop date and time of the newest recorded data in the track
} onvif_TrackInformation;

typedef struct 
{
	uint32  EarliestRecordingFlag	: 1;				// Indicates whether the field EarliestRecording is valid
	uint32  LatestRecordingFlag		: 1;				// Indicates whether the field LatestRecording is valid
	uint32  Reserved				: 30;
	
	char 	RecordingToken[ONVIF_TOKEN_LEN];			// required, 
	
	onvif_RecordingSourceInformation	Source;			// required, Information about the source of the recording
	
	time_t	EarliestRecording;							// optional, 
	time_t	LatestRecording;							// optional, 
	char	Content[256];								// required, 

	int 	sizeTrack;	
	onvif_TrackInformation	Track[5];					// optional, Basic information about the track. Note that a track may represent a single contiguous time span or consist of multiple slices
	
	onvif_RecordingStatus	RecordingStatus;			// required, 
} onvif_RecordingInformation;

typedef struct 
{
	uint32  BitrateFlag	: 1;							// Indicates whether the field Bitrate is valid
	uint32  Reserved	: 31;
	
	int 	Bitrate;									// optional, Average bitrate in kbps
	int 	Width;										// required, The width of the video in pixels
	int 	Height;										// required, The height of the video in pixels

	onvif_VideoEncoding Encoding;						// required, Used video codec, either Jpeg, H.264 or Mpeg4

	float 	Framerate;									// required, Average framerate in frames per second
} onvif_VideoAttributes;

typedef struct 
{
	uint32  BitrateFlag	: 1;							// Indicates whether the field Bitrate is valid
	uint32  Reserved	: 31;
	
	int 	Bitrate;									// optional, The bitrate in kbps

	onvif_AudioEncoding Encoding;						// required, Audio codec used for encoding the audio (either G.711, G.726 or AAC)

	int 	Samplerate;									// required, The sample rate in kHz
} onvif_AudioAttributes;

typedef struct 
{
	uint32  PtzSpacesFlag	: 1;						// Indicates whether the field PtzSpaces is valid
	uint32  Reserved		: 31;
	
	BOOL 	CanContainPTZ;								// required, Indicates that there can be PTZ data in the metadata track in the specified time interval
	BOOL 	CanContainAnalytics;						// required, Indicates that there can be analytics data in the metadata track in the specified time interval
	BOOL 	CanContainNotifications;					// required, Indicates that there can be notifications in the metadata track in the specified time interval
	char 	PtzSpaces[256];								// optional, List of all PTZ spaces active for recording. Note that events are only recorded on position changes and 
														//	the actual point of recording may not necessarily contain an event of the specified type
} onvif_MetadataAttributes;

typedef struct 
{
	uint32  VideoAttributesFlag		: 1;				// Indicates whether the field VideoAttributes is valid
	uint32  AudioAttributesFlag		: 1;				// Indicates whether the field AudioAttributes is valid
	uint32  MetadataAttributesFlag	: 1;				// Indicates whether the field MetadataAttributes is valid
	uint32  Reserved				: 29;
	
	onvif_TrackInformation		TrackInformation;		// required, The basic information about the track. Note that a track may represent a single contiguous time span or consist of multiple slices
	onvif_VideoAttributes		VideoAttributes;		// optional, If the track is a video track, exactly one of this structure shall be present and contain the video attributes
	onvif_AudioAttributes		AudioAttributes;		// optional, If the track is an audio track, exactly one of this structure shall be present and contain the audio attributes
	onvif_MetadataAttributes	MetadataAttributes;		// optional, If the track is an metadata track, exactly one of this structure shall be present and contain the metadata attributes
} onvif_TrackAttributes;

typedef struct _ONVIF_TrackAttributes
{
	struct _ONVIF_TrackAttributes * next;
	
	onvif_TrackAttributes	TrackAttributes;
} ONVIF_TrackAttributes;

typedef struct 
{
	char 	RecordingToken[ONVIF_TOKEN_LEN];			// required, A reference to the recording that has these attributes
	
	int 	sizeTrackAttributes;
	onvif_TrackAttributes	TrackAttributes[5];			// optional, A set of attributes for each track

	time_t 	From;										// required, The attributes are valid from this point in time in the recording
	time_t 	Until;										// required, The attributes are valid until this point in time in the recording. 
														//	Can be equal to 'From' to indicate that the attributes are only known to be valid for this particular point in time
} onvif_MediaAttributes;

typedef struct 
{
	uint32  RecordingInformationFilterFlag	: 1;		// Indicates whether the field RecordingInformationFilter is valid
	uint32  Reserved						: 31;
	
	int 	sizeIncludedSources;
	onvif_SourceReference	IncludedSources[10];		// optional, A list of sources that are included in the scope. If this list is included, only data from one of these sources shall be searched
	
	int 	sizeIncludedRecordings;
	char 	IncludedRecordings[10][ONVIF_TOKEN_LEN];	// optional, A list of recordings that are included in the scope. If this list is included, only data from one of these recordings shall be searched

	char 	RecordingInformationFilter[128];			// optional, An xpath expression used to specify what recordings to search. 
														//	Only those recordings with an RecordingInformation structure that matches the filter shall be searched
} onvif_SearchScope;

typedef struct _ONVIF_RecordingInformation
{
	struct _ONVIF_RecordingInformation * next;

	onvif_RecordingInformation	RecordingInformation;
} ONVIF_RecordingInformation;

typedef struct 
{
	onvif_SearchState SearchState;						// required, The state of the search when the result is returned. Indicates if there can be more results, or if the search is completed
	
	ONVIF_RecordingInformation * RecordInformation;     // optional, A RecordingInformation structure for each found recording matching the search
} onvif_FindRecordingResultList;

typedef struct 
{
	char 	RecordingToken[ONVIF_TOKEN_LEN];			// required, The recording where this event was found. Empty string if no recording is associated with this event
	char 	TrackToken[ONVIF_TOKEN_LEN];				// required, A reference to the track where this event was found. Empty string if no track is associated with this event
	time_t 	Time;										// required, The time when the event occured

	onvif_NotificationMessage 	Event;					// required, The description of the event

	BOOL 	StartStateEvent;							// required, If true, indicates that the event is a virtual event generated for this particular search session to give the state of a property at the start time of the search
} onvif_FindEventResult;

typedef struct _ONVIF_FindEventResult
{
	struct _ONVIF_FindEventResult * next;

	onvif_FindEventResult	FindEventResult;
} ONVIF_FindEventResult;

typedef struct 
{
	onvif_SearchState SearchState;						// required, The state of the search when the result is returned. Indicates if there can be more results, or if the search is completed

	ONVIF_FindEventResult * Result;				        // optional
} onvif_FindEventResultList;


//////////////////////////////////////////////////////////////////////////
//	Video analytics struct defines
//////////////////////////////////////////////////////////////////////////

typedef struct 
{
	onvif_ItemList	Parameters;							// required
	
	char 	Name[32];									// required
	char 	Type[32];									// required
} onvif_Config;

typedef struct _ONVIF_Config
{
	struct _ONVIF_Config * next;

	onvif_Config	Config;
} ONVIF_Config;

typedef struct 
{
	ONVIF_Config * AnalyticsModule;						// optional
} onvif_AnalyticsEngineConfiguration;

typedef struct 
{
	ONVIF_Config * Rule;								// optional
} onvif_RuleEngineConfiguration;

typedef struct 
{
	char 	Name[ONVIF_NAME_LEN];						// required
	int 	UseCount;									// required
	char 	token[ONVIF_TOKEN_LEN];						// required

	onvif_AnalyticsEngineConfiguration 	AnalyticsEngineConfiguration;	// required
	onvif_RuleEngineConfiguration 		RuleEngineConfiguration;		// required 
} onvif_VideoAnalyticsConfiguration;

typedef struct
{
	char 	Name[64];									// required
	char 	Type[64];									// required
} onvif_SimpleItemDescription;

typedef struct _ONVIF_SimpleItemDescription
{
	struct _ONVIF_SimpleItemDescription * next;

	onvif_SimpleItemDescription	SimpleItemDescription;
} ONVIF_SimpleItemDescription;

typedef struct 
{
	ONVIF_SimpleItemDescription	* SimpleItemDescription;
	ONVIF_SimpleItemDescription	* ElementItemDescription;
} onvif_ItemListDescription;

typedef struct 
{
	uint32  SourceFlag		: 1;						// Indicates whether the field Source is valid
	uint32  KeyFlag			: 1;						// Indicates whether the field Source is valid
	uint32  DataFlag		: 1;						// Indicates whether the field Source is valid
	uint32  IsPropertyFlag	: 1;						// Indicates whether the field Source is valid
	uint32  Reserved		: 28;
	
	onvif_ItemListDescription	Source;					// optional 
	onvif_ItemListDescription	Key;					// optional 
	onvif_ItemListDescription	Data;					// optional 

	BOOL	IsProperty;									// optional 
	char	ParentTopic[100];							// required 
} onvif_ConfigDescription_Messages;

typedef struct _ONVIF_ConfigDescription_Messages
{
	struct _ONVIF_ConfigDescription_Messages * next;

	onvif_ConfigDescription_Messages Messages;
} ONVIF_ConfigDescription_Messages;

typedef struct 
{
	onvif_ItemListDescription 	Parameters;				// required 

	ONVIF_ConfigDescription_Messages * Messages;		

	char 	Name[ONVIF_NAME_LEN];						// required 
} onvif_ConfigDescription;

typedef struct _ONVIF_ConfigDescription
{
	struct _ONVIF_ConfigDescription * next;

	onvif_ConfigDescription	ConfigDescription;
} ONVIF_ConfigDescription;

typedef struct 
{
	int 	sizeRuleContentSchemaLocation;
	char 	RuleContentSchemaLocation[10][256];			// optional

	ONVIF_ConfigDescription	* RuleDescription;
} onvif_SupportedRules;

typedef struct
{
    char    Dialect[128];
    char    Expression[256];
} onvif_EventFilterItem;

typedef struct
{
    int     sizeTopicExpression;
    int     sizeMessageContent;
    
    onvif_EventFilterItem   TopicExpression[5];
    onvif_EventFilterItem   MessageContent[5];
} onvif_EventFilter;

// PROFILE C Define Begin

/**
 * The AccessPoint capabilities reflect optional functionality of a particular physical entity.
 * Different AccessPoint instances may have different set of capabilities. 
 * This information maychange during device operation, e.g. if hardware settings are changed.
 */
typedef struct 
{
	BOOL    DisableAccessPoint;	                        // required, Indicates whether or not this AccessPoint instance supports EnableAccessPoint and DisableAccessPoint commands
	BOOL    Duress;	                                    // optional, Indicates whether or not this AccessPoint instance supports generation of duress events
	BOOL    AnonymousAccess;	                        // optional, Indicates whether or not this AccessPoint has a REX switch or other input that allows anonymous access
	BOOL    AccessTaken;	                            // optional, Indicates whether or not this AccessPoint instance supports generation of AccessTaken and AccessNotTaken events.
	                                                    //  If AnonymousAccess and AccessTaken are both true, it indicates that the Anonymous versions of AccessTaken and AccessNotTaken are supported
	BOOL    ExternalAuthorization;	                    // optional, Indicates whether or not this AccessPoint instance supports the ExternalAuthorization operation and the generation of Request events. 
	                                                    //  If AnonymousAccess and ExternalAuthorization are both true, it indicates that the Anonymous version is supported as well
} onvif_AccessPointCapabilities;

/**
 * The AccessPointInfo structure contains basic information about an AccessPoint instance.
 * An AccessPoint defines an entity a Credential can be granted or denied access to. 
 * TheAccessPointInfo provides basic information on how access is controlled in one direction for adoor (from which area to which area).
 * door is the typical device involved, but other type ofdevices may be supported as well.
 * Multiple AccessPoints may cover the same Door.A typical case is one AccessPoint for entry and another for exit, both referencingthe same Door.
 * An ONVIF compliant device shall provide the following fields for each AccessPoint instance
 */
typedef struct 
{
    uint32  DescriptionFlag : 1;
    uint32  AreaFromFlag    : 1;
    uint32  AreaToFlag      : 1;
    uint32  EntityTypeFlag  : 1;
    uint32  Reserved        : 28;
    
    char    token[ONVIF_TOKEN_LEN];                     // required
    char    Name[ONVIF_NAME_LEN];                       // required, A user readable name. It shall be up to 64 characters
    char    Description[1024];                          // optional, Optional user readable description for the AccessPoint. It shall be up to 1024 characters
    char    AreaFrom[ONVIF_TOKEN_LEN];                  // optional, Optional reference to the Area from which access is requested
    char    AreaTo[ONVIF_TOKEN_LEN];                    // optional, Optional reference to the Area to which access is requested
    char    EntityType[100];                            // optional, Optional entity type; if missing, a Door type as defined by the ONVIF DoorControl service should be assumed. 
                                                        //  This can also be represented by the QName value "tdc:Door" - where tdc is the namespace of the Door Control service. 
                                                        //  This field is provided for future extensions; it will allow an AccessPoint being extended to cover entity types other than Doors as well
    char    Entity[ONVIF_TOKEN_LEN];                    // required, Reference to the entity used to control access; the entity type may be specified by the optional EntityType field explained below but is typically a Door

    onvif_AccessPointCapabilities   Capabilities;       // required, The capabilities for the AccessPoint
} onvif_AccessPointInfo;

typedef struct _ONVIF_AccessPoint
{
    struct _ONVIF_AccessPoint * next;

    BOOL    Enabled;                                    // Indicates that the AccessPoint is enabled. By default this field value shall be True, if the DisableAccessPoint capabilities is not supported
    
    onvif_AccessPointInfo   AccessPointInfo;
} ONVIF_AccessPoint;

typedef struct _ONVIF_AccessPointInfo
{
    struct _ONVIF_AccessPointInfo * next;
    
    onvif_AccessPointInfo   AccessPointInfo;
} ONVIF_AccessPointInfo;

/**
 * DoorCapabilities reflect optional functionality of a particular physical entity.
 * Different door instances may have different set of capabilities.
 * This information may change during device operation, e.g. if hardware settings are changed
 */
typedef struct 
{
	BOOL    Access;	                                    // optional, Indicates whether or not this Door instance supports AccessDoor command to perform momentary access
	BOOL    AccessTimingOverride;	                    // optional, Indicates that this Door instance supports overriding configured timing in the AccessDoor command
	BOOL    Lock;	                                    // optional, Indicates that this Door instance supports LockDoor command to lock the door
	BOOL    Unlock;	                                    // optional, Indicates that this Door instance supports UnlockDoor command to unlock the door
	BOOL    Block;	                                    // optional, Indicates that this Door instance supports BlockDoor command to block the door
	BOOL    DoubleLock;	                                // optional, Indicates that this Door instance supports DoubleLockDoor command to lock multiple locks on the door
	BOOL    LockDown;	                                // optional, Indicates that this Door instance supports LockDown (and LockDownRelease) commands to lock the door and put it in LockedDown mode
	BOOL    LockOpen;	                                // optional, Indicates that this Door instance supports LockOpen (and LockOpenRelease) commands to unlock the door and put it in LockedOpen mode
	BOOL    DoorMonitor;	                            // optional, Indicates that this Door instance has a DoorMonitor and supports the DoorPhysicalState event
	BOOL    LockMonitor;	                            // optional, Indicates that this Door instance has a LockMonitor and supports the LockPhysicalState event
	BOOL    DoubleLockMonitor;	                        // optional, Indicates that this Door instance has a DoubleLockMonitor and supports the DoubleLockPhysicalState event
	BOOL    Alarm;	                                    // optional, Indicates that this Door instance supports door alarm and the DoorAlarm event
	BOOL    Tamper;	                                    // optional, Indicates that this Door instance has a Tamper detector and supports the DoorTamper event
	BOOL    Fault;	                                    // optional, Indicates that this Door instance supports door fault and the DoorFault event
} onvif_DoorCapabilities;

// Tampering information for a Door
typedef struct 
{
    uint32  ReasonFlag : 1;
    uint32  Reserved   : 31;
    
	char    Reason[100];                                // optional, Optional field; Details describing tampering state change (e.g., reason, place and time).
	                                                    //  NOTE: All fields (including this one) which are designed to give end-user prompts can be localized to the customers's native language
	onvif_DoorTamperState State;	                    // required, State of the tamper detector
} onvif_DoorTamper;

// Fault information for a Door
typedef struct 
{
    uint32  ReasonFlag : 1;
    uint32  Reserved   : 31;
    
	char    Reason[100];	                            // optional, Optional reason for fault
	
	onvif_DoorFaultState State;	                        // required, Overall fault state for the door; it is of type DoorFaultState. If there are any faults, the value shall be: FaultDetected. 
	                                                    //  Details of the detected fault shall be found in the Reason field, and/or the various DoorState fields and/or in extensions to this structure
} onvif_DoorFault;

// The DoorState structure contains current aggregate runtime status of Door
typedef struct
{
    uint32  DoorPhysicalStateFlag       : 1;
    uint32  LockPhysicalStateFlag       : 1;
    uint32  DoubleLockPhysicalStateFlag : 1;
    uint32  AlarmFlag                   : 1;
    uint32  TamperFlag                  : 1;
    uint32  FaultFlag                   : 1;
    uint32  Reserved                    : 26;
    
	onvif_DoorPhysicalState DoorPhysicalState;	        // optional, Physical state of Door; it is of type DoorPhysicalState. 
	                                                    //  A device that signals support for DoorMonitor capability for a particular door instance shall provide this field 
	onvif_LockPhysicalState LockPhysicalState;	        // optional, Physical state of the Lock; it is of type LockPhysicalState. 
	                                                    //  A device that signals support for LockMonitor capability for a particular door instance shall provide this field
	onvif_LockPhysicalState DoubleLockPhysicalState;	// optional, Physical state of the DoubleLock; it is of type LockPhysicalState. 
	                                                    //  A device that signals support for DoubleLockMonitor capability for a particular door instance shall provide this field
	onvif_DoorAlarmState    Alarm;	                    // optional, Alarm state of the door; it is of type DoorAlarmState. 
	                                                    //  A device that signals support for Alarm capability for a particular door instance shall provide this field
	onvif_DoorTamper        Tamper;	                    // optional, Tampering state of the door; it is of type DoorTamper.
	                                                    //  A device that signals support for Tamper capability for a particular door instance shall provide this field
	onvif_DoorFault         Fault;	                    // optional, Fault information for door; it is of type DoorFault.
	                                                    //  A device that signals support for Fault capability for a particular door instance shall provide this field
	onvif_DoorMode          DoorMode;	                // required,  The logical operating mode of the door; it is of type DoorMode. An ONVIF compatible device shall report current operating mode in this field
} onvif_DoorState;

/**
 * The DoorInfo type represents the Door as a physical object.
 * The structure contains information and capabilities of a specific door instance
 */
typedef struct 
{
    uint32  DescriptionFlag : 1;
    uint32  Reserved        : 31;
    
	char    token[ONVIF_TOKEN_LEN];	                    // required
	char    Name[ONVIF_NAME_LEN];	                    // required, A user readable name. It shall be up to 64 characters
	char    Description[1024];	                        // optional, A user readable description. It shall be up to 1024 characters

	onvif_DoorCapabilities  Capabilities;	            // required, The capabilities of the Door
} onvif_DoorInfo;

typedef struct _ONVIF_Door
{
    struct _ONVIF_Door * next;

    onvif_DoorState DoorState;     
    onvif_DoorInfo  DoorInfo;
} ONVIF_Door;

typedef struct _ONVIF_DoorInfo
{
    struct _ONVIF_DoorInfo * next;
    
    onvif_DoorInfo  DoorInfo;
} ONVIF_DoorInfo;

/**
 * The AreaInfo structure contains basic information about an Area
 */
typedef struct 
{
    uint32  DescriptionFlag : 1;
    uint32  Reserved        : 31;
    
	char    token[ONVIF_TOKEN_LEN];	                    // required
	char    Name[ONVIF_NAME_LEN];	                    // required, A user readable name. It shall be up to 64 characters
	char    Description[1024];	                        // optional, A user readable description. It shall be up to 1024 characters
} onvif_AreaInfo;

typedef struct _ONVIF_AreaInfo
{
    struct _ONVIF_AreaInfo * next;

    onvif_AreaInfo   AreaInfo;
} ONVIF_AreaInfo;


// PROFILE C Define End

// DEVICEIO Define Begin

// A pane layout describes one Video window of a display. It links a pane configuration to a region of the screen
typedef struct 
{
	char 	Pane[ONVIF_TOKEN_LEN];						// required, Reference to the configuration of the streaming and coding parameters

	onvif_Rectangle 	Area;							// required, Describes the location and size of the area on the monitor. 
														//	The area coordinate values are espressed in normalized units [-1.0, 1.0]
} onvif_PaneLayout;

typedef struct _ONVIF_PaneLayout
{
	struct _ONVIF_PaneLayout * next;

	onvif_PaneLayout	PaneLayout;						// required
} ONVIF_PaneLayout;

// A layout describes a set of Video windows that are displayed simultaniously on a display
typedef struct 
{
	ONVIF_PaneLayout * 	PaneLayout;						// required, List of panes assembling the display layout
} onvif_Layout;

// Representation of a physical video outputs
typedef struct 
{
	uint32  ResolutionFlag 	: 1;						// Indicates whether the field Resolution is valid
	uint32  RefreshRateFlag : 1;						// Indicates whether the field RefreshRate is valid
	uint32  AspectRatioFlag : 1;						// Indicates whether the field AspectRatio is valid
    uint32  Reserved        : 29;						
    
	char 	token[ONVIF_TOKEN_LEN];						// required, 

	onvif_Layout 			Layout;						// required, 
	onvif_VideoResolution 	Resolution;					// optional, Resolution of the display in Pixel

	float 	RefreshRate;								// optional, Refresh rate of the display in Hertz
	float 	AspectRatio;								// optional, Aspect ratio of the display as physical extent of width divided by height
} onvif_VideoOutput;

typedef struct _ONVIF_VideoOutput
{
	struct _ONVIF_VideoOutput * next;

	onvif_VideoOutput	VideoOutput;
} ONVIF_VideoOutput;

typedef struct 
{
	char 	Name[ONVIF_NAME_LEN];						// required
	int 	UseCount;									// required
	char 	token[ONVIF_TOKEN_LEN];						// required
	char 	OutputToken[ONVIF_TOKEN_LEN];				// required
} onvif_VideoOutputConfiguration;

typedef struct _ONVIF_VideoOutputConfiguration
{
    struct _ONVIF_VideoOutputConfiguration * next;

    onvif_VideoOutputConfiguration  Configuration;
} ONVIF_VideoOutputConfiguration;

typedef struct
{
    char 	token[ONVIF_TOKEN_LEN];						// required, 
} onvif_AudioOutput;

typedef struct _ONVIF_AudioOutput
{
    struct _ONVIF_AudioOutput  * next;
    
    onvif_AudioOutput   AudioOutput;
} ONVIF_AudioOutput;

typedef struct 
{
	int     sizeOutputTokensAvailable;	                
	char    OutputTokensAvailable[5][ONVIF_TOKEN_LEN];	// required, Tokens of the physical Audio outputs (typically one)
	int     sizeSendPrimacyOptions;
	char    SendPrimacyOptions[5][100];	                // optional, The following modes for the Send-Primacy are defined:
							                            //  www.onvif.org/ver20/HalfDuplex/Server
							                            //  www.onvif.org/ver20/HalfDuplex/Client
							                            //  www.onvif.org/ver20/HalfDuplex/Auto

	onvif_IntRange  OutputLevelRange;	                // required, Minimum and maximum level range supported for this Output
} onvif_AudioOutputConfigurationOptions;

typedef struct 
{
    uint32  SendPrimacyFlag : 1;						// Indicates whether the field SendPrimacy is valid
    uint32  Reserved        : 31;
    
	char    Name[ONVIF_NAME_LEN];	                    // required, 
	int     UseCount;	                                // required, 
	char    token[ONVIF_TOKEN_LEN];	                    // required, 
	char    OutputToken[ONVIF_TOKEN_LEN];	            // required, Token of the phsycial Audio output
	char    SendPrimacy[100];	                        // optional, The following modes for the Send-Primacy are defined:
	                                                    //  www.onvif.org/ver20/HalfDuplex/Server
	                                                    //  www.onvif.org/ver20/HalfDuplex/Client
	                                                    //  www.onvif.org/ver20/HalfDuplex/Auto
	int     OutputLevel;	                            // required, Volume setting of the output. The applicable range is defined via the option AudioOutputOptions.OutputLevelRange
} onvif_AudioOutputConfiguration;

typedef struct _ONVIF_AudioOutputConfiguration
{
    struct _ONVIF_AudioOutputConfiguration * next;

    onvif_AudioOutputConfigurationOptions   Options;
    onvif_AudioOutputConfiguration          Configuration;
} ONVIF_AudioOutputConfiguration;

typedef struct 
{
	onvif_RelayMode Mode;	                            // required, 'Bistable' or 'Monostable'
	uint32  DelayTime;	                                // external, Time after which the relay returns to its idle state if it is in monostable mode. 
	                                                    //  If the Mode field is set to bistable mode the value of the parameter can be ignored
	onvif_RelayIdleState IdleState;	                    // required, 'open' or 'closed'
} onvif_RelayOutputSettings;

typedef struct 
{
    uint32 RelayMode_BistableFlag   : 1;
    uint32 RelayMode_MonostableFlag : 1;    
    uint32 DelayTimesFlag           : 1;
    uint32 DiscreteFlag             : 1;
    uint32 Reserved                 : 28;
    
	char    DelayTimes[100];	                        // optional, Supported delay time range or discrete values in seconds. This element must be present if MonoStable mode is supported.
	BOOL    Discrete;	                                // optional, True if the relay only supports the exact values for the DelayTimes listed. Default is false
	char    token[ONVIF_TOKEN_LEN];	                    // required, Token of the relay output
} onvif_RelayOutputOptions;

typedef struct 
{
	char    token[ONVIF_TOKEN_LEN];	                    // required

	onvif_RelayOutputSettings   Properties;	            // required
} onvif_RelayOutput;

typedef struct _ONVIF_RelayOutput
{
    struct _ONVIF_RelayOutput * next;

    onvif_RelayOutputOptions    Options;
    onvif_RelayLogicalState     RelayLogicalState;     
    onvif_RelayOutput           RelayOutput;
} ONVIF_RelayOutput;

typedef struct 
{
    uint32 IdleStateFlag    : 1;
    uint32 Reserved         : 31;
    
	char    token[ONVIF_TOKEN_LEN];	                    // required

	onvif_DigitalIdleState  IdleState;	                // optional, Indicate the Digital IdleState status
} onvif_DigitalInput;

typedef struct 
{
    uint32  DigitalIdleState_closedFlag : 1;
    uint32  DigitalIdleState_openFlag   : 1;
    uint32  Reserved                    : 30;
} onvif_DigitalInputConfigurationInputOptions;

typedef struct _ONVIF_DigitalInput
{
    struct _ONVIF_DigitalInput * next;

    onvif_DigitalInputConfigurationInputOptions Options;
    
    onvif_DigitalInput  DigitalInput;
} ONVIF_DigitalInput;

typedef struct 
{
	int     BaudRate;	                                // required, The transfer bitrate	
	int     CharacterLength;	                        // required, The bit length for each character
	float   StopBit;	                                // required, The number of stop bits used to terminate each character
	char    token[ONVIF_TOKEN_LEN];	                    // required,

	onvif_ParityBit         ParityBit;	                // required, The parity for the data error detection
	onvif_SerialPortType    type;	                    // required,
} onvif_SerialPortConfiguration;

typedef struct 
{
	onvif_IntList           BaudRateList;	            // required, The list of configurable transfer bitrate
	onvif_ParityBitList     ParityBitList;	            // required, The list of configurable parity for the data error detection
	onvif_IntList           CharacterLengthList;        // required, The list of configurable bit length for each character
	onvif_FloatList         StopBitList;	            // required, The list of configurable number of stop bits used to terminate each character

	char    token[ONVIF_TOKEN_LEN];	                    // required, 
} onvif_SerialPortConfigurationOptions;

typedef struct 
{
	char    token[ONVIF_TOKEN_LEN];	                    // required
} onvif_SerialPort;

typedef struct _ONVIF_SerialPort
{
    struct _ONVIF_SerialPort * next;

    onvif_SerialPortConfiguration           Configuration;
    onvif_SerialPortConfigurationOptions    Options;
    onvif_SerialPort                        SerialPort;
} ONVIF_SerialPort;

typedef union 
{
	char   * Binary;
	char   * String;
} onvif_union_SerialData;

typedef struct 
{
    int     _union_SerialData;                          // 0 - Binary; 1 - String
    
	onvif_union_SerialData  union_SerialData;
} onvif_SerialData;

typedef struct 
{
    uint32  SerialDataFlag  : 1;
    uint32  TimeOutFlag     : 1;
    uint32  DataLengthFlag  : 1;
    uint32  DelimiterFlag   : 1;
    uint32  Reserved        : 28;
    
	onvif_SerialData    SerialData;	                    // optional, The serial port data

	uint32  TimeOut;	                                // optional, Indicates that the command should be responded back within the specified period of time
	int     DataLength;	                                // optional, This element may be put in the case that data length returned from the connected serial device is already determined as some fixed bytes length. 
	                                                    //  It indicates the length of received data which can be regarded as available
	char    Delimiter[100];	                            // optional, This element may be put in the case that the delimiter codes returned from the connected serial device is already known. 
	                                                    //  It indicates the termination data sequence of the responded data. In case the string has more than one character a device shall interpret the whole string as a single delimiter. 
	                                                    //  Furthermore a device shall return the delimiter character(s) to the client
} onvif_SendReceiveSerialCommand;


// DEVICEIO Define End

// MEDIA2 Define Begin

typedef struct 
{
    uint32  GovLengthRangeFlag           : 1;           // Indicates whether the field GovLengthRange is valid
    uint32  FrameRatesSupportedFlag      : 1;           // Indicates whether the field FrameRatesSupported is valid
    uint32  ProfilesSupportedFlag        : 1;           // Indicates whether the field ProfilesSupported is valid
    uint32  ConstantBitRateSupportedFlag : 1;           // Indicates whether the field ConstantBitRateSupported is valid
    uint32  Reserved                     : 28;
    
	char    Encoding[64];	                            // required, Mime name of the supported Video format
	                                                    //  JPEG, MPV4-ES, H264, H265

    onvif_VideoEncoding     VideoEncoding;              // media server 1 field

	onvif_FloatRange        QualityRange;	            // required, Range of the quality values. A high value means higher quality
	onvif_VideoResolution	ResolutionsAvailable[MAX_RES_NUMS];	// required, List of supported image sizes
	onvif_IntRange          BitrateRange;	            // required, Supported range of encoded bitrate in kbps

	char    GovLengthRange[100];	                    // optional, Lower and Upper bounds for the supported group of Video frames length. 
	                                                    //  This value typically corresponds to the I-Frame distance
	char    FrameRatesSupported[100];	                // optional, List of supported target frame rates in fps (frames per second). 
	                                                    //  The list shall be sorted with highest values first
	char    ProfilesSupported[256];	                    // optional, List of supported encoder profiles
	                                                    //  Simple          <!-- MPEG4 SP -->
	                                                    //  AdvancedSimple  <!-- MPEG4 ASP -->
	                                                    //  Baseline        <!-- H264 Baseline -->
	                                                    //  Main            <!-- H264 Main, H.265 Main -->
	                                                    //  Main10          <!-- H265 Main 10 -->
	                                                    //  Extended        <!-- H264 Extended -->
	                                                    //  High            <!-- H264 High -->
	BOOL    ConstantBitRateSupported;	                // optional, Signal whether enforcing constant bitrate is supported
} onvif_VideoEncoder2ConfigurationOptions;

typedef struct _ONVIF_VideoEncoder2ConfigurationOptions
{
    struct _ONVIF_VideoEncoder2ConfigurationOptions * next;

    onvif_VideoEncoder2ConfigurationOptions Options;
} ONVIF_VideoEncoder2ConfigurationOptions;

typedef struct 
{
    uint32  ConstantBitRateFlag : 1;                    // Indicates whether the field ConstantBitRate is valid
    uint32  Reserved            : 31;
    
	float   FrameRateLimit;	                            // required, Desired frame rate in fps. The actual rate may be lower due to e.g. performance limitations
	int     BitrateLimit;	                            // required, the maximum output bitrate in kbps
	BOOL    ConstantBitRate;	                        // optional, Enforce constant bitrate

	int     EncodingInterval;                           // required, The media server field
} onvif_VideoRateControl2;

typedef struct 
{
    uint32  RateControlFlag : 1;                        // Indicates whether the field RateControl is valid
    uint32  MulticastFlag   : 1;                        // Indicates whether the field Multicast is valid
    uint32  GovLengthFlag   : 1;                        // Indicates whether the field GovLength is valid
    uint32  ProfileFlag     : 1;                        // Indicates whether the field Profile is valid
    uint32  Reserved        : 28;
    
	char    Name[ONVIF_NAME_LEN];	                    // required
	int     UseCount;	                                // required
	char    token[ONVIF_TOKEN_LEN];	                    // required
	char    Encoding[64];	                            // required, Mime name of the supported video format.
	                                                    //  JPEG, MPV4-ES, H264, H265
    onvif_VideoEncoding             VideoEncoding;      // required, the media service field
    
	onvif_VideoResolution           Resolution;	        // required, Configured video resolution
	onvif_VideoRateControl2         RateControl;	    // optional, Optional element to configure rate control related parameters
	onvif_MulticastConfiguration    Multicast;	        // optional, Defines the multicast settings that could be used for video streaming

	float   Quality;	                                // required, Relative value for the video quantizers and the quality of the video. 
	                                                    //  A high value within supported quality range means higher quality
	int     GovLength;	                                // optional, Group of Video frames length. Determines typically the interval in which the I-Frames will be coded. 
	                                                    //  An entry of 1 indicates I-Frames are continuously generated. An entry of 2 indicates that every 2nd image is an I-Frame, and 3 only every 3rd frame, etc. 
	                                                    //  The frames in between are coded as P or B Frames
	char    Profile[64];	                            // optional, The encoder profile
	                                                    //  Simple          <!-- MPEG4 SP -->
	                                                    //  AdvancedSimple  <!-- MPEG4 ASP -->
	                                                    //  Baseline        <!-- H264 Baseline -->
	                                                    //  Main            <!-- H264 Main, H.265 Main -->
	                                                    //  Main10          <!-- H265 Main 10 -->
	                                                    //  Extended        <!-- H264 Extended -->
	                                                    //  High            <!-- H264 High -->

	int     SessionTimeout;                             // required, the media service field
} onvif_VideoEncoder2Configuration;

typedef struct _ONVIF_VideoEncoder2Configuration
{
    struct _ONVIF_VideoEncoder2Configuration * next;

    onvif_VideoEncoder2Configuration        Configuration;
} ONVIF_VideoEncoder2Configuration;

typedef struct 
{
    uint32  MulticastFlag   : 1;                        // Indicates whether the field Multicast is valid
    uint32  Reserved        : 31;
    
	char    Name[ONVIF_NAME_LEN];	                    // required
	int     UseCount;	                                // required
	char    token[ONVIF_TOKEN_LEN];	                    // required
	char    Encoding[32];	                            // required, Mime name of the supported audio format
	                                                    //  PCMU, G726, MP4A-LATM(AAC)

	onvif_AudioEncoding             AudioEncoding;      // required, the media service field
	
	onvif_MulticastConfiguration    Multicast;	        // optional, Optional multicast configuration of the audio stream
	int     Bitrate;	                                // required, The output bitrate in kbps
	int     SampleRate;	                                // required, The output sample rate in kHz

	int     SessionTimeout;                             // required, the media service field
} onvif_AudioEncoder2Configuration;

typedef struct 
{
	char    Encoding[32];	                            // required, Mime name of the supported audio format
	                                                    //  PCMU, G726, MP4A-LATM(AAC)
    onvif_AudioEncoding AudioEncoding;                  // media server 1 field
    
	onvif_IntList   BitrateList;	                    // required, List of supported bitrates in kbps for the specified Encoding
	onvif_IntList   SampleRateList;	                    // required, List of supported Sample Rates in kHz for the specified Encoding
} onvif_AudioEncoder2ConfigurationOptions;

typedef struct _ONVIF_AudioEncoder2ConfigurationOptions
{
    struct _ONVIF_AudioEncoder2ConfigurationOptions * next;

    onvif_AudioEncoder2ConfigurationOptions Options;
} ONVIF_AudioEncoder2ConfigurationOptions;

typedef struct _ONVIF_AudioEncoder2Configuration
{
    struct _ONVIF_AudioEncoder2Configuration * next;

    onvif_AudioEncoder2Configuration        Configuration;
} ONVIF_AudioEncoder2Configuration;

typedef struct 
{
    uint32  TokenFlag   : 1;                            // Indicates whether the field Token is valid
    uint32  Reserved    : 31;
    
	char    Type[32];	                                // required, Type of the configuration
	                                                    //  All, VideoSource, VideoEncoder, AudioSource, AudioEncoder, 
	                                                    //  AudioOutput, AudioDecoder, Metadata, Analytics, PTZ
	char    Token[ONVIF_TOKEN_LEN];	                    // optional, Reference token of an existing configuration
} onvif_ConfigurationRef;

typedef struct 
{
	char    Encoding[32];	                            // required,
	int     Number;	                                    // required,
} onvif_EncoderInstance;

typedef struct 
{
	int     sizeCodec;  
	onvif_EncoderInstance   Codec[10];	                // optional, If a device limits the number of instances for respective Video Codecs the response
	                                                    //  contains the information how many streams can be set up at the same time per VideoSource
	
	int     Total;	                                    // required, The minimum guaranteed total number of encoder instances (applications) per VideoSourceConfiguration. 
	                                                    //  The device is able to deliver the Total number of streams
} onvif_EncoderInstanceInfo;

typedef struct 
{
	char    Name[ONVIF_NAME_LEN];	                    // required, 
	int     UseCount;	                                // required, 
	char    token[ONVIF_TOKEN_LEN];	                    // required, 
} onvif_ConfigurationEntity;

typedef struct 
{
	char    Name[ONVIF_NAME_LEN];	                    // required, 
	int     UseCount;	                                // required, 
	char    token[ONVIF_TOKEN_LEN];	                    // required, 
} onvif_AudioDecoderConfiguration;

typedef struct _ONVIF_AudioDecoderConfiguration
{
	struct _ONVIF_AudioDecoderConfiguration * next;

	onvif_AudioDecoderConfiguration Configuration;
} ONVIF_AudioDecoderConfiguration;

typedef struct 
{
	onvif_IntList   Bitrate;	                        // required
	onvif_IntList   SampleRateRange;	                // required
} onvif_AACDecOptions;

typedef struct 
{
	onvif_IntList   Bitrate;	                        // required
	onvif_IntList   SampleRateRange;	                // required
} onvif_G711DecOptions;

typedef struct 
{
	onvif_IntList   Bitrate;	                        // required
	onvif_IntList   SampleRateRange;	                // required
} onvif_G726DecOptions;

typedef struct
{
    uint32 AACDecOptionsFlag  : 1;
    uint32 G711DecOptionsFlag : 1;
    uint32 G726DecOptionsFlag : 1;
    uint32 Reserved           : 29;
    
    onvif_AACDecOptions     AACDecOptions;	            // optional
	onvif_G711DecOptions    G711DecOptions;	            // optional
	onvif_G726DecOptions    G726DecOptions;	            // optional
} onvif_AudioDecoderConfigurationOptions;

typedef struct 
{
    uint32  VideoSourceFlag     : 1;
    uint32  AudioSourceFlag     : 1;
    uint32  VideoEncoderFlag    : 1;
    uint32  AudioEncoderFlag    : 1;
    uint32  AnalyticsFlag       : 1;
    uint32  PTZFlag             : 1;
    uint32  MetadataFlag        : 1;
    uint32  AudioOutputFlag     : 1;
    uint32  AudioDecoderFlag    : 1;
    uint32  Reserved            : 23;
    
	onvif_VideoSourceConfiguration      VideoSource;	// optional, Optional configuration of the Video input
	onvif_AudioSourceConfiguration      AudioSource;	// optional, Optional configuration of the Audio input
	onvif_VideoEncoder2Configuration    VideoEncoder;	// optional, Optional configuration of the Video encoder
	onvif_AudioEncoder2Configuration    AudioEncoder;	// optional, Optional configuration of the Audio encoder
	onvif_ConfigurationEntity           Analytics;	    // optional, Optional configuration of the analytics module and rule engine
	onvif_PTZConfiguration              PTZ;	        // optional, Optional configuration of the pan tilt zoom unit
	onvif_MetadataConfiguration         Metadata;	    // optional, Optional configuration of the metadata stream
	onvif_AudioOutputConfiguration      AudioOutput;	// optional, Optional configuration of the Audio output
	onvif_AudioDecoderConfiguration     AudioDecoder;	// optional, Optional configuration of the Audio decoder
} onvif_ConfigurationSet;

typedef struct 
{
	char    Name[ONVIF_NAME_LEN];	                    // required, User readable name of the profile

	onvif_ConfigurationSet  Configurations;	            // required, The configurations assigned to the profile

	char    token[ONVIF_TOKEN_LEN];	                    // required, Unique identifier of the profile
	BOOL    fixed;	                                    // optional, A value of true signals that the profile cannot be deleted. Default is false
} onvif_MediaProfile;

typedef struct _ONVIF_MediaProfile
{
    struct _ONVIF_MediaProfile * next;

    onvif_MediaProfile  MediaProfile;
} ONVIF_MediaProfile;

// MEDIA2 Define End


#ifdef __cplusplus
extern "C" {
#endif


ONVIF_API const char * 				        onvif_CapabilityCategoryToString(onvif_CapabilityCategory category);
ONVIF_API onvif_CapabilityCategory 	        onvif_StringToCapabilityCategory(const char * str);

ONVIF_API const char *                      onvif_FactoryDefaultTypeToString(onvif_FactoryDefaultType type);
ONVIF_API onvif_FactoryDefaultType          onvif_StringToFactoryDefaultType(const char * str);

ONVIF_API const char *                      onvif_SystemLogTypeToString(onvif_SystemLogType type);
ONVIF_API onvif_SystemLogType               onvif_StringToSystemLogType(const char * str);

ONVIF_API const char * 				        onvif_VideoEncodingToString(onvif_VideoEncoding encoding);
ONVIF_API onvif_VideoEncoding 		        onvif_StringToVideoEncoding(const char * str);

ONVIF_API const char * 				        onvif_AudioEncodingToString(onvif_AudioEncoding encoding);
ONVIF_API onvif_AudioEncoding 		        onvif_StringToAudioEncoding(const char * str);

ONVIF_API const char * 				        onvif_H264ProfileToString(onvif_H264Profile profile);
ONVIF_API onvif_H264Profile 			    onvif_StringToH264Profile(const char * str);

ONVIF_API const char * 				        onvif_Mpeg4ProfileToString(onvif_Mpeg4Profile profile);
ONVIF_API onvif_Mpeg4Profile 			    onvif_StringToMpeg4Profile(const char * str);

ONVIF_API const char * 				        onvif_UserLevelToString(onvif_UserLevel level);
ONVIF_API onvif_UserLevel 			        onvif_StringToUserLevel(const char * str);

ONVIF_API const char * 				        onvif_MoveStatusToString(onvif_MoveStatus status);
ONVIF_API onvif_MoveStatus 			        onvif_StringToMoveStatus(const char * str);

ONVIF_API const char * 				        onvif_OSDTypeToString(onvif_OSDType type);
ONVIF_API onvif_OSDType 				    onvif_StringToOSDType(const char * type);

ONVIF_API const char * 				        onvif_OSDPosTypeToString(onvif_OSDPosType type);
ONVIF_API onvif_OSDPosType 			        onvif_StringToOSDPosType(const char * type);

ONVIF_API const char * 				        onvif_OSDTextTypeToString(onvif_OSDTextType type);
ONVIF_API onvif_OSDTextType 			    onvif_StringToOSDTextType(const char * type);

ONVIF_API const char * 				        onvif_BacklightCompensationModeToString(onvif_BacklightCompensationMode mode);
ONVIF_API onvif_BacklightCompensationMode   onvif_StringToBacklightCompensationMode(const char * str);

ONVIF_API const char * 				        onvif_ExposureModeToString(onvif_ExposureMode mode);
ONVIF_API onvif_ExposureMode 			    onvif_StringToExposureMode(const char * str);

ONVIF_API const char * 				        onvif_ExposurePriorityToString(onvif_ExposurePriority mode);
ONVIF_API onvif_ExposurePriority 		    onvif_StringToExposurePriority(const char * str);

ONVIF_API const char * 				        onvif_AutoFocusModeToString(onvif_AutoFocusMode mode);
ONVIF_API onvif_AutoFocusMode 		        onvif_StringToAutoFocusMode(const char * str);

ONVIF_API const char * 				        onvif_WideDynamicModeToString(onvif_WideDynamicMode mode);
ONVIF_API onvif_WideDynamicMode 		    onvif_StringToWideDynamicMode(const char * str);

ONVIF_API const char * 				        onvif_IrCutFilterModeToString(onvif_IrCutFilterMode mode);
ONVIF_API onvif_IrCutFilterMode 		    onvif_StringToIrCutFilterMode(const char * str);

ONVIF_API const char * 				        onvif_WhiteBalanceModeToString(onvif_WhiteBalanceMode mode);
ONVIF_API onvif_WhiteBalanceMode 		    onvif_StringToWhiteBalanceMode(const char * str);

ONVIF_API const char * 				        onvif_EFlipModeToString(onvif_EFlipMode mode);
ONVIF_API onvif_EFlipMode 			        onvif_StringToEFlipMode(const char * str);

ONVIF_API const char * 				        onvif_ReverseModeToString(onvif_ReverseMode mode);
ONVIF_API onvif_ReverseMode 			    onvif_StringToReverseMode(const char * str);

ONVIF_API const char *				        onvif_DiscoveryModeToString(onvif_DiscoveryMode mode);
ONVIF_API onvif_DiscoveryMode			    onvif_StringToDiscoveryMode(const char * str);

ONVIF_API const char * 				        onvif_SetDateTimeTypeToString(onvif_SetDateTimeType type);
ONVIF_API onvif_SetDateTimeType		        onvif_StringToSetDateTimeType(const char * str);

ONVIF_API const char * 				        onvif_StreamTypeToString(onvif_StreamType type);
ONVIF_API onvif_StreamType			        onvif_StringToStreamType(const char * str);

ONVIF_API const char * 				        onvif_TransportProtocolToString(onvif_TransportProtocol type);
ONVIF_API onvif_TransportProtocol		    onvif_StringToTransportProtocol(const char * str);

ONVIF_API const char *				        onvif_DynamicDNSTypeToString(onvif_DynamicDNSType type);
ONVIF_API onvif_DynamicDNSType		        onvif_StringToDynamicDNSType(const char * str);

ONVIF_API const char * 				        onvif_TrackTypeToString(onvif_TrackType type);
ONVIF_API onvif_TrackType				    onvif_StringToTrackType(const char * str);

ONVIF_API const char * 				        onvif_PropertyOperationToString(onvif_PropertyOperation type);
ONVIF_API onvif_PropertyOperation		    onvif_StringToPropertyOperation(const char * str);

ONVIF_API const char * 				        onvif_RecordingStatusToString(onvif_RecordingStatus status);
ONVIF_API onvif_RecordingStatus		        onvif_StringToRecordingStatus(const char * str);

ONVIF_API const char *				        onvif_SearchStateToString(onvif_SearchState state);
ONVIF_API onvif_SearchState			        onvif_StringToSearchState(const char * str);

ONVIF_API const char * 				        onvif_RotateModeToString(onvif_RotateMode mode);
ONVIF_API onvif_RotateMode			        onvif_StringToRotateMode(const char * str);

ONVIF_API const char *                      onvif_ScopeDefinitionToString(onvif_ScopeDefinition def);
ONVIF_API onvif_ScopeDefinition             onvif_StringToScopeDefinition(const char * str);

ONVIF_API const char *                      onvif_Dot11AuthAndMangementSuiteToString(onvif_Dot11AuthAndMangementSuite req);
ONVIF_API onvif_Dot11AuthAndMangementSuite  onvif_StringToDot11AuthAndMangementSuite(const char * str);

ONVIF_API const char *                      onvif_Dot11CipherToString(onvif_Dot11Cipher req);
ONVIF_API onvif_Dot11Cipher                 onvif_StringToDot11Cipher(const char * str);

ONVIF_API const char *                      onvif_Dot11SignalStrengthToString(onvif_Dot11SignalStrength req);
ONVIF_API onvif_Dot11SignalStrength         onvif_StringToDot11SignalStrength(const char * str);

ONVIF_API const char *                      onvif_Dot11StationModeToString(onvif_Dot11StationMode req);
ONVIF_API onvif_Dot11StationMode            onvif_StringToDot11StationMode(const char * str);

ONVIF_API const char *                      onvif_Dot11SecurityModeToString(onvif_Dot11SecurityMode req);
ONVIF_API onvif_Dot11SecurityMode           onvif_StringToDot11SecurityMode(const char * str);

ONVIF_API const char *                      onvif_PTZPresetTourOperationToString(onvif_PTZPresetTourOperation op);
ONVIF_API onvif_PTZPresetTourOperation      onvif_StringToPTZPresetTourOperation(const char * str);

ONVIF_API const char *                      onvif_PTZPresetTourStateToString(onvif_PTZPresetTourState st);
ONVIF_API onvif_PTZPresetTourState          onvif_StringToPTZPresetTourState(const char * str);

ONVIF_API const char *                      onvif_PTZPresetTourDirectionToString(onvif_PTZPresetTourDirection dir);
ONVIF_API onvif_PTZPresetTourDirection      onvif_StringToPTZPresetTourDirection(const char * str);

ONVIF_API const char *				        onvif_DoorPhysicalStateToString(onvif_DoorPhysicalState state);
ONVIF_API onvif_DoorPhysicalState			onvif_StringToDoorPhysicalState(const char * str);

ONVIF_API const char *				        onvif_LockPhysicalStateToString(onvif_LockPhysicalState state);
ONVIF_API onvif_LockPhysicalState			onvif_StringToLockPhysicalState(const char * str);

ONVIF_API const char *				        onvif_DoorAlarmStateToString(onvif_DoorAlarmState state);
ONVIF_API onvif_DoorAlarmState			    onvif_StringToDoorAlarmState(const char * str);

ONVIF_API const char *				        onvif_DoorTamperStateToString(onvif_DoorTamperState state);
ONVIF_API onvif_DoorTamperState			    onvif_StringToDoorTamperState(const char * str);

ONVIF_API const char *				        onvif_DoorFaultStateToString(onvif_DoorFaultState state);
ONVIF_API onvif_DoorFaultState			    onvif_StringToDoorFaultState(const char * str);

ONVIF_API const char *				        onvif_DoorModeToString(onvif_DoorMode mode);
ONVIF_API onvif_DoorMode			        onvif_StringToDoorMode(const char * str);

ONVIF_API const char *                      onvif_RelayModeToString(onvif_RelayMode mode);
ONVIF_API onvif_RelayMode                   onvif_StringToRelayMode(const char * str);

ONVIF_API const char *                      onvif_RelayIdleStateToString(onvif_RelayIdleState state);
ONVIF_API onvif_RelayIdleState              onvif_StringToRelayIdleState(const char * str);

ONVIF_API const char *                      onvif_RelayLogicalStateToString(onvif_RelayLogicalState state);
ONVIF_API onvif_RelayLogicalState           onvif_StringToRelayLogicalState(const char * str);

ONVIF_API const char *                      onvif_DigitalIdleStateToString(onvif_DigitalIdleState state);
ONVIF_API onvif_DigitalIdleState            onvif_StringToDigitalIdleState(const char * str);

ONVIF_API const char *                      onvif_ParityBitToString(onvif_ParityBit type);
ONVIF_API onvif_ParityBit                   onvif_StringToParityBit(const char * str);

ONVIF_API const char *                      onvif_SerialPortTypeToString(onvif_SerialPortType type);
ONVIF_API onvif_SerialPortType              onvif_StringToSerialPortType(const char * str);

#ifdef __cplusplus
}
#endif

#endif	/* end of ONVIF_COMM_H */





