/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2010-2016, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#include "sys_inc.h"
#include "onvif.h"
#include "http.h"
#include "http_cln.h"
#include "onvif_cln.h" 
#include "soap_parser.h"


/***************************************************************************************/
#define DEF_REQ_TIMEOUT		6000


/***************************************************************************************/
void onvif_init_req(HTTPREQ * p_req, onvif_XAddr * p_xaddr)
{
    memset(p_req, 0, sizeof(HTTPREQ));
	
	strcpy(p_req->host, p_xaddr->host);
	p_req->port = p_xaddr->port;
	p_req->https = p_xaddr->https;
	
	if (p_xaddr->url[0] != '\0')
	{
	    strcpy(p_req->url, p_xaddr->url);
	}
	else
	{
	    strcpy(p_req->url, "/onvif/device_service");
	}
}

ONVIF_API void onvif_SetAuthInfo(ONVIF_DEVICE * p_dev, const char * user, const char * pass)
{
	strncpy(p_dev->username, user, sizeof(p_dev->username)-1);
	strncpy(p_dev->password, pass, sizeof(p_dev->password)-1);
}


/***************************************************************************************/
ONVIF_API BOOL onvif_GetCapabilities(ONVIF_DEVICE * p_dev, GetCapabilities_REQ * p_req, GetCapabilities_RES * p_res)
{
    HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetCapabilities, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetServices(ONVIF_DEVICE * p_dev, GetServices_REQ * p_req, GetServices_RES * p_res)
{
    HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetServices, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetDeviceInformation(ONVIF_DEVICE * p_dev, GetDeviceInformation_REQ * p_req, GetDeviceInformation_RES * p_res)
{
    HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetDeviceInformation, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetUsers(ONVIF_DEVICE * p_dev, GetUsers_REQ * p_req, GetUsers_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetUsers, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_CreateUsers(ONVIF_DEVICE * p_dev, CreateUsers_REQ * p_req, CreateUsers_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eCreateUsers, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_DeleteUsers(ONVIF_DEVICE * p_dev, DeleteUsers_REQ * p_req, DeleteUsers_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eDeleteUsers, p_dev, p_req, p_res);

}

ONVIF_API BOOL onvif_SetUser(ONVIF_DEVICE * p_dev, SetUser_REQ * p_req, SetUser_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetUser, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetRemoteUser(ONVIF_DEVICE * p_dev, GetRemoteUser_REQ * p_req, GetRemoteUser_RES * p_res)
{
    HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetRemoteUser, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_SetRemoteUser(ONVIF_DEVICE * p_dev, SetRemoteUser_REQ * p_req, SetRemoteUser_RES * p_res)
{
    HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetRemoteUser, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetNetworkInterfaces(ONVIF_DEVICE * p_dev, GetNetworkInterfaces_REQ * p_req, GetNetworkInterfaces_RES * p_res)
{
    HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetNetworkInterfaces, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_SetNetworkInterfaces(ONVIF_DEVICE * p_dev, SetNetworkInterfaces_REQ * p_req, SetNetworkInterfaces_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetNetworkInterfaces, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetNTP(ONVIF_DEVICE * p_dev, GetNTP_REQ * p_req, GetNTP_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetNTP, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_SetNTP(ONVIF_DEVICE * p_dev, SetNTP_REQ * p_req, SetNTP_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetNTP, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetHostname(ONVIF_DEVICE * p_dev, GetHostname_REQ * p_req, GetHostname_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetHostname, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_SetHostname(ONVIF_DEVICE * p_dev, SetHostname_REQ * p_req, SetHostname_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetHostname, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_SetHostnameFromDHCP(ONVIF_DEVICE * p_dev, SetHostnameFromDHCP_REQ * p_req, SetHostnameFromDHCP_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetHostnameFromDHCP, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetDNS(ONVIF_DEVICE * p_dev, GetDNS_REQ * p_req, GetDNS_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetDNS, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_SetDNS(ONVIF_DEVICE * p_dev, SetDNS_REQ * p_req, SetDNS_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetDNS, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetDynamicDNS(ONVIF_DEVICE * p_dev, GetDynamicDNS_REQ * p_req, GetDynamicDNS_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetDynamicDNS, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_SetDynamicDNS(ONVIF_DEVICE * p_dev, SetDynamicDNS_REQ * p_req, SetDynamicDNS_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetDynamicDNS, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetNetworkProtocols(ONVIF_DEVICE * p_dev, GetNetworkProtocols_REQ * p_req, GetNetworkProtocols_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetNetworkProtocols, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_SetNetworkProtocols(ONVIF_DEVICE * p_dev, SetNetworkProtocols_REQ * p_req, SetNetworkProtocols_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetNetworkProtocols, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetDiscoveryMode(ONVIF_DEVICE * p_dev, GetDiscoveryMode_REQ * p_req, GetDiscoveryMode_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetDiscoveryMode, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_SetDiscoveryMode(ONVIF_DEVICE * p_dev, SetDiscoveryMode_REQ * p_req, SetDiscoveryMode_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetDiscoveryMode, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetNetworkDefaultGateway(ONVIF_DEVICE * p_dev, GetNetworkDefaultGateway_REQ * p_req, GetNetworkDefaultGateway_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetNetworkDefaultGateway, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_SetNetworkDefaultGateway(ONVIF_DEVICE * p_dev, SetNetworkDefaultGateway_REQ * p_req, SetNetworkDefaultGateway_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetNetworkDefaultGateway, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetZeroConfiguration(ONVIF_DEVICE * p_dev, GetZeroConfiguration_REQ * p_req, GetZeroConfiguration_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetZeroConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_SetZeroConfiguration(ONVIF_DEVICE * p_dev, SetZeroConfiguration_REQ * p_req, SetZeroConfiguration_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetZeroConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetEndpointReference(ONVIF_DEVICE * p_dev, GetEndpointReference_REQ * p_req, GetEndpointReference_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetEndpointReference, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetSystemDateAndTime(ONVIF_DEVICE * p_dev, GetSystemDateAndTime_REQ * p_req, GetSystemDateAndTime_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetSystemDateAndTime, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_SetSystemDateAndTime(ONVIF_DEVICE * p_dev, SetSystemDateAndTime_REQ * p_req, SetSystemDateAndTime_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetSystemDateAndTime, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_SystemReboot(ONVIF_DEVICE * p_dev, SystemReboot_REQ * p_req, SystemReboot_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSystemReboot, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_SetSystemFactoryDefault(ONVIF_DEVICE * p_dev, SetSystemFactoryDefault_REQ * p_req, SetSystemFactoryDefault_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetSystemFactoryDefault, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetSystemLog(ONVIF_DEVICE * p_dev, GetSystemLog_REQ * p_req, GetSystemLog_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetSystemLog, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetScopes(ONVIF_DEVICE * p_dev, GetScopes_REQ * p_req, GetScopes_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetScopes, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_SetScopes(ONVIF_DEVICE * p_dev, SetScopes_REQ * p_req, SetScopes_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetScopes, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_AddScopes(ONVIF_DEVICE * p_dev, AddScopes_REQ * p_req, AddScopes_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eAddScopes, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_RemoveScopes(ONVIF_DEVICE * p_dev, RemoveScopes_REQ * p_req, RemoveScopes_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eRemoveScopes, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_StartFirmwareUpgrade(ONVIF_DEVICE * p_dev, StartFirmwareUpgrade_REQ * p_req, StartFirmwareUpgrade_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eStartFirmwareUpgrade, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetSystemUris(ONVIF_DEVICE * p_dev, GetSystemUris_REQ * p_req, GetSystemUris_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetSystemUris, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_StartSystemRestore(ONVIF_DEVICE * p_dev, StartSystemRestore_REQ * p_req, StartSystemRestore_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->binfo.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eStartSystemRestore, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetVideoSources(ONVIF_DEVICE * p_dev, GetVideoSources_REQ * p_req, GetVideoSources_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetVideoSources, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetAudioSources(ONVIF_DEVICE * p_dev, GetAudioSources_REQ * p_req, GetAudioSources_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetAudioSources, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_CreateProfile(ONVIF_DEVICE * p_dev, CreateProfile_REQ * p_req, CreateProfile_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eCreateProfile, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetProfile(ONVIF_DEVICE * p_dev, GetProfile_REQ * p_req, GetProfile_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetProfile, p_dev, p_req, p_res);
}


ONVIF_API BOOL onvif_GetProfiles(ONVIF_DEVICE * p_dev, GetProfiles_REQ * p_req, GetProfiles_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetProfiles, p_dev, p_req, p_res);    
}

ONVIF_API BOOL onvif_AddVideoEncoderConfiguration(ONVIF_DEVICE * p_dev, AddVideoEncoderConfiguration_REQ * p_req, AddVideoEncoderConfiguration_RES * p_res)	
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eAddVideoEncoderConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_AddVideoSourceConfiguration(ONVIF_DEVICE * p_dev, AddVideoSourceConfiguration_REQ * p_req, AddVideoSourceConfiguration_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eAddVideoSourceConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_AddAudioEncoderConfiguration(ONVIF_DEVICE * p_dev, AddAudioEncoderConfiguration_REQ * p_req, AddAudioEncoderConfiguration_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eAddAudioEncoderConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_AddAudioSourceConfiguration(ONVIF_DEVICE * p_dev, AddAudioSourceConfiguration_REQ * p_req, AddAudioSourceConfiguration_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eAddAudioSourceConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetVideoSourceModes(ONVIF_DEVICE * p_dev, GetVideoSourceModes_REQ * p_req, GetVideoSourceModes_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetVideoSourceModes, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_SetVideoSourceMode(ONVIF_DEVICE * p_dev, SetVideoSourceMode_REQ * p_req, SetVideoSourceMode_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetVideoSourceMode, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_AddPTZConfiguration(ONVIF_DEVICE * p_dev, AddPTZConfiguration_REQ * p_req, AddPTZConfiguration_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eAddPTZConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_RemoveVideoEncoderConfiguration(ONVIF_DEVICE * p_dev, RemoveVideoEncoderConfiguration_REQ * p_req, RemoveVideoEncoderConfiguration_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eRemoveVideoEncoderConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_RemoveVideoSourceConfiguration(ONVIF_DEVICE * p_dev, RemoveVideoSourceConfiguration_REQ * p_req, RemoveVideoSourceConfiguration_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eRemoveVideoSourceConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_RemoveAudioEncoderConfiguration(ONVIF_DEVICE * p_dev, RemoveAudioEncoderConfiguration_REQ * p_req, RemoveAudioEncoderConfiguration_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eRemoveAudioEncoderConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_RemoveAudioSourceConfiguration(ONVIF_DEVICE * p_dev, RemoveAudioSourceConfiguration_REQ * p_req, RemoveAudioSourceConfiguration_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eRemoveAudioSourceConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_RemovePTZConfiguration(ONVIF_DEVICE * p_dev, RemovePTZConfiguration_REQ * p_req, RemovePTZConfiguration_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eRemovePTZConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_DeleteProfile(ONVIF_DEVICE * p_dev, DeleteProfile_REQ * p_req, DeleteProfile_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eDeleteProfile, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetVideoSourceConfigurations(ONVIF_DEVICE * p_dev, GetVideoSourceConfigurations_REQ * p_req, GetVideoSourceConfigurations_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetVideoSourceConfigurations, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetVideoEncoderConfigurations(ONVIF_DEVICE * p_dev, GetVideoEncoderConfigurations_REQ * p_req, GetVideoEncoderConfigurations_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetVideoEncoderConfigurations, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetAudioSourceConfigurations(ONVIF_DEVICE * p_dev, GetAudioSourceConfigurations_REQ * p_req, GetAudioSourceConfigurations_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetAudioSourceConfigurations, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetAudioEncoderConfigurations(ONVIF_DEVICE * p_dev, GetAudioEncoderConfigurations_REQ * p_req, GetAudioEncoderConfigurations_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetAudioEncoderConfigurations, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetVideoSourceConfiguration(ONVIF_DEVICE * p_dev, GetVideoSourceConfiguration_REQ * p_req, GetVideoSourceConfiguration_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetVideoSourceConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetVideoEncoderConfiguration(ONVIF_DEVICE * p_dev, GetVideoEncoderConfiguration_REQ * p_req, GetVideoEncoderConfiguration_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetVideoEncoderConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetAudioSourceConfiguration(ONVIF_DEVICE * p_dev, GetAudioSourceConfiguration_REQ * p_req, GetAudioSourceConfiguration_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetAudioSourceConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetAudioEncoderConfiguration(ONVIF_DEVICE * p_dev, GetAudioEncoderConfiguration_REQ * p_req, GetAudioEncoderConfiguration_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetAudioEncoderConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_SetVideoSourceConfiguration(ONVIF_DEVICE * p_dev, SetVideoSourceConfiguration_REQ * p_req, SetVideoSourceConfiguration_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetVideoSourceConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_SetVideoEncoderConfiguration(ONVIF_DEVICE * p_dev, SetVideoEncoderConfiguration_REQ * p_req, SetVideoEncoderConfiguration_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetVideoEncoderConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_SetAudioSourceConfiguration(ONVIF_DEVICE * p_dev, SetAudioSourceConfiguration_REQ * p_req, SetAudioSourceConfiguration_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetAudioSourceConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_SetAudioEncoderConfiguration(ONVIF_DEVICE * p_dev, SetAudioEncoderConfiguration_REQ * p_req, SetAudioEncoderConfiguration_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetAudioEncoderConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetVideoSourceConfigurationOptions(ONVIF_DEVICE * p_dev, GetVideoSourceConfigurationOptions_REQ * p_req, GetVideoSourceConfigurationOptions_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetVideoSourceConfigurationOptions, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetVideoEncoderConfigurationOptions(ONVIF_DEVICE * p_dev, GetVideoEncoderConfigurationOptions_REQ * p_req, GetVideoEncoderConfigurationOptions_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetVideoEncoderConfigurationOptions, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetAudioSourceConfigurationOptions(ONVIF_DEVICE * p_dev, GetAudioSourceConfigurationOptions_REQ * p_req, GetAudioSourceConfigurationOptions_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetAudioSourceConfigurationOptions, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetAudioEncoderConfigurationOptions(ONVIF_DEVICE * p_dev, GetAudioEncoderConfigurationOptions_REQ * p_req, GetAudioEncoderConfigurationOptions_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetAudioEncoderConfigurationOptions, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetStreamUri(ONVIF_DEVICE * p_dev, GetStreamUri_REQ * p_req, GetStreamUri_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetStreamUri, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_SetSynchronizationPoint(ONVIF_DEVICE * p_dev, SetSynchronizationPoint_REQ * p_req, SetSynchronizationPoint_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

    return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetSynchronizationPoint, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetSnapshotUri(ONVIF_DEVICE * p_dev, GetSnapshotUri_REQ * p_req, GetSnapshotUri_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);
    
    return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetSnapshotUri, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetNodes(ONVIF_DEVICE * p_dev, GetNodes_REQ * p_req, GetNodes_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.ptz.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetNodes, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetNode(ONVIF_DEVICE * p_dev, GetNode_REQ * p_req, GetNode_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.ptz.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetNode, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetPresets(ONVIF_DEVICE * p_dev, GetPresets_REQ * p_req, GetPresets_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.ptz.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetPresets, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_SetPreset(ONVIF_DEVICE * p_dev, SetPreset_REQ * p_req, SetPreset_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.ptz.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetPreset, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_RemovePreset(ONVIF_DEVICE * p_dev, RemovePreset_REQ * p_req, RemovePreset_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.ptz.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eRemovePreset, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GotoPreset(ONVIF_DEVICE * p_dev, GotoPreset_REQ * p_req, GotoPreset_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.ptz.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGotoPreset, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GotoHomePosition(ONVIF_DEVICE * p_dev, GotoHomePosition_REQ * p_req, GotoHomePosition_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.ptz.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGotoHomePosition, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_SetHomePosition(ONVIF_DEVICE * p_dev, SetHomePosition_REQ * p_req, SetHomePosition_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.ptz.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetHomePosition, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetStatus(ONVIF_DEVICE * p_dev, GetStatus_REQ * p_req, GetStatus_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.ptz.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetStatus, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_ContinuousMove(ONVIF_DEVICE * p_dev, ContinuousMove_REQ * p_req, ContinuousMove_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.ptz.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eContinuousMove, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_RelativeMove(ONVIF_DEVICE * p_dev, RelativeMove_REQ * p_req, RelativeMove_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.ptz.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eRelativeMove, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_AbsoluteMove(ONVIF_DEVICE * p_dev, AbsoluteMove_REQ * p_req, AbsoluteMove_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.ptz.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eAbsoluteMove, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_PTZStop(ONVIF_DEVICE * p_dev, PTZStop_REQ * p_req, PTZStop_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.ptz.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, ePTZStop, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetConfigurations(ONVIF_DEVICE * p_dev, GetConfigurations_REQ * p_req, GetConfigurations_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.ptz.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetConfigurations, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetConfiguration(ONVIF_DEVICE * p_dev, GetConfiguration_REQ * p_req, GetConfiguration_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.ptz.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_SetConfiguration(ONVIF_DEVICE * p_dev, SetConfiguration_REQ * p_req, SetConfiguration_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.ptz.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetConfigurationOptions(ONVIF_DEVICE * p_dev, GetConfigurationOptions_REQ * p_req, GetConfigurationOptions_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.ptz.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetConfigurationOptions, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetPresetTours(ONVIF_DEVICE * p_dev, GetPresetTours_REQ * p_req, GetPresetTours_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.ptz.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetPresetTours, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetPresetTour(ONVIF_DEVICE * p_dev, GetPresetTour_REQ * p_req, GetPresetTour_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.ptz.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetPresetTour, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetPresetTourOptions(ONVIF_DEVICE * p_dev, GetPresetTourOptions_REQ * p_req, GetPresetTourOptions_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.ptz.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetPresetTourOptions, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_CreatePresetTour(ONVIF_DEVICE * p_dev, CreatePresetTour_REQ * p_req, CreatePresetTour_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.ptz.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eCreatePresetTour, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_ModifyPresetTour(ONVIF_DEVICE * p_dev, ModifyPresetTour_REQ * p_req, ModifyPresetTour_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.ptz.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eModifyPresetTour, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_OperatePresetTour(ONVIF_DEVICE * p_dev, OperatePresetTour_REQ * p_req, OperatePresetTour_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.ptz.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eOperatePresetTour, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_RemovePresetTour(ONVIF_DEVICE * p_dev, RemovePresetTour_REQ * p_req, RemovePresetTour_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.ptz.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eRemovePresetTour, p_dev, p_req, p_res);
}


ONVIF_API BOOL onvif_GetEventProperties(ONVIF_DEVICE * p_dev, GetEventProperties_REQ * p_req, GetEventProperties_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.events.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetEventProperties, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_Renew(ONVIF_DEVICE * p_dev, Renew_REQ * p_req, Renew_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.events.XAddr);

	onvif_XAddr xaddr;
	memset(&xaddr, 0, sizeof(xaddr));
	
    parse_XAddr(p_dev->events.producter_addr, &xaddr);
    strcpy(http_req.url, xaddr.url);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eRenew, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_Unsubscribe(ONVIF_DEVICE * p_dev, Unsubscribe_REQ * p_req, Unsubscribe_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.events.XAddr);

	onvif_XAddr xaddr;
	memset(&xaddr, 0, sizeof(xaddr));
	
    parse_XAddr(p_dev->events.producter_addr, &xaddr);
    strcpy(http_req.url, xaddr.url);
    
	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eUnsubscribe, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_Subscribe(ONVIF_DEVICE * p_dev, Subscribe_REQ * p_req, Subscribe_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.events.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSubscribe, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_CreatePullPointSubscription(ONVIF_DEVICE * p_dev, CreatePullPointSubscription_REQ * p_req, CreatePullPointSubscription_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.events.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eCreatePullPointSubscription, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_PullMessages(ONVIF_DEVICE * p_dev, PullMessages_REQ * p_req, PullMessages_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.events.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, ePullMessages, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetImagingSettings(ONVIF_DEVICE * p_dev, GetImagingSettings_REQ * p_req, GetImagingSettings_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.image.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetImagingSettings, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_SetImagingSettings(ONVIF_DEVICE * p_dev, SetImagingSettings_REQ * p_req, SetImagingSettings_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.image.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetImagingSettings, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetOptions(ONVIF_DEVICE * p_dev, GetOptions_REQ * p_req, GetOptions_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.image.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetOptions, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_img_Move(ONVIF_DEVICE * p_dev, img_Move_REQ * p_req, img_Move_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.image.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eimgMove, p_dev, p_req, p_res);
}


ONVIF_API BOOL onvif_img_Stop(ONVIF_DEVICE * p_dev, img_Stop_REQ * p_req, img_Stop_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.image.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eimgStop, p_dev, p_req, p_res);
}


ONVIF_API BOOL onvif_img_GetStatus(ONVIF_DEVICE * p_dev, img_GetStatus_REQ * p_req, img_GetStatus_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.image.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eimgGetStatus, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_img_GetMoveOptions(ONVIF_DEVICE * p_dev, img_GetMoveOptions_REQ * p_req, img_GetMoveOptions_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.image.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eimgGetMoveOptions, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetOSDs(ONVIF_DEVICE * p_dev, GetOSDs_REQ * p_req, GetOSDs_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetOSDs, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetOSD(ONVIF_DEVICE * p_dev, GetOSD_REQ * p_req, GetOSD_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetOSD, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_SetOSD(ONVIF_DEVICE * p_dev, SetOSD_REQ * p_req, SetOSD_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetOSD, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetOSDOptions(ONVIF_DEVICE * p_dev, GetOSDOptions_REQ * p_req, GetOSDOptions_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetOSDOptions, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_CreateOSD(ONVIF_DEVICE * p_dev, CreateOSD_REQ * p_req, CreateOSD_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eCreateOSD, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_DeleteOSD(ONVIF_DEVICE * p_dev, DeleteOSD_REQ * p_req, DeleteOSD_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eDeleteOSD, p_dev, p_req, p_res);
}


ONVIF_API BOOL onvif_GetVideoAnalyticsConfigurations(ONVIF_DEVICE * p_dev, GetVideoAnalyticsConfigurations_REQ * p_req, GetVideoAnalyticsConfigurations_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetVideoAnalyticsConfigurations, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_AddVideoAnalyticsConfiguration(ONVIF_DEVICE * p_dev, AddVideoAnalyticsConfiguration_REQ * p_req, AddVideoAnalyticsConfiguration_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eAddVideoAnalyticsConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetVideoAnalyticsConfiguration(ONVIF_DEVICE * p_dev, GetVideoAnalyticsConfiguration_REQ * p_req, GetVideoAnalyticsConfiguration_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetVideoAnalyticsConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_RemoveVideoAnalyticsConfiguration(ONVIF_DEVICE * p_dev, RemoveVideoAnalyticsConfiguration_REQ * p_req, RemoveVideoAnalyticsConfiguration_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eRemoveVideoAnalyticsConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_SetVideoAnalyticsConfiguration(ONVIF_DEVICE * p_dev, SetVideoAnalyticsConfiguration_REQ * p_req, SetVideoAnalyticsConfiguration_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->Capabilities.media.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetVideoAnalyticsConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetSupportedRules(ONVIF_DEVICE * p_dev, GetSupportedRules_REQ * p_req, GetSupportedRules_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->Capabilities.analytics.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetSupportedRules, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_CreateRules(ONVIF_DEVICE * p_dev, CreateRules_REQ * p_req, CreateRules_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->Capabilities.analytics.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eCreateRules, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_DeleteRules(ONVIF_DEVICE * p_dev, DeleteRules_REQ * p_req, DeleteRules_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->Capabilities.analytics.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eDeleteRules, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetRules(ONVIF_DEVICE * p_dev, GetRules_REQ * p_req, GetRules_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->Capabilities.analytics.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetRules, p_dev, p_req, p_res);
}
	
ONVIF_API BOOL onvif_ModifyRules(ONVIF_DEVICE * p_dev, ModifyRules_REQ * p_req, ModifyRules_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->Capabilities.analytics.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eModifyRules, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_CreateAnalyticsModules(ONVIF_DEVICE * p_dev, CreateAnalyticsModules_REQ * p_req, CreateAnalyticsModules_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->Capabilities.analytics.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eCreateAnalyticsModules, p_dev, p_req, p_res);
}	

ONVIF_API BOOL onvif_DeleteAnalyticsModules(ONVIF_DEVICE * p_dev, DeleteAnalyticsModules_REQ * p_req, DeleteAnalyticsModules_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->Capabilities.analytics.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eDeleteAnalyticsModules, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetAnalyticsModules(ONVIF_DEVICE * p_dev, GetAnalyticsModules_REQ * p_req, GetAnalyticsModules_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->Capabilities.analytics.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetAnalyticsModules, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_ModifyAnalyticsModules(ONVIF_DEVICE * p_dev, ModifyAnalyticsModules_REQ * p_req, ModifyAnalyticsModules_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->Capabilities.analytics.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eModifyAnalyticsModules, p_dev, p_req, p_res);
}

// ONVIF media 2 service interfaces

ONVIF_API BOOL onvif_tr2_GetVideoEncoderConfigurations(ONVIF_DEVICE * p_dev, tr2_GetVideoEncoderConfigurations_REQ * p_req, tr2_GetVideoEncoderConfigurations_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media2.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, etr2GetVideoEncoderConfigurations, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_tr2_GetVideoEncoderConfigurationOptions(ONVIF_DEVICE * p_dev, tr2_GetVideoEncoderConfigurationOptions_REQ * p_req, tr2_GetVideoEncoderConfigurationOptions_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media2.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, etr2GetVideoEncoderConfigurationOptions, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_tr2_SetVideoEncoderConfiguration(ONVIF_DEVICE * p_dev, tr2_SetVideoEncoderConfiguration_REQ * p_req, tr2_SetVideoEncoderConfiguration_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media2.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, etr2SetVideoEncoderConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_tr2_GetProfiles(ONVIF_DEVICE * p_dev, tr2_GetProfiles_REQ * p_req, tr2_GetProfiles_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media2.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, etr2GetProfiles, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_tr2_CreateProfile(ONVIF_DEVICE * p_dev, tr2_CreateProfile_REQ * p_req, tr2_CreateProfile_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media2.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, etr2CreateProfile, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_tr2_DeleteProfile(ONVIF_DEVICE * p_dev, tr2_DeleteProfile_REQ * p_req, tr2_DeleteProfile_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media2.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, etr2DeleteProfile, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_tr2_GetStreamUri(ONVIF_DEVICE * p_dev, tr2_GetStreamUri_REQ * p_req, tr2_GetStreamUri_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media2.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, etr2GetStreamUri, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_tr2_GetVideoSourceConfigurations(ONVIF_DEVICE * p_dev, tr2_GetVideoSourceConfigurations_REQ * p_req, tr2_GetVideoSourceConfigurations_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media2.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, etr2GetVideoSourceConfigurations, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_tr2_GetVideoSourceConfigurationOptions(ONVIF_DEVICE * p_dev, tr2_GetVideoSourceConfigurationOptions_REQ * p_req, tr2_GetVideoSourceConfigurationOptions_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media2.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, etr2GetVideoSourceConfigurationOptions, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_tr2_SetVideoSourceConfiguration(ONVIF_DEVICE * p_dev, tr2_SetVideoSourceConfiguration_REQ * p_req, tr2_SetVideoSourceConfiguration_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media2.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, etr2SetVideoSourceConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_tr2_SetSynchronizationPoint(ONVIF_DEVICE * p_dev, tr2_SetSynchronizationPoint_REQ * p_req, tr2_SetSynchronizationPoint_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media2.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, etr2SetSynchronizationPoint, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_tr2_GetMetadataConfigurations(ONVIF_DEVICE * p_dev, tr2_GetMetadataConfigurations_REQ * p_req, tr2_GetMetadataConfigurations_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media2.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, etr2GetMetadataConfigurations, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_tr2_GetMetadataConfigurationOptions(ONVIF_DEVICE * p_dev, tr2_GetMetadataConfigurationOptions_REQ * p_req, tr2_GetMetadataConfigurationOptions_RES * p_res)
{

	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media2.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, etr2GetMetadataConfigurationOptions, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_tr2_SetMetadataConfiguration(ONVIF_DEVICE * p_dev, tr2_SetMetadataConfiguration_REQ * p_req, tr2_SetMetadataConfiguration_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media2.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, etr2SetMetadataConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_tr2_GetAudioEncoderConfigurations(ONVIF_DEVICE * p_dev, tr2_GetAudioEncoderConfigurations_REQ * p_req, tr2_GetAudioEncoderConfigurations_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media2.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, etr2GetAudioEncoderConfigurations, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_tr2_GetAudioSourceConfigurations(ONVIF_DEVICE * p_dev, tr2_GetAudioSourceConfigurations_REQ * p_req, tr2_GetAudioSourceConfigurations_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media2.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, etr2GetAudioSourceConfigurations, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_tr2_GetAudioSourceConfigurationOptions(ONVIF_DEVICE * p_dev, tr2_GetAudioSourceConfigurationOptions_REQ * p_req, tr2_GetAudioSourceConfigurationOptions_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media2.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, etr2GetAudioSourceConfigurationOptions, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_tr2_SetAudioSourceConfiguration(ONVIF_DEVICE * p_dev, tr2_SetAudioSourceConfiguration_REQ * p_req, tr2_SetAudioSourceConfiguration_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media2.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, etr2SetAudioSourceConfiguration, p_dev, p_req, p_res);
}


ONVIF_API BOOL onvif_tr2_SetAudioEncoderConfiguration(ONVIF_DEVICE * p_dev, tr2_SetAudioEncoderConfiguration_REQ * p_req, tr2_SetAudioEncoderConfiguration_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media2.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, etr2SetAudioEncoderConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_tr2_GetAudioEncoderConfigurationOptions(ONVIF_DEVICE * p_dev, tr2_GetAudioEncoderConfigurationOptions_REQ * p_req, tr2_GetAudioEncoderConfigurationOptions_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media2.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, etr2GetAudioEncoderConfigurationOptions, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_tr2_AddConfiguration(ONVIF_DEVICE * p_dev, tr2_AddConfiguration_REQ * p_req, tr2_AddConfiguration_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media2.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, etr2AddConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_tr2_RemoveConfiguration(ONVIF_DEVICE * p_dev, tr2_RemoveConfiguration_REQ * p_req, tr2_RemoveConfiguration_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media2.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, etr2RemoveConfiguration, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_tr2_GetVideoEncoderInstances(ONVIF_DEVICE * p_dev, tr2_GetVideoEncoderInstances_REQ * p_req, tr2_GetVideoEncoderInstances_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.media2.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, etr2GetVideoEncoderInstances, p_dev, p_req, p_res);
}

#ifdef PROFILE_G_SUPPORT

// recording service interfaces
ONVIF_API BOOL onvif_CreateRecording(ONVIF_DEVICE * p_dev, CreateRecording_REQ * p_req, CreateRecording_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.recording.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eCreateRecording, p_dev, p_req, p_res);
}   

ONVIF_API BOOL onvif_DeleteRecording(ONVIF_DEVICE * p_dev, DeleteRecording_REQ * p_req, DeleteRecording_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.recording.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eDeleteRecording, p_dev, p_req, p_res);
} 
   
ONVIF_API BOOL onvif_GetRecordings(ONVIF_DEVICE * p_dev, GetRecordings_REQ * p_req, GetRecordings_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.recording.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetRecordings, p_dev, p_req, p_res);
} 
 
ONVIF_API BOOL onvif_SetRecordingConfiguration(ONVIF_DEVICE * p_dev, SetRecordingConfiguration_REQ * p_req, SetRecordingConfiguration_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.recording.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetRecordingConfiguration, p_dev, p_req, p_res);
} 
 
ONVIF_API BOOL onvif_GetRecordingConfiguration(ONVIF_DEVICE * p_dev, GetRecordingConfiguration_REQ * p_req, GetRecordingConfiguration_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.recording.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetRecordingConfiguration, p_dev, p_req, p_res);
} 
 
ONVIF_API BOOL onvif_GetRecordingOptions(ONVIF_DEVICE * p_dev, GetRecordingOptions_REQ * p_req, GetRecordingOptions_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.recording.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetRecordingOptions, p_dev, p_req, p_res);
} 
 
ONVIF_API BOOL onvif_CreateTrack(ONVIF_DEVICE * p_dev, CreateTrack_REQ * p_req, CreateTrack_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.recording.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eCreateTrack, p_dev, p_req, p_res);
} 
 
ONVIF_API BOOL onvif_DeleteTrack(ONVIF_DEVICE * p_dev, DeleteTrack_REQ * p_req, DeleteTrack_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.recording.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eDeleteTrack, p_dev, p_req, p_res);
} 
 
ONVIF_API BOOL onvif_GetTrackConfiguration(ONVIF_DEVICE * p_dev, GetTrackConfiguration_REQ * p_req, GetTrackConfiguration_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.recording.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetTrackConfiguration, p_dev, p_req, p_res);
} 
 
ONVIF_API BOOL onvif_SetTrackConfiguration(ONVIF_DEVICE * p_dev, SetTrackConfiguration_REQ * p_req, SetTrackConfiguration_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.recording.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetTrackConfiguration, p_dev, p_req, p_res);
} 
 
ONVIF_API BOOL onvif_CreateRecordingJob(ONVIF_DEVICE * p_dev, CreateRecordingJob_REQ * p_req, CreateRecordingJob_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.recording.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eCreateRecordingJob, p_dev, p_req, p_res);
} 
 
ONVIF_API BOOL onvif_DeleteRecordingJob(ONVIF_DEVICE * p_dev, DeleteRecordingJob_REQ * p_req, DeleteRecordingJob_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.recording.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eDeleteRecordingJob, p_dev, p_req, p_res);
} 
 
ONVIF_API BOOL onvif_GetRecordingJobs(ONVIF_DEVICE * p_dev, GetRecordingJobs_REQ * p_req, GetRecordingJobs_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.recording.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetRecordingJobs, p_dev, p_req, p_res);
} 
 
ONVIF_API BOOL onvif_SetRecordingJobConfiguration(ONVIF_DEVICE * p_dev, SetRecordingJobConfiguration_REQ * p_req, SetRecordingJobConfiguration_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.recording.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetRecordingJobConfiguration, p_dev, p_req, p_res);
} 
 
ONVIF_API BOOL onvif_GetRecordingJobConfiguration(ONVIF_DEVICE * p_dev, GetRecordingJobConfiguration_REQ * p_req, GetRecordingJobConfiguration_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.recording.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetRecordingJobConfiguration, p_dev, p_req, p_res);
} 
 
ONVIF_API BOOL onvif_SetRecordingJobMode(ONVIF_DEVICE * p_dev, SetRecordingJobMode_REQ * p_req, SetRecordingJobMode_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.recording.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eSetRecordingJobMode, p_dev, p_req, p_res);
} 
 
ONVIF_API BOOL onvif_GetRecordingJobState(ONVIF_DEVICE * p_dev, GetRecordingJobState_REQ * p_req, GetRecordingJobState_RES * p_res)
{
    HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.recording.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetRecordingJobState, p_dev, p_req, p_res);
} 

ONVIF_API BOOL onvif_GetReplayUri(ONVIF_DEVICE * p_dev, GetReplayUri_REQ * p_req, GetReplayUri_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.replay.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetReplayUri, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetRecordingSummary(ONVIF_DEVICE * p_dev, GetRecordingSummary_REQ * p_req, GetRecordingSummary_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.search.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetRecordingSummary, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetRecordingInformation(ONVIF_DEVICE * p_dev, GetRecordingInformation_REQ * p_req, GetRecordingInformation_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->Capabilities.search.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetRecordingInformation, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetMediaAttributes(ONVIF_DEVICE * p_dev, GetMediaAttributes_REQ * p_req, GetMediaAttributes_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->Capabilities.search.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetMediaAttributes, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_FindRecordings(ONVIF_DEVICE * p_dev, FindRecordings_REQ * p_req, FindRecordings_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->Capabilities.search.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eFindRecordings, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetRecordingSearchResults(ONVIF_DEVICE * p_dev, GetRecordingSearchResults_REQ * p_req, GetRecordingSearchResults_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->Capabilities.search.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetRecordingSearchResults, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_FindEvents(ONVIF_DEVICE * p_dev, FindEvents_REQ * p_req, FindEvents_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->Capabilities.search.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eFindEvents, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetEventSearchResults(ONVIF_DEVICE * p_dev, GetEventSearchResults_REQ * p_req, GetEventSearchResults_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->Capabilities.search.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetEventSearchResults, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetSearchState(ONVIF_DEVICE * p_dev, GetSearchState_REQ * p_req, GetSearchState_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->Capabilities.search.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetSearchState, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_EndSearch(ONVIF_DEVICE * p_dev, EndSearch_REQ * p_req, EndSearch_RES * p_res)
{
	HTTPREQ http_req;
	onvif_init_req(&http_req, &p_dev->Capabilities.search.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eEndSearch, p_dev, p_req, p_res);
}

#endif // end of PROFILE_G_SUPPORT

#ifdef PROFILE_C_SUPPORT

ONVIF_API BOOL onvif_GetAccessPointInfoList(ONVIF_DEVICE * p_dev, GetAccessPointInfoList_REQ * p_req, GetAccessPointInfoList_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.accesscontrol.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetAccessPointInfoList, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetAccessPointInfo(ONVIF_DEVICE * p_dev, GetAccessPointInfo_REQ * p_req, GetAccessPointInfo_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.accesscontrol.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetAccessPointInfo, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetDoorInfoList(ONVIF_DEVICE * p_dev, GetDoorInfoList_REQ * p_req, GetDoorInfoList_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.doorcontrol.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetDoorInfoList, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetDoorInfo(ONVIF_DEVICE * p_dev, GetDoorInfo_REQ * p_req, GetDoorInfo_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.doorcontrol.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetDoorInfo, p_dev, p_req, p_res);
}

ONVIF_API BOOL onvif_GetAreaInfoList(ONVIF_DEVICE * p_dev, GetAreaInfoList_REQ * p_req, GetAreaInfoList_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.accesscontrol.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetAreaInfoList, p_dev, p_req, p_res);
}
  
ONVIF_API BOOL onvif_GetAreaInfo(ONVIF_DEVICE * p_dev, GetAreaInfo_REQ * p_req, GetAreaInfo_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.accesscontrol.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetAreaInfo, p_dev, p_req, p_res);
}
  
ONVIF_API BOOL onvif_GetAccessPointState(ONVIF_DEVICE * p_dev, GetAccessPointState_REQ * p_req, GetAccessPointState_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.accesscontrol.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetAccessPointState, p_dev, p_req, p_res);
}
  
ONVIF_API BOOL onvif_GetDoorState(ONVIF_DEVICE * p_dev, GetDoorState_REQ * p_req, GetDoorState_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.doorcontrol.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eGetDoorState, p_dev, p_req, p_res);
}
  
ONVIF_API BOOL onvif_AccessDoor(ONVIF_DEVICE * p_dev, AccessDoor_REQ * p_req, AccessDoor_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.doorcontrol.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eAccessDoor, p_dev, p_req, p_res);
}
  
ONVIF_API BOOL onvif_LockDoor(ONVIF_DEVICE * p_dev, LockDoor_REQ * p_req, LockDoor_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.doorcontrol.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eLockDoor, p_dev, p_req, p_res);
}
  
ONVIF_API BOOL onvif_UnlockDoor(ONVIF_DEVICE * p_dev, UnlockDoor_REQ * p_req, UnlockDoor_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.doorcontrol.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eUnlockDoor, p_dev, p_req, p_res);
}
  
ONVIF_API BOOL onvif_DoubleLockDoor(ONVIF_DEVICE * p_dev, DoubleLockDoor_REQ * p_req, DoubleLockDoor_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.doorcontrol.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eDoubleLockDoor, p_dev, p_req, p_res);
}
  
ONVIF_API BOOL onvif_BlockDoor(ONVIF_DEVICE * p_dev, BlockDoor_REQ * p_req, BlockDoor_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.doorcontrol.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eBlockDoor, p_dev, p_req, p_res);
}
  
ONVIF_API BOOL onvif_LockDownDoor(ONVIF_DEVICE * p_dev, LockDownDoor_REQ * p_req, LockDownDoor_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.doorcontrol.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eLockDownDoor, p_dev, p_req, p_res);
}
  
ONVIF_API BOOL onvif_LockDownReleaseDoor(ONVIF_DEVICE * p_dev, LockDownReleaseDoor_REQ * p_req, LockDownReleaseDoor_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.doorcontrol.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eLockDownReleaseDoor, p_dev, p_req, p_res);
}
  
ONVIF_API BOOL onvif_LockOpenDoor(ONVIF_DEVICE * p_dev, LockOpenDoor_REQ * p_req, LockOpenDoor_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.doorcontrol.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eLockOpenDoor, p_dev, p_req, p_res);
}
  
ONVIF_API BOOL onvif_LockOpenReleaseDoor(ONVIF_DEVICE * p_dev, LockOpenReleaseDoor_REQ * p_req, LockOpenReleaseDoor_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.doorcontrol.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eLockOpenReleaseDoor, p_dev, p_req, p_res);
}
  
ONVIF_API BOOL onvif_EnableAccessPoint(ONVIF_DEVICE * p_dev, EnableAccessPoint_REQ * p_req, EnableAccessPoint_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.accesscontrol.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eEnableAccessPoint, p_dev, p_req, p_res);
}
  
ONVIF_API BOOL onvif_DisableAccessPoint(ONVIF_DEVICE * p_dev, DisableAccessPoint_REQ * p_req, DisableAccessPoint_RES * p_res)
{
	HTTPREQ http_req;
    onvif_init_req(&http_req, &p_dev->Capabilities.accesscontrol.XAddr);

	return http_onvif_trans(&http_req, DEF_REQ_TIMEOUT, eDisableAccessPoint, p_dev, p_req, p_res);
}
	  

#endif // end of PROFILE_C_SUPPORT


