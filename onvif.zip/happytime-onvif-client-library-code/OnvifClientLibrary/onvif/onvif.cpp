/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2010-2016, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#include "sys_inc.h"
#include "onvif.h"
#include "onvif_api.h"


ONVIF_API ONVIF_NetworkInterface * onvif_add_NetworkInterface(ONVIF_NetworkInterface ** p_net_inf)
{
	ONVIF_NetworkInterface * p_tmp;
	ONVIF_NetworkInterface * p_new_net_inf = (ONVIF_NetworkInterface *) malloc(sizeof(ONVIF_NetworkInterface));
	if (NULL == p_new_net_inf)
	{
		return NULL;
	}

	memset(p_new_net_inf, 0, sizeof(ONVIF_NetworkInterface));

	p_tmp = *p_net_inf;
	if (NULL == p_tmp)
	{
		*p_net_inf = p_new_net_inf;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_net_inf;
	}
	
	return p_new_net_inf;
}

ONVIF_API void onvif_free_NetworkInterfaces(ONVIF_NetworkInterface ** p_net_inf)
{
	ONVIF_NetworkInterface * p_next;
	ONVIF_NetworkInterface * p_tmp = *p_net_inf;

	while (p_tmp)
	{
		p_next = p_tmp->next;

		free(p_tmp);
		p_tmp = p_next;
	}

	*p_net_inf = NULL;
}

ONVIF_API ONVIF_VideoSource * onvif_add_VideoSource(ONVIF_VideoSource ** p_v_src)
{
	ONVIF_VideoSource * p_tmp;
    ONVIF_VideoSource * p_new_v_src = (ONVIF_VideoSource *) malloc(sizeof(ONVIF_VideoSource));
	if (NULL == p_new_v_src)
	{
		return NULL;
	}

	memset(p_new_v_src, 0, sizeof(ONVIF_VideoSource));

	p_tmp = *p_v_src;
	if (NULL == p_tmp)
	{
		*p_v_src = p_new_v_src;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_v_src;
	}
	
	return p_new_v_src;
}

ONVIF_API void onvif_free_VideoSources(ONVIF_VideoSource ** p_v_src)
{
    ONVIF_VideoSource * p_next;
	ONVIF_VideoSource * p_tmp = *p_v_src;

	while (p_tmp)
	{
		p_next = p_tmp->next;

		free(p_tmp);
		p_tmp = p_next;
	}

	*p_v_src = NULL;
}

ONVIF_API ONVIF_VideoSource * onvif_find_VideoSource(ONVIF_DEVICE * p_dev, const char * token)
{
    ONVIF_VideoSource * p_v_src = p_dev->video_src;
    
    while (p_v_src)
	{
	    if (strcmp(p_v_src->VideoSource.token, token) == 0)
	    {
	        break;
	    }
	    
		p_v_src = p_v_src->next;
	}

	return p_v_src;
}

ONVIF_API ONVIF_VideoSource * onvif_get_cur_VideoSource(ONVIF_DEVICE * p_dev)
{
	ONVIF_VideoSource * p_v_src;
    ONVIF_Profile * p_profile = p_dev->curProfile;	
	if (NULL == p_profile)
	{
		p_profile = p_dev->profiles;
	}
	
	if (NULL == p_profile || NULL == p_profile->video_src_cfg)
	{
		return NULL;
	}

	p_v_src = onvif_find_VideoSource(p_dev, p_profile->video_src_cfg->Configuration.SourceToken);
	if (NULL == p_v_src)
	{
		return NULL;
	}

	return p_v_src;
}

ONVIF_API ONVIF_VideoSourceMode * onvif_add_VideoSourceMode(ONVIF_VideoSourceMode ** p_v_src_mode)
{
	ONVIF_VideoSourceMode * p_tmp;
    ONVIF_VideoSourceMode * p_new_v_src_mode = (ONVIF_VideoSourceMode *) malloc(sizeof(ONVIF_VideoSourceMode));
	if (NULL == p_new_v_src_mode)
	{
		return NULL;
	}

	memset(p_new_v_src_mode, 0, sizeof(ONVIF_VideoSourceMode));

	p_tmp = *p_v_src_mode;
	if (NULL == p_tmp)
	{
		*p_v_src_mode = p_new_v_src_mode;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_v_src_mode;
	}
	
	return p_new_v_src_mode;
}

ONVIF_API void onvif_free_VideoSourceModes(ONVIF_VideoSourceMode ** p_v_src_mode)
{
	ONVIF_VideoSourceMode * p_next;
	ONVIF_VideoSourceMode * p_tmp = *p_v_src_mode;

	while (p_tmp)
	{
		p_next = p_tmp->next;

		free(p_tmp);
		p_tmp = p_next;
	}

	*p_v_src_mode = NULL;
}

ONVIF_API ONVIF_AudioSource * onvif_add_AudioSource(ONVIF_AudioSource ** p_a_src)
{
	ONVIF_AudioSource * p_tmp;
    ONVIF_AudioSource * p_new_a_src = (ONVIF_AudioSource *) malloc(sizeof(ONVIF_AudioSource));
	if (NULL == p_new_a_src)
	{
		return NULL;
	}

	memset(p_new_a_src, 0, sizeof(ONVIF_AudioSource));

	p_tmp = *p_a_src;
	if (NULL == p_tmp)
	{
		*p_a_src = p_new_a_src;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_a_src;
	}
	
	return p_new_a_src;
}

ONVIF_API void onvif_free_AudioSources(ONVIF_AudioSource ** p_a_src)
{
    ONVIF_AudioSource * p_next;
	ONVIF_AudioSource * p_tmp = *p_a_src;

	while (p_tmp)
	{
		p_next = p_tmp->next;

		free(p_tmp);
		p_tmp = p_next;
	}

	*p_a_src = NULL;
}

ONVIF_API ONVIF_AudioSource * onvif_find_AudioSource(ONVIF_DEVICE * p_dev, const char * token)
{
    ONVIF_AudioSource * p_a_src = p_dev->audio_src;
    
    while (p_a_src)
	{
		if (strcmp(p_a_src->AudioSource.token, token) == 0)
	    {
	        break;
	    }
	    
		p_a_src = p_a_src->next;
	}

	return p_a_src;
}

ONVIF_API ONVIF_VideoSourceConfiguration * onvif_add_VideoSourceConfiguration(ONVIF_VideoSourceConfiguration ** p_v_src_cfg)
{
	ONVIF_VideoSourceConfiguration * p_tmp;
	ONVIF_VideoSourceConfiguration * p_new_v_src_cfg = (ONVIF_VideoSourceConfiguration *) malloc(sizeof(ONVIF_VideoSourceConfiguration));
	if (NULL == p_new_v_src_cfg)
	{
		return NULL;
	}

	memset(p_new_v_src_cfg, 0, sizeof(ONVIF_VideoSourceConfiguration));

	p_tmp = *p_v_src_cfg;
	if (NULL == p_tmp)
	{
		*p_v_src_cfg = p_new_v_src_cfg;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_v_src_cfg;
	}
	
	return p_new_v_src_cfg;
}

ONVIF_API void onvif_free_VideoSourceConfigurations(ONVIF_VideoSourceConfiguration ** p_v_src_cfg)
{
	ONVIF_VideoSourceConfiguration * p_next;
	ONVIF_VideoSourceConfiguration * p_tmp = *p_v_src_cfg;

	while (p_tmp)
	{
		p_next = p_tmp->next;

		free(p_tmp);
		p_tmp = p_next;
	}

	*p_v_src_cfg = NULL;
}

ONVIF_API ONVIF_VideoSourceConfiguration * onvif_find_VideoSourceConfiguration(ONVIF_DEVICE * p_dev, const char * token)
{
    ONVIF_VideoSourceConfiguration * p_v_src_cfg = p_dev->video_src_cfg;
    
    while (p_v_src_cfg)
	{
	    if (strcmp(p_v_src_cfg->Configuration.token, token) == 0)
	    {
	        break;
	    }
	    
		p_v_src_cfg = p_v_src_cfg->next;
	}

	return p_v_src_cfg;
}

ONVIF_API ONVIF_AudioSourceConfiguration * onvif_add_AudioSourceConfiguration(ONVIF_AudioSourceConfiguration ** p_a_src_cfg)
{
	ONVIF_AudioSourceConfiguration * p_tmp;
	ONVIF_AudioSourceConfiguration * p_new_a_src_cfg = (ONVIF_AudioSourceConfiguration *) malloc(sizeof(ONVIF_AudioSourceConfiguration));
	if (NULL == p_new_a_src_cfg)
	{
		return NULL;
	}

	memset(p_new_a_src_cfg, 0, sizeof(ONVIF_AudioSourceConfiguration));

	p_tmp = *p_a_src_cfg;
	if (NULL == p_tmp)
	{
		*p_a_src_cfg = p_new_a_src_cfg;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_a_src_cfg;
	}
	
	return p_new_a_src_cfg;
}

ONVIF_API void onvif_free_AudioSourceConfigurations(ONVIF_AudioSourceConfiguration ** p_a_src_cfg)
{
	ONVIF_AudioSourceConfiguration * p_next;
	ONVIF_AudioSourceConfiguration * p_tmp = *p_a_src_cfg;

	while (p_tmp)
	{
		p_next = p_tmp->next;

		free(p_tmp);
		p_tmp = p_next;
	}

	*p_a_src_cfg = NULL;
}

ONVIF_API ONVIF_AudioSourceConfiguration * onvif_find_AudioSourceConfiguration(ONVIF_DEVICE * p_dev, const char * token)
{
    ONVIF_AudioSourceConfiguration * p_a_src_cfg = p_dev->audio_src_cfg;
    
    while (p_a_src_cfg)
	{
	    if (strcmp(p_a_src_cfg->Configuration.token, token) == 0)
	    {
	        break;
	    }
	    
		p_a_src_cfg = p_a_src_cfg->next;
	}

	return p_a_src_cfg;
}

ONVIF_API ONVIF_VideoEncoderConfiguration * onvif_add_VideoEncoderConfiguration(ONVIF_VideoEncoderConfiguration ** p_v_enc)
{
	ONVIF_VideoEncoderConfiguration * p_tmp;
	ONVIF_VideoEncoderConfiguration * p_new_v_enc = (ONVIF_VideoEncoderConfiguration *) malloc(sizeof(ONVIF_VideoEncoderConfiguration));
	if (NULL == p_new_v_enc)
	{
		return NULL;
	}

	memset(p_new_v_enc, 0, sizeof(ONVIF_VideoEncoderConfiguration));

	p_tmp = *p_v_enc;
	if (NULL == p_tmp)
	{
		*p_v_enc = p_new_v_enc;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_v_enc;
	}
	
	return p_new_v_enc;
}

ONVIF_API void onvif_free_VideoEncoderConfigurations(ONVIF_VideoEncoderConfiguration ** p_v_enc)
{
	ONVIF_VideoEncoderConfiguration * p_next;
	ONVIF_VideoEncoderConfiguration * p_tmp = *p_v_enc;

	while (p_tmp)
	{
		p_next = p_tmp->next;

		free(p_tmp);
		p_tmp = p_next;
	}

	*p_v_enc = NULL;
}

ONVIF_API ONVIF_VideoEncoderConfiguration * onvif_find_VideoEncoderConfiguration(ONVIF_DEVICE * p_dev, const char * token)
{
    ONVIF_VideoEncoderConfiguration * p_v_enc = p_dev->video_enc;
    
    while (p_v_enc)
	{
	    if (strcmp(p_v_enc->Configuration.token, token) == 0)
	    {
	        break;
	    }
	    
		p_v_enc = p_v_enc->next;
	}

	return p_v_enc;
}

ONVIF_API ONVIF_AudioEncoderConfiguration * onvif_add_AudioEncoderConfiguration(ONVIF_AudioEncoderConfiguration ** p_a_enc)
{
	ONVIF_AudioEncoderConfiguration * p_tmp;
	ONVIF_AudioEncoderConfiguration * p_new_a_enc = (ONVIF_AudioEncoderConfiguration *) malloc(sizeof(ONVIF_AudioEncoderConfiguration));
	if (NULL == p_new_a_enc)
	{
		return NULL;
	}

	memset(p_new_a_enc, 0, sizeof(ONVIF_AudioEncoderConfiguration));

	p_tmp = *p_a_enc;
	if (NULL == p_tmp)
	{
		*p_a_enc = p_new_a_enc;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_a_enc;
	}
	
	return p_new_a_enc;
}

ONVIF_API void onvif_free_AudioEncoderConfigurations(ONVIF_AudioEncoderConfiguration ** p_a_enc)
{
	ONVIF_AudioEncoderConfiguration * p_next;
	ONVIF_AudioEncoderConfiguration * p_tmp = *p_a_enc;

	while (p_tmp)
	{
		p_next = p_tmp->next;

		free(p_tmp);
		p_tmp = p_next;
	}

	*p_a_enc = NULL;
}

ONVIF_API ONVIF_AudioEncoderConfiguration * onvif_find_AudioEncoderConfiguration(ONVIF_DEVICE * p_dev, const char * token)
{
    ONVIF_AudioEncoderConfiguration * p_a_enc = p_dev->audio_enc;
    
    while (p_a_enc)
	{
	    if (strcmp(p_a_enc->Configuration.token, token) == 0)
	    {
	        break;
	    }
	    
		p_a_enc = p_a_enc->next;
	}

	return p_a_enc;
}

ONVIF_API ONVIF_MetadataConfiguration * onvif_add_MetadataConfiguration(ONVIF_MetadataConfiguration ** p_cfg)
{
	ONVIF_MetadataConfiguration * p_tmp;
	ONVIF_MetadataConfiguration * p_new_cfg = (ONVIF_MetadataConfiguration *) malloc(sizeof(ONVIF_MetadataConfiguration));
	if (NULL == p_new_cfg)
	{
		return NULL;
	}

	memset(p_new_cfg, 0, sizeof(ONVIF_MetadataConfiguration));

	p_tmp = *p_cfg;
	if (NULL == p_tmp)
	{
		*p_cfg = p_new_cfg;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_cfg;
	}
	
	return p_new_cfg;
}

ONVIF_API void onvif_free_MetadataConfigurations(ONVIF_MetadataConfiguration ** p_cfg)
{
	ONVIF_MetadataConfiguration * p_next;
	ONVIF_MetadataConfiguration * p_tmp = *p_cfg;

	while (p_tmp)
	{
		p_next = p_tmp->next;

		free(p_tmp);
		p_tmp = p_next;
	}

	*p_cfg = NULL;
}

ONVIF_API ONVIF_MetadataConfiguration * onvif_find_MetadataConfiguration(ONVIF_MetadataConfiguration * p_cfg, const char * token)
{
	ONVIF_MetadataConfiguration * p_item = p_cfg;
    
    while (p_item)
	{
	    if (strcmp(p_item->Configuration.token, token) == 0)
	    {
	        break;
	    }
	    
		p_item = p_item->next;
	}

	return p_item;
}

ONVIF_API ONVIF_VideoEncoder2Configuration * onvif_add_VideoEncoder2Configuration(ONVIF_VideoEncoder2Configuration ** p_v_enc)
{
	ONVIF_VideoEncoder2Configuration * p_tmp;
	ONVIF_VideoEncoder2Configuration * p_new_v_enc = (ONVIF_VideoEncoder2Configuration *) malloc(sizeof(ONVIF_VideoEncoder2Configuration));
	if (NULL == p_new_v_enc)
	{
		return NULL;
	}

	memset(p_new_v_enc, 0, sizeof(ONVIF_VideoEncoder2Configuration));

	p_tmp = *p_v_enc;
	if (NULL == p_tmp)
	{
		*p_v_enc = p_new_v_enc;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_v_enc;
	}
	
	return p_new_v_enc;
}

ONVIF_API void onvif_free_VideoEncoder2Configurations(ONVIF_VideoEncoder2Configuration ** p_v_enc)
{
	ONVIF_VideoEncoder2Configuration * p_next;
	ONVIF_VideoEncoder2Configuration * p_tmp = *p_v_enc;

	while (p_tmp)
	{
		p_next = p_tmp->next;

		free(p_tmp);
		p_tmp = p_next;
	}

	*p_v_enc = NULL;
}

ONVIF_API ONVIF_VideoEncoder2Configuration * onvif_find_VideoEncoder2Configuration(ONVIF_VideoEncoder2Configuration * p_v_enc, const char * token)
{
	ONVIF_VideoEncoder2Configuration * p_item = p_v_enc;
    
    while (p_item)
	{
	    if (strcmp(p_item->Configuration.token, token) == 0)
	    {
	        break;
	    }
	    
		p_item = p_item->next;
	}

	return p_item;
}

ONVIF_API ONVIF_VideoEncoder2ConfigurationOptions * onvif_add_VideoEncoder2ConfigurationOptions(ONVIF_VideoEncoder2ConfigurationOptions ** p_options)
{
    ONVIF_VideoEncoder2ConfigurationOptions * p_tmp;
	ONVIF_VideoEncoder2ConfigurationOptions * p_new_options = (ONVIF_VideoEncoder2ConfigurationOptions *) malloc(sizeof(ONVIF_VideoEncoder2ConfigurationOptions));
	if (NULL == p_new_options)
	{
		return NULL;
	}

	memset(p_new_options, 0, sizeof(ONVIF_VideoEncoder2ConfigurationOptions));

	p_tmp = *p_options;
	if (NULL == p_tmp)
	{
		*p_options = p_new_options;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_options;
	}
	
	return p_new_options;
}

ONVIF_API void onvif_free_VideoEncoder2ConfigurationOptions(ONVIF_VideoEncoder2ConfigurationOptions ** p_options)
{
    ONVIF_VideoEncoder2ConfigurationOptions * p_next;
	ONVIF_VideoEncoder2ConfigurationOptions * p_tmp = *p_options;

	while (p_tmp)
	{
		p_next = p_tmp->next;

		free(p_tmp);
		p_tmp = p_next;
	}

	*p_options = NULL;
}

ONVIF_API ONVIF_VideoEncoder2ConfigurationOptions * onvif_find_VideoEncoder2ConfigurationOptions(ONVIF_VideoEncoder2ConfigurationOptions * p_options, const char * encoding)
{
    ONVIF_VideoEncoder2ConfigurationOptions * p_option = p_options;
    
    while (p_option)
	{
	    if (strcmp(p_option->Options.Encoding, encoding) == 0)
	    {
	        break;
	    }
	    
		p_option = p_option->next;
	}

	return p_option;
}

ONVIF_API ONVIF_AudioEncoder2Configuration * onvif_add_AudioEncoder2Configuration(ONVIF_AudioEncoder2Configuration ** p_cfg)
{
	ONVIF_AudioEncoder2Configuration * p_tmp;
	ONVIF_AudioEncoder2Configuration * p_new_cfg = (ONVIF_AudioEncoder2Configuration *) malloc(sizeof(ONVIF_AudioEncoder2Configuration));
	if (NULL == p_new_cfg)
	{
		return NULL;
	}

	memset(p_new_cfg, 0, sizeof(ONVIF_AudioEncoder2Configuration));

	p_tmp = *p_cfg;
	if (NULL == p_tmp)
	{
		*p_cfg = p_new_cfg;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_cfg;
	}
	
	return p_new_cfg;
}

ONVIF_API void onvif_free_AudioEncoder2Configurations(ONVIF_AudioEncoder2Configuration ** p_cfg)
{
	ONVIF_AudioEncoder2Configuration * p_next;
	ONVIF_AudioEncoder2Configuration * p_tmp = *p_cfg;

	while (p_tmp)
	{
		p_next = p_tmp->next;

		free(p_tmp);
		p_tmp = p_next;
	}

	*p_cfg = NULL;
}

ONVIF_API ONVIF_AudioEncoder2Configuration * onvif_find_AudioEncoder2Configuration(ONVIF_AudioEncoder2Configuration * p_cfg, const char * token)
{
	ONVIF_AudioEncoder2Configuration * p_item = p_cfg;
    
    while (p_item)
	{
	    if (strcmp(p_item->Configuration.token, token) == 0)
	    {
	        break;
	    }
	    
		p_item = p_item->next;
	}

	return p_item;
}

ONVIF_API ONVIF_AudioEncoder2ConfigurationOptions * onvif_add_AudioEncoder2ConfigurationOptions(ONVIF_AudioEncoder2ConfigurationOptions ** p_options)
{
    ONVIF_AudioEncoder2ConfigurationOptions * p_tmp;
	ONVIF_AudioEncoder2ConfigurationOptions * p_new_options = (ONVIF_AudioEncoder2ConfigurationOptions *) malloc(sizeof(ONVIF_AudioEncoder2ConfigurationOptions));
	if (NULL == p_new_options)
	{
		return NULL;
	}

	memset(p_new_options, 0, sizeof(ONVIF_AudioEncoder2ConfigurationOptions));

	p_tmp = *p_options;
	if (NULL == p_tmp)
	{
		*p_options = p_new_options;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_options;
	}
	
	return p_new_options;
}

ONVIF_API void onvif_free_AudioEncoder2ConfigurationOptions(ONVIF_AudioEncoder2ConfigurationOptions ** p_options)
{
    ONVIF_AudioEncoder2ConfigurationOptions * p_next;
	ONVIF_AudioEncoder2ConfigurationOptions * p_tmp = *p_options;

	while (p_tmp)
	{
		p_next = p_tmp->next;

		free(p_tmp);
		p_tmp = p_next;
	}

	*p_options = NULL;
}

ONVIF_API ONVIF_AudioEncoder2ConfigurationOptions * onvif_find_AudioEncoder2ConfigurationOptions(ONVIF_AudioEncoder2ConfigurationOptions * p_options, const char * encoding)
{
    ONVIF_AudioEncoder2ConfigurationOptions * p_option = p_options;
    
    while (p_option)
	{
	    if (strcmp(p_option->Options.Encoding, encoding) == 0)
	    {
	        break;
	    }
	    
		p_option = p_option->next;
	}

	return p_option;
}

ONVIF_API ONVIF_Profile * onvif_add_Profile(ONVIF_Profile ** p_profile)
{
	ONVIF_Profile * p_tmp;
    ONVIF_Profile * p_new_profile = (ONVIF_Profile *) malloc(sizeof(ONVIF_Profile));
	if (NULL == p_new_profile)
	{
		return NULL;
	}

	memset(p_new_profile, 0, sizeof(ONVIF_Profile));

	p_tmp = *p_profile;
	if (NULL == p_tmp)
	{
		*p_profile = p_new_profile;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_profile;
	}
	
	return p_new_profile;
}

ONVIF_API void onvif_free_Profile(ONVIF_Profile * p_profile)
{
	if (NULL == p_profile)
	{
		return;
	}
	
	if (p_profile->video_src_cfg)
    {
        onvif_free_VideoSourceConfigurations(&p_profile->video_src_cfg);
    }

    if (p_profile->video_enc)
    {
        onvif_free_VideoEncoderConfigurations(&p_profile->video_enc);
    }

    if (p_profile->audio_src_cfg)
    {
        onvif_free_AudioSourceConfigurations(&p_profile->audio_src_cfg);
    }

    if (p_profile->audio_enc)
    {
        onvif_free_AudioEncoderConfigurations(&p_profile->audio_enc);
    }

    if (p_profile->ptz_node)
    {
        onvif_free_PTZNodes(&p_profile->ptz_node);
    }

    if (p_profile->ptz_cfg)
    {
        onvif_free_PTZConfigurations(&p_profile->ptz_cfg);
    }

    if (p_profile->va_cfg)
    {
        onvif_free_VideoAnalyticsConfigurations(&p_profile->va_cfg);
    }
}

ONVIF_API void onvif_free_Profiles(ONVIF_Profile ** p_profile)
{
	ONVIF_Profile * p_next;
	ONVIF_Profile * p_tmp = *p_profile;

	while (p_tmp)
	{
		p_next = p_tmp->next;

        onvif_free_Profile(p_tmp);
        
		free(p_tmp);
		p_tmp = p_next;
	}

	*p_profile = NULL;
}

ONVIF_API ONVIF_Profile * onvif_find_Profile(ONVIF_DEVICE * p_dev, const char * token)
{
    ONVIF_Profile * p_profile = p_dev->profiles;
    
    while (p_profile)
	{
	    if (strcmp(p_profile->token, token) == 0)
	    {
	        break;
	    }
	    
		p_profile = p_profile->next;
	}

	return p_profile;
}

ONVIF_API ONVIF_MediaProfile * onvif_add_MediaProfile(ONVIF_MediaProfile ** p_profile)
{
	ONVIF_MediaProfile * p_tmp;
    ONVIF_MediaProfile * p_new_profile = (ONVIF_MediaProfile *) malloc(sizeof(ONVIF_MediaProfile));
	if (NULL == p_new_profile)
	{
		return NULL;
	}

	memset(p_new_profile, 0, sizeof(ONVIF_MediaProfile));

	p_tmp = *p_profile;
	if (NULL == p_tmp)
	{
		*p_profile = p_new_profile;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_profile;
	}
	
	return p_new_profile;
}

ONVIF_API void onvif_free_MediaProfiles(ONVIF_MediaProfile ** p_profile)
{
	ONVIF_MediaProfile * p_next;
	ONVIF_MediaProfile * p_tmp = *p_profile;

	while (p_tmp)
	{
		p_next = p_tmp->next;
        
		free(p_tmp);
		p_tmp = p_next;
	}

	*p_profile = NULL;
}

ONVIF_API ONVIF_MediaProfile * onvif_find_MediaProfile(ONVIF_MediaProfile * p_profile, const char * token)
{
    ONVIF_MediaProfile * p_tmp = p_profile;
    
    while (p_tmp)
	{
	    if (strcmp(p_tmp->MediaProfile.token, token) == 0)
	    {
	        break;
	    }
	    
		p_tmp = p_tmp->next;
	}

	return p_tmp;
}

ONVIF_API ONVIF_PTZNode * onvif_add_PTZNode(ONVIF_PTZNode ** p_ptz_node)
{
	ONVIF_PTZNode * p_tmp;
    ONVIF_PTZNode * p_new_ptz_node = (ONVIF_PTZNode *) malloc(sizeof(ONVIF_PTZNode));
	if (NULL == p_new_ptz_node)
	{
		return NULL;
	}

	memset(p_new_ptz_node, 0, sizeof(ONVIF_PTZNode));

	p_tmp = *p_ptz_node;
	if (NULL == p_tmp)
	{
		*p_ptz_node = p_new_ptz_node;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_ptz_node;
	}
	
	return p_new_ptz_node;
}

ONVIF_API void onvif_free_PTZNodes(ONVIF_PTZNode ** p_ptz_node)
{
	ONVIF_PTZNode * p_next;
	ONVIF_PTZNode * p_tmp = *p_ptz_node;

	while (p_tmp)
	{
		p_next = p_tmp->next;
        
		free(p_tmp);
		p_tmp = p_next;
	}

	*p_ptz_node = NULL;
}

ONVIF_API ONVIF_PTZNode * onvif_find_PTZNode(ONVIF_DEVICE * p_dev, const char * token)
{
    ONVIF_PTZNode * p_ptz_node = p_dev->ptznodes;
    
    while (p_ptz_node)
	{
	    if (strcmp(p_ptz_node->PTZNode.token, token) == 0)
	    {
	        break;
	    }
	    
		p_ptz_node = p_ptz_node->next;
	}

	return p_ptz_node;
}

ONVIF_API ONVIF_PTZConfiguration * onvif_add_PTZConfiguration(ONVIF_PTZConfiguration ** p_ptz_cfg)
{
	ONVIF_PTZConfiguration * p_tmp;
    ONVIF_PTZConfiguration * p_new_ptz_cfg = (ONVIF_PTZConfiguration *) malloc(sizeof(ONVIF_PTZConfiguration));
	if (NULL == p_new_ptz_cfg)
	{
		return NULL;
	}

	memset(p_new_ptz_cfg, 0, sizeof(ONVIF_PTZConfiguration));

	p_tmp = *p_ptz_cfg;
	if (NULL == p_tmp)
	{
		*p_ptz_cfg = p_new_ptz_cfg;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_ptz_cfg;
	}
	
	return p_new_ptz_cfg;
}

ONVIF_API void onvif_free_PTZConfigurations(ONVIF_PTZConfiguration ** p_ptz_cfg)
{
    ONVIF_PTZConfiguration * p_next;
	ONVIF_PTZConfiguration * p_tmp = *p_ptz_cfg;

	while (p_tmp)
	{
		p_next = p_tmp->next;
        
		free(p_tmp);
		p_tmp = p_next;
	}

	*p_ptz_cfg = NULL;
}

ONVIF_API ONVIF_PTZConfiguration * onvif_find_PTZConfiguration(ONVIF_DEVICE * p_dev, const char * token)
{
    ONVIF_PTZConfiguration * p_ptz_cfg = p_dev->ptz_cfg;
    
    while (p_ptz_cfg)
	{
	    if (strcmp(p_ptz_cfg->Configuration.token, token) == 0)
	    {
	        break;
	    }
	    
		p_ptz_cfg = p_ptz_cfg->next;
	}

	return p_ptz_cfg;
}

ONVIF_API ONVIF_PTZPreset * onvif_add_PTZPreset(ONVIF_PTZPreset ** p_ptz_preset)
{
	ONVIF_PTZPreset * p_tmp;
    ONVIF_PTZPreset * p_new_ptz_preset = (ONVIF_PTZPreset *) malloc(sizeof(ONVIF_PTZPreset));
	if (NULL == p_new_ptz_preset)
	{
		return NULL;
	}

	memset(p_new_ptz_preset, 0, sizeof(ONVIF_PTZPreset));

	p_tmp = *p_ptz_preset;
	if (NULL == p_tmp)
	{
		*p_ptz_preset = p_new_ptz_preset;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_ptz_preset;
	}
	
	return p_new_ptz_preset;
}

ONVIF_API void onvif_free_PTZPresets(ONVIF_PTZPreset ** p_ptz_preset)
{
	ONVIF_PTZPreset * p_next;
	ONVIF_PTZPreset * p_tmp = *p_ptz_preset;

	while (p_tmp)
	{
		p_next = p_tmp->next;
        
		free(p_tmp);
		p_tmp = p_next;
	}

	*p_ptz_preset = NULL;
}

ONVIF_API ONVIF_PTZPresetTourSpot * onvif_add_PTZPresetTourSpot(ONVIF_PTZPresetTourSpot ** p_ptz_tourspot)
{
	ONVIF_PTZPresetTourSpot * p_tmp;
    ONVIF_PTZPresetTourSpot * p_new_ptz_tourspot = (ONVIF_PTZPresetTourSpot *) malloc(sizeof(ONVIF_PTZPresetTourSpot));
	if (NULL == p_new_ptz_tourspot)
	{
		return NULL;
	}

	memset(p_new_ptz_tourspot, 0, sizeof(ONVIF_PTZPresetTourSpot));

	p_tmp = *p_ptz_tourspot;
	if (NULL == p_tmp)
	{
		*p_ptz_tourspot = p_new_ptz_tourspot;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_ptz_tourspot;
	}
	
	return p_new_ptz_tourspot;
}

ONVIF_API void onvif_free_PTZPresetTourSpots(ONVIF_PTZPresetTourSpot ** p_ptz_tourspot)
{
	ONVIF_PTZPresetTourSpot * p_next;
	ONVIF_PTZPresetTourSpot * p_tmp = *p_ptz_tourspot;

	while (p_tmp)
	{
		p_next = p_tmp->next;
        
		free(p_tmp);
		p_tmp = p_next;
	}

	*p_ptz_tourspot = NULL;
}

ONVIF_API ONVIF_PresetTour * onvif_add_PresetTour(ONVIF_PresetTour ** p_preset_tour)
{
	ONVIF_PresetTour * p_tmp;
    ONVIF_PresetTour * p_new_preset_tour = (ONVIF_PresetTour *) malloc(sizeof(ONVIF_PresetTour));
	if (NULL == p_new_preset_tour)
	{
		return NULL;
	}

	memset(p_new_preset_tour, 0, sizeof(ONVIF_PresetTour));

	p_tmp = *p_preset_tour;
	if (NULL == p_tmp)
	{
		*p_preset_tour = p_new_preset_tour;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_preset_tour;
	}
	
	return p_new_preset_tour;
}

ONVIF_API void onvif_free_PresetTours(ONVIF_PresetTour ** p_preset_tour)
{
	ONVIF_PresetTour * p_next;
	ONVIF_PresetTour * p_tmp = *p_preset_tour;

	while (p_tmp)
	{
		p_next = p_tmp->next;

		onvif_free_PTZPresetTourSpots(&p_tmp->PresetTour.TourSpot);
        
		free(p_tmp);
		p_tmp = p_next;
	}

	*p_preset_tour = NULL;
}

ONVIF_API ONVIF_NotificationMessage * onvif_add_NotificationMessage(ONVIF_NotificationMessage ** p_message)
{
	ONVIF_NotificationMessage * p_tmp;
	ONVIF_NotificationMessage * p_new_message = (ONVIF_NotificationMessage *) malloc(sizeof(ONVIF_NotificationMessage));
	if (NULL == p_new_message)
	{
		return NULL;
	}

	memset(p_new_message, 0, sizeof(ONVIF_NotificationMessage));

	if (p_message)
	{
		p_tmp = *p_message;
		if (NULL == p_tmp)
		{
			*p_message = p_new_message;
		}
		else
		{
			while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

			p_tmp->next = p_new_message;
		}	
	}

	return p_new_message;
}

ONVIF_API void onvif_free_NotificationMessage(ONVIF_NotificationMessage * p_message)
{
	if (p_message)
	{
        onvif_free_SimpleItems(&p_message->NotificationMessage.Message.Source.SimpleItem);
		onvif_free_SimpleItems(&p_message->NotificationMessage.Message.Key.SimpleItem);
		onvif_free_SimpleItems(&p_message->NotificationMessage.Message.Data.SimpleItem);

		onvif_free_ElementItems(&p_message->NotificationMessage.Message.Source.ElementItem);
		onvif_free_ElementItems(&p_message->NotificationMessage.Message.Key.ElementItem);
		onvif_free_ElementItems(&p_message->NotificationMessage.Message.Data.ElementItem);

		free(p_message);
	}
}

ONVIF_API void onvif_free_NotificationMessages(ONVIF_NotificationMessage ** p_message)
{
	ONVIF_NotificationMessage * p_next;
	ONVIF_NotificationMessage * p_tmp = *p_message;

	while (p_tmp)
	{
		p_next = p_tmp->next;

		onvif_free_NotificationMessage(p_tmp);
		
		p_tmp = p_next;
	}

	*p_message = NULL;
}

ONVIF_API ONVIF_SimpleItem * onvif_add_SimpleItem(ONVIF_SimpleItem ** p_simpleitem)
{
	ONVIF_SimpleItem * p_tmp;
	ONVIF_SimpleItem * p_new_item = (ONVIF_SimpleItem *) malloc(sizeof(ONVIF_SimpleItem));
	if (NULL == p_new_item)
	{
		return NULL;
	}

	memset(p_new_item, 0, sizeof(ONVIF_SimpleItem));

	p_tmp = *p_simpleitem;
	if (NULL == p_tmp)
	{
		*p_simpleitem = p_new_item;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_item;
	}	

	return p_new_item;
}

ONVIF_API void onvif_free_SimpleItems(ONVIF_SimpleItem ** p_simpleitem)
{
    ONVIF_SimpleItem * p_next;
	ONVIF_SimpleItem * p_tmp = *p_simpleitem;

	while (p_tmp)
	{
		p_next = p_tmp->next;
		
		free(p_tmp);
		p_tmp = p_next;
	}

	*p_simpleitem = NULL;
}

ONVIF_API ONVIF_ElementItem * onvif_add_ElementItem(ONVIF_ElementItem ** p_elementitem)
{
	ONVIF_ElementItem * p_tmp;
	ONVIF_ElementItem * p_new_item = (ONVIF_ElementItem *) malloc(sizeof(ONVIF_ElementItem));
	if (NULL == p_new_item)
	{
		return NULL;
	}

	memset(p_new_item, 0, sizeof(ONVIF_ElementItem));

	p_tmp = *p_elementitem;
	if (NULL == p_tmp)
	{
		*p_elementitem = p_new_item;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_item;
	}	

	return p_new_item;
}

ONVIF_API void onvif_free_ElementItems(ONVIF_ElementItem ** p_elementitem)
{
    ONVIF_ElementItem * p_next;
	ONVIF_ElementItem * p_tmp = *p_elementitem;

	while (p_tmp)
	{
		p_next = p_tmp->next;
		
		free(p_tmp);
		p_tmp = p_next;
	}

	*p_elementitem = NULL;
}

ONVIF_API ONVIF_SimpleItemDescription * onvif_add_SimpleItemDescription(ONVIF_SimpleItemDescription ** p_item)
{
	ONVIF_SimpleItemDescription * p_tmp;
	ONVIF_SimpleItemDescription * p_new_item = (ONVIF_SimpleItemDescription *) malloc(sizeof(ONVIF_SimpleItemDescription));
	if (NULL == p_new_item)
	{
		return NULL;
	}

	memset(p_new_item, 0, sizeof(ONVIF_SimpleItemDescription));

	p_tmp = *p_item;
	if (NULL == p_tmp)
	{
		*p_item = p_new_item;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_item;
	}	

	return p_new_item;
}

ONVIF_API void onvif_free_SimpleItemDescriptions(ONVIF_SimpleItemDescription ** p_item)
{
	ONVIF_SimpleItemDescription * p_next;
	ONVIF_SimpleItemDescription * p_tmp = *p_item;

	while (p_tmp)
	{
		p_next = p_tmp->next;
		
		free(p_tmp);
		p_tmp = p_next;
	}

	*p_item = NULL;
}

ONVIF_API ONVIF_ConfigDescription_Messages * onvif_add_ConfigDescription_Messages(ONVIF_ConfigDescription_Messages ** p_item)
{
	ONVIF_ConfigDescription_Messages * p_tmp;
	ONVIF_ConfigDescription_Messages * p_new_item = (ONVIF_ConfigDescription_Messages *) malloc(sizeof(ONVIF_ConfigDescription_Messages));
	if (NULL == p_new_item)
	{
		return NULL;
	}

	memset(p_new_item, 0, sizeof(ONVIF_ConfigDescription_Messages));

	p_tmp = *p_item;
	if (NULL == p_tmp)
	{
		*p_item = p_new_item;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_item;
	}	

	return p_new_item;
}

ONVIF_API void onvif_free_ConfigDescription_Message(ONVIF_ConfigDescription_Messages * p_item)
{
	onvif_free_SimpleItemDescriptions(&p_item->Messages.Source.SimpleItemDescription);
	onvif_free_SimpleItemDescriptions(&p_item->Messages.Source.ElementItemDescription);

	onvif_free_SimpleItemDescriptions(&p_item->Messages.Key.SimpleItemDescription);
	onvif_free_SimpleItemDescriptions(&p_item->Messages.Key.ElementItemDescription);

	onvif_free_SimpleItemDescriptions(&p_item->Messages.Data.SimpleItemDescription);
	onvif_free_SimpleItemDescriptions(&p_item->Messages.Data.ElementItemDescription);
}

ONVIF_API void onvif_free_ConfigDescription_Messages(ONVIF_ConfigDescription_Messages ** p_item)
{
	ONVIF_ConfigDescription_Messages * p_next;
	ONVIF_ConfigDescription_Messages * p_tmp = *p_item;

	while (p_tmp)
	{
		p_next = p_tmp->next;
		
		onvif_free_ConfigDescription_Message(p_tmp);

		free(p_tmp);
		p_tmp = p_next;
	}

	*p_item = NULL;
}

/***
 * get notify list item numbers
 */
ONVIF_API int onvif_get_NotificationMessages_nums(ONVIF_NotificationMessage * p_notify)
{
    int nums = 0;
    ONVIF_NotificationMessage * p_tmp = p_notify;

    while (p_tmp)
    {
        ++nums;
        p_tmp = p_tmp->next;
    }

    return nums;
}

/***
 * add notify list to onvif device event notify list at last
 */
ONVIF_API void onvif_device_add_NotificationMessages(ONVIF_DEVICE * p_dev, ONVIF_NotificationMessage * p_notify)
{
    if (NULL == p_dev->events.notify)
    {        
        p_dev->events.notify = p_notify;
    }
    else
    {
        ONVIF_NotificationMessage * p_tmp = p_dev->events.notify;

        while (p_tmp && p_tmp->next)
        {
            p_tmp = p_tmp->next;
        }

        p_tmp->next = p_notify;
    }    
}

/***
 * free nums event notify item from onvif device event notify list at first
 *
 * return the freed notify item numbers
 */
ONVIF_API int onvif_device_free_NotificationMessages(ONVIF_DEVICE * p_dev, int nums)
{
    int freed_nums = 0;

    ONVIF_NotificationMessage * p_next;
    ONVIF_NotificationMessage * p_notify = p_dev->events.notify;
    while (p_notify && freed_nums < nums)
    {
        p_next = p_notify->next;
        
        onvif_free_NotificationMessage(p_notify);

        ++freed_nums;
        p_notify = p_next;
    }

    p_dev->events.notify = p_notify;

    return freed_nums;
}

ONVIF_API const char * onvif_format_SimpleItem(ONVIF_SimpleItem * p_item)
{
    int offset = 0;
    int mlen = 1024;
    static char str[1024];
	ONVIF_SimpleItem * p_tmp;

    memset(str, 0, sizeof(str));
    
    p_tmp = p_item;
    while (p_tmp)
    {
        offset += snprintf(str+offset, mlen-offset, "%s:%s\r\n", p_tmp->SimpleItem.Name, p_tmp->SimpleItem.Value);
        
        p_tmp = p_tmp->next;
    }

    return str;
}

ONVIF_API ONVIF_User * onvif_add_User(ONVIF_User ** p_user)
{
	ONVIF_User * p_tmp;
	ONVIF_User * p_new_user = (ONVIF_User *) malloc(sizeof(ONVIF_User));
	if (NULL == p_new_user)
	{
		return NULL;
	}

	memset(p_new_user, 0, sizeof(ONVIF_User));

	p_tmp = *p_user;
	if (NULL == p_tmp)
	{
		*p_user = p_new_user;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_user;
	}
	
	return p_new_user;
}

ONVIF_API void onvif_free_Users(ONVIF_User ** p_user)
{
	ONVIF_User * p_next;
	ONVIF_User * p_tmp = *p_user;

	while (p_tmp)
	{
		p_next = p_tmp->next;
        
		free(p_tmp);
		p_tmp = p_next;
	}

	*p_user = NULL;
}

ONVIF_API ONVIF_OSDConfiguration * onvif_add_OSDConfiguration(ONVIF_OSDConfiguration ** p_osd)
{
	ONVIF_OSDConfiguration * p_tmp;
	ONVIF_OSDConfiguration * p_new_osd = (ONVIF_OSDConfiguration *) malloc(sizeof(ONVIF_OSDConfiguration));
	if (NULL == p_new_osd)
	{
		return NULL;
	}

	memset(p_new_osd, 0, sizeof(ONVIF_OSDConfiguration));

	p_tmp = *p_osd;
	if (NULL == p_tmp)
	{
		*p_osd = p_new_osd;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_osd;
	}
	
	return p_new_osd;
}

ONVIF_API void onvif_free_OSDConfigurations(ONVIF_OSDConfiguration ** p_osd)
{
	ONVIF_OSDConfiguration * p_next;
	ONVIF_OSDConfiguration * p_tmp = *p_osd;

	while (p_tmp)
	{
		p_next = p_tmp->next;
        
		free(p_tmp);
		p_tmp = p_next;
	}

	*p_osd = NULL;
}

ONVIF_API ONVIF_Config * onvif_add_Config(ONVIF_Config ** p_config)
{
	ONVIF_Config * p_tmp;
	ONVIF_Config * p_new_config = (ONVIF_Config *) malloc(sizeof(ONVIF_Config));
	if (NULL == p_new_config)
	{
		return NULL;
	}

	memset(p_new_config, 0, sizeof(ONVIF_Config));

	p_tmp = *p_config;
	if (NULL == p_tmp)
	{
		*p_config = p_new_config;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_config;
	}	

	return p_new_config;
}

ONVIF_API void onvif_free_Config(ONVIF_Config * p_config)
{
	onvif_free_SimpleItems(&p_config->Config.Parameters.SimpleItem);
	onvif_free_ElementItems(&p_config->Config.Parameters.ElementItem);
}

ONVIF_API void onvif_free_Configs(ONVIF_Config ** p_config)
{
	ONVIF_Config * p_next;
	ONVIF_Config * p_tmp = *p_config;

	while (p_tmp)
	{
		p_next = p_tmp->next;

		onvif_free_Config(p_tmp);
		
		free(p_tmp);
		p_tmp = p_next;
	}

	*p_config = NULL;
}

ONVIF_API ONVIF_Config * onvif_find_Config(ONVIF_Config ** p_config, const char * name)
{
	ONVIF_Config * p_cfg = *p_config;
	while (p_cfg)
	{
		if (strcmp(p_cfg->Config.Name, name) == 0)
		{
			break;
		}

		p_cfg = p_cfg->next;
	}

	return p_cfg;
}

ONVIF_API void onvif_remove_Config(ONVIF_Config ** p_config, ONVIF_Config * p_remove)
{
	BOOL found = FALSE;
	ONVIF_Config * p_prev = NULL;
	ONVIF_Config * p_cfg = *p_config;	
	
	while (p_cfg)
	{
		if (p_cfg == p_remove)
		{
			found = TRUE;
			break;
		}

		p_prev = p_cfg;
		p_cfg = p_cfg->next;
	}

	if (found)
	{
		if (NULL == p_prev)
		{
			*p_config = p_cfg->next;
		}
		else
		{
			p_prev->next = p_cfg->next;
		}

		onvif_free_Config(p_cfg);
		free(p_cfg);
	}
}

ONVIF_API ONVIF_Config * onvif_get_prev_Config(ONVIF_Config ** p_config, ONVIF_Config * p_found)
{
	ONVIF_Config * p_prev = *p_config;
	
	if (p_found == *p_config)
	{
		return NULL;
	}

	while (p_prev)
	{
		if (p_prev->next == p_found)
		{
			break;
		}
		
		p_prev = p_prev->next;
	}

	return p_prev;
}

ONVIF_API ONVIF_VideoAnalyticsConfiguration * onvif_add_VideoAnalyticsConfiguration(ONVIF_VideoAnalyticsConfiguration ** p_config)
{
	ONVIF_VideoAnalyticsConfiguration * p_tmp;
	ONVIF_VideoAnalyticsConfiguration * p_new_config = (ONVIF_VideoAnalyticsConfiguration *) malloc(sizeof(ONVIF_VideoAnalyticsConfiguration));
	if (NULL == p_new_config)
	{
		return NULL;
	}

	memset(p_new_config, 0, sizeof(ONVIF_VideoAnalyticsConfiguration));

	p_tmp = *p_config;
	if (NULL == p_tmp)
	{
		*p_config = p_new_config;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_config;
	}	

	return p_new_config;
}

ONVIF_API void onvif_free_VideoAnalyticsConfiguration(ONVIF_VideoAnalyticsConfiguration * p_config)
{
	onvif_free_Configs(&p_config->rules);
	onvif_free_Configs(&p_config->modules);

	onvif_free_ConfigDescriptions(&p_config->SupportedRules.RuleDescription);
	
	onvif_free_Configs(&p_config->Configuration.AnalyticsEngineConfiguration.AnalyticsModule);
	onvif_free_Configs(&p_config->Configuration.RuleEngineConfiguration.Rule);
}

ONVIF_API void onvif_free_VideoAnalyticsConfigurations(ONVIF_VideoAnalyticsConfiguration ** p_config)
{
	ONVIF_VideoAnalyticsConfiguration * p_next;
	ONVIF_VideoAnalyticsConfiguration * p_tmp = *p_config;

	while (p_tmp)
	{
		p_next = p_tmp->next;

		onvif_free_VideoAnalyticsConfiguration(p_tmp);
		
		free(p_tmp);
		p_tmp = p_next;
	}

	*p_config = NULL;
}

ONVIF_API ONVIF_ConfigDescription * onvif_add_ConfigDescription(ONVIF_ConfigDescription ** p_cfg_desc)
{
	ONVIF_ConfigDescription * p_tmp;
	ONVIF_ConfigDescription * p_new_config = (ONVIF_ConfigDescription *) malloc(sizeof(ONVIF_ConfigDescription));
	if (NULL == p_new_config)
	{
		return NULL;
	}

	memset(p_new_config, 0, sizeof(ONVIF_ConfigDescription));

	p_tmp = *p_cfg_desc;
	if (NULL == p_tmp)
	{
		*p_cfg_desc = p_new_config;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_config;
	}	

	return p_new_config;
}

ONVIF_API void onvif_free_ConfigDescription(ONVIF_ConfigDescription * p_cfg_desc)
{
	onvif_free_SimpleItemDescriptions(&p_cfg_desc->ConfigDescription.Parameters.SimpleItemDescription);
	onvif_free_SimpleItemDescriptions(&p_cfg_desc->ConfigDescription.Parameters.ElementItemDescription);
	
	onvif_free_ConfigDescription_Messages(&p_cfg_desc->ConfigDescription.Messages);
}

ONVIF_API void onvif_free_ConfigDescriptions(ONVIF_ConfigDescription ** p_cfg_desc)
{
	ONVIF_ConfigDescription * p_next;
	ONVIF_ConfigDescription * p_tmp = *p_cfg_desc;

	while (p_tmp)
	{
		p_next = p_tmp->next;

		onvif_free_ConfigDescription(p_tmp);
		
		free(p_tmp);
		p_tmp = p_next;
	}

	*p_cfg_desc = NULL;
}

ONVIF_API void onvif_free_device(ONVIF_DEVICE * p_dev)
{
	if (NULL == p_dev)
	{
		return;
	}

	if (p_dev->events.subscribe)
    {
        Unsubscribe(p_dev);
    }
    
	onvif_free_Profiles(&p_dev->profiles);
    onvif_free_VideoSources(&p_dev->video_src);
    onvif_free_AudioSources(&p_dev->audio_src);
    onvif_free_VideoSourceConfigurations(&p_dev->video_src_cfg);
    onvif_free_AudioSourceConfigurations(&p_dev->audio_src_cfg);
    onvif_free_VideoEncoderConfigurations(&p_dev->video_enc);
    onvif_free_AudioEncoderConfigurations(&p_dev->audio_enc);
    onvif_free_PTZNodes(&p_dev->ptznodes);
    onvif_free_PTZConfigurations(&p_dev->ptz_cfg);    

    onvif_free_NotificationMessages(&p_dev->events.notify);
}

#ifdef PROFILE_G_SUPPORT

ONVIF_API ONVIF_Recording * onvif_add_Recording(ONVIF_Recording ** p_recording)
{
    ONVIF_Recording * p_tmp;
	ONVIF_Recording * p_item = (ONVIF_Recording *) malloc(sizeof(ONVIF_Recording));
	if (NULL == p_item)
	{
		return NULL;
	}

	memset(p_item, 0, sizeof(ONVIF_Recording));

	p_tmp = *p_recording;
	if (NULL == p_tmp)
	{
		*p_recording = p_item;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_item;
	}

	return p_item;
}

ONVIF_Recording * onvif_find_Recording(ONVIF_Recording * p_recording, const char * token)
{
	ONVIF_Recording * p_item = p_recording;
	while (p_item)
	{
		if (strcmp(p_item->Recording.RecordingToken, token) == 0)
		{
			break;
		}

		p_item = p_item->next;
	}

	return p_item;
}

void onvif_free_Recordings(ONVIF_Recording ** p_recording)
{
    ONVIF_Recording * p_next;
	ONVIF_Recording * p_tmp = *p_recording;

	while (p_tmp)
	{
		p_next = p_tmp->next;

        onvif_free_Tracks(&p_tmp->Recording.Tracks);
        
		free(p_tmp);
		p_tmp = p_next;
	}

	*p_recording = NULL;
}

ONVIF_Track * onvif_add_Track(ONVIF_Track ** p_tracks)
{
	ONVIF_Track * p_tmp;
	ONVIF_Track * p_track = (ONVIF_Track *) malloc(sizeof(ONVIF_Track));
	if (NULL == p_track)
	{
		return NULL;
	}

	memset(p_track, 0, sizeof(ONVIF_Track));

	p_tmp = *p_tracks;
	if (NULL == p_tmp)
	{
		*p_tracks = p_track;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_track;
	}	

	return p_track;
}

void onvif_free_Tracks(ONVIF_Track ** p_tracks)
{
	ONVIF_Track * p_next;
	ONVIF_Track * p_tmp = *p_tracks;

	while (p_tmp)
	{
		p_next = p_tmp->next;

		free(p_tmp);
		p_tmp = p_next;
	}

	*p_tracks = NULL;
}

ONVIF_Track * onvif_find_Track(ONVIF_Track * p_tracks, const char * token)
{
	ONVIF_Track * p_track = p_tracks;
	while (p_track)
	{
		if (strcmp(p_track->Track.TrackToken, token) == 0)
		{
			break;
		}

		p_track = p_track->next;
	}

	return p_track;
}

ONVIF_API ONVIF_RecordingJob * onvif_add_RecordingJob(ONVIF_RecordingJob ** p_recordingjob)
{
    ONVIF_RecordingJob * p_tmp;
	ONVIF_RecordingJob * p_item = (ONVIF_RecordingJob *) malloc(sizeof(ONVIF_RecordingJob));
	if (NULL == p_item)
	{
		return NULL;
	}

	memset(p_item, 0, sizeof(ONVIF_RecordingJob));

	p_tmp = *p_recordingjob;
	if (NULL == p_tmp)
	{
		*p_recordingjob = p_item;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_item;
	}	

	return p_item;
}

ONVIF_RecordingJob * onvif_find_RecordingJob(ONVIF_RecordingJob * p_recordingjob, const char * token)
{
	ONVIF_RecordingJob * p_item = p_recordingjob;
	while (p_item)
	{
		if (strcmp(p_item->RecordingJob.JobToken, token) == 0)
		{
			break;
		}

		p_item = p_item->next;
	}

	return p_item;
}

ONVIF_API void onvif_free_RecordingJobs(ONVIF_RecordingJob ** p_recordingjob)
{
    ONVIF_RecordingJob * p_next;
	ONVIF_RecordingJob * p_tmp = *p_recordingjob;

	while (p_tmp)
	{
		p_next = p_tmp->next;

		free(p_tmp);
		p_tmp = p_next;
	}

	*p_recordingjob = NULL;
}

ONVIF_API ONVIF_TrackAttributes * onvif_add_TrackAttributes(ONVIF_TrackAttributes ** p_track_attr)
{
	ONVIF_TrackAttributes * p_tmp;
	ONVIF_TrackAttributes * p_new_track_attr = (ONVIF_TrackAttributes *) malloc(sizeof(ONVIF_TrackAttributes));
	if (NULL == p_new_track_attr)
	{
		return NULL;
	}

	memset(p_new_track_attr, 0, sizeof(ONVIF_TrackAttributes));

	p_tmp = *p_track_attr;
	if (NULL == p_tmp)
	{
		*p_track_attr = p_new_track_attr;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_track_attr;
	}
	
	return p_new_track_attr;
}

ONVIF_API void onvif_free_TrackAttributes(ONVIF_TrackAttributes ** p_track_attr)
{
	ONVIF_TrackAttributes * p_next;
	ONVIF_TrackAttributes * p_tmp = *p_track_attr;

	while (p_tmp)
	{
		p_next = p_tmp->next;
        
		free(p_tmp);
		p_tmp = p_next;
	}

	*p_track_attr = NULL;
}

ONVIF_API ONVIF_RecordingInformation * onvif_add_RecordingInformation(ONVIF_RecordingInformation ** p_recording)
{
	ONVIF_RecordingInformation * p_tmp;
	ONVIF_RecordingInformation * p_new_recording = (ONVIF_RecordingInformation *) malloc(sizeof(ONVIF_RecordingInformation));
	if (NULL == p_new_recording)
	{
		return NULL;
	}

	memset(p_new_recording, 0, sizeof(ONVIF_RecordingInformation));

	p_tmp = *p_recording;
	if (NULL == p_tmp)
	{
		*p_recording = p_new_recording;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_recording;
	}
	
	return p_new_recording;
}

ONVIF_API void onvif_free_RecordingInformations(ONVIF_RecordingInformation ** p_recording)
{
	ONVIF_RecordingInformation * p_next;
	ONVIF_RecordingInformation * p_tmp = *p_recording;

	while (p_tmp)
	{
		p_next = p_tmp->next;
        
		free(p_tmp);
		p_tmp = p_next;
	}

	*p_recording = NULL;
}

#endif	// end of PROFILE_G_SUPPORT

#ifdef PROFILE_C_SUPPORT

ONVIF_API ONVIF_AccessPointInfo * onvif_add_AccessPointInfo(ONVIF_AccessPointInfo ** p_info)
{
    ONVIF_AccessPointInfo * p_tmp;
	ONVIF_AccessPointInfo * p_new_info = (ONVIF_AccessPointInfo *) malloc(sizeof(ONVIF_AccessPointInfo));
	if (NULL == p_new_info)
	{
		return NULL;
	}

	memset(p_new_info, 0, sizeof(ONVIF_AccessPointInfo));

	p_tmp = *p_info;
	if (NULL == p_tmp)
	{
		*p_info = p_new_info;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_info;
	}	

	return p_new_info;
}

ONVIF_API ONVIF_AccessPointInfo * onvif_find_AccessPointInfo(ONVIF_AccessPointInfo * p_info, const char * token)
{
    ONVIF_AccessPointInfo * p_accesspoint = p_info;  
    
    if (NULL == token)
    {
        return NULL;
    }

    while (p_accesspoint)
    {
        if (strcasecmp(token, p_accesspoint->AccessPointInfo.token) == 0)
        {
            return p_accesspoint;
        }
        
        p_accesspoint = p_accesspoint->next;
    }

    return NULL;
}

ONVIF_API void onvif_free_AccessPointInfos(ONVIF_AccessPointInfo ** p_info)
{
    ONVIF_AccessPointInfo * p_next;
	ONVIF_AccessPointInfo * p_tmp = *p_info;

	while (p_tmp)
	{
		p_next = p_tmp->next;

		free(p_tmp);
		p_tmp = p_next;
	}

	*p_info = NULL;
}

ONVIF_API ONVIF_DoorInfo * onvif_add_DoorInfo(ONVIF_DoorInfo ** p_info)
{
    ONVIF_DoorInfo * p_tmp;
	ONVIF_DoorInfo * p_new_info = (ONVIF_DoorInfo *) malloc(sizeof(ONVIF_DoorInfo));
	if (NULL == p_new_info)
	{
		return NULL;
	}

	memset(p_new_info, 0, sizeof(ONVIF_DoorInfo));

	p_tmp = *p_info;
	if (NULL == p_tmp)
	{
		*p_info = p_new_info;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_info;
	}	

	return p_new_info;
}

ONVIF_API ONVIF_DoorInfo * onvif_find_DoorInfo(ONVIF_DoorInfo * p_info, const char * token)
{
    ONVIF_DoorInfo * p_door = p_info;  
    
    if (NULL == token)
    {
        return NULL;
    }

    while (p_door)
    {
        if (strcasecmp(token, p_door->DoorInfo.token) == 0)
        {
            return p_door;
        }
        
        p_door = p_door->next;
    }

    return NULL;
}

ONVIF_API void onvif_free_DoorInfos(ONVIF_DoorInfo ** p_info)
{
    ONVIF_DoorInfo * p_next;
	ONVIF_DoorInfo * p_tmp = *p_info;

	while (p_tmp)
	{
		p_next = p_tmp->next;

		free(p_tmp);
		p_tmp = p_next;
	}

	*p_info = NULL;
}

ONVIF_API ONVIF_AreaInfo * onvif_add_AreaInfo(ONVIF_AreaInfo ** p_info)
{
    ONVIF_AreaInfo * p_tmp;
	ONVIF_AreaInfo * p_new_info = (ONVIF_AreaInfo *) malloc(sizeof(ONVIF_AreaInfo));
	if (NULL == p_new_info)
	{
		return NULL;
	}

	memset(p_new_info, 0, sizeof(ONVIF_AreaInfo));

	p_tmp = *p_info;
	if (NULL == p_tmp)
	{
		*p_info = p_new_info;
	}
	else
	{
		while (p_tmp && p_tmp->next) p_tmp = p_tmp->next;

		p_tmp->next = p_new_info;
	}	

	return p_new_info;
}

ONVIF_API ONVIF_AreaInfo * onvif_find_AreaInfo(ONVIF_AreaInfo * p_info, const char * token)
{
    ONVIF_AreaInfo * p_area = p_info;  
    
    if (NULL == token)
    {
        return NULL;
    }

    while (p_area)
    {
        if (strcasecmp(token, p_area->AreaInfo.token) == 0)
        {
            return p_area;
        }
        
        p_area = p_area->next;
    }

    return NULL;
}

ONVIF_API void onvif_free_AreaInfos(ONVIF_AreaInfo ** p_info)
{
    ONVIF_AreaInfo * p_next;
	ONVIF_AreaInfo * p_tmp = *p_info;

	while (p_tmp)
	{
		p_next = p_tmp->next;

		free(p_tmp);
		p_tmp = p_next;
	}

	*p_info = NULL;
}

#endif // end of PROFILE_C_SUPPORT



