/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2010-2016, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#ifndef _ONVIF_UTILS_H_
#define _ONVIF_UTILS_H_

#include "sys_inc.h"
#include "onvif.h"

#ifdef __cplusplus
extern "C" {
#endif

ONVIF_API void 	        onvif_get_time_str(char * buff, int len, int sec_off);
ONVIF_API void 	        onvif_get_time_str_s(char * buff, int len, time_t nowtime, int sec_off);
ONVIF_API BOOL 	        onvif_is_valid_hostname(const char * name);
ONVIF_API BOOL 	        onvif_is_valid_timezone(const char * tz);
ONVIF_API void 	        onvif_get_timezone(char * tz, int len);

ONVIF_API char        * onvif_uuid_create(char * uuid, int len);
ONVIF_API const char  * onvif_get_local_ip();

ONVIF_API time_t 	    onvif_timegm(struct tm *T);
ONVIF_API int  	        onvif_parse_xaddr(const char * pdata, char * host, int hostsize, char * url, int urlsize, int * port, int * https);

ONVIF_API time_t        onvif_datetime_to_time_t(onvif_DateTime * p_datetime);
ONVIF_API void          onvif_time_t_to_datetime(time_t n, onvif_DateTime * p_datetime);
ONVIF_API char        * onvif_format_datetime_str(time_t n, int flag, const char * format, char * buff, int buflen);
ONVIF_API time_t	    onvif_timegm(struct tm *T);
ONVIF_API int           onvif_parse_uri(const char * p_in, char * p_out, int outlen);

#ifdef __cplusplus
}
#endif


#endif


