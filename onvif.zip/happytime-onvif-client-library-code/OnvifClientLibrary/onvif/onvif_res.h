/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2010-2016, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#ifndef ONVIF_RES_H
#define ONVIF_RES_H



/*************************************************************************
 *
 * onvif response structure
 *
**************************************************************************/
typedef struct
{
	onvif_Capabilities	Capabilities;					// required, Capability information
} GetCapabilities_RES;

typedef struct
{
    onvif_Capabilities	Capabilities;					// required, Capability information
} GetServices_RES;

typedef struct
{
	onvif_DeviceInformation	DeviceInformation;			// required, Device information
} GetDeviceInformation_RES;

typedef struct
{
	ONVIF_User	* User;
} GetUsers_RES;

typedef struct
{
	int		dummy;
} CreateUsers_RES;

typedef struct
{
	int		dummy;
} DeleteUsers_RES;

typedef struct
{
	int		dummy;
} SetUser_RES;

typedef struct
{
    uint32	RemoteUserFlag	: 1;					    // Indicates whether the field RemoteUser is valid
	uint32 	Reserved		: 31;
	
    onvif_RemoteUser RemoteUser;                        // optional
} GetRemoteUser_RES;

typedef struct
{
	int		dummy;
} SetRemoteUser_RES;

typedef struct
{
	ONVIF_NetworkInterface * NetworkInterfaces;		    // required, List of network interfaces
} GetNetworkInterfaces_RES;

typedef struct
{
	BOOL	RebootNeeded;								// required, Indicates whether or not a reboot is required after configuration updates, 
} SetNetworkInterfaces_RES;

typedef struct
{
	onvif_NTPInformation	NTPInformation;				// required, NTP information
} GetNTP_RES;

typedef struct 
{	
	int		dummy;
} SetNTP_RES;

typedef struct
{
	onvif_HostnameInformation	HostnameInformation;	// required, Host name information
} GetHostname_RES;

typedef struct
{
	int		dummy;
} SetHostname_RES;

typedef struct
{
	BOOL	RebootNeeded;								// required, Indicates whether or not a reboot is required after configuration updates
} SetHostnameFromDHCP_RES;

typedef struct
{
	onvif_DNSInformation	DNSInformation;				// required, DNS information
} GetDNS_RES;

typedef struct 
{
	int		dummy;
} SetDNS_RES;

typedef struct
{
	onvif_DynamicDNSInformation	DynamicDNSInformation;	// Dynamic DNS information
} GetDynamicDNS_RES;

typedef struct
{
	int		dummy;
} SetDynamicDNS_RES;

typedef struct
{
	onvif_NetworkProtocol	NetworkProtocols;			// Contains defined protocols supported by the device
} GetNetworkProtocols_RES;

typedef struct
{
	int		dummy;
} SetNetworkProtocols_RES;

typedef struct
{
	onvif_DiscoveryMode	DiscoveryMode;					// required, Indicator of discovery mode: Discoverable, NonDiscoverable
} GetDiscoveryMode_RES;

typedef struct
{
	int		dummy;
} SetDiscoveryMode_RES;

typedef struct
{
	char	IPv4Address[MAX_GATEWAY][32];				// required, Gets the default IPv4 and IPv6 gateway settings from the device
} GetNetworkDefaultGateway_RES;

typedef struct
{
	int		dummy;
} SetNetworkDefaultGateway_RES;

typedef struct
{
    onvif_NetworkZeroConfiguration ZeroConfiguration;   // Contains the zero-configuration
} GetZeroConfiguration_RES;

typedef struct
{
    int		dummy;
} SetZeroConfiguration_RES;

typedef struct
{
    char    GUID[128];
} GetEndpointReference_RES;

typedef struct
{
    uint32	UTCDateTimeFlag		: 1;					// Indicates whether the field UTCDateTime is valid
    uint32	LocalDateTimeFlag	: 1;					// Indicates whether the field LocalDateTime is valid
	uint32 	Reserved			: 30;
	
    onvif_SystemDateTime	SystemDateTime;				// required,     
    onvif_DateTime 			UTCDateTime;				// optional, Date and time in UTC. If time is obtained via NTP, UTCDateTime has no meaning
    onvif_DateTime 			LocalDateTime;				// optional, 
} GetSystemDateAndTime_RES;

typedef struct
{
	int		dummy;
} SetSystemDateAndTime_RES;

typedef struct
{
	int		dummy;
} SystemReboot_RES;

typedef struct
{
	int		dummy;
} SetSystemFactoryDefault_RES;

typedef struct
{
	int		dummy;
} GetSystemLog_RES;

typedef struct
{
	int     sizeScopes;

	onvif_Scope Scopes[MAX_SCOPE_NUMS];
} GetScopes_RES;

typedef struct
{
	int     dummy;
} SetScopes_RES;

typedef struct
{
	int		dummy;
} AddScopes_RES;

typedef struct
{
	int		dummy;
} RemoveScopes_RES;

typedef struct
{
	char    UploadUri[256];	                			// required 
	int     UploadDelay;	                			// required 
	int     ExpectedDownTime;	            			// required 
} StartFirmwareUpgrade_RES;

typedef struct
{
    uint32	SystemLogUriFlag    : 1;					// Indicates whether the field SystemLogUri is valid
    uint32	AccessLogUriFlag	: 1;					// Indicates whether the field AccessLogUri is valid
    uint32	SupportInfoUriFlag  : 1;					// Indicates whether the field SupportInfoUri is valid
    uint32	SystemBackupUriFlag	: 1;					// Indicates whether the field SystemBackupUri is valid
	uint32 	Reserved			: 28;
	
    char    SystemLogUri[256];                          // optional
    char    AccessLogUri[256];                          // optional
	char    SupportInfoUri[256];	                    // optional
	char    SystemBackupUri[256];	                    // optional
} GetSystemUris_RES;

typedef struct
{
    char    UploadUri[256];	                            // required
	int     ExpectedDownTime;	                        // required
} StartSystemRestore_RES;

typedef struct
{
	ONVIF_VideoSource * VideoSources;			        // List of existing Video Sources
} GetVideoSources_RES;

typedef struct
{
    ONVIF_AudioSource * AudioSources;		            // List of existing Audio Sources
} GetAudioSources_RES;

typedef struct
{
	ONVIF_Profile Profile;								// required, returns the new created profile						
} CreateProfile_RES;

typedef struct
{
	ONVIF_Profile Profile;								// required, returns the requested media profile
} GetProfile_RES;

typedef struct
{
	ONVIF_Profile * Profiles;							// lists all profiles that exist in the media service
} GetProfiles_RES;

typedef struct
{
	int		dummy;
} AddVideoEncoderConfiguration_RES;

typedef struct
{
	int		dummy;
} AddVideoSourceConfiguration_RES;

typedef struct
{
	int		dummy;
} AddAudioEncoderConfiguration_RES;

typedef struct
{
	int		dummy;
} AddAudioSourceConfiguration_RES;

typedef struct
{
	ONVIF_VideoSourceMode * VideoSourceModes;	        // Return the information for specified video source mode			
} GetVideoSourceModes_RES;

typedef struct
{
	BOOL 	Reboot;										// The response contains information about rebooting after returning response. When Reboot is set true, a device will reboot automatically after setting mode
} SetVideoSourceMode_RES;

typedef struct
{
	int		dummy;
} AddPTZConfiguration_RES;

typedef struct
{
	int		dummy;
} RemoveVideoEncoderConfiguration_RES;

typedef struct
{
	int		dummy;
} RemoveVideoSourceConfiguration_RES;

typedef struct
{
	int		dummy;
} RemoveAudioEncoderConfiguration_RES;

typedef struct
{
	int		dummy;
} RemoveAudioSourceConfiguration_RES;

typedef struct
{
	int		dummy;
} RemovePTZConfiguration_RES;

typedef struct
{
	int		dummy;
} DeleteProfile_RES;

typedef struct
{
	ONVIF_VideoSourceConfiguration * Configurations;    // This element contains a list of video source configurations
} GetVideoSourceConfigurations_RES;

typedef struct
{
	ONVIF_VideoEncoderConfiguration * Configurations;   // This element contains a list of video encoder configurations
} GetVideoEncoderConfigurations_RES;

typedef struct
{
	ONVIF_AudioSourceConfiguration * Configurations;    // This element contains a list of audio source configurations
} GetAudioSourceConfigurations_RES;

typedef struct
{
	ONVIF_AudioEncoderConfiguration * Configurations;   // This element contains a list of audio encoder configurations
} GetAudioEncoderConfigurations_RES;

typedef struct
{
	onvif_VideoSourceConfiguration	Configuration;		// required, The requested video source configuration
} GetVideoSourceConfiguration_RES;

typedef struct
{
	onvif_VideoEncoderConfiguration	Configuration;		// required, The requested video encoder configuration
} GetVideoEncoderConfiguration_RES;

typedef struct
{
	onvif_AudioSourceConfiguration	Configuration;		// required, The requested audio source configuration
} GetAudioSourceConfiguration_RES;

typedef struct
{
	onvif_AudioEncoderConfiguration	Configuration;		// required, The requested audio encorder configuration
} GetAudioEncoderConfiguration_RES;

typedef struct
{
	int		dummy;
} SetVideoSourceConfiguration_RES;

typedef struct
{
	int		dummy;
} SetVideoEncoderConfiguration_RES;

typedef struct
{
	int		dummy;
} SetAudioSourceConfiguration_RES;

typedef struct
{
	int		dummy;
} SetAudioEncoderConfiguration_RES;

typedef struct
{
    onvif_VideoSourceConfigurationOptions   Options;
} GetVideoSourceConfigurationOptions_RES;

typedef struct
{
	onvif_VideoEncoderConfigurationOptions	Options;	// required
} GetVideoEncoderConfigurationOptions_RES;

typedef struct
{
	int		dummy;
} GetAudioSourceConfigurationOptions_RES;

typedef struct
{
	onvif_AudioEncoderConfigurationOptions	Options;	// required
} GetAudioEncoderConfigurationOptions_RES;

typedef struct
{
	char	Uri[ONVIF_URI_LEN];							// required, Stable Uri to be used for requesting the media stream

	int 	Timeout;									// required, Duration how long the Uri is valid. This parameter shall be set to PT0S to indicate that this stream URI is indefinitely valid even if the profile changes
	
	BOOL	InvalidAfterConnect;						// required, Indicates if the Uri is only valid until the connection is established. The value shall be set to "false"
	BOOL	InvalidAfterReboot;							// required, Indicates if the Uri is invalid after a reboot of the device. The value shall be set to "false"
} GetStreamUri_RES;

typedef struct
{
	int		dummy;
} SetSynchronizationPoint_RES;

typedef struct
{
	char	Uri[ONVIF_URI_LEN];							// required, Stable Uri to be used for requesting the media stream

	int 	Timeout;									// required, Duration how long the Uri is valid. This parameter shall be set to PT0S to indicate that this stream URI is indefinitely valid even if the profile changes
	
	BOOL	InvalidAfterConnect;						// required, Indicates if the Uri is only valid until the connection is established. The value shall be set to "false"
	BOOL	InvalidAfterReboot;							// required, Indicates if the Uri is invalid after a reboot of the device. The value shall be set to "false"
} GetSnapshotUri_RES;


typedef struct
{
	ONVIF_PTZNode * PTZNode;						    // A list of the existing PTZ Nodes on the device
} GetNodes_RES;

typedef struct
{
	onvif_PTZNode	PTZNode;							// required, A requested PTZNode
} GetNode_RES;

typedef struct
{
	_ONVIF_PTZPreset * PTZPresets;					    // A list of presets which are available for the requested MediaProfile
} GetPresets_RES;

typedef struct
{
	char	PresetToken[ONVIF_TOKEN_LEN];				// required, A token to the Preset which has been set
} SetPreset_RES;

typedef struct
{
	int		dummy;
} RemovePreset_RES;

typedef struct
{
	int		dummy;
} GotoPreset_RES;

typedef struct
{
	int		dummy;
} GotoHomePosition_RES;

typedef struct
{
	int		dummy;
} SetHomePosition_RES;

typedef struct
{
	onvif_PTZStatus	PTZStatus;							// required, The PTZStatus for the requested MediaProfile
} GetStatus_RES;

typedef struct
{
	int		dummy;
} ContinuousMove_RES;

typedef struct
{
	int		dummy;
} RelativeMove_RES;

typedef struct
{
	int		dummy;
} AbsoluteMove_RES;

typedef struct
{
	int		dummy;
} PTZStop_RES;

typedef struct
{
    ONVIF_PTZConfiguration * PTZConfiguration;		    // A list of all existing PTZConfigurations on the device
} GetConfigurations_RES;

typedef struct
{
    onvif_PTZConfiguration	PTZConfiguration;			// required, A requested PTZConfiguration
} GetConfiguration_RES;

typedef struct
{
	int		dummy;
} SetConfiguration_RES;

typedef struct
{
	onvif_PTZConfigurationOptions	PTZConfigurationOptions;	// required, The requested PTZ configuration options
} GetConfigurationOptions_RES;

typedef struct
{
    ONVIF_PresetTour *  PresetTour;
} GetPresetTours_RES;

typedef struct
{
    onvif_PresetTour    PresetTour;
} GetPresetTour_RES;

typedef struct
{
    onvif_PTZPresetTourOptions  Options;
} GetPresetTourOptions_RES;

typedef struct
{
    char    PresetTourToken[ONVIF_TOKEN_LEN];	        // required, 
} CreatePresetTour_RES;

typedef struct
{
    int     dummy;
} ModifyPresetTour_RES;

typedef struct
{
    int     dummy;
} OperatePresetTour_RES;

typedef struct
{
    int     dummy;
} RemovePresetTour_RES;


typedef struct
{
	int		dummy;
} GetEventProperties_RES;

typedef struct
{
	int		dummy;
} Renew_RES;

typedef struct
{
	int		dummy;
} Unsubscribe_RES;

typedef struct
{
    char    producter_addr[256];						// required
} Subscribe_RES;

typedef struct
{
    char    producter_addr[256];						// required, Endpoint reference of the subscription to be used for pulling the messages
    
    time_t  CurrentTime;	                            // required, Current time of the server for synchronization purposes
	time_t  TerminationTime;	                        // required, Date time when the PullPoint will be shut down without further pull requests
} CreatePullPointSubscription_RES;

typedef struct
{
    time_t  CurrentTime;	                            // required, The date and time when the messages have been delivered by the web server to the client
	time_t  TerminationTime;	                        // required, Date time when the PullPoint will be shut down without further pull requests

	ONVIF_NotificationMessage * NotifyMessages;
} PullMessages_RES;

typedef struct
{
    onvif_ImagingSettings	ImagingSettings;			// required, ImagingSettings for the VideoSource that was requested
} GetImagingSettings_RES;

typedef struct
{
	int		dummy;
} SetImagingSettings_RES;

typedef struct
{
	onvif_ImagingOptions	ImagingOptions;				// required, Valid ranges for the imaging parameters that are categorized as device specific
} GetOptions_RES;

typedef struct
{
    int		dummy;
} img_Move_RES;

typedef struct
{
    int		dummy;
} img_Stop_RES;

typedef struct
{
    onvif_ImagingStatus Status;	                        // required
} img_GetStatus_RES;

typedef struct
{
    onvif_MoveOptions20 MoveOptions;	                // required 
} img_GetMoveOptions_RES;

// recording
typedef struct
{
    char    RecordingToken[ONVIF_TOKEN_LEN];	        // required
} CreateRecording_RES;

typedef struct
{
    int		dummy;
} DeleteRecording_RES;

typedef struct
{
    ONVIF_Recording * Recordings;
} GetRecordings_RES;

typedef struct
{
    int		dummy;
} SetRecordingConfiguration_RES;

typedef struct
{
    onvif_RecordingConfiguration    RecordingConfiguration;
} GetRecordingConfiguration_RES;

typedef struct
{
    onvif_RecordingOptions  Options;
} GetRecordingOptions_RES;

typedef struct
{
    char    TrackToken[ONVIF_TOKEN_LEN];	            // required
} CreateTrack_RES;

typedef struct
{
    int		dummy;
} DeleteTrack_RES;

typedef struct
{
    onvif_TrackConfiguration    TrackConfiguration;	    // required
} GetTrackConfiguration_RES;

typedef struct
{
    int		dummy;
} SetTrackConfiguration_RES;

typedef struct
{
    char    JobToken[ONVIF_TOKEN_LEN];	                // required
    
	onvif_RecordingJobConfiguration JobConfiguration;   // required
} CreateRecordingJob_RES;

typedef struct
{
    int		dummy;
} DeleteRecordingJob_RES;

typedef struct
{
    ONVIF_RecordingJob * RecordingJobs;
} GetRecordingJobs_RES;

typedef struct
{
    onvif_RecordingJobConfiguration JobConfiguration;   // required
} SetRecordingJobConfiguration_RES;

typedef struct
{
    onvif_RecordingJobConfiguration JobConfiguration;   // required
} GetRecordingJobConfiguration_RES;

typedef struct
{
    int		dummy;
} SetRecordingJobMode_RES;

typedef struct
{
    onvif_RecordingJobStateInformation  State;	        // required
} GetRecordingJobState_RES;

typedef struct
{
    char 	Uri[ONVIF_URI_LEN];							// required. The URI to which the client should connect in order to stream the recording
} GetReplayUri_RES;

typedef struct
{
	time_t	DataFrom;									// Required. The earliest point in time where there is recorded data on the device.
	time_t	DataUntil;									// Required. The most recent point in time where there is recorded data on the device
	int		NumberRecordings;							// Required. The device contains this many recordings
} GetRecordingSummary_RES;

typedef struct
{
	onvif_RecordingInformation	RecordingInformation;	// required
} GetRecordingInformation_RES;

typedef struct
{
	onvif_MediaAttributes	MediaAttributes;
} GetMediaAttributes_RES;

typedef struct
{
	char 	SearchToken[ONVIF_TOKEN_LEN];				// Required, A unique reference to the search session created by this request
} FindRecordings_RES;

typedef struct
{
	onvif_FindRecordingResultList	ResultList;
} GetRecordingSearchResults_RES;

typedef struct
{
	char 	SearchToken[ONVIF_TOKEN_LEN];				// Required, A unique reference to the search session created by this request
} FindEvents_RES;

typedef struct
{
	int		dummy;
} GetEventSearchResults_RES;

typedef struct
{
	onvif_SearchState	State;	
} GetSearchState_RES;

typedef struct
{
	time_t 		Endpoint;								// Required, The point of time the search had reached when it was ended. It is equal to the EndPoint specified in Find-operation if the search was completed
} EndSearch_RES;

typedef struct
{
	ONVIF_OSDConfiguration	* OSDs;					    // This element contains a list of requested OSDs
} GetOSDs_RES;

typedef struct
{
	onvif_OSDConfiguration	OSD;						// required, The requested OSD configuration
} GetOSD_RES;

typedef struct
{
	int		dummy;
} SetOSD_RES;

typedef struct
{
	onvif_OSDConfigurationOptions 	OSDOptions;			// required, 
} GetOSDOptions_RES;

typedef struct
{
	char 	OSDToken[ONVIF_TOKEN_LEN];					// required, Returns Token of the newly created OSD
} CreateOSD_RES;

typedef struct
{
	int		dummy;
} DeleteOSD_RES;

typedef struct
{
    ONVIF_VideoAnalyticsConfiguration * Configurations;
} GetVideoAnalyticsConfigurations_RES;

typedef struct
{
    int		dummy;
} AddVideoAnalyticsConfiguration_RES;

typedef struct
{
    onvif_VideoAnalyticsConfiguration	Configuration;
} GetVideoAnalyticsConfiguration_RES;

typedef struct
{
    int		dummy;
} RemoveVideoAnalyticsConfiguration_RES;

typedef struct
{
    int		dummy;
} SetVideoAnalyticsConfiguration_RES;

typedef struct
{
    onvif_SupportedRules    SupportedRules;
} GetSupportedRules_RES;

typedef struct
{
    int		dummy;
} CreateRules_RES;

typedef struct
{
    int		dummy;
} DeleteRules_RES;

typedef struct
{
    ONVIF_Config * Rule;									// optional
} GetRules_RES;

typedef struct
{
    int		dummy;
} ModifyRules_RES;

typedef struct
{
    int		dummy;
} CreateAnalyticsModules_RES;

typedef struct
{
    int		dummy;
} DeleteAnalyticsModules_RES;

typedef struct
{
    ONVIF_Config * AnalyticsModule;							// optional
} GetAnalyticsModules_RES;

typedef struct
{
    int		dummy;
} ModifyAnalyticsModules_RES;

// onvif media service 2 interfaces

typedef struct
{
    ONVIF_VideoEncoder2Configuration * Configurations;      // This element contains a list of video encoder configurations
} tr2_GetVideoEncoderConfigurations_RES;

typedef struct
{
	ONVIF_VideoEncoder2ConfigurationOptions * Options;	    // required
} tr2_GetVideoEncoderConfigurationOptions_RES;

typedef struct
{
    int		dummy;
} tr2_SetVideoEncoderConfiguration_RES;

typedef struct
{
    char    Token[ONVIF_TOKEN_LEN];                         // required, Token assigned by the device for the newly created profile
} tr2_CreateProfile_RES;

typedef struct
{
    ONVIF_MediaProfile * Profiles;                          // Lists all profiles that exist in the media service. 
                                                            //  The response provides the requested types of Configurations as far as available. 
									                        //  If a profile doesn't contain a type no error shall be provided
} tr2_GetProfiles_RES;

typedef struct
{
    int		dummy;
} tr2_DeleteProfile_RES;

typedef struct
{
    char    Uri[256];	                                    // required, Stable Uri to be used for requesting the media stream
} tr2_GetStreamUri_RES;

typedef struct
{
    ONVIF_VideoSourceConfiguration * Configurations;
} tr2_GetVideoSourceConfigurations_RES;

typedef struct
{
    onvif_VideoSourceConfigurationOptions   Options;
} tr2_GetVideoSourceConfigurationOptions_RES;

typedef struct
{
    int     dummy;
} tr2_SetVideoSourceConfiguration_RES;

typedef struct
{
    int     dummy;
} tr2_SetSynchronizationPoint_RES;

typedef struct
{
    ONVIF_MetadataConfiguration * Configurations;
} tr2_GetMetadataConfigurations_RES;

typedef struct
{
    int     dummy;
} tr2_GetMetadataConfigurationOptions_RES;

typedef struct
{
    int     dummy;
} tr2_SetMetadataConfiguration_RES;

typedef struct
{
    ONVIF_AudioEncoder2Configuration * Configurations;
} tr2_GetAudioEncoderConfigurations_RES;

typedef struct
{
    ONVIF_AudioSourceConfiguration * Configurations;
} tr2_GetAudioSourceConfigurations_RES;

typedef struct
{
    int     dummy;
} tr2_GetAudioSourceConfigurationOptions_RES;

typedef struct
{
    int     dummy;
} tr2_SetAudioSourceConfiguration_RES;

typedef struct
{
    int     dummy;
} tr2_SetAudioEncoderConfiguration_RES;

typedef struct
{
    ONVIF_AudioEncoder2ConfigurationOptions * Options;
} tr2_GetAudioEncoderConfigurationOptions_RES;

typedef struct
{
    int     dummy;
} tr2_AddConfiguration_RES;

typedef struct
{
    int     dummy;
} tr2_RemoveConfiguration_RES;

typedef struct
{
    onvif_EncoderInstanceInfo   Info;	                    // required
} tr2_GetVideoEncoderInstances_RES;

// end of onvif media 2 interfaces

typedef struct
{
    uint32  NextStartReferenceFlag : 1;
    uint32  Reserved               : 31;
    
    char    NextStartReference[ONVIF_TOKEN_LEN];            // optional, StartReference to use in next call to get the following items. If absent, no more items to get
	
	ONVIF_AccessPointInfo * AccessPointInfo;	            // optional, List of AccessPointInfo items
} GetAccessPointInfoList_RES;

typedef struct
{
    ONVIF_AccessPointInfo * AccessPointInfo;	            // List of AccessPointInfo items
} GetAccessPointInfo_RES;

typedef struct
{
    uint32  NextStartReferenceFlag : 1;
    uint32  Reserved               : 31;
    
    char    NextStartReference[ONVIF_TOKEN_LEN];            // optional, StartReference to use in next call to get the following items. If absent, no more items to get
	
	ONVIF_DoorInfo * DoorInfo;	                            // optional, List of DoorInfo items
} GetDoorInfoList_RES;

typedef struct
{
    ONVIF_DoorInfo * DoorInfo;	                            // List of DoorInfo items
} GetDoorInfo_RES;

typedef struct
{
    uint32  NextStartReferenceFlag : 1;
    uint32  Reserved               : 31;
    
    char    NextStartReference[ONVIF_TOKEN_LEN];            // optional, StartReference to use in next call to get the following items. If absent, no more items to get
	
	ONVIF_AreaInfo * AreaInfo;	                            // optional, List of AreaInfo items
} GetAreaInfoList_RES;

typedef struct
{
    ONVIF_AreaInfo * AreaInfo;	                            // List of AreaInfo items
} GetAreaInfo_RES;

typedef struct
{
    BOOL    Enabled;                                        // required, Indicates that the AccessPoint is enabled. 
                                                            //  By default this field value shall be True, if the DisableAccessPoint capabilities is not supported
} GetAccessPointState_RES;

typedef struct
{
    onvif_DoorState DoorState;
} GetDoorState_RES;

typedef struct
{
    int     dummy;
} AccessDoor_RES;

typedef struct
{
    int     dummy;
} LockDoor_RES;

typedef struct
{
    int     dummy;
} UnlockDoor_RES;

typedef struct
{
    int     dummy;
} DoubleLockDoor_RES;

typedef struct
{
    int     dummy;
} BlockDoor_RES;

typedef struct
{
    int     dummy;
} LockDownDoor_RES;

typedef struct
{
    int     dummy;
} LockDownReleaseDoor_RES;

typedef struct
{
    int     dummy;
} LockOpenDoor_RES;

typedef struct
{
    int     dummy;
} LockOpenReleaseDoor_RES;

typedef struct
{
    int     dummy;
} EnableAccessPoint_RES;

typedef struct
{
    int     dummy;
} DisableAccessPoint_RES;

#endif // end of ONVIF_RES_H



