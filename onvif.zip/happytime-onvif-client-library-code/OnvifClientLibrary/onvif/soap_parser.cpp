/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2010-2016, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#include "sys_inc.h"
#include "soap_parser.h"
#include "onvif_utils.h"


/***************************************************************************************/

ONVIF_API BOOL parse_Bool(const char * pdata)
{    
    if (strcasecmp(pdata, "true") == 0)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

/**
 * dn:NetworkVideoTransmitter tds:Device
 */
ONVIF_API int parse_DeviceType(const char * pdata)
{
    const char *p1, *p2;
    char type[256] = {'\0'};
    
    p2 = pdata;
    p1 = strchr(pdata, ' ');
    while (p1)
    {
        strncpy(type, p2, p1-p2);

        if (soap_strcmp(type, "dn:NetworkVideoTransmitter") == 0 || 
		    soap_strcmp(type, "tds:Device") == 0)
        {
            return ODT_NVT;
        }
        else if (soap_strcmp(type, "dn:NetworkVideoDisplay") == 0)
        {
            return ODT_NVD;
        }
        else if (soap_strcmp(type, "dn:NetworkVideoStorage") == 0)
        {
            return ODT_NVS;
        }
        else if (soap_strcmp(type, "dn:NetworkVideoAnalytics") == 0)
        {
            return ODT_NVA;
        }

        p2 = p1+1;
        p1 = strchr(p2, ' ');
    }

	if (p2)
	{
		if (soap_strcmp(p2, "dn:NetworkVideoTransmitter") == 0 || 
		    soap_strcmp(p2, "tds:Device") == 0)
        {
            return ODT_NVT;
        }
        else if (soap_strcmp(p2, "dn:NetworkVideoDisplay") == 0)
        {
            return ODT_NVD;
        }
        else if (soap_strcmp(p2, "dn:NetworkVideoStorage") == 0)
        {
            return ODT_NVS;
        }
        else if (soap_strcmp(p2, "dn:NetworkVideoAnalytics") == 0)
        {
            return ODT_NVA;
        }
	}

    return ODT_NVT;
}

/**
 * http://192.168.5.235/onvif/device_service http://[fe80::c256:e3ff:fea2:e019]/onvif/device_service 
 */
ONVIF_API int parse_XAddr(const char * pdata, onvif_XAddr	* p_xaddr)
{
	return onvif_parse_xaddr(pdata, p_xaddr->host, sizeof(p_xaddr->host), p_xaddr->url, sizeof(p_xaddr->url), &p_xaddr->port, &p_xaddr->https);   
}

int parse_Time(const char * pdata)
{
    return atoi(pdata+2);
}

BOOL parse_XSDDatetime(const char * s, time_t * p)
{
	if (s)
	{ 
		char zone[32];
		struct tm T;
		const char *t;
		
		*zone = '\0';
		memset(&T, 0, sizeof(T));
		
		if (strchr(s, '-'))
		{
			t = "%d-%d-%dT%d:%d:%d%31s";
		}	
		else if (strchr(s, ':'))
		{
			t = "%4d%2d%2dT%d:%d:%d%31s";
		}	
		else /* parse non-XSD-standard alternative ISO 8601 format */
		{
			t = "%4d%2d%2dT%2d%2d%2d%31s";
		}
		
		if (sscanf(s, t, &T.tm_year, &T.tm_mon, &T.tm_mday, &T.tm_hour, &T.tm_min, &T.tm_sec, zone) < 6)
		{
			return FALSE;
		}
		
		if (T.tm_year == 1)
		{
			T.tm_year = 70;
		}	
		else
		{
			T.tm_year -= 1900;
		}
		
		T.tm_mon--;
		
		if (*zone == '.')
		{ 
			for (s = zone + 1; *s; s++)
			{
				if (*s < '0' || *s > '9')
				{
					break;
				}	
			}	
		}
    	else
    	{
      		s = zone;
      	}
      	
		if (*s)
		{
			if (*s == '+' || *s == '-')
			{ 
				int h = 0, m = 0;
				if (s[3] == ':')
				{ 
					/* +hh:mm */
					sscanf(s, "%d:%d", &h, &m);
					if (h < 0)
						m = -m;
				}
				else /* +hhmm */
				{
					m = (int)strtol(s, NULL, 10);
					h = m / 100;
					m = m % 100;
				}
				
				T.tm_min -= m;
				T.tm_hour -= h;
				/* put hour and min in range */
				T.tm_hour += T.tm_min / 60;
				T.tm_min %= 60;
				
				if (T.tm_min < 0)
				{ 
					T.tm_min += 60;
					T.tm_hour--;
				}
				
				T.tm_mday += T.tm_hour / 24;
				T.tm_hour %= 24;
				
				if (T.tm_hour < 0)
				{
					T.tm_hour += 24;
					T.tm_mday--;
				}
				/* note: day of the month may be out of range, timegm() handles it */
			}

			*p = onvif_timegm(&T);
		}
		else /* no UTC or timezone, so assume we got a localtime */
		{ 
			T.tm_isdst = -1;
			*p = mktime(&T);
		}
	}
	
	return TRUE;
}

BOOL parse_XSDDuration(const char *s, int *a)
{ 
	int sign = 1, Y = 0, M = 0, D = 0, H = 0, N = 0, S = 0;
	float f = 0;
	*a = 0;
	if (s)
	{ 
		if (*s == '-')
		{ 
			sign = -1;
			s++;
		}
		if (*s++ != 'P')
			return FALSE;
			
		/* date part */
		while (s && *s)
		{ 
			int n;
			char k;
			if (*s == 'T')
			{ 
				s++;
				break;
			}
			
			if (sscanf(s, "%d%c", &n, &k) != 2)
				return FALSE;
				
			s = strchr(s, k);
			if (!s)
				return FALSE;
				
			switch (k)
			{ 
			case 'Y':
				Y = n;
				break;
				
			case 'M':
				M = n;
				break;
				
			case 'D':
				D = n;
				break;
				
			default:
				return FALSE;
			}
			
			s++;
		}
		
	    /* time part */
	    while (s && *s)
		{ 
			int n;
			char k;
			if (sscanf(s, "%d%c", &n, &k) != 2)
				return FALSE;
				
			s = strchr(s, k);
			if (!s)
				return FALSE;
				
			switch (k)
			{ 
			case 'H':
				H = n;
				break;
				
			case 'M':
				N = n;
				break;
				
			case '.':
				S = n;
				if (sscanf(s, "%g", &f) != 1)
					return FALSE;
				s = NULL;
				continue;
				
			case 'S':
				S = n;
				break;
				
			default:
				return FALSE;
			}
			
			s++;
		}
	    /* convert Y-M-D H:N:S.f to signed long long int */
	    *a = sign * ((((((((((Y * 12) + M) * 30) + D) * 24) + H) * 60) + N) * 60) + S);
	}

	return TRUE;
}

BOOL parse_Fault(XMLN * p_node, onvif_Fault * p_res)
{
    XMLN * p_Fault;
    
    p_Fault = xml_node_soap_get(p_node, "Fault");
	if (p_Fault)
	{
	    XMLN * p_Code;
	    XMLN * p_Reason;	    

	    p_Code = xml_node_soap_get(p_Fault, "Code");
	    if (p_Code)
	    {
	        XMLN * p_Value;
	        XMLN * p_Subcode;

	        p_Value = xml_node_soap_get(p_Code, "Value");
	        if (p_Value && p_Value->data)
	        {
	            strncpy(p_res->Code, p_Value->data, sizeof(p_res->Code)-1);
	        }

	        p_Subcode = xml_node_soap_get(p_Code, "Subcode");
	        if (p_Subcode)
	        {
	            p_Value = xml_node_soap_get(p_Subcode, "Value");
    	        if (p_Value && p_Value->data)
    	        {
    	            strncpy(p_res->Subcode, p_Value->data, sizeof(p_res->Subcode)-1);
    	        }
	        }
	    }

	    p_Reason = xml_node_soap_get(p_Fault, "Reason");
	    if (p_Reason)
	    {
	        XMLN * p_Text;

	        p_Text = xml_node_soap_get(p_Reason, "Text");
	        if (p_Text && p_Text->data)
	        {
	            strncpy(p_res->Reason, p_Text->data, sizeof(p_res->Reason)-1);
	        }
	    }

	    return TRUE;
	}
    else
    {
        return FALSE;
    }	
}

/* format : "1.0 2.0" */
BOOL parse_FloatRangeList(const char * p_buff, onvif_FloatRange * p_range)
{
    int i = 0;
    float min = 0.0, max = 0.0;
    const char * p_buf = p_buff;
    char p_min[32];
    
    // remove space
    while (*p_buf != '\0') 
    {
        if (*p_buf == ' ') p_buf++;
        else break;
    }
    
    while (*p_buf != '\0') 
    {
        if (*p_buf == ' ')
        {
            p_buf++;
            break;
        }
        else if (i < 31)
        {
            p_min[i++] = *p_buf;
            p_buf++;
        }
    }

    p_min[i] = '\0';
    min = (float)atof(p_min);

    while (*p_buf != '\0')
    {
        if (*p_buf == ' ') p_buf++;
        else break;
    }

    if (p_buf)
    {
        max = (float)atof(p_buf);
    }

    if (min < max)
    {
        p_range->Min = min;
        p_range->Max = max;

        return TRUE;
    }
    
    return FALSE;
}

BOOL parse_IntList(XMLN * p_node, onvif_IntList * p_req)
{
	XMLN * p_Items;

	p_Items = xml_node_soap_get(p_node, "Items");
    while (p_Items && soap_strcmp(p_Items->name, "Items") == 0)
    {
    	int idx = p_req->sizeItems;

    	p_req->Items[idx] = atoi(p_Items->data);

    	p_req->sizeItems++;
    	if (p_req->sizeItems >= 10)
    	{
    		break;
    	}

		p_Items = p_Items->next;
    }

    return TRUE;
}

BOOL parse_FloatRange(XMLN * p_node, onvif_FloatRange * p_res)
{
	XMLN * p_Min;
	XMLN * p_Max;

	p_Min = xml_node_soap_get(p_node, "Min");
	if (p_Min && p_Min->data)
	{
		p_res->Min = (float)atof(p_Min->data);
	}
	
	p_Max = xml_node_soap_get(p_node, "Max");
	if (p_Max && p_Max->data)
	{
		p_res->Max = (float)atof(p_Max->data);
	}

	return TRUE;
}

/* format : "JPEG MPEG4 H264 G711 G726 AAC" */
BOOL parse_EncodingList(const char * p_encoding, onvif_RecordingCapabilities * p_cap)
{
    int i = 0;
    const char * p_buf = p_encoding;
    char p_buff[32];

    while (*p_buf != '\0')
    {
        // remove space
        while (*p_buf != '\0') 
        {
            if (*p_buf == ' ') p_buf++;
            else break;
        }

        i = 0;
        while (*p_buf != '\0') 
        {
            if (*p_buf == ' ')
            {
                p_buf++;
                break;
            }
            else if (i < 31)
            {
                p_buff[i++] = *p_buf;
                p_buf++;
            }
        }

        p_buff[i] = '\0';

        if (strcasecmp(p_buff, "JPEG") == 0)
        {
            p_cap->JPEG = 1;
        }
        else if (strcasecmp(p_buff, "MPEG4") == 0)
        {
            p_cap->MPEG4 = 1;
        }
        else if (strcasecmp(p_buff, "H264") == 0)
        {
            p_cap->H264 = 1;
        }
        else if (strcasecmp(p_buff, "G711") == 0)
        {
            p_cap->G711 = 1;
        }
        else if (strcasecmp(p_buff, "G726") == 0)
        {
            p_cap->G726 = 1;
        }
        else if (strcasecmp(p_buff, "AAC") == 0)
        {
            p_cap->AAC = 1;
        }
    }
    
    return TRUE;
}

ONVIF_RET parse_Vector(XMLN * p_node, onvif_Vector * p_req)
{
	const char * p_x;
	const char * p_y;
	
	p_x = xml_attr_get(p_node, "x");
	if (p_x)
	{			
		p_req->x = (float)atof(p_x);
	}

	p_y = xml_attr_get(p_node, "y");
	if (p_y)
	{
		p_req->y = (float)atof(p_y);
	}

	return ONVIF_OK;
}

ONVIF_RET parse_Vector1D(XMLN * p_node, onvif_Vector1D * p_req)
{
	const char * p_x;
	
	p_x = xml_attr_get(p_node, "x");
	if (p_x)
	{			
		p_req->x = (float)atof(p_x);
	}

	return ONVIF_OK;
}

ONVIF_RET parse_PTZSpeed(XMLN * p_node, onvif_PTZSpeed * p_req)
{
	XMLN * p_PanTilt;
	XMLN * p_Zoom;

	p_PanTilt = xml_node_soap_get(p_node, "PanTilt");
	if (p_PanTilt)
	{
		p_req->PanTiltFlag = 1;		
		parse_Vector(p_PanTilt, &p_req->PanTilt);
	}

	p_Zoom = xml_node_soap_get(p_node, "Zoom");
	if (p_Zoom)
	{
		p_req->ZoomFlag = 1;		
		parse_Vector1D(p_Zoom, &p_req->Zoom);
	}

	return ONVIF_OK;
}

ONVIF_RET parse_PTZVector(XMLN * p_node, onvif_PTZVector * p_req)
{
	XMLN * p_PanTilt;
	XMLN * p_Zoom;

	p_PanTilt = xml_node_soap_get(p_node, "PanTilt");
	if (p_PanTilt)
	{	
		p_req->PanTiltFlag = 1;		
		parse_Vector(p_PanTilt, &p_req->PanTilt);
	}

	p_Zoom = xml_node_soap_get(p_node, "Zoom");
	if (p_Zoom)
	{	
		p_req->ZoomFlag = 1;		
		parse_Vector1D(p_Zoom, &p_req->Zoom);
	}

	return ONVIF_OK;
}


/***************************************************************************************/

BOOL parse_AnalyticsCapabilities(XMLN * p_node, onvif_AnalyticsCapabilities * p_cap)
{
	XMLN * p_XAddr;
	XMLN * p_RuleSupport;
	XMLN * p_AnalyticsModuleSupport;

	p_XAddr = xml_node_soap_get(p_node, "XAddr");
    if (p_XAddr && p_XAddr->data)
    {
		parse_XAddr(p_XAddr->data, &p_cap->XAddr);
    }
    else
    {
        return FALSE;
    }

    p_RuleSupport = xml_node_soap_get(p_node, "RuleSupport");
	if (p_RuleSupport && p_RuleSupport->data)
	{
		p_cap->RuleSupport = parse_Bool(p_RuleSupport->data);
	}

	p_AnalyticsModuleSupport = xml_node_soap_get(p_node, "_AnalyticsModuleSupport");
	if (p_AnalyticsModuleSupport && p_AnalyticsModuleSupport->data)
	{
		p_cap->AnalyticsModuleSupport = parse_Bool(p_AnalyticsModuleSupport->data);
	}

	return TRUE;
}

BOOL parse_DeviceCapabilities(XMLN * p_node, onvif_DevicesCapabilities * p_cap)
{
	XMLN * p_XAddr;
	XMLN * p_Network;
	XMLN * p_System;
	XMLN * p_Security;

	p_XAddr = xml_node_soap_get(p_node, "XAddr");
    if (p_XAddr && p_XAddr->data)
    {
		parse_XAddr(p_XAddr->data, &p_cap->XAddr);
    }
    else
    {
        return FALSE;
    }

	p_Network = xml_node_soap_get(p_node, "Network");
	if (p_Network)
	{
		XMLN * p_IPFilter;
		XMLN * p_ZeroConfiguration;
		XMLN * p_IPVersion6;
		XMLN * p_DynDNS;
		XMLN * p_Extension;

		p_IPFilter = xml_node_soap_get(p_Network, "IPFilter");
		if (p_IPFilter && p_IPFilter->data)
		{
			p_cap->IPFilter = parse_Bool(p_IPFilter->data);
		}

		p_ZeroConfiguration = xml_node_soap_get(p_Network, "ZeroConfiguration");
		if (p_ZeroConfiguration && p_ZeroConfiguration->data)
		{
			p_cap->ZeroConfiguration = parse_Bool(p_ZeroConfiguration->data);
		}

		p_IPVersion6 = xml_node_soap_get(p_Network, "IPVersion6");
		if (p_IPVersion6 && p_IPVersion6->data)
		{
			p_cap->IPVersion6 = parse_Bool(p_IPVersion6->data);
		}

		p_DynDNS = xml_node_soap_get(p_Network, "DynDNS");
		if (p_DynDNS && p_DynDNS->data)
		{
			p_cap->DynDNS = parse_Bool(p_DynDNS->data);
		}

		p_Extension = xml_node_soap_get(p_Network, "Extension");
		if (p_Extension)
		{
		    XMLN * p_Dot11Configuration;
		    
			p_Dot11Configuration = xml_node_soap_get(p_Extension, "Dot11Configuration");
    		if (p_Dot11Configuration && p_Dot11Configuration->data)
    		{
    			p_cap->Dot11Configuration = parse_Bool(p_Dot11Configuration->data);
    		}
		}
	}

    p_System = xml_node_soap_get(p_node, "System");
	if (p_System)
	{
		XMLN * p_DiscoveryResolve;
		XMLN * p_DiscoveryBye;
		XMLN * p_RemoteDiscovery;
		XMLN * p_SystemBackup;
		XMLN * p_SystemLogging;
		XMLN * p_FirmwareUpgrade;
		XMLN * p_Extension;

		p_DiscoveryResolve = xml_node_soap_get(p_System, "DiscoveryResolve");
		if (p_DiscoveryResolve && p_DiscoveryResolve->data)
		{
			p_cap->DiscoveryResolve = parse_Bool(p_DiscoveryResolve->data);
		}

		p_DiscoveryBye = xml_node_soap_get(p_System, "DiscoveryBye");
		if (p_DiscoveryBye && p_DiscoveryBye->data)
		{
			p_cap->DiscoveryBye = parse_Bool(p_DiscoveryBye->data);
		}

		p_RemoteDiscovery = xml_node_soap_get(p_System, "RemoteDiscovery");
		if (p_RemoteDiscovery && p_RemoteDiscovery->data)
		{
			p_cap->RemoteDiscovery = parse_Bool(p_RemoteDiscovery->data);
		}

		p_SystemBackup = xml_node_soap_get(p_System, "SystemBackup");
		if (p_SystemBackup && p_SystemBackup->data)
		{
			p_cap->SystemBackup = parse_Bool(p_SystemBackup->data);
		}

		p_SystemLogging = xml_node_soap_get(p_System, "SystemLogging");
		if (p_SystemLogging && p_SystemLogging->data)
		{
			p_cap->SystemLogging = parse_Bool(p_SystemLogging->data);
		}

		p_FirmwareUpgrade = xml_node_soap_get(p_System, "FirmwareUpgrade");
		if (p_FirmwareUpgrade && p_FirmwareUpgrade->data)
		{
			p_cap->FirmwareUpgrade = parse_Bool(p_FirmwareUpgrade->data);
		}

		p_Extension = xml_node_soap_get(p_System, "Extension");
		if (p_Extension)
		{
		    XMLN * p_HttpFirmwareUpgrade;
		    XMLN * p_HttpSystemBackup;
		    XMLN * p_HttpSystemLogging;
		    XMLN * p_HttpSupportInformation;
		    
			p_HttpFirmwareUpgrade = xml_node_soap_get(p_Extension, "HttpFirmwareUpgrade");
    		if (p_HttpFirmwareUpgrade && p_HttpFirmwareUpgrade->data)
    		{
    			p_cap->HttpFirmwareUpgrade = parse_Bool(p_HttpFirmwareUpgrade->data);
    		}

    		p_HttpSystemBackup = xml_node_soap_get(p_Extension, "HttpSystemBackup");
    		if (p_HttpSystemBackup && p_HttpSystemBackup->data)
    		{
    			p_cap->HttpSystemBackup = parse_Bool(p_HttpSystemBackup->data);
    		}

    		p_HttpSystemLogging = xml_node_soap_get(p_Extension, "HttpSystemLogging");
    		if (p_HttpSystemLogging && p_HttpSystemLogging->data)
    		{
    			p_cap->HttpSystemLogging = parse_Bool(p_HttpSystemLogging->data);
    		}

    		p_HttpSupportInformation = xml_node_soap_get(p_Extension, "HttpSupportInformation");
    		if (p_HttpSupportInformation && p_HttpSupportInformation->data)
    		{
    			p_cap->HttpSupportInformation = parse_Bool(p_HttpSupportInformation->data);
    		}
		}
	}

    p_Security = xml_node_soap_get(p_node, "Security");
	if (p_Security)
    {
        XMLN * p_TLS11;
        XMLN * p_TLS12;
        XMLN * p_OnboardKeyGeneration;
        XMLN * p_AccessPolicyConfig;
        XMLN * p_X509Token;
        XMLN * p_SAMLToken;
        XMLN * p_KerberosToken;
        XMLN * p_RELToken;
        XMLN * p_Extension;

        p_TLS11 = xml_node_soap_get(p_Security, "TLS1.1");
		if (p_TLS11 && p_TLS11->data)
		{
			p_cap->TLS11 = parse_Bool(p_TLS11->data);
		}

		p_TLS12 = xml_node_soap_get(p_Security, "TLS1.2");
		if (p_TLS12 && p_TLS12->data)
		{
			p_cap->TLS12 = parse_Bool(p_TLS12->data);
		}

		p_OnboardKeyGeneration = xml_node_soap_get(p_Security, "OnboardKeyGeneration");
		if (p_OnboardKeyGeneration && p_OnboardKeyGeneration->data)
		{
			p_cap->OnboardKeyGeneration = parse_Bool(p_OnboardKeyGeneration->data);
		}

		p_AccessPolicyConfig = xml_node_soap_get(p_Security, "AccessPolicyConfig");
		if (p_AccessPolicyConfig && p_AccessPolicyConfig->data)
		{
			p_cap->AccessPolicyConfig = parse_Bool(p_AccessPolicyConfig->data);
		}

		p_X509Token = xml_node_soap_get(p_Security, "X.509Token");
		if (p_X509Token && p_X509Token->data)
		{
			p_cap->X509Token = parse_Bool(p_X509Token->data);
		}

		p_SAMLToken = xml_node_soap_get(p_Security, "SAMLToken");
		if (p_SAMLToken && p_SAMLToken->data)
		{
			p_cap->SAMLToken = parse_Bool(p_SAMLToken->data);
		}

		p_KerberosToken = xml_node_soap_get(p_Security, "KerberosToken");
		if (p_KerberosToken && p_KerberosToken->data)
		{
			p_cap->KerberosToken = parse_Bool(p_KerberosToken->data);
		}

		p_RELToken = xml_node_soap_get(p_Security, "RELToken");
		if (p_RELToken && p_RELToken->data)
		{
			p_cap->RELToken = parse_Bool(p_RELToken->data);
		}

		p_Extension = xml_node_soap_get(p_Security, "Extension");
		if (p_Extension)
		{
		    XMLN * p_TLS10;
		    XMLN * p_Extension1;
		    
			p_TLS10 = xml_node_soap_get(p_Extension, "TLS1.0");
    		if (p_TLS10 && p_TLS10->data)
    		{
    			p_cap->TLS10 = parse_Bool(p_TLS10->data);
    		}

    		p_Extension1 = xml_node_soap_get(p_Extension, "Extension");
    		if (p_Extension1)
    		{
    		    XMLN * p_Dot1X;
    		    XMLN * p_SupportedEAPMethod;
    		    XMLN * p_RemoteUserHandling;
    		    
    		    p_Dot1X = xml_node_soap_get(p_Extension1, "Dot1X");
        		if (p_Dot1X && p_Dot1X->data)
        		{
        			p_cap->Dot1X = parse_Bool(p_Dot1X->data);
        		}

        		p_SupportedEAPMethod = xml_node_soap_get(p_Extension1, "SupportedEAPMethod");
        		if (p_SupportedEAPMethod && p_SupportedEAPMethod->data)
        		{
        			p_cap->SupportedEAPMethods = atoi(p_SupportedEAPMethod->data);
        		}

        		p_RemoteUserHandling = xml_node_soap_get(p_Extension1, "RemoteUserHandling");
        		if (p_RemoteUserHandling && p_RemoteUserHandling->data)
        		{
        			p_cap->RemoteUserHandling = atoi(p_RemoteUserHandling->data);
        		}
    		}
		}
    }
    
	return TRUE;
}

BOOL parse_EventsCapabilities(XMLN * p_node, onvif_EventCapabilities * p_cap)
{
	XMLN * p_XAddr;
	XMLN * p_WSSubscriptionPolicySupport;
	XMLN * p_WSPullPointSupport;
	XMLN * p_WSPausableSubscriptionManagerInterfaceSupport;

	p_XAddr = xml_node_soap_get(p_node, "XAddr");
    if (p_XAddr && p_XAddr->data)
    {
        parse_XAddr(p_XAddr->data, &p_cap->XAddr);
    }
    else
    {
        return FALSE;
    }

    p_WSSubscriptionPolicySupport = xml_node_soap_get(p_node, "WSSubscriptionPolicySupport");
    if (p_WSSubscriptionPolicySupport && p_WSSubscriptionPolicySupport->data)
	{
		p_cap->WSSubscriptionPolicySupport = parse_Bool(p_WSSubscriptionPolicySupport->data);
    }

    p_WSPullPointSupport = xml_node_soap_get(p_node, "WSPullPointSupport");
    if (p_WSPullPointSupport && p_WSPullPointSupport->data)
	{
		p_cap->WSPullPointSupport = parse_Bool(p_WSPullPointSupport->data);
    }

    p_WSPausableSubscriptionManagerInterfaceSupport = xml_node_soap_get(p_node, "WSPausableSubscriptionManagerInterfaceSupport");
    if (p_WSPausableSubscriptionManagerInterfaceSupport && p_WSPausableSubscriptionManagerInterfaceSupport->data)
	{
		p_cap->WSPausableSubscriptionManagerInterfaceSupport = parse_Bool(p_WSPausableSubscriptionManagerInterfaceSupport->data);
    }

    return TRUE;
}

BOOL parse_ImageCapabilities(XMLN * p_node, onvif_ImagingCapabilities * p_cap)
{
	XMLN * p_XAddr = xml_node_soap_get(p_node, "XAddr");
    if (p_XAddr && p_XAddr->data)
    {
        parse_XAddr(p_XAddr->data, &p_cap->XAddr);
    }
    else
    {
        return FALSE;
    }

    return TRUE;
}

BOOL parse_MediaCapabilities(XMLN * p_node, onvif_MediaCapabilities * p_cap)
{
    XMLN * p_XAddr;
	XMLN * p_StreamingCapabilities;
	XMLN * p_Extension;

	p_XAddr = xml_node_soap_get(p_node, "XAddr");
    if (p_XAddr && p_XAddr->data)
    {
        parse_XAddr(p_XAddr->data, &p_cap->XAddr);
    }
    else
    {
        return FALSE;
    }

    p_StreamingCapabilities = xml_node_soap_get(p_node, "StreamingCapabilities");
    if (p_StreamingCapabilities)
    {
        XMLN * p_RTPMulticast;
		XMLN * p_RTP_TCP;
		XMLN * p_RTP_RTSP_TCP;

		p_RTPMulticast = xml_node_soap_get(p_StreamingCapabilities, "RTPMulticast");
	    if (p_RTPMulticast && p_RTPMulticast->data)
	    {
	        p_cap->RTPMulticast = parse_Bool(p_RTPMulticast->data);
	    }

		p_RTP_TCP = xml_node_soap_get(p_StreamingCapabilities, "RTP_TCP");
	    if (p_RTP_TCP && p_RTP_TCP->data)
	    {
	        p_cap->RTP_TCP = parse_Bool(p_RTP_TCP->data);
	    }

	    p_RTP_RTSP_TCP = xml_node_soap_get(p_StreamingCapabilities, "RTP_RTSP_TCP");
	    if (p_RTP_RTSP_TCP && p_RTP_RTSP_TCP->data)
	    {
	        p_cap->RTP_RTSP_TCP = parse_Bool(p_RTP_RTSP_TCP->data);
	    } 
    }

    p_Extension = xml_node_soap_get(p_node, "Extension");
    if (p_Extension)
    {
        XMLN * p_ProfileCapabilities;
        
        p_ProfileCapabilities = xml_node_soap_get(p_Extension, "ProfileCapabilities");
        if (p_ProfileCapabilities)
        {
            XMLN * p_MaximumNumberOfProfiles;
            
            p_MaximumNumberOfProfiles = xml_node_soap_get(p_ProfileCapabilities, "MaximumNumberOfProfiles");
            if (p_MaximumNumberOfProfiles && p_MaximumNumberOfProfiles->data)
            {
                p_cap->MaximumNumberOfProfiles = atoi(p_MaximumNumberOfProfiles->data);
            }
        }
    }
					
    return TRUE;
}

BOOL parse_PTZCapabilities(XMLN * p_node, onvif_PTZCapabilities * p_cap)
{
    XMLN * p_XAddr = xml_node_soap_get(p_node, "XAddr");
    if (p_XAddr && p_XAddr->data)
    {
        parse_XAddr(p_XAddr->data, &p_cap->XAddr);
    }
    else
    {
        return FALSE;
    }
    
    return TRUE;
}

BOOL parse_RecordingCapabilities(XMLN * p_node, onvif_RecordingCapabilities * p_cap)
{
    XMLN * p_XAddr;
	XMLN * p_ReceiverSource;
	XMLN * p_MediaProfileSource;
	XMLN * p_DynamicRecordings;
	XMLN * p_DynamicTracks;
	XMLN * p_MaxStringLength;
	
	p_XAddr = xml_node_soap_get(p_node, "XAddr");
    if (p_XAddr && p_XAddr->data)
    {
        parse_XAddr(p_XAddr->data, &p_cap->XAddr);
    }
    else
    {
        return FALSE;
    }

    p_ReceiverSource = xml_node_soap_get(p_node, "ReceiverSource");
    if (p_ReceiverSource && p_ReceiverSource->data)
    {
        p_cap->ReceiverSource = parse_Bool(p_ReceiverSource->data);
    }

    p_MediaProfileSource = xml_node_soap_get(p_node, "MediaProfileSource");
    if (p_MediaProfileSource && p_MediaProfileSource->data)
    {
        p_cap->MediaProfileSource = parse_Bool(p_MediaProfileSource->data);
    }

    p_DynamicRecordings = xml_node_soap_get(p_node, "DynamicRecordings");
    if (p_DynamicRecordings && p_DynamicRecordings->data)
    {
        p_cap->DynamicRecordings = parse_Bool(p_DynamicRecordings->data);
    }

    p_DynamicTracks = xml_node_soap_get(p_node, "DynamicTracks");
    if (p_DynamicTracks && p_DynamicTracks->data)
    {
        p_cap->DynamicTracks = parse_Bool(p_DynamicTracks->data);
    }

    p_MaxStringLength = xml_node_soap_get(p_node, "MaxStringLength");
    if (p_MaxStringLength && p_MaxStringLength->data)
    {
        p_cap->MaxStringLength = atoi(p_MaxStringLength->data);
    }
    
    return TRUE;
}

BOOL parse_SearchCapabilities(XMLN * p_node, onvif_SearchCapabilities * p_cap)
{
    XMLN * p_XAddr;
	XMLN * p_MetadataSearch;

	p_XAddr = xml_node_soap_get(p_node, "XAddr");
    if (p_XAddr && p_XAddr->data)
    {
        parse_XAddr(p_XAddr->data, &p_cap->XAddr);
    }
    else
    {
        return FALSE;
    }

    p_MetadataSearch = xml_node_soap_get(p_node, "MetadataSearch");
    if (p_MetadataSearch && p_MetadataSearch->data)
    {
        p_cap->MetadataSearch = parse_Bool(p_MetadataSearch->data);
    }

    return TRUE;
}

BOOL parse_ReplayCapabilities(XMLN * p_node, onvif_ReplayCapabilities * p_cap)
{
    XMLN * p_XAddr = xml_node_soap_get(p_node, "XAddr");
    if (p_XAddr && p_XAddr->data)
    {
        parse_XAddr(p_XAddr->data, &p_cap->XAddr);
    }
    else
    {
        return FALSE;
    }

    return TRUE;
}

BOOL parse_VideoSourceConfiguration(XMLN * p_node, onvif_VideoSourceConfiguration * p_res)
{
    XMLN * p_Name;
	XMLN * p_UseCount;
	XMLN * p_SourceToken;
	XMLN * p_Bounds;
	XMLN * p_Extension;

	p_Name = xml_node_soap_get(p_node, "Name");
    if (p_Name && p_Name->data)
    {
        strncpy(p_res->Name, p_Name->data, sizeof(p_res->Name)-1);
    }

    p_UseCount = xml_node_soap_get(p_node, "UseCount");
    if (p_UseCount && p_UseCount->data)
    {
        p_res->UseCount = atoi(p_UseCount->data);
    }

    p_SourceToken = xml_node_soap_get(p_node, "SourceToken");
    if (p_SourceToken && p_SourceToken->data)
    {
        strncpy(p_res->SourceToken, p_SourceToken->data, sizeof(p_res->SourceToken)-1);
    }

    p_Bounds = xml_node_soap_get(p_node, "Bounds");
    if (p_Bounds)
    {
    	const char * p_height;
		const char * p_width;
		const char * p_x;
		const char * p_y;

		p_height = xml_attr_get(p_Bounds, "height");
    	if (p_height)
    	{
        	p_res->Bounds.height = atoi(p_height);
        }

        p_width = xml_attr_get(p_Bounds, "width");
        if (p_width)
        {
        	p_res->Bounds.width = atoi(p_width);
        }

        p_x = xml_attr_get(p_Bounds, "x");
        if (p_x)
        {
        	p_res->Bounds.x = atoi(p_x);
        }

        p_y = xml_attr_get(p_Bounds, "y");
        if (p_y)
        {
        	p_res->Bounds.y = atoi(p_y);
        }	
    }

    p_Extension = xml_node_soap_get(p_node, "Extension");
    if (p_Extension)
    {
    	XMLN * p_Rotate;
    	
    	p_res->ExtensionFlag = 1;

    	p_Rotate = xml_node_soap_get(p_Extension, "Rotate");
    	if (p_Rotate)
    	{
    		p_res->Extension.RotateFlag = 1;

    		XMLN * p_Mode;
    		XMLN * p_Degree;

    		p_Mode = xml_node_soap_get(p_Rotate, "Mode");
    		if (p_Mode && p_Mode->data)
    		{
    			p_res->Extension.Rotate.Mode = onvif_StringToRotateMode(p_Mode->data);
    		}

    		p_Degree = xml_node_soap_get(p_Rotate, "Degree");
    		if (p_Degree && p_Degree->data)
    		{
    			p_res->Extension.Rotate.DegreeFlag = 1;
    			p_res->Extension.Rotate.Degree = atoi(p_Degree->data);
    		}
    	}
    }
    
    return TRUE;
}

BOOL parse_AudioSourceConfiguration(XMLN * p_node, onvif_AudioSourceConfiguration * p_res)
{
    XMLN * p_Name;
	XMLN * p_UseCount;
	XMLN * p_SourceToken;

	p_Name = xml_node_soap_get(p_node, "Name");
    if (p_Name && p_Name->data)
    {
        strncpy(p_res->Name, p_Name->data, sizeof(p_res->Name)-1);
    }

    p_UseCount = xml_node_soap_get(p_node, "UseCount");
    if (p_UseCount && p_UseCount->data)
    {
        p_res->UseCount = atoi(p_UseCount->data);
    }

    p_SourceToken = xml_node_soap_get(p_node, "SourceToken");
    if (p_SourceToken && p_SourceToken->data)
    {
        strncpy(p_res->SourceToken, p_SourceToken->data, sizeof(p_res->SourceToken)-1);
    }
    
    return TRUE;
}

BOOL parse_MulticastConfiguration(XMLN * p_node, onvif_MulticastConfiguration * p_res)
{
	XMLN * p_Address;
	XMLN * p_Port;
	XMLN * p_TTL;
	
	p_Address = xml_node_soap_get(p_node, "Address");
    if (p_Address)
    {
    	XMLN * p_IPv4Address;

    	p_IPv4Address = xml_node_soap_get(p_Address, "IPv4Address");
    	if (p_IPv4Address && p_IPv4Address->data)
    	{
    		strncpy(p_res->IPv4Address, p_IPv4Address->data, sizeof(p_res->IPv4Address)-1);
    	}
    }

    p_Port = xml_node_soap_get(p_node, "Port");
    if (p_Port && p_Port->data)
    {
    	p_res->Port = atoi(p_Port->data);
    }

    p_TTL = xml_node_soap_get(p_node, "TTL");
    if (p_TTL && p_TTL->data)
    {
    	p_res->TTL = atoi(p_TTL->data);
    }

    return TRUE;
}

BOOL parse_Resolution(XMLN * p_node, onvif_VideoResolution * p_res)
{
	XMLN * p_Width;
	XMLN * p_Height;

	p_Width = xml_node_soap_get(p_node, "Width");
    if (p_Width && p_Width->data)
    {
        p_res->Width = atoi(p_Width->data);
    }

    p_Height = xml_node_soap_get(p_node, "Height");
    if (p_Height && p_Height->data)
    {
        p_res->Height = atoi(p_Height->data);
    }

	return TRUE;
}

BOOL parse_VideoEncoderConfiguration(XMLN * p_node, onvif_VideoEncoderConfiguration * p_res)
{
    XMLN * p_Name;
	XMLN * p_UseCount;
	XMLN * p_Encoding;
	XMLN * p_Resolution;
	XMLN * p_Quality;
	XMLN * p_RateControl;
	XMLN * p_Multicast;
	XMLN * p_SessionTimeout;
	
	p_Name = xml_node_soap_get(p_node, "Name");
    if (p_Name && p_Name->data)
    {
        strncpy(p_res->Name, p_Name->data, sizeof(p_res->Name));
    }
    else
    {
        return FALSE;
    }

    p_UseCount = xml_node_soap_get(p_node, "UseCount");
    if (p_UseCount && p_UseCount->data)
    {
        p_res->UseCount = atoi(p_UseCount->data);
    }

    p_Encoding = xml_node_soap_get(p_node, "Encoding");
    if (p_Encoding && p_Encoding->data)
    {
    	p_res->Encoding = onvif_StringToVideoEncoding(p_Encoding->data);
    }
    else
    {
        return FALSE;
    }

    p_Resolution = xml_node_soap_get(p_node, "Resolution");
    if (p_Resolution)
    {
        parse_Resolution(p_Resolution, &p_res->Resolution);
    }

    p_Quality = xml_node_soap_get(p_node, "Quality");
    if (p_Quality && p_Quality->data)
    {
        p_res->Quality = atoi(p_Quality->data);
    }

    p_RateControl = xml_node_soap_get(p_node, "RateControl");
    if (p_RateControl)
    {
        XMLN * p_FrameRateLimit;
		XMLN * p_EncodingInterval;
		XMLN * p_BitrateLimit;
		const char * p_ConstantBitRate;

		p_res->RateControlFlag = 1;

		p_ConstantBitRate = xml_attr_get(p_RateControl, "p_ConstantBitRate");
		if (p_ConstantBitRate)
		{
		    p_res->RateControl.ConstantBitRateFlag = 1;
		    p_res->RateControl.ConstantBitRate = parse_Bool(p_ConstantBitRate);
		}
		
		p_FrameRateLimit = xml_node_soap_get(p_RateControl, "FrameRateLimit");
        if (p_FrameRateLimit && p_FrameRateLimit->data)
        {
            p_res->RateControl.FrameRateLimit = atoi(p_FrameRateLimit->data);
        }

        p_EncodingInterval = xml_node_soap_get(p_RateControl, "EncodingInterval");
        if (p_EncodingInterval && p_EncodingInterval->data)
        {
            p_res->RateControl.EncodingInterval = atoi(p_EncodingInterval->data);
        }

        p_BitrateLimit = xml_node_soap_get(p_RateControl, "BitrateLimit");
        if (p_BitrateLimit && p_BitrateLimit->data)
        {
            p_res->RateControl.BitrateLimit = atoi(p_BitrateLimit->data);
        }
    }

    if (VideoEncoding_H264 == p_res->Encoding)
    {
        XMLN * p_H264 = xml_node_soap_get(p_node, "H264");
        if (p_H264)
        {
            XMLN * p_GovLength;
			XMLN * p_H264Profile;

			p_res->H264Flag = 1;
			
			p_GovLength = xml_node_soap_get(p_H264, "GovLength");
            if (p_GovLength && p_GovLength->data)
            {
                p_res->H264.GovLength = atoi(p_GovLength->data);
            }

            p_H264Profile = xml_node_soap_get(p_H264, "H264Profile");
            if (p_H264Profile && p_H264Profile->data)
            {
            	p_res->H264.H264Profile = onvif_StringToH264Profile(p_H264Profile->data);
            }
        }    
    }
    if (VideoEncoding_MPEG4 == p_res->Encoding)
    {
    	XMLN * p_MPEG4 = xml_node_soap_get(p_node, "MPEG4");
        if (p_MPEG4)
        {
            XMLN * p_GovLength;
			XMLN * p_Mpeg4Profile;

			p_res->MPEG4Flag = 1;
			
			p_GovLength = xml_node_soap_get(p_MPEG4, "GovLength");
            if (p_GovLength && p_GovLength->data)
            {
                p_res->MPEG4.GovLength = atoi(p_GovLength->data);
            }

            p_Mpeg4Profile = xml_node_soap_get(p_MPEG4, "Mpeg4Profile");
            if (p_Mpeg4Profile && p_Mpeg4Profile->data)
            {
                p_res->MPEG4.Mpeg4Profile = onvif_StringToMpeg4Profile(p_Mpeg4Profile->data);
            }
        }
    }

    p_Multicast = xml_node_soap_get(p_node, "Multicast");
    if (p_Multicast)
    {
    	parse_MulticastConfiguration(p_Multicast, &p_res->Multicast);
    }
    
	p_SessionTimeout = xml_node_soap_get(p_node, "SessionTimeout");
	if (p_SessionTimeout && p_SessionTimeout->data)
	{
		parse_XSDDuration(p_SessionTimeout->data, &p_res->SessionTimeout);
	}
					
    return TRUE;
}

BOOL parse_AudioEncoderConfiguration(XMLN * p_node, onvif_AudioEncoderConfiguration * p_res)
{
    XMLN * p_Name;
	XMLN * p_UseCount;
	XMLN * p_Encoding;
	XMLN * p_Bitrate;
	XMLN * p_SampleRate;
	XMLN * p_Multicast;
	XMLN * p_SessionTimeout;

	p_Name = xml_node_soap_get(p_node, "Name");
    if (p_Name && p_Name->data)
    {
        strncpy(p_res->Name, p_Name->data, sizeof(p_res->Name));
    }
    else
    {
        return FALSE;
    }

    p_UseCount = xml_node_soap_get(p_node, "UseCount");
    if (p_UseCount && p_UseCount->data)
    {
        p_res->UseCount = atoi(p_UseCount->data);
    }

    p_Encoding = xml_node_soap_get(p_node, "Encoding");
    if (p_Encoding && p_Encoding->data)
    {
        p_res->Encoding = onvif_StringToAudioEncoding(p_Encoding->data);
    }
    else
    {
        return FALSE;
    }

   	p_Bitrate = xml_node_soap_get(p_node, "Bitrate");
    if (p_Bitrate && p_Bitrate->data)
    {
        p_res->Bitrate = atoi(p_Bitrate->data);
    }

    p_SampleRate = xml_node_soap_get(p_node, "SampleRate");
    if (p_SampleRate && p_SampleRate->data)
    {
        p_res->SampleRate = atoi(p_SampleRate->data);
    }

	p_Multicast = xml_node_soap_get(p_node, "Multicast");
    if (p_Multicast)
    {
    	parse_MulticastConfiguration(p_Multicast, &p_res->Multicast);
    }
    
	p_SessionTimeout = xml_node_soap_get(p_node, "SessionTimeout");
	if (p_SessionTimeout && p_SessionTimeout->data)
	{
	    parse_XSDDuration(p_SessionTimeout->data, &p_res->SessionTimeout);
	}
					
    return TRUE;
}


BOOL parse_PTZConfiguration(XMLN * p_node, onvif_PTZConfiguration * p_res)
{
	const char * p_MoveRamp;
	const char * p_PresetRamp;
	const char * p_PresetTourRamp;
	XMLN * p_Name;
	XMLN * p_UseCount;
	XMLN * p_NodeToken;
	XMLN * p_DefaultPTZSpeed;
	XMLN * p_DefaultPTZTimeout;
	XMLN * p_PanTiltLimits;
	XMLN * p_ZoomLimits;

	p_MoveRamp = xml_attr_get(p_node, "MoveRamp");
	if (p_MoveRamp)
	{
		p_res->MoveRampFlag = 1;
		p_res->MoveRamp = atoi(p_MoveRamp);
	}

	p_PresetRamp = xml_attr_get(p_node, "PresetRamp");
	if (p_PresetRamp)
	{
		p_res->PresetRampFlag = 1;
		p_res->PresetRamp = atoi(p_PresetRamp);
	}

	p_PresetTourRamp = xml_attr_get(p_node, "PresetTourRamp");
	if (p_PresetTourRamp)
	{
		p_res->PresetTourRampFlag = 1;
		p_res->PresetTourRamp = atoi(p_PresetTourRamp);
	}

	p_Name = xml_node_soap_get(p_node, "Name");
    if (p_Name && p_Name->data)
    {
        strncpy(p_res->Name, p_Name->data, sizeof(p_res->Name)-1);
    }
    else
    {
        return FALSE;
    }

    p_UseCount = xml_node_soap_get(p_node, "UseCount");
    if (p_UseCount && p_UseCount->data)
    {
        p_res->UseCount = atoi(p_UseCount->data);
    }

    p_NodeToken = xml_node_soap_get(p_node, "NodeToken");
    if (p_NodeToken && p_NodeToken->data)
    {
        strncpy(p_res->NodeToken, p_NodeToken->data, sizeof(p_res->NodeToken)-1);
    }

    p_DefaultPTZSpeed = xml_node_soap_get(p_node, "DefaultPTZSpeed");
    if (p_DefaultPTZSpeed)
    {
		p_res->DefaultPTZSpeedFlag = 1;
		parse_PTZSpeed(p_DefaultPTZSpeed, &p_res->DefaultPTZSpeed);
    }

    p_DefaultPTZTimeout = xml_node_soap_get(p_node, "DefaultPTZTimeout");
	if (p_DefaultPTZTimeout && p_DefaultPTZTimeout->data)
	{
	    p_res->DefaultPTZTimeoutFlag = 1;
	    parse_XSDDuration(p_DefaultPTZTimeout->data, &p_res->DefaultPTZTimeout);
	}

	p_PanTiltLimits = xml_node_soap_get(p_node, "PanTiltLimits");
	if (p_PanTiltLimits)
	{
		XMLN * p_Range;

		p_res->PanTiltLimitsFlag = 1;
		
		p_Range = xml_node_soap_get(p_PanTiltLimits, "Range");
		if (p_Range)
		{
			XMLN * p_XRange;
			XMLN * p_YRange;

			p_XRange = xml_node_soap_get(p_Range, "XRange");
			if (p_XRange)
			{
				parse_FloatRange(p_XRange, &p_res->PanTiltLimits.XRange);
			}
			
			p_YRange = xml_node_soap_get(p_Range, "YRange");
			if (p_YRange)
			{
				parse_FloatRange(p_YRange, &p_res->PanTiltLimits.YRange);
			}
		}
	}
	
	p_ZoomLimits = xml_node_soap_get(p_node, "ZoomLimits");
	if (p_ZoomLimits)
	{
		XMLN * p_Range;

		p_res->ZoomLimitsFlag = 1;
		
		p_Range = xml_node_soap_get(p_ZoomLimits, "Range");
		if (p_Range)
		{
			XMLN * p_XRange = xml_node_soap_get(p_Range, "XRange");
			if (p_XRange)
			{
				parse_FloatRange(p_XRange, &p_res->ZoomLimits.XRange);
			}
		}		
	}
				
    return TRUE;
}

BOOL parse_Profile(XMLN * p_node, ONVIF_Profile * p_profile)
{
    XMLN * p_Name;
	XMLN * p_VideoSourceConfiguration;
	XMLN * p_AudioSourceConfiguration;
	XMLN * p_VideoEncoderConfiguration;
	XMLN * p_AudioEncoderConfiguration;
	XMLN * p_PTZConfiguration;
	XMLN * p_VideoAnalyticsConfiguration;

	p_Name = xml_node_soap_get(p_node, "Name");
    if (p_Name && p_Name->data)
    {
        strncpy(p_profile->name, p_Name->data, sizeof(p_profile->name)-1);
    }
    else
    {
        return FALSE;
    }    

    p_VideoSourceConfiguration = xml_node_soap_get(p_node, "VideoSourceConfiguration");
    if (p_VideoSourceConfiguration)
    {
        p_profile->video_src_cfg = (ONVIF_VideoSourceConfiguration *) malloc(sizeof(ONVIF_VideoSourceConfiguration));
        if (p_profile->video_src_cfg)
        {
        	const char * p_token;
			
            memset(p_profile->video_src_cfg, 0, sizeof(ONVIF_VideoSourceConfiguration));

            p_token = xml_attr_get(p_VideoSourceConfiguration, "token");
            if (p_token)
            {
            	strncpy(p_profile->video_src_cfg->Configuration.token, p_token, sizeof(p_profile->video_src_cfg->Configuration.token)-1);
            }	

            if (!parse_VideoSourceConfiguration(p_VideoSourceConfiguration, &p_profile->video_src_cfg->Configuration))
            {
            	return FALSE;
            }
        }
    }

	p_AudioSourceConfiguration = xml_node_soap_get(p_node, "AudioSourceConfiguration");
    if (p_AudioSourceConfiguration)
    {
        p_profile->audio_src_cfg = (ONVIF_AudioSourceConfiguration *) malloc(sizeof(ONVIF_AudioSourceConfiguration));
        if (p_profile->audio_src_cfg)
        {
        	const char * p_token;
			
            memset(p_profile->audio_src_cfg, 0, sizeof(ONVIF_AudioSourceConfiguration));

            p_token = xml_attr_get(p_AudioSourceConfiguration, "token");  
            if (p_token)
            {
            	strncpy(p_profile->audio_src_cfg->Configuration.token, p_token, sizeof(p_profile->audio_src_cfg->Configuration.token)-1);
            }	

            if (!parse_AudioSourceConfiguration(p_AudioSourceConfiguration, &p_profile->audio_src_cfg->Configuration))
            {
            	return FALSE;
            }
        }    
    }
    
    p_VideoEncoderConfiguration = xml_node_soap_get(p_node, "VideoEncoderConfiguration");
    if (p_VideoEncoderConfiguration)
    {
        p_profile->video_enc = (ONVIF_VideoEncoderConfiguration *) malloc(sizeof(ONVIF_VideoEncoderConfiguration));
        if (p_profile->video_enc)
        { 
        	const char * p_token;
			
            memset(p_profile->video_enc, 0, sizeof(ONVIF_VideoEncoderConfiguration));

            p_token = xml_attr_get(p_VideoEncoderConfiguration, "token");
            if (p_token)
            {
            	strncpy(p_profile->video_enc->Configuration.token, p_token, sizeof(p_profile->video_enc->Configuration.token)-1);
            }	

            if (!parse_VideoEncoderConfiguration(p_VideoEncoderConfiguration, &p_profile->video_enc->Configuration))
            {
                return FALSE;           
            }
        }    
    }

	p_AudioEncoderConfiguration = xml_node_soap_get(p_node, "AudioEncoderConfiguration");
    if (p_AudioEncoderConfiguration)
    {
        p_profile->audio_enc = (ONVIF_AudioEncoderConfiguration *) malloc(sizeof(ONVIF_AudioEncoderConfiguration));
        if (p_profile->audio_enc)
        { 
        	const char * p_token;
			
            memset(p_profile->audio_enc, 0, sizeof(ONVIF_AudioEncoderConfiguration));

            p_token = xml_attr_get(p_AudioEncoderConfiguration, "token");
            if (p_token)
            {
            	strncpy(p_profile->audio_enc->Configuration.token, p_token, sizeof(p_profile->audio_enc->Configuration.token)-1);
            }	

            if (!parse_AudioEncoderConfiguration(p_AudioEncoderConfiguration, &p_profile->audio_enc->Configuration))
            {
                return FALSE;           
            }
        }    
    }

    p_PTZConfiguration = xml_node_soap_get(p_node, "PTZConfiguration");
    if (p_PTZConfiguration)
    {
        p_profile->ptz_cfg = (ONVIF_PTZConfiguration *) malloc(sizeof(ONVIF_PTZConfiguration));
        if (p_profile->ptz_cfg)
        { 
        	const char * p_token;
			
            memset(p_profile->ptz_cfg, 0, sizeof(ONVIF_PTZConfiguration));

            p_token = xml_attr_get(p_PTZConfiguration, "token");	
            if (p_token)
            {
            	strncpy(p_profile->ptz_cfg->Configuration.token, p_token, sizeof(p_profile->ptz_cfg->Configuration.token)-1);
            }	

            if (!parse_PTZConfiguration(p_PTZConfiguration, &p_profile->ptz_cfg->Configuration))
            {
                return FALSE;           
            }
        }    
    }   

	p_VideoAnalyticsConfiguration = xml_node_soap_get(p_node, "VideoAnalyticsConfiguration");
    if (p_VideoAnalyticsConfiguration)
    {
    	p_profile->va_cfg = (ONVIF_VideoAnalyticsConfiguration *) malloc(sizeof(ONVIF_VideoAnalyticsConfiguration));
    	if (p_profile->va_cfg)
    	{
    		memset(p_profile->va_cfg, 0, sizeof(ONVIF_VideoAnalyticsConfiguration));
    		
			if (parse_VideoAnalyticsConfiguration(p_VideoAnalyticsConfiguration, &p_profile->va_cfg->Configuration) == FALSE)
		    {
		        return FALSE;
		    }
	    }
    }
	        
    return TRUE;
}

BOOL parse_Dot11Configuration(XMLN * p_node, onvif_Dot11Configuration * p_req)
{
    XMLN * p_SSID;
    XMLN * p_Mode;
    XMLN * p_Alias;
    XMLN * p_Priority;
    XMLN * p_Security;

    p_SSID = xml_node_soap_get(p_node, "SSID");
	if (p_SSID && p_SSID->data)
	{
	    strncpy(p_req->SSID, p_SSID->data, sizeof(p_req->SSID)-1);
	}

	p_Mode = xml_node_soap_get(p_node, "Mode");
	if (p_Mode && p_Mode->data)
	{
	    p_req->Mode = onvif_StringToDot11StationMode(p_Mode->data);
	}

	p_Alias = xml_node_soap_get(p_node, "Alias");
	if (p_Alias && p_Alias->data)
	{
	    strncpy(p_req->Alias, p_Alias->data, sizeof(p_req->Alias)-1);
	}

	p_Priority = xml_node_soap_get(p_node, "Priority");
	if (p_Priority && p_Priority->data)
	{
	    p_req->Priority = atoi(p_Priority->data);
	}

	p_Security = xml_node_soap_get(p_node, "Security");
    if (p_Security)
    {
        XMLN * p_Mode;
        XMLN * p_Algorithm;
        XMLN * p_PSK;
        XMLN * p_Dot1X;

        p_Mode = xml_node_soap_get(p_Security, "Mode");
    	if (p_Mode && p_Mode->data)
    	{
    	    p_req->Security.Mode = onvif_StringToDot11SecurityMode(p_Mode->data);
    	}

    	p_Algorithm = xml_node_soap_get(p_Security, "Algorithm");
    	if (p_Algorithm && p_Algorithm->data)
    	{
    	    p_req->Security.AlgorithmFlag = 1;
    	    p_req->Security.Algorithm = onvif_StringToDot11Cipher(p_Algorithm->data);
    	}

    	p_PSK = xml_node_soap_get(p_Security, "PSK");
    	if (p_PSK)
    	{
    	    XMLN * p_Key;
            XMLN * p_Passphrase;

            p_req->Security.PSKFlag = 1;
            
            p_Key = xml_node_soap_get(p_PSK, "Key");
        	if (p_Key && p_Key->data)
        	{
        	    p_req->Security.PSK.KeyFlag = 1;
        	    strncpy(p_req->Security.PSK.Key, p_Key->data, sizeof(p_req->Security.PSK.Key)-1);
        	}

        	p_Passphrase = xml_node_soap_get(p_PSK, "Passphrase");
        	if (p_Passphrase && p_Passphrase->data)
        	{
        	    p_req->Security.PSK.PassphraseFlag = 1;
        	    strncpy(p_req->Security.PSK.Passphrase, p_Passphrase->data, sizeof(p_req->Security.PSK.Passphrase)-1);
        	}
    	}

    	p_Dot1X = xml_node_soap_get(p_Security, "Dot1X");
    	if (p_Dot1X && p_Dot1X->data)
    	{
    	    p_req->Security.Dot1XFlag = 1;
    	    strncpy(p_req->Security.Dot1X, p_Dot1X->data, sizeof(p_req->Security.Dot1X)-1);
    	}
    }

	return TRUE;
}

BOOL parse_NetworkInterface(XMLN * p_node, onvif_NetworkInterface * p_res)
{
	XMLN * p_Enabled;
	XMLN * p_Info;
	XMLN * p_IPv4;
	XMLN * p_Extension;

	p_Enabled = xml_node_soap_get(p_node, "Enabled");
    if (p_Enabled && p_Enabled->data)
    {   
    	p_res->Enabled = parse_Bool(p_Enabled->data);
    }

    p_Info = xml_node_soap_get(p_node, "Info");
    if (p_Info)
    {
    	XMLN * p_Name;
		XMLN * p_HwAddress;
		XMLN * p_MTU;

		p_res->InfoFlag = 1;
		
		p_Name = xml_node_soap_get(p_Info, "Name");
	    if (p_Name && p_Name->data)
	    {
	    	p_res->Info.NameFlag = 1;
	    	strncpy(p_res->Info.Name, p_Name->data, sizeof(p_res->Info.Name)-1);
	    }

	    p_HwAddress = xml_node_soap_get(p_Info, "HwAddress");
	    if (p_HwAddress && p_HwAddress->data)
	    {
	    	strncpy(p_res->Info.HwAddress, p_HwAddress->data, sizeof(p_res->Info.HwAddress)-1);
	    }

	    p_MTU = xml_node_soap_get(p_Info, "MTU");
	    if (p_MTU && p_MTU->data)
	    {
	    	p_res->Info.MTUFlag = 1;
	    	p_res->Info.MTU = atoi(p_MTU->data);
	    }
    }

    p_IPv4 = xml_node_soap_get(p_node, "IPv4");
    if (p_IPv4)
    {
    	XMLN * p_Enabled;
		XMLN * p_Config;

		p_res->IPv4Flag = 1;
		
		p_Enabled = xml_node_soap_get(p_IPv4, "Enabled");
	    if (p_Enabled && p_Enabled->data)
	    {   
	    	p_res->IPv4.Enabled = parse_Bool(p_Enabled->data);
	    }

	    p_Config = xml_node_soap_get(p_IPv4, "Config");
	    if (p_Config)
	    {   
	    	XMLN * p_Manual;
			XMLN * p_FromDHCP;
			XMLN * p_DHCP;
			
			p_Manual = xml_node_soap_get(p_Config, "Manual");
		    if (p_Manual)
		    {   
		    	XMLN * p_Address;
				XMLN * p_PrefixLength;
				
		    	p_Address = xml_node_soap_get(p_Manual, "Address");
			    if (p_Address && p_Address->data)
			    {   
			    	strncpy(p_res->IPv4.Config.Address, p_Address->data, sizeof(p_res->IPv4.Config.Address)-1);
			    }

			    p_PrefixLength = xml_node_soap_get(p_Manual, "PrefixLength");
			    if (p_PrefixLength && p_PrefixLength->data)
			    {   
			    	p_res->IPv4.Config.PrefixLength = atoi(p_PrefixLength->data);
			    }
		    }

		    p_FromDHCP = xml_node_soap_get(p_Config, "FromDHCP");
		    if (p_FromDHCP)
		    {   
		    	XMLN * p_Address;
				XMLN * p_PrefixLength;

				p_Address = xml_node_soap_get(p_FromDHCP, "Address");
			    if (p_Address && p_Address->data)
			    {   
			    	strncpy(p_res->IPv4.Config.Address, p_Address->data, sizeof(p_res->IPv4.Config.Address)-1);
			    }

			    p_PrefixLength = xml_node_soap_get(p_FromDHCP, "PrefixLength");
			    if (p_PrefixLength && p_PrefixLength->data)
			    {   
			    	p_res->IPv4.Config.PrefixLength = atoi(p_PrefixLength->data);
			    }
		    }

		    p_DHCP = xml_node_soap_get(p_Config, "DHCP");
		    if (p_DHCP && p_DHCP->data)
		    {
		    	p_res->IPv4.Config.DHCP = parse_Bool(p_DHCP->data);
		    }
	    }
    }

    p_Extension = xml_node_soap_get(p_node, "Extension");
    if (p_Extension)
    {
        XMLN * p_InterfaceType;
        XMLN * p_Dot11;

        p_res->ExtensionFlag = 1;

        p_InterfaceType = xml_node_soap_get(p_Extension, "InterfaceType");
        if (p_InterfaceType && p_InterfaceType->data)
        {
            p_res->Extension.InterfaceType = atoi(p_InterfaceType->data);
        }
        
        p_Dot11 = xml_node_soap_get(p_Extension, "Dot11");
        while (p_Dot11 && soap_strcmp(p_Dot11->name, "Dot11") == 0)
        {
            int idx = p_res->Extension.sizeDot11;

            parse_Dot11Configuration(p_Dot11, &p_res->Extension.Dot11[idx]);
            
            p_res->Extension.sizeDot11++;
            if (p_res->Extension.sizeDot11 >= 4)
            {
                break;
            }
        }
    }
    
    return TRUE;
}


/***************************************************************************************/
BOOL parse_GetCapabilities(XMLN * p_node, GetCapabilities_RES * p_res)
{
    XMLN * p_Capabilities;
    XMLN * p_Analytics;
	XMLN * p_Device;
	XMLN * p_Events;
	XMLN * p_Imaging;
	XMLN * p_Media;
	XMLN * p_PTZ;
	XMLN * p_Extension;

	p_Capabilities = xml_node_soap_get(p_node, "Capabilities");
    if (NULL == p_Capabilities)
    {
        return FALSE;
    }

	p_Analytics = xml_node_soap_get(p_Capabilities, "Analytics");
    if (p_Analytics)
    {
		if (parse_AnalyticsCapabilities(p_Analytics, &p_res->Capabilities.analytics))
		{
			p_res->Capabilities.analytics.support = 1;
		}
    }
    
    p_Device = xml_node_soap_get(p_Capabilities, "Device");
    if (p_Device)
    {
		parse_DeviceCapabilities(p_Device, &p_res->Capabilities.device);
    }

	p_Events = xml_node_soap_get(p_Capabilities, "Events");
    if (p_Events)
    {
        if (parse_EventsCapabilities(p_Events, &p_res->Capabilities.events))
        {
        	p_res->Capabilities.events.support = 1;
        }
        else
        {
        	p_res->Capabilities.events.support = 0;
        }
    }

    p_Imaging = xml_node_soap_get(p_Capabilities, "Imaging");
    if (p_Imaging)
    {
        if (parse_ImageCapabilities(p_Imaging, &p_res->Capabilities.image))
        {
        	p_res->Capabilities.image.support = 1;
        }
        else
        {
        	p_res->Capabilities.image.support = 0;
        }
    }
    
    p_Media = xml_node_soap_get(p_Capabilities, "Media");
    if (p_Media)
    {
        if (parse_MediaCapabilities(p_Media, &p_res->Capabilities.media))
        {
        	p_res->Capabilities.media.support = 1;
        }
        else
        {
        	p_res->Capabilities.media.support = 0;
        }
    }

    p_PTZ = xml_node_soap_get(p_Capabilities, "PTZ");
    if (p_PTZ)
    {
        if (parse_PTZCapabilities(p_PTZ, &p_res->Capabilities.ptz))
        {
        	p_res->Capabilities.ptz.support = 1;
        }
        else
        {
        	p_res->Capabilities.ptz.support = 0;
        }
    }

	p_Extension = xml_node_soap_get(p_Capabilities, "Extension");
    if (p_Extension)
    {
        XMLN * p_Recording;
		XMLN * p_Search;
		XMLN * p_Replay;

		p_Recording = xml_node_soap_get(p_Extension, "Recording");
        if (p_Recording)
        {
            if (parse_RecordingCapabilities(p_Recording, &p_res->Capabilities.recording))
            {
            	p_res->Capabilities.recording.support = 1;
            }
            else
            {
            	p_res->Capabilities.recording.support = 0;
            }
        }

        p_Search = xml_node_soap_get(p_Extension, "Search");
        if (p_Search)
        {
            if (parse_SearchCapabilities(p_Search, &p_res->Capabilities.search))
            {
            	p_res->Capabilities.search.support = 1;
            }
            else
            {
            	p_res->Capabilities.search.support = 0;
            }
        }

        p_Replay = xml_node_soap_get(p_Extension, "Replay");
        if (p_Replay)
        {
            if (parse_ReplayCapabilities(p_Replay, &p_res->Capabilities.replay))
            {
            	p_res->Capabilities.replay.support = 1;
            }
            else
            {
            	p_res->Capabilities.replay.support = 0;
            }
        }
    }
    
    return TRUE;
}

BOOL parse_GetDeviceInformation(XMLN * p_node, GetDeviceInformation_RES * p_res)
{
    XMLN * p_Manufacturer;
	XMLN * p_Model;
	XMLN * p_FirmwareVersion;
	XMLN * p_SerialNumber;
	XMLN * p_HardwareId;

	p_Manufacturer = xml_node_soap_get(p_node, "Manufacturer");
    if (p_Manufacturer && p_Manufacturer->data)
    {   
        strncpy(p_res->DeviceInformation.Manufacturer, p_Manufacturer->data, sizeof(p_res->DeviceInformation.Manufacturer)-1);
    }

    p_Model = xml_node_soap_get(p_node, "Model");
    if (p_Model && p_Model->data)
    {   
        strncpy(p_res->DeviceInformation.Model, p_Model->data, sizeof(p_res->DeviceInformation.Model)-1);
    }

    p_FirmwareVersion = xml_node_soap_get(p_node, "FirmwareVersion");
    if (p_FirmwareVersion && p_FirmwareVersion->data)
    {   
        strncpy(p_res->DeviceInformation.FirmwareVersion, p_FirmwareVersion->data, sizeof(p_res->DeviceInformation.FirmwareVersion)-1);
    }

    p_SerialNumber = xml_node_soap_get(p_node, "SerialNumber");
    if (p_SerialNumber && p_SerialNumber->data)
    {   
        strncpy(p_res->DeviceInformation.SerialNumber, p_SerialNumber->data, sizeof(p_res->DeviceInformation.SerialNumber)-1);
    }

    p_HardwareId = xml_node_soap_get(p_node, "HardwareId");
    if (p_HardwareId && p_HardwareId->data)
    {   
        strncpy(p_res->DeviceInformation.HardwareId, p_HardwareId->data, sizeof(p_res->DeviceInformation.HardwareId)-1);
    }	

    return TRUE;
}

BOOL parse_User(XMLN * p_node, onvif_User * p_res)
{
	XMLN * p_Username;
	XMLN * p_Password;
	XMLN * p_UserLevel;
	
	p_Username = xml_node_soap_get(p_node, "Username");
    if (p_Username && p_Username->data)
    {   
        strncpy(p_res->Username, p_Username->data, sizeof(p_res->Username)-1);
    }

    p_Password = xml_node_soap_get(p_node, "Password");
    if (p_Password && p_Password->data)
    {   
    	p_res->PasswordFlag = 1;
        strncpy(p_res->Password, p_Password->data, sizeof(p_res->Password)-1);
    }

    p_UserLevel = xml_node_soap_get(p_node, "UserLevel");
    if (p_UserLevel && p_UserLevel->data)
    {   
        p_res->UserLevel = onvif_StringToUserLevel(p_UserLevel->data);
    }

    return TRUE;
}

BOOL parse_GetRemoteUser(XMLN * p_node, GetRemoteUser_RES * p_res)
{
    XMLN * p_RemoteUser = xml_node_soap_get(p_node, "RemoteUser");
	if (p_RemoteUser)
	{
		XMLN * p_Username;
		XMLN * p_Password;
		XMLN * p_UseDerivedPassword;

		p_res->RemoteUserFlag = 1;

		p_Username = xml_node_soap_get(p_RemoteUser, "Username");
    	if (p_Username && p_Username->data)
    	{
    	    strncpy(p_res->RemoteUser.Username, p_Username->data, sizeof(p_res->RemoteUser.Username)-1);
    	}

    	p_Password = xml_node_soap_get(p_RemoteUser, "Password");
    	if (p_Password && p_Password->data)
    	{
    	    p_res->RemoteUser.PasswordFlag = 1;
    	    strncpy(p_res->RemoteUser.Password, p_Password->data, sizeof(p_res->RemoteUser.Password)-1);
    	}

    	p_UseDerivedPassword = xml_node_soap_get(p_RemoteUser, "UseDerivedPassword");
    	if (p_UseDerivedPassword && p_UseDerivedPassword->data)
    	{
    	    p_res->RemoteUser.UseDerivedPassword = parse_Bool(p_UseDerivedPassword->data);
    	}
	}

	return TRUE;
}

BOOL parse_GetStreamUri(XMLN * p_node, GetStreamUri_RES * p_res)
{
    XMLN * p_MediaUri;
	XMLN * p_Uri;
	XMLN * p_InvalidAfterConnect;
	XMLN * p_InvalidAfterReboot;
	XMLN * p_Timeout;

	p_MediaUri = xml_node_soap_get(p_node, "MediaUri");
    if (NULL == p_MediaUri)
    {
    	return FALSE;
    }
    
    p_Uri = xml_node_soap_get(p_MediaUri, "Uri");
    if (p_Uri && p_Uri->data)
    {
        onvif_parse_uri(p_Uri->data, p_res->Uri, sizeof(p_res->Uri));
    }
    else
    {
        return FALSE;
    }

	p_InvalidAfterConnect = xml_node_soap_get(p_MediaUri, "InvalidAfterConnect");
    if (p_InvalidAfterConnect && p_InvalidAfterConnect->data)
    {
    	p_res->InvalidAfterConnect = parse_Bool(p_InvalidAfterConnect->data);
    }

    p_InvalidAfterReboot = xml_node_soap_get(p_MediaUri, "InvalidAfterReboot");
    if (p_InvalidAfterReboot && p_InvalidAfterReboot->data)
    {
    	p_res->InvalidAfterReboot = parse_Bool(p_InvalidAfterReboot->data);
    }

	p_Timeout = xml_node_soap_get(p_MediaUri, "Timeout");
    if (p_Timeout && p_Timeout->data)
    {
    	p_res->Timeout = parse_Time(p_Timeout->data);
    }
    
    return TRUE;
}

BOOL parse_Space2DDescription(XMLN * p_node, onvif_Space2DDescription * p_res)
{
	XMLN * p_XRange;
	XMLN * p_YRange;

	p_XRange = xml_node_soap_get(p_node, "XRange");
	if (p_XRange)
	{
		parse_FloatRange(p_XRange, &p_res->XRange);
	}

	p_YRange = xml_node_soap_get(p_node, "YRange");
	if (p_YRange)
	{
		parse_FloatRange(p_YRange, &p_res->YRange);
	}

	return TRUE;
}

BOOL parse_Space1DDescription(XMLN * p_node, onvif_Space1DDescription * p_res)
{
	XMLN * p_XRange;

	p_XRange = xml_node_soap_get(p_node, "XRange");
	if (p_XRange)
	{
		parse_FloatRange(p_XRange, &p_res->XRange);
	}

	return TRUE;
}


BOOL parse_GetConfigurationOptions(XMLN * p_node, GetConfigurationOptions_RES * p_res)
{
	XMLN * p_PTZConfigurationOptions;
	XMLN * p_Spaces;
	XMLN * p_AbsolutePanTiltPositionSpace;
	XMLN * p_AbsoluteZoomPositionSpace;
	XMLN * p_RelativePanTiltTranslationSpace;
	XMLN * p_RelativeZoomTranslationSpace;
	XMLN * p_ContinuousPanTiltVelocitySpace;
	XMLN * p_ContinuousZoomVelocitySpace;
	XMLN * p_PanTiltSpeedSpace;
	XMLN * p_ZoomSpeedSpace;
	XMLN * p_PTZTimeout;
	XMLN * p_PTControlDirection;

	p_PTZConfigurationOptions = xml_node_soap_get(p_node, "PTZConfigurationOptions");
	if (NULL == p_PTZConfigurationOptions)
	{
		return FALSE;
	}

	p_Spaces = xml_node_soap_get(p_PTZConfigurationOptions, "Spaces");
	if (NULL == p_Spaces)
	{
		return FALSE;
	}

	p_AbsolutePanTiltPositionSpace = xml_node_soap_get(p_Spaces, "AbsolutePanTiltPositionSpace");
	if (p_AbsolutePanTiltPositionSpace)
	{
		p_res->PTZConfigurationOptions.Spaces.AbsolutePanTiltPositionSpaceFlag = 1;
		parse_Space2DDescription(p_AbsolutePanTiltPositionSpace, &p_res->PTZConfigurationOptions.Spaces.AbsolutePanTiltPositionSpace);
	}

	p_AbsoluteZoomPositionSpace = xml_node_soap_get(p_Spaces, "AbsoluteZoomPositionSpace");
	if (p_AbsoluteZoomPositionSpace)
	{
		p_res->PTZConfigurationOptions.Spaces.AbsoluteZoomPositionSpaceFlag = 1;
		parse_Space1DDescription(p_AbsoluteZoomPositionSpace, &p_res->PTZConfigurationOptions.Spaces.AbsoluteZoomPositionSpace);
	}

	p_RelativePanTiltTranslationSpace = xml_node_soap_get(p_Spaces, "RelativePanTiltTranslationSpace");
	if (p_RelativePanTiltTranslationSpace)
	{
		p_res->PTZConfigurationOptions.Spaces.RelativePanTiltTranslationSpaceFlag = 1;
		parse_Space2DDescription(p_RelativePanTiltTranslationSpace, &p_res->PTZConfigurationOptions.Spaces.RelativePanTiltTranslationSpace);		
	}

	p_RelativeZoomTranslationSpace = xml_node_soap_get(p_Spaces, "RelativeZoomTranslationSpace");
	if (p_RelativeZoomTranslationSpace)
	{
		p_res->PTZConfigurationOptions.Spaces.RelativeZoomTranslationSpaceFlag = 1;
		parse_Space1DDescription(p_RelativeZoomTranslationSpace, &p_res->PTZConfigurationOptions.Spaces.RelativeZoomTranslationSpace);
	}

	p_ContinuousPanTiltVelocitySpace = xml_node_soap_get(p_Spaces, "ContinuousPanTiltVelocitySpace");
	if (p_ContinuousPanTiltVelocitySpace)
	{
		p_res->PTZConfigurationOptions.Spaces.ContinuousPanTiltVelocitySpaceFlag = 1;
		parse_Space2DDescription(p_ContinuousPanTiltVelocitySpace, &p_res->PTZConfigurationOptions.Spaces.ContinuousPanTiltVelocitySpace);
	}

	p_ContinuousZoomVelocitySpace = xml_node_soap_get(p_Spaces, "ContinuousZoomVelocitySpace");
	if (p_ContinuousZoomVelocitySpace)
	{
		p_res->PTZConfigurationOptions.Spaces.ContinuousZoomVelocitySpaceFlag = 1;
		parse_Space1DDescription(p_ContinuousZoomVelocitySpace, &p_res->PTZConfigurationOptions.Spaces.ContinuousZoomVelocitySpace);
	}

	p_PanTiltSpeedSpace = xml_node_soap_get(p_Spaces, "PanTiltSpeedSpace");
	if (p_PanTiltSpeedSpace)
	{
		p_res->PTZConfigurationOptions.Spaces.PanTiltSpeedSpaceFlag = 1;
		parse_Space1DDescription(p_PanTiltSpeedSpace, &p_res->PTZConfigurationOptions.Spaces.PanTiltSpeedSpace);
	}

	p_ZoomSpeedSpace = xml_node_soap_get(p_Spaces, "ZoomSpeedSpace");
	if (p_ZoomSpeedSpace)
	{
		p_res->PTZConfigurationOptions.Spaces.ZoomSpeedSpaceFlag = 1;
		parse_Space1DDescription(p_ZoomSpeedSpace, &p_res->PTZConfigurationOptions.Spaces.ZoomSpeedSpace);
	}

	p_PTZTimeout = xml_node_soap_get(p_PTZConfigurationOptions, "PTZTimeout");
	if (p_PTZTimeout)
	{
		XMLN * p_Min;
		XMLN * p_Max;

		p_Min = xml_node_soap_get(p_PTZTimeout, "Min");
		if (p_Min && p_Min->data)
		{
			parse_XSDDuration(p_Min->data, &p_res->PTZConfigurationOptions.PTZTimeout.Min);
		}

		p_Max = xml_node_soap_get(p_PTZTimeout, "Max");
		if (p_Max && p_Max->data)
		{
			parse_XSDDuration(p_Max->data, &p_res->PTZConfigurationOptions.PTZTimeout.Max);
		}
	}

	p_PTControlDirection = xml_node_soap_get(p_PTZConfigurationOptions, "PTControlDirection");
	if (p_PTControlDirection)
	{
		XMLN * p_EFlip;
		XMLN * p_Reverse;

		p_res->PTZConfigurationOptions.PTControlDirectionFlag = 1;
		
		p_EFlip = xml_node_soap_get(p_PTControlDirection, "EFlip");
		if (p_EFlip)
		{
			XMLN * p_Mode;
			
			p_Mode = xml_node_soap_get(p_EFlip, "Mode");
			while (p_Mode && p_Mode->data && soap_strcmp(p_Mode->name, "Mode") == 0)
			{
				if (strcasecmp(p_Mode->data, "ON") == 0)
				{
					p_res->PTZConfigurationOptions.PTControlDirection.EFlipMode_ON = 1;
				}	
				else if (strcasecmp(p_Mode->data, "OFF") == 0)
				{
					p_res->PTZConfigurationOptions.PTControlDirection.EFlipMode_OFF = 1;
				}
				else if (strcasecmp(p_Mode->data, "Extended") == 0)
				{
					p_res->PTZConfigurationOptions.PTControlDirection.EFlipMode_Extended = 1;
				}
			}
		}

		p_Reverse = xml_node_soap_get(p_PTControlDirection, "Reverse");
		if (p_Reverse)
		{
			XMLN * p_Mode;
			
			p_Mode = xml_node_soap_get(p_Reverse, "Mode");
			while (p_Mode && p_Mode->data && soap_strcmp(p_Mode->name, "Mode") == 0)
			{
				if (strcasecmp(p_Mode->data, "ON") == 0)
				{
					p_res->PTZConfigurationOptions.PTControlDirection.ReverseMode_ON = 1;
				}	
				else if (strcasecmp(p_Mode->data, "OFF") == 0)
				{
					p_res->PTZConfigurationOptions.PTControlDirection.ReverseMode_OFF = 1;
				}
				else if (strcasecmp(p_Mode->data, "Extended") == 0)
				{
					p_res->PTZConfigurationOptions.PTControlDirection.ReverseMode_Extended = 1;
				}
				else if (strcasecmp(p_Mode->data, "AUTO") == 0)
				{
					p_res->PTZConfigurationOptions.PTControlDirection.ReverseMode_AUTO = 1;
				}
			}
		}
	}
    
	return TRUE;
}

BOOL parse_SetNetworkInterfaces(XMLN * p_node, SetNetworkInterfaces_RES * p_res)
{
	XMLN * p_RebootNeeded = xml_node_soap_get(p_node, "RebootNeeded");
	if (p_RebootNeeded && p_RebootNeeded->data)
	{
		p_res->RebootNeeded = parse_Bool(p_RebootNeeded->data);
	}

	return TRUE;
}

BOOL parse_SetHostnameFromDHCP(XMLN * p_node, SetHostnameFromDHCP_RES * p_res)
{
	XMLN * p_RebootNeeded = xml_node_soap_get(p_node, "RebootNeeded");
	if (p_RebootNeeded && p_RebootNeeded->data)
	{
		p_res->RebootNeeded = parse_Bool(p_RebootNeeded->data);
	}

	return TRUE;
}

BOOL parse_GetNTP(XMLN * p_node, GetNTP_RES * p_res)
{
	int i = 0;	
	char node[32];
	XMLN * p_NTPInformation;
	XMLN * p_FromDHCP;
	XMLN * p_NTP;

	p_NTPInformation = xml_node_soap_get(p_node, "NTPInformation");
	if (NULL == p_NTPInformation)
	{
		return FALSE;
	}
	
	p_FromDHCP = xml_node_soap_get(p_NTPInformation, "FromDHCP");
	if (p_FromDHCP && p_FromDHCP->data)
	{
		p_res->NTPInformation.FromDHCP = parse_Bool(p_FromDHCP->data);
	}	

	if (p_res->NTPInformation.FromDHCP)
	{
		strcpy(node, "NTPFromDHCP");
	}
	else
	{
		strcpy(node, "NTPManual");
	}
	
	p_NTP = xml_node_soap_get(p_NTPInformation, node);
	while (p_NTP && soap_strcmp(p_NTP->name, node) == 0)
	{
		XMLN * p_Type;
		XMLN * p_IPv4Address;
		XMLN * p_DNSname;

		p_Type = xml_node_soap_get(p_NTP, "Type");
		if (p_Type && p_Type->data)
		{
			if (strcasecmp(p_Type->data, "IPv4") != 0 && strcasecmp(p_Type->data, "DNS") != 0) // only support ipv4
			{
			    p_NTP = p_NTP->next;
				continue;
			}
		}

		p_IPv4Address = xml_node_soap_get(p_NTP, "IPv4Address");
		if (p_IPv4Address && p_IPv4Address->data)
		{
			if (is_ip_address(p_IPv4Address->data) && i < MAX_NTP_SERVER)
			{
				strncpy(p_res->NTPInformation.NTPServer[i], p_IPv4Address->data, sizeof(p_res->NTPInformation.NTPServer[i])-1);
				++i;
			}
		}

		p_DNSname = xml_node_soap_get(p_NTP, "DNSname");
		if (p_DNSname && p_DNSname->data)
		{
			if (i < MAX_NTP_SERVER)
			{
				strncpy(p_res->NTPInformation.NTPServer[i], p_DNSname->data, sizeof(p_res->NTPInformation.NTPServer[i])-1);
				++i;
			}
		}
		
		p_NTP = p_NTP->next;
	}

	return TRUE;
}

BOOL parse_GetHostname(XMLN * p_node, GetHostname_RES * p_res)
{
	XMLN * p_HostnameInformation;
	XMLN * p_FromDHCP;
	XMLN * p_Name;

	p_HostnameInformation = xml_node_soap_get(p_node, "HostnameInformation");
	if (NULL == p_HostnameInformation)
	{
		return FALSE;
	}	
	
	p_FromDHCP = xml_node_soap_get(p_HostnameInformation, "FromDHCP");
	if (p_FromDHCP && p_FromDHCP->data)
	{
		p_res->HostnameInformation.FromDHCP = parse_Bool(p_FromDHCP->data);
	}
	
	p_Name = xml_node_soap_get(p_HostnameInformation, "Name");
	if (p_Name && p_Name->data)
	{
		p_res->HostnameInformation.NameFlag = 1;
		strncpy(p_res->HostnameInformation.Name, p_Name->data, sizeof(p_res->HostnameInformation.Name)-1);
	}

	return TRUE;
}

BOOL parse_GetDNS(XMLN * p_node, GetDNS_RES * p_res)
{
	int i = 0;
	char node[32];
	XMLN * p_DNSInformation;
	XMLN * p_FromDHCP;
	XMLN * p_SearchDomain;
	XMLN * p_DNS;

	p_DNSInformation = xml_node_soap_get(p_node, "DNSInformation");
	if (NULL == p_DNSInformation)
	{
		return FALSE;
	}
	
	p_FromDHCP = xml_node_soap_get(p_DNSInformation, "FromDHCP");
	if (p_FromDHCP && p_FromDHCP->data)
	{
		p_res->DNSInformation.FromDHCP = parse_Bool(p_FromDHCP->data);
	}
	
	p_SearchDomain = xml_node_soap_get(p_DNSInformation, "SearchDomain");
	while (p_SearchDomain && p_SearchDomain->data && soap_strcmp(p_SearchDomain->name, "SearchDomain") == 0)
	{
		p_res->DNSInformation.SearchDomainFlag = 1;
		
		if (i < MAX_SEARCHDOMAIN)
		{
			strncpy(p_res->DNSInformation.SearchDomain[i], p_SearchDomain->data, sizeof(p_res->DNSInformation.SearchDomain[i])-1);
			++i;
		}

		p_SearchDomain = p_SearchDomain->next;
	}
	
	i = 0;

	if (p_res->DNSInformation.FromDHCP)
	{
		strcpy(node, "DNSFromDHCP");
	}
	else
	{
		strcpy(node, "DNSManual");
	}
	
	p_DNS = xml_node_soap_get(p_DNSInformation, node);
	while (p_DNS && soap_strcmp(p_DNS->name, node) == 0)
	{
		XMLN * p_Type;
		XMLN * p_IPv4Address;

		p_Type = xml_node_soap_get(p_DNS, "Type");
		if (p_Type && p_Type->data)
		{
			if (strcasecmp(p_Type->data, "IPv4") != 0) // only support ipv4
			{
			    p_DNS = p_DNS->next;
				continue;
			}
		}

		p_IPv4Address = xml_node_soap_get(p_DNS, "IPv4Address");
		if (p_IPv4Address && p_IPv4Address->data)
		{
			if (is_ip_address(p_IPv4Address->data) && i < MAX_NTP_SERVER)
			{
				strncpy(p_res->DNSInformation.DNSServer[i], p_IPv4Address->data, sizeof(p_res->DNSInformation.DNSServer[i])-1);
				++i;
			}
		}
		
		p_DNS = p_DNS->next;
	}

	return TRUE;
}

BOOL parse_GetDynamicDNS(XMLN * p_node, GetDynamicDNS_RES * p_res)
{
	XMLN * p_DynamicDNSInformation;
	XMLN * p_Type;
	XMLN * p_Name;
	XMLN * p_TTL;

	p_DynamicDNSInformation = xml_node_soap_get(p_node, "DynamicDNSInformation");
	if (NULL == p_DynamicDNSInformation)
	{
		return FALSE;
	}

	p_Type = xml_node_soap_get(p_DynamicDNSInformation, "Type");
	if (p_Type && p_Type->data)
	{
		p_res->DynamicDNSInformation.Type = onvif_StringToDynamicDNSType(p_Type->data);
	}

	p_Name = xml_node_soap_get(p_DynamicDNSInformation, "Name");
	if (p_Name && p_Name->data)
	{
		strncpy(p_res->DynamicDNSInformation.Name, p_Name->data, sizeof(p_res->DynamicDNSInformation.Name)-1);
	}

	p_TTL = xml_node_soap_get(p_DynamicDNSInformation, "TTL");
	if (p_TTL && p_TTL->data)
	{
		p_res->DynamicDNSInformation.TTL = atoi(p_TTL->data);
	}

	return TRUE;
}


BOOL parse_GetNetworkProtocols(XMLN * p_node, GetNetworkProtocols_RES * p_res)
{
	char name[32];
	BOOL enable;
	int  port[MAX_SERVER_PORT];
	
	XMLN * p_NetworkProtocols = xml_node_soap_get(p_node, "NetworkProtocols");
	while (p_NetworkProtocols && soap_strcmp(p_NetworkProtocols->name, "NetworkProtocols") == 0)
	{
		int i = 0;
		XMLN * p_Name;
		XMLN * p_Enabled;
		XMLN * p_Port;
		
		enable = FALSE;
		memset(name, 0, sizeof(name));
		memset(port, 0, sizeof(int)*MAX_SERVER_PORT);
		
		p_Name = xml_node_soap_get(p_NetworkProtocols, "Name");
		if (p_Name && p_Name->data)
		{
			strncpy(name, p_Name->data, sizeof(name)-1);
		}

		p_Enabled = xml_node_soap_get(p_NetworkProtocols, "Enabled");
		if (p_Enabled && p_Enabled->data)
		{
			enable = parse_Bool(p_Enabled->data);
		}
		
		p_Port = xml_node_soap_get(p_NetworkProtocols, "Port");
		while (p_Port && p_Port->data && soap_strcmp(p_Port->name, "Port") == 0)
		{
			if (i < MAX_SERVER_PORT)
			{
				port[i++] = atoi(p_Port->data);
			}
			
			p_Port = p_Port->next;
		}

		if (strcasecmp(name, "HTTP") == 0)
		{
			p_res->NetworkProtocols.HTTPFlag = 1;
			p_res->NetworkProtocols.HTTPEnabled = enable;
			memcpy(p_res->NetworkProtocols.HTTPPort, port, sizeof(int)*MAX_SERVER_PORT);
		}
		else if (strcasecmp(name, "HTTPS") == 0)
		{
			p_res->NetworkProtocols.HTTPSFlag = 1;
			p_res->NetworkProtocols.HTTPSEnabled = enable;
			memcpy(p_res->NetworkProtocols.HTTPSPort, port, sizeof(int)*MAX_SERVER_PORT);
		}
		else if (strcasecmp(name, "RTSP") == 0)
		{
			p_res->NetworkProtocols.RTSPFlag = 1;
			p_res->NetworkProtocols.RTSPEnabled = enable;
			memcpy(p_res->NetworkProtocols.RTSPPort, port, sizeof(int)*MAX_SERVER_PORT);
		}
		
		p_NetworkProtocols = p_NetworkProtocols->next;
	}

	return TRUE;
}

BOOL parse_GetDiscoveryMode(XMLN * p_node, GetDiscoveryMode_RES * p_res)
{
	XMLN * p_DiscoveryMode = xml_node_soap_get(p_node, "DiscoveryMode");
	if (p_DiscoveryMode && p_DiscoveryMode->data)
	{
		p_res->DiscoveryMode = onvif_StringToDiscoveryMode(p_DiscoveryMode->data);
	}

	return TRUE;
}

BOOL parse_GetNetworkDefaultGateway(XMLN * p_node, GetNetworkDefaultGateway_RES * p_res)
{
	int i = 0;
	XMLN * p_NetworkGateway;
	XMLN * p_IPv4Address;

	p_NetworkGateway = xml_node_soap_get(p_node, "NetworkGateway");
	if (NULL == p_NetworkGateway)
	{
		return FALSE;
	}

	p_IPv4Address = xml_node_soap_get(p_NetworkGateway, "IPv4Address");
	while (p_IPv4Address && p_IPv4Address->data && soap_strcmp(p_IPv4Address->name, "IPv4Address") == 0)
	{
		if (is_ip_address(p_IPv4Address->data) && i < MAX_GATEWAY)
		{
			strncpy(p_res->IPv4Address[i++], p_IPv4Address->data, sizeof(p_res->IPv4Address[0])-1);
		}
		
		p_IPv4Address = p_IPv4Address->next;
	}

	return TRUE;
}

BOOL parse_GetZeroConfiguration(XMLN * p_node, GetZeroConfiguration_RES * p_res)
{
    XMLN * p_ZeroConfiguration;
    
    p_ZeroConfiguration = xml_node_soap_get(p_node, "ZeroConfiguration");
    if (p_ZeroConfiguration)
    {
        XMLN * p_InterfaceToken;
        XMLN * p_Enabled;
        XMLN * p_Addresses;

        p_InterfaceToken = xml_node_soap_get(p_ZeroConfiguration, "InterfaceToken");
        if (p_InterfaceToken && p_InterfaceToken->data)
        {
            strncpy(p_res->ZeroConfiguration.InterfaceToken, p_InterfaceToken->data, sizeof(p_res->ZeroConfiguration.InterfaceToken)-1);
        }

        p_Enabled = xml_node_soap_get(p_ZeroConfiguration, "Enabled");
        if (p_Enabled && p_Enabled->data)
        {
            p_res->ZeroConfiguration.Enabled = parse_Bool(p_Enabled->data);
        }

        p_Addresses = xml_node_soap_get(p_ZeroConfiguration, "Addresses");
        while (p_Addresses && p_Addresses->data && soap_strcmp(p_Addresses->name, "Addresses") == 0)
        {
            int idx = p_res->ZeroConfiguration.sizeAddresses;

            strncpy(p_res->ZeroConfiguration.Addresses[idx], p_Addresses->data, sizeof(p_res->ZeroConfiguration.Addresses[idx])-1);
            
            p_res->ZeroConfiguration.sizeAddresses++;
            if (p_res->ZeroConfiguration.sizeAddresses >= 4)
            {
                break;
            }
            
            p_Addresses = p_Addresses->next;
        }
    }

    return TRUE;
}

BOOL parse_GetSnapshotUri(XMLN * p_node, GetSnapshotUri_RES * p_res)
{
    XMLN * p_MediaUri;
	XMLN * p_Uri;
	XMLN * p_InvalidAfterConnect;
	XMLN * p_InvalidAfterReboot;
	XMLN * p_Timeout;

	p_MediaUri = xml_node_soap_get(p_node, "MediaUri");
    if (NULL == p_MediaUri)
    {
    	return FALSE;
    }
    
    p_Uri = xml_node_soap_get(p_MediaUri, "Uri");
    if (p_Uri && p_Uri->data)
    {
        strncpy(p_res->Uri, p_Uri->data, sizeof(p_res->Uri));
    }
    else
    {
        return FALSE;
    }

	p_InvalidAfterConnect = xml_node_soap_get(p_MediaUri, "InvalidAfterConnect");
    if (p_InvalidAfterConnect && p_InvalidAfterConnect->data)
    {
    	p_res->InvalidAfterConnect = parse_Bool(p_InvalidAfterConnect->data);
    }

    p_InvalidAfterReboot = xml_node_soap_get(p_MediaUri, "InvalidAfterReboot");
    if (p_InvalidAfterReboot && p_InvalidAfterReboot->data)
    {
    	p_res->InvalidAfterReboot = parse_Bool(p_InvalidAfterReboot->data);
    }

	p_Timeout = xml_node_soap_get(p_MediaUri, "Timeout");
    if (p_Timeout && p_Timeout->data)
    {
    	p_res->Timeout = parse_Time(p_Timeout->data);
    }
    
    return TRUE;
}

BOOL parse_IntRange(XMLN * p_node, onvif_IntRange * p_res)
{
	XMLN * p_Min;
	XMLN * p_Max;

	p_Min = xml_node_soap_get(p_node, "Min");
	if (p_Min && p_Min->data)
	{
		p_res->Min = atoi(p_Min->data);
	}

	p_Max = xml_node_soap_get(p_node, "Max");
	if (p_Max && p_Max->data)
	{
		p_res->Max = atoi(p_Max->data);
	}

	return TRUE;
}

BOOL parse_VideoResolution(XMLN * p_node, onvif_VideoResolution * p_res)
{
	XMLN * p_Width;
	XMLN * p_Height;

	p_Width = xml_node_soap_get(p_node, "Width");
	if (p_Width && p_Width->data)
	{
		p_res->Width = atoi(p_Width->data);
	}

	p_Height = xml_node_soap_get(p_node, "Height");
	if (p_Height && p_Height->data)
	{
		p_res->Height = atoi(p_Height->data);
	}

	return TRUE;
}

BOOL parse_GetVideoSourceConfigurationOptions(XMLN * p_node, GetVideoSourceConfigurationOptions_RES * p_res)
{
    XMLN * p_Options;
    XMLN * p_BoundsRange;
    XMLN * p_VideoSourceTokensAvailable;
    XMLN * p_Extension;

    p_Options = xml_node_soap_get(p_node, "Options");
	if (NULL == p_Options)
	{
		return FALSE;
	}

	p_BoundsRange = xml_node_soap_get(p_Options, "BoundsRange");
	if (p_BoundsRange)
	{

	    XMLN * p_XRange;
	    XMLN * p_YRange;
	    XMLN * p_WidthRange;
	    XMLN * p_HeightRange;

	    p_XRange = xml_node_soap_get(p_BoundsRange, "XRange");
	    if (p_XRange)
	    {
	        parse_IntRange(p_XRange, &p_res->Options.BoundsRange.XRange);
	    }
	    
	    p_YRange = xml_node_soap_get(p_BoundsRange, "YRange");
	    if (p_YRange)
	    {
	        parse_IntRange(p_YRange, &p_res->Options.BoundsRange.YRange);
	    }

	    p_WidthRange = xml_node_soap_get(p_BoundsRange, "WidthRange");
	    if (p_WidthRange)
	    {
	        parse_IntRange(p_WidthRange, &p_res->Options.BoundsRange.WidthRange);
	    }

	    p_HeightRange = xml_node_soap_get(p_BoundsRange, "HeightRange");
	    if (p_HeightRange)
	    {
	        parse_IntRange(p_HeightRange, &p_res->Options.BoundsRange.HeightRange);
	    }
	}

    p_res->Options.sizeVideoSourceTokensAvailable = 0;
    
	p_VideoSourceTokensAvailable = xml_node_soap_get(p_Options, "VideoSourceTokensAvailable");
	while (p_VideoSourceTokensAvailable && 
	       p_VideoSourceTokensAvailable->data && 
	       soap_strcmp(p_VideoSourceTokensAvailable->name, "VideoSourceTokensAvailable") == 0)
	{
	    if (p_res->Options.sizeVideoSourceTokensAvailable < 10)
	    {
	        strncpy(p_res->Options.VideoSourceTokensAvailable[p_res->Options.sizeVideoSourceTokensAvailable], 
	            p_VideoSourceTokensAvailable->data, 
	            sizeof(p_res->Options.VideoSourceTokensAvailable[p_res->Options.sizeVideoSourceTokensAvailable])-1);
	        p_res->Options.sizeVideoSourceTokensAvailable++;
	    }

	    p_VideoSourceTokensAvailable = p_VideoSourceTokensAvailable->next;
	}

	p_Extension = xml_node_soap_get(p_Options, "Extension");
	if (p_Extension)
	{
	    XMLN * p_Rotate;
	    
	    p_res->Options.ExtensionFlag = 1;

	    p_Rotate = xml_node_soap_get(p_Extension, "Rotate");
	    if (p_Rotate)
	    {
	        XMLN * p_Mode;
	        XMLN * p_DegreeList;

	        p_res->Options.Extension.RotateFlag = 1;
	        
	        p_Mode = xml_node_soap_get(p_Rotate, "Mode");
    	    while (p_Mode && p_Mode->data && soap_strcmp(p_Mode->name, "Mode") == 0)
    	    {
    	        if (strcasecmp(p_Mode->data, "OFF") == 0)
    	        {
    	            p_res->Options.Extension.Rotate.RotateMode_OFF = 1;
    	        }
    	        else if (strcasecmp(p_Mode->data, "ON") == 0)
    	        {
    	            p_res->Options.Extension.Rotate.RotateMode_ON = 1;
    	        }
    	        else if (strcasecmp(p_Mode->data, "AUTO") == 0)
    	        {
    	            p_res->Options.Extension.Rotate.RotateMode_AUTO = 1;
    	        }
    	        
    	        p_Mode = p_Mode->next;
    	    }

    	    p_DegreeList = xml_node_soap_get(p_Rotate, "DegreeList");
    	    if (p_DegreeList)
    	    {
    	        XMLN * p_Items;
    	        
    	        p_res->Options.Extension.Rotate.DegreeListFlag = 1;
                p_res->Options.Extension.Rotate.sizeDegreeList = 0;
                
    	        p_Items = xml_node_soap_get(p_DegreeList, "Items"); 
    	        while (p_Items && p_Items->data && soap_strcmp(p_Items->name, "Items") == 0)
    	        {
    	            if (p_res->Options.Extension.Rotate.sizeDegreeList < 10)
    	            {
                        p_res->Options.Extension.Rotate.DegreeList[p_res->Options.Extension.Rotate.sizeDegreeList] = atoi(p_Items->data);
    	                p_res->Options.Extension.Rotate.sizeDegreeList++;
    	            }
    	            
    	            p_Items = p_Items->next;
    	        }
    	    }
	    }
	}

	return TRUE;
}

BOOL parse_JPEGOptions(XMLN * p_node, onvif_JpegOptions * p_res)
{
    int	i = 0;		
	XMLN * p_ResolutionsAvailable;
	XMLN * p_FrameRateRange;
	XMLN * p_EncodingIntervalRange;	
	
	p_ResolutionsAvailable = xml_node_soap_get(p_node, "ResolutionsAvailable");
	while (p_ResolutionsAvailable && soap_strcmp(p_ResolutionsAvailable->name, "ResolutionsAvailable") == 0)
	{
		parse_VideoResolution(p_ResolutionsAvailable, &p_res->ResolutionsAvailable[i++]);

		if (i >= MAX_RES_NUMS)
		{
			break;
		}
		
		p_ResolutionsAvailable = p_ResolutionsAvailable->next;
	}

	p_FrameRateRange = xml_node_soap_get(p_node, "FrameRateRange");
	if (p_FrameRateRange)
	{
		parse_IntRange(p_FrameRateRange, &p_res->FrameRateRange);			
	}

	p_EncodingIntervalRange = xml_node_soap_get(p_node, "EncodingIntervalRange");
	if (p_EncodingIntervalRange)
	{
		parse_IntRange(p_EncodingIntervalRange, &p_res->EncodingIntervalRange);	
	}

	return TRUE;
}

BOOL parse_MPEG4Options(XMLN * p_node, onvif_Mpeg4Options * p_res)
{
    int	i = 0;		
	XMLN * p_ResolutionsAvailable;
	XMLN * p_GovLengthRange;
	XMLN * p_FrameRateRange;
	XMLN * p_EncodingIntervalRange;
	XMLN * p_Mpeg4ProfilesSupported;
	
	p_ResolutionsAvailable = xml_node_soap_get(p_node, "ResolutionsAvailable");
	while (p_ResolutionsAvailable && soap_strcmp(p_ResolutionsAvailable->name, "ResolutionsAvailable") == 0)
	{
		parse_VideoResolution(p_ResolutionsAvailable, &p_res->ResolutionsAvailable[i++]);

		if (i >= MAX_RES_NUMS)
		{
			break;
		}
		
		p_ResolutionsAvailable = p_ResolutionsAvailable->next;
	}

	p_GovLengthRange = xml_node_soap_get(p_node, "GovLengthRange");
	if (p_GovLengthRange)
	{
		parse_IntRange(p_GovLengthRange, &p_res->GovLengthRange);
	}
	
	p_FrameRateRange = xml_node_soap_get(p_node, "FrameRateRange");
	if (p_FrameRateRange)
	{
		parse_IntRange(p_FrameRateRange, &p_res->FrameRateRange);
	}

	p_EncodingIntervalRange = xml_node_soap_get(p_node, "EncodingIntervalRange");
	if (p_EncodingIntervalRange)
	{
		parse_IntRange(p_EncodingIntervalRange, &p_res->EncodingIntervalRange);
	}

	p_Mpeg4ProfilesSupported = xml_node_soap_get(p_node, "Mpeg4ProfilesSupported");
	while (p_Mpeg4ProfilesSupported && soap_strcmp(p_Mpeg4ProfilesSupported->name, "Mpeg4ProfilesSupported") == 0)
	{
		if (strcasecmp(p_Mpeg4ProfilesSupported->data, "SP") == 0)
		{
			p_res->Mpeg4Profile_SP = 1;
		}
		else if (strcasecmp(p_Mpeg4ProfilesSupported->data, "ASP") == 0)
		{
			p_res->Mpeg4Profile_ASP = 1;
		}
		
		p_Mpeg4ProfilesSupported = p_Mpeg4ProfilesSupported->next;
	}

	return TRUE;
}

BOOL parse_H264Options(XMLN * p_node, onvif_H264Options * p_res)
{
    int	i = 0;		
	XMLN * p_ResolutionsAvailable;
	XMLN * p_GovLengthRange;
	XMLN * p_FrameRateRange;
	XMLN * p_EncodingIntervalRange;
	XMLN * p_H264ProfilesSupported;

	p_ResolutionsAvailable = xml_node_soap_get(p_node, "ResolutionsAvailable");
	while (p_ResolutionsAvailable && soap_strcmp(p_ResolutionsAvailable->name, "ResolutionsAvailable") == 0)
	{
		parse_VideoResolution(p_ResolutionsAvailable, &p_res->ResolutionsAvailable[i++]);

		if (i >= MAX_RES_NUMS)
		{
			break;
		}
		
		p_ResolutionsAvailable = p_ResolutionsAvailable->next;
	}

	p_GovLengthRange = xml_node_soap_get(p_node, "GovLengthRange");
	if (p_GovLengthRange)
	{
		parse_IntRange(p_GovLengthRange, &p_res->GovLengthRange);
	}
	
	p_FrameRateRange = xml_node_soap_get(p_node, "FrameRateRange");
	if (p_FrameRateRange)
	{
		parse_IntRange(p_FrameRateRange, &p_res->FrameRateRange);
	}

	p_EncodingIntervalRange = xml_node_soap_get(p_node, "EncodingIntervalRange");
	if (p_EncodingIntervalRange)
	{
		parse_IntRange(p_EncodingIntervalRange, &p_res->EncodingIntervalRange);
	}

	p_H264ProfilesSupported = xml_node_soap_get(p_node, "H264ProfilesSupported");
	while (p_H264ProfilesSupported && soap_strcmp(p_H264ProfilesSupported->name, "H264ProfilesSupported") == 0)
	{
		if (strcasecmp(p_H264ProfilesSupported->data, "Baseline") == 0)
		{
			p_res->H264Profile_Baseline = 1;
		}
		else if (strcasecmp(p_H264ProfilesSupported->data, "Main") == 0)
		{
			p_res->H264Profile_Main = 1;
		}
		else if (strcasecmp(p_H264ProfilesSupported->data, "High") == 0)
		{
			p_res->H264Profile_High = 1;
		}
		else if (strcasecmp(p_H264ProfilesSupported->data, "Extended") == 0)
		{
			p_res->H264Profile_Extended = 1;
		}
		
		p_H264ProfilesSupported = p_H264ProfilesSupported->next;
	}

	return TRUE;
}

BOOL parse_GetVideoEncoderConfigurationOptions(XMLN * p_node, GetVideoEncoderConfigurationOptions_RES * p_res)
{
	XMLN * p_Options;
	XMLN * p_QualityRange;
	XMLN * p_JPEG;
	XMLN * p_MPEG4;
	XMLN * p_H264;
	XMLN * p_Extension;

	p_Options = xml_node_soap_get(p_node, "Options");
	if (NULL == p_Options)
	{
		return FALSE;
	}

	p_QualityRange = xml_node_soap_get(p_Options, "QualityRange");
	if (p_QualityRange)
	{
		parse_IntRange(p_QualityRange, &p_res->Options.QualityRange);
	}

	p_JPEG = xml_node_soap_get(p_Options, "JPEG");
	if (p_JPEG)
	{
		p_res->Options.JPEGFlag = 1;		
		parse_JPEGOptions(p_JPEG, &p_res->Options.JPEG);
	}

	p_MPEG4 = xml_node_soap_get(p_Options, "MPEG4");
	if (p_MPEG4)
	{
		p_res->Options.MPEG4Flag = 1;
		parse_MPEG4Options(p_MPEG4, &p_res->Options.MPEG4);
	}	

	p_H264 = xml_node_soap_get(p_Options, "H264");
	if (p_H264)
	{
		p_res->Options.H264Flag = 1;
	    parse_H264Options(p_H264, &p_res->Options.H264);
	}	

    p_Extension = xml_node_soap_get(p_Options, "Extension");
	if (p_Extension)
	{
	    XMLN * p_JPEG;
    	XMLN * p_MPEG4;
    	XMLN * p_H264;
    	XMLN * p_BitrateRange;

    	p_res->Options.ExtensionFlag = 1;

    	p_JPEG = xml_node_soap_get(p_Extension, "JPEG");
    	if (p_JPEG)
    	{
    		p_res->Options.Extension.JPEGFlag = 1;		
    		parse_JPEGOptions(p_JPEG, &p_res->Options.Extension.JPEG.JpegOptions);

    		p_BitrateRange = xml_node_soap_get(p_JPEG, "BitrateRange");
        	if (p_BitrateRange)
        	{
        		parse_IntRange(p_BitrateRange, &p_res->Options.Extension.JPEG.BitrateRange);			
        	}
    	}

    	p_MPEG4 = xml_node_soap_get(p_Extension, "MPEG4");
    	if (p_MPEG4)
    	{
    		p_res->Options.Extension.MPEG4Flag = 1;
    		parse_MPEG4Options(p_MPEG4, &p_res->Options.Extension.MPEG4.Mpeg4Options);

    		p_BitrateRange = xml_node_soap_get(p_MPEG4, "BitrateRange");
        	if (p_BitrateRange)
        	{
        		parse_IntRange(p_BitrateRange, &p_res->Options.Extension.MPEG4.BitrateRange);			
        	}
    	}	

    	p_H264 = xml_node_soap_get(p_Extension, "H264");
    	if (p_H264)
    	{
    		p_res->Options.Extension.H264Flag = 1;
    	    parse_H264Options(p_H264, &p_res->Options.Extension.H264.H264Options);

    	    p_BitrateRange = xml_node_soap_get(p_H264, "BitrateRange");
        	if (p_BitrateRange)
        	{
        		parse_IntRange(p_BitrateRange, &p_res->Options.Extension.H264.BitrateRange);			
        	}
    	}	
	}
    
	return TRUE;
}

BOOL parse_GetAudioEncoderConfigurationOptions(XMLN * p_node, GetAudioEncoderConfigurationOptions_RES * p_res)
{
	XMLN * p_Options;

	p_Options = xml_node_soap_get(p_node, "Options");
	if (p_Options)
	{	
		XMLN * p_Options1;
		
		p_Options1 = xml_node_soap_get(p_Options, "Options");
		while (p_Options1 && soap_strcmp(p_Options1->name, "Options") == 0)
		{
			XMLN * p_Encoding;
			XMLN * p_BitrateList;
			XMLN * p_SampleRateList;

			int idx = p_res->Options.sizeOptions;
			
			p_Encoding = xml_node_soap_get(p_Options1, "Encoding");
			if (p_Encoding && p_Encoding->data)
			{
				p_res->Options.Options[idx].Encoding = onvif_StringToAudioEncoding(p_Encoding->data);				
			}

			p_BitrateList = xml_node_soap_get(p_Options1, "BitrateList");
			if (p_BitrateList)
			{
				parse_IntList(p_BitrateList, &p_res->Options.Options[idx].BitrateList);
			}

			p_SampleRateList = xml_node_soap_get(p_Options1, "SampleRateList");
			if (p_SampleRateList)
			{
				parse_IntList(p_SampleRateList, &p_res->Options.Options[idx].SampleRateList);
			}

			p_res->Options.sizeOptions++;
			if (p_res->Options.sizeOptions >= 3)
			{
				break;
			}

			p_Options1 = p_Options1->next;
		}
	}

	return TRUE;
}

BOOL parse_PTZNode(XMLN * p_node, onvif_PTZNode * p_res)
{
	XMLN * p_Name;
	XMLN * p_SupportedPTZSpaces;
	XMLN * p_MaximumNumberOfPresets;
	XMLN * p_HomeSupported;
	XMLN * p_Extension;

	p_Name = xml_node_soap_get(p_node, "Name");
	if (p_Name && p_Name->data)
	{
		p_res->NameFlag = 1;
		strncpy(p_res->Name, p_Name->data, sizeof(p_res->Name)-1);
	}

	p_SupportedPTZSpaces = xml_node_soap_get(p_node, "SupportedPTZSpaces");
	if (p_SupportedPTZSpaces)
	{
		XMLN * p_AbsolutePanTiltPositionSpace;
		XMLN * p_AbsoluteZoomPositionSpace;
		XMLN * p_RelativePanTiltTranslationSpace;
		XMLN * p_RelativeZoomTranslationSpace;
		XMLN * p_ContinuousPanTiltVelocitySpace;
		XMLN * p_ContinuousZoomVelocitySpace;
		XMLN * p_PanTiltSpeedSpace;
		XMLN * p_ZoomSpeedSpace;

		p_AbsolutePanTiltPositionSpace = xml_node_soap_get(p_SupportedPTZSpaces, "AbsolutePanTiltPositionSpace");
		if (p_AbsolutePanTiltPositionSpace)
		{
			p_res->SupportedPTZSpaces.AbsolutePanTiltPositionSpaceFlag = 1;			
			parse_Space2DDescription(p_AbsolutePanTiltPositionSpace, &p_res->SupportedPTZSpaces.AbsolutePanTiltPositionSpace);
		}

		p_AbsoluteZoomPositionSpace = xml_node_soap_get(p_SupportedPTZSpaces, "AbsoluteZoomPositionSpace");
		if (p_AbsoluteZoomPositionSpace)
		{
			p_res->SupportedPTZSpaces.AbsoluteZoomPositionSpaceFlag = 1;			
			parse_Space1DDescription(p_AbsoluteZoomPositionSpace, &p_res->SupportedPTZSpaces.AbsoluteZoomPositionSpace);
		}

		p_RelativePanTiltTranslationSpace = xml_node_soap_get(p_SupportedPTZSpaces, "RelativePanTiltTranslationSpace");
		if (p_RelativePanTiltTranslationSpace)
		{
			p_res->SupportedPTZSpaces.RelativePanTiltTranslationSpaceFlag = 1;			
			parse_Space2DDescription(p_RelativePanTiltTranslationSpace, &p_res->SupportedPTZSpaces.RelativePanTiltTranslationSpace);
		}

		p_RelativeZoomTranslationSpace = xml_node_soap_get(p_SupportedPTZSpaces, "RelativeZoomTranslationSpace");
		if (p_RelativeZoomTranslationSpace)
		{
			p_res->SupportedPTZSpaces.RelativeZoomTranslationSpaceFlag = 1;			
			parse_Space1DDescription(p_RelativeZoomTranslationSpace, &p_res->SupportedPTZSpaces.RelativeZoomTranslationSpace);
		}

		p_ContinuousPanTiltVelocitySpace = xml_node_soap_get(p_SupportedPTZSpaces, "ContinuousPanTiltVelocitySpace");
		if (p_ContinuousPanTiltVelocitySpace)
		{
			p_res->SupportedPTZSpaces.ContinuousPanTiltVelocitySpaceFlag = 1;			
			parse_Space2DDescription(p_ContinuousPanTiltVelocitySpace, &p_res->SupportedPTZSpaces.ContinuousPanTiltVelocitySpace);
		}

		p_ContinuousZoomVelocitySpace = xml_node_soap_get(p_SupportedPTZSpaces, "ContinuousZoomVelocitySpace");
		if (p_ContinuousZoomVelocitySpace)
		{
			p_res->SupportedPTZSpaces.ContinuousZoomVelocitySpaceFlag = 1;			
			parse_Space1DDescription(p_ContinuousZoomVelocitySpace, &p_res->SupportedPTZSpaces.ContinuousZoomVelocitySpace);
		}

		p_PanTiltSpeedSpace = xml_node_soap_get(p_SupportedPTZSpaces, "PanTiltSpeedSpace");
		if (p_PanTiltSpeedSpace)
		{
			p_res->SupportedPTZSpaces.PanTiltSpeedSpaceFlag = 1;			
			parse_Space1DDescription(p_PanTiltSpeedSpace, &p_res->SupportedPTZSpaces.PanTiltSpeedSpace);
		}

		p_ZoomSpeedSpace = xml_node_soap_get(p_SupportedPTZSpaces, "ZoomSpeedSpace");
		if (p_ZoomSpeedSpace)
		{
			p_res->SupportedPTZSpaces.ZoomSpeedSpaceFlag = 1;			
			parse_Space1DDescription(p_ZoomSpeedSpace, &p_res->SupportedPTZSpaces.ZoomSpeedSpace);
		}
	}

	p_MaximumNumberOfPresets = xml_node_soap_get(p_node, "MaximumNumberOfPresets");
	if (p_MaximumNumberOfPresets && p_MaximumNumberOfPresets->data)
	{
		p_res->MaximumNumberOfPresets = atoi(p_MaximumNumberOfPresets->data);
	}
	
	p_HomeSupported = xml_node_soap_get(p_node, "HomeSupported");
	if (p_HomeSupported && p_HomeSupported->data)
	{
		p_res->HomeSupported = parse_Bool(p_HomeSupported->data);
	}

	p_Extension = xml_node_soap_get(p_node, "Extension");
	if (p_Extension)
	{
		XMLN * p_SupportedPresetTour;
		
		p_res->ExtensionFlag = 1;
		
		p_SupportedPresetTour = xml_node_soap_get(p_Extension, "SupportedPresetTour");
		if (p_SupportedPresetTour)
		{
			XMLN * p_MaximumNumberOfPresetTours;
			XMLN * p_PTZPresetTourOperation;
			
			p_res->Extension.SupportedPresetTourFlag = 1;

			p_MaximumNumberOfPresetTours = xml_node_soap_get(p_Extension, "MaximumNumberOfPresetTours");
			if (p_MaximumNumberOfPresetTours && p_MaximumNumberOfPresetTours->data)
			{
				p_res->Extension.SupportedPresetTour.MaximumNumberOfPresetTours = atoi(p_MaximumNumberOfPresetTours->data);
			}

			p_PTZPresetTourOperation = xml_node_soap_get(p_Extension, "PTZPresetTourOperation");
			while (p_PTZPresetTourOperation && p_PTZPresetTourOperation->data && soap_strcmp(p_PTZPresetTourOperation->name, "PTZPresetTourOperation") == 0)
			{
				if (strcasecmp(p_PTZPresetTourOperation->data, "Start") == 0)
				{
					p_res->Extension.SupportedPresetTour.PTZPresetTourOperation_Start = 1;
				}
				else if (strcasecmp(p_PTZPresetTourOperation->data, "Stop") == 0)
				{
					p_res->Extension.SupportedPresetTour.PTZPresetTourOperation_Stop = 1;
				}
				else if (strcasecmp(p_PTZPresetTourOperation->data, "Pause") == 0)
				{
					p_res->Extension.SupportedPresetTour.PTZPresetTourOperation_Pause = 1;
				}
				else if (strcasecmp(p_PTZPresetTourOperation->data, "Extended") == 0)
				{
					p_res->Extension.SupportedPresetTour.PTZPresetTourOperation_Extended = 1;
				}
			}
		}
	}
	
	return TRUE;
}

BOOL parse_Preset(XMLN * p_node, onvif_PTZPreset * p_res)
{
	XMLN * p_Name;
	XMLN * p_PTZPosition;

	p_Name = xml_node_soap_get(p_node, "Name");
	if (p_Name && p_Name->data)
	{
		strncpy(p_res->Name, p_Name->data, sizeof(p_res->Name)-1);
	}

	p_PTZPosition = xml_node_soap_get(p_node, "PTZPosition");
	if (p_PTZPosition)
	{
		p_res->PTZPositionFlag = 1;
		parse_PTZVector(p_PTZPosition, &p_res->PTZPosition);
	}

	return TRUE;
}

BOOL parse_SetPreset(XMLN * p_node, SetPreset_RES * p_res)
{
	XMLN * p_PresetToken = xml_node_soap_get(p_node, "PresetToken");
	if (p_PresetToken && p_PresetToken->data)
	{
		strncpy(p_res->PresetToken, p_PresetToken->data, sizeof(p_res->PresetToken)-1);
	}	

	return TRUE;
}

BOOL parse_GetStatus(XMLN * p_node, GetStatus_RES * p_res)
{	
	XMLN * p_PTZStatus;
	XMLN * p_Position;
	XMLN * p_MoveStatus;
	XMLN * p_Error;
	XMLN * p_UtcTime;

	p_PTZStatus = xml_node_soap_get(p_node, "PTZStatus");
	if (NULL == p_PTZStatus)
	{
		return FALSE;
	}

	p_Position = xml_node_soap_get(p_PTZStatus, "Position");
	if (p_Position)
	{
		p_res->PTZStatus.PositionFlag = 1;
		parse_PTZVector(p_Position, &p_res->PTZStatus.Position);
	}

	p_MoveStatus = xml_node_soap_get(p_PTZStatus, "MoveStatus");
	if (p_MoveStatus)
	{
		XMLN * p_PanTilt;
		XMLN * p_Zoom;

		p_res->PTZStatus.MoveStatusFlag = 1;
		
		p_PanTilt = xml_node_soap_get(p_MoveStatus, "PanTilt");
		if (p_PanTilt && p_PanTilt->data)
		{
			p_res->PTZStatus.MoveStatus.PanTiltFlag = 1;
			p_res->PTZStatus.MoveStatus.PanTilt = onvif_StringToMoveStatus(p_PanTilt->data);
		}

		p_Zoom = xml_node_soap_get(p_MoveStatus, "Zoom");
		if (p_Zoom && p_Zoom->data)
		{
			p_res->PTZStatus.MoveStatus.ZoomFlag = 1;
			p_res->PTZStatus.MoveStatus.Zoom = onvif_StringToMoveStatus(p_Zoom->data);
		}
	}

	p_Error = xml_node_soap_get(p_PTZStatus, "Error");
	if (p_Error && p_Error->data)
	{
		p_res->PTZStatus.ErrorFlag = 1;
		strncpy(p_res->PTZStatus.Error, p_Error->data, sizeof(p_res->PTZStatus.Error)-1);
	}

	p_UtcTime = xml_node_soap_get(p_PTZStatus, "UtcTime");
	if (p_UtcTime && p_UtcTime->data)
	{
		parse_XSDDatetime(p_UtcTime->data, &p_res->PTZStatus.UtcTime);
	}
	
	return TRUE;
}

BOOL parse_ImagingSettings(XMLN * p_node, onvif_ImagingSettings * p_res)
{
	XMLN * p_BacklightCompensation;
	XMLN * p_Brightness;
	XMLN * p_ColorSaturation;
	XMLN * p_Contrast;
	XMLN * p_Exposure;
	XMLN * p_Focus;
	XMLN * p_IrCutFilter;
	XMLN * p_Sharpness;
	XMLN * p_WideDynamicRange;
	XMLN * p_WhiteBalance;
	
    p_BacklightCompensation = xml_node_soap_get(p_node, "BacklightCompensation");
    if (p_BacklightCompensation)
    {
    	XMLN * p_Mode;
		XMLN * p_Level;

		p_res->BacklightCompensationFlag = 1;
		
		p_Mode = xml_node_soap_get(p_BacklightCompensation, "Mode");
    	if (p_Mode && p_Mode->data)
    	{
    		p_res->BacklightCompensation.Mode = onvif_StringToBacklightCompensationMode(p_Mode->data);
    	}

    	p_Level = xml_node_soap_get(p_BacklightCompensation, "Level");
    	if (p_Level && p_Level->data)
    	{
    		p_res->BacklightCompensation.LevelFlag = 1;
    	    p_res->BacklightCompensation.Level = (float)atof(p_Level->data);
    	}
    }

    p_Brightness = xml_node_soap_get(p_node, "Brightness");
    if (p_Brightness && p_Brightness->data)
    {
    	p_res->BrightnessFlag = 1;
    	p_res->Brightness = (float)atof(p_Brightness->data);
    }

    p_ColorSaturation = xml_node_soap_get(p_node, "ColorSaturation");
    if (p_ColorSaturation && p_ColorSaturation->data)
    {
    	p_res->ColorSaturationFlag = 1;
    	p_res->ColorSaturation = (float)atof(p_ColorSaturation->data);
    }

    p_Contrast = xml_node_soap_get(p_node, "Contrast");
    if (p_Contrast && p_Contrast->data)
    {
    	p_res->ContrastFlag = 1;
    	p_res->Contrast = (float)atof(p_Contrast->data);
    }

    p_Exposure = xml_node_soap_get(p_node, "Exposure");
    if (p_Exposure)
    {
    	XMLN * p_Mode;
		XMLN * p_Priority;
		XMLN * p_Window;
		XMLN * p_MinExposureTime;
		XMLN * p_MaxExposureTime;
		XMLN * p_MinGain;
		XMLN * p_MaxGain;
		XMLN * p_MinIris;
		XMLN * p_MaxIris;
		XMLN * p_ExposureTime;
		XMLN * p_Gain;
		XMLN * p_Iris;

		p_res->ExposureFlag = 1;
		
		p_Mode = xml_node_soap_get(p_Exposure, "Mode");
    	if (p_Mode && p_Mode->data)
    	{
    		p_res->Exposure.Mode = onvif_StringToExposureMode(p_Mode->data);
    	}

        p_Window = xml_node_soap_get(p_Exposure, "Priority");
    	if (p_Window && p_Window->data)
    	{
    		const char * p_bottom;
    		const char * p_top;
    		const char * p_right;
    		const char * p_left;

    	    p_bottom = xml_attr_get(p_Window, "bottom");
    	    if (p_bottom)
    	    {
    	        p_res->Exposure.Window.bottom = (float)atof(p_bottom);
    	    }

    	    p_top = xml_attr_get(p_Window, "top");
    	    if (p_top)
    	    {
    	        p_res->Exposure.Window.top = (float)atof(p_top);
    	    }

    	    p_right = xml_attr_get(p_Window, "right");
    	    if (p_right)
    	    {
    	        p_res->Exposure.Window.right = (float)atof(p_right);
    	    }

    	    p_left = xml_attr_get(p_Window, "left");
    	    if (p_left)
    	    {
    	        p_res->Exposure.Window.left = (float)atof(p_left);
    	    }
    	}

    	p_Priority = xml_node_soap_get(p_Exposure, "Priority");
    	if (p_Priority && p_Priority->data)
    	{
    		p_res->Exposure.PriorityFlag = 1;
    		p_res->Exposure.Priority = onvif_StringToExposurePriority(p_Priority->data);
    	}
    	
    	p_MinExposureTime = xml_node_soap_get(p_Exposure, "MinExposureTime");
    	if (p_MinExposureTime && p_MinExposureTime->data)
    	{
    		p_res->Exposure.MinExposureTimeFlag = 1;
    		p_res->Exposure.MinExposureTime = (float)atof(p_MinExposureTime->data);
    	}

    	p_MaxExposureTime = xml_node_soap_get(p_Exposure, "MaxExposureTime");
    	if (p_MaxExposureTime && p_MaxExposureTime->data)
    	{
    		p_res->Exposure.MaxExposureTimeFlag = 1;
    		p_res->Exposure.MaxExposureTime = (float)atof(p_MaxExposureTime->data);
    	}

    	p_MinGain = xml_node_soap_get(p_Exposure, "MinGain");
    	if (p_MinGain && p_MinGain->data)
    	{
    		p_res->Exposure.MinGainFlag = 1;
    		p_res->Exposure.MinGain = (float)atof(p_MinGain->data);
    	}

    	p_MaxGain = xml_node_soap_get(p_Exposure, "MaxGain");
    	if (p_MaxGain && p_MaxGain->data)
    	{
    		p_res->Exposure.MaxGainFlag = 1;
    		p_res->Exposure.MaxGain = (float)atof(p_MaxGain->data);
    	}

    	p_MinIris = xml_node_soap_get(p_Exposure, "MinIris");
    	if (p_MinIris && p_MinIris->data)
    	{
    		p_res->Exposure.MinIrisFlag = 1;
    		p_res->Exposure.MinIris = (float)atof(p_MinIris->data);
    	}

    	p_MaxIris = xml_node_soap_get(p_Exposure, "MaxIris");
    	if (p_MaxIris && p_MaxIris->data)
    	{
    		p_res->Exposure.MaxIrisFlag = 1;
    		p_res->Exposure.MaxIris = (float)atof(p_MaxIris->data);
    	}

    	p_ExposureTime = xml_node_soap_get(p_Exposure, "ExposureTime");
    	if (p_ExposureTime && p_ExposureTime->data)
    	{
    		p_res->Exposure.ExposureTimeFlag = 1;
    		p_res->Exposure.ExposureTime = (float)atof(p_ExposureTime->data);
    	}

    	p_Gain = xml_node_soap_get(p_Exposure, "Gain");
    	if (p_Gain && p_Gain->data)
    	{
    		p_res->Exposure.GainFlag = 1;
    		p_res->Exposure.Gain = (float)atof(p_Gain->data);
    	}

    	p_Iris = xml_node_soap_get(p_Exposure, "Iris");
    	if (p_Iris && p_Iris->data)
    	{
    		p_res->Exposure.IrisFlag = 1;
    		p_res->Exposure.Iris = (float)atof(p_Iris->data);
    	}
    }

    p_Focus = xml_node_soap_get(p_node, "Focus");
    if (p_Focus)
    {
        XMLN * p_AutoFocusMode;
		XMLN * p_DefaultSpeed;
		XMLN * p_NearLimit;
		XMLN * p_FarLimit;

		p_res->FocusFlag = 1;
		
		p_AutoFocusMode = xml_node_soap_get(p_Focus, "AutoFocusMode");
    	if (p_AutoFocusMode && p_AutoFocusMode->data)
    	{
    		p_res->Focus.AutoFocusMode = onvif_StringToAutoFocusMode(p_AutoFocusMode->data);
    	}

    	p_DefaultSpeed = xml_node_soap_get(p_Focus, "DefaultSpeed");
    	if (p_DefaultSpeed && p_DefaultSpeed->data)
    	{
    		p_res->Focus.DefaultSpeedFlag = 1;
    	    p_res->Focus.DefaultSpeed = (float)atof(p_DefaultSpeed->data);
    	}

    	p_NearLimit = xml_node_soap_get(p_Focus, "NearLimit");
    	if (p_NearLimit && p_NearLimit->data)
    	{
    		p_res->Focus.NearLimitFlag = 1;
    	    p_res->Focus.NearLimit = (float)atof(p_NearLimit->data);
    	}

    	p_FarLimit = xml_node_soap_get(p_Focus, "FarLimit");
    	if (p_FarLimit && p_FarLimit->data)
    	{
    		p_res->Focus.FarLimitFlag = 1;
    	    p_res->Focus.FarLimit = (float)atof(p_FarLimit->data);
    	}
    }
    
    p_IrCutFilter = xml_node_soap_get(p_node, "IrCutFilter");
    if (p_IrCutFilter && p_IrCutFilter->data)
    {
    	p_res->IrCutFilterFlag = 1;
    	p_res->IrCutFilter = onvif_StringToIrCutFilterMode(p_IrCutFilter->data);
    }

    p_Sharpness = xml_node_soap_get(p_node, "Sharpness");
    if (p_Sharpness && p_Sharpness->data)
    {
    	p_res->SharpnessFlag = 1;
    	p_res->Sharpness = (float)atof(p_Sharpness->data);
    }

    p_WideDynamicRange = xml_node_soap_get(p_node, "WideDynamicRange");
    if (p_WideDynamicRange)
    {
    	XMLN * p_Mode;
		XMLN * p_Level;

		p_res->WideDynamicRangeFlag = 1;
		
		p_Mode = xml_node_soap_get(p_WideDynamicRange, "Mode");
    	if (p_Mode && p_Mode->data)
    	{
    		p_res->WideDynamicRange.Mode = onvif_StringToWideDynamicMode(p_Mode->data);
    	}

    	p_Level = xml_node_soap_get(p_WideDynamicRange, "Level");
    	if (p_Level && p_Level->data)
    	{
    		p_res->WideDynamicRange.LevelFlag = 1;
    		p_res->WideDynamicRange.Level = (float)atof(p_Level->data);
    	}
    }

    p_WhiteBalance = xml_node_soap_get(p_node, "WhiteBalance");
    if (p_WhiteBalance)
    {
    	XMLN * p_Mode;
		XMLN * p_CrGain;
		XMLN * p_CbGain;

		p_res->WhiteBalanceFlag = 1;
		
		p_Mode = xml_node_soap_get(p_WhiteBalance, "Mode");
    	if (p_Mode && p_Mode->data)
    	{
    		p_res->WhiteBalance.Mode = onvif_StringToWhiteBalanceMode(p_Mode->data);
    	}

    	p_CrGain = xml_node_soap_get(p_WhiteBalance, "CrGain");
    	if (p_CrGain && p_CrGain->data)
    	{
    		p_res->WhiteBalance.CrGainFlag = 1;
    	    p_res->WhiteBalance.CrGain = (float)atof(p_CrGain->data);
    	}

    	p_CbGain = xml_node_soap_get(p_WhiteBalance, "CbGain");
    	if (p_CbGain && p_CbGain->data)
    	{
    		p_res->WhiteBalance.CbGainFlag = 1;
    	    p_res->WhiteBalance.CbGain = (float)atof(p_CbGain->data);
    	}
    }    
    
    return TRUE;
}

BOOL parse_VideoSource(XMLN * p_node, onvif_VideoSource * p_res)
{
    XMLN * p_Framerate;
	XMLN * p_Resolution;
	XMLN * p_Imaging;

	p_Framerate = xml_node_soap_get(p_node, "Framerate");
	if (p_Framerate && p_Framerate->data)
	{
	    p_res->Framerate = (float) atof(p_Framerate->data);
	}

	p_Resolution = xml_node_soap_get(p_node, "Resolution");
	if (p_Resolution)
	{
	    parse_Resolution(p_Resolution, &p_res->Resolution);
	}

	p_Imaging = xml_node_soap_get(p_node, "Imaging");
	if (p_Imaging)
	{
		p_res->ImagingSettingsFlag = parse_ImagingSettings(p_Imaging, &p_res->ImagingSettings);
	}
	
    return TRUE;
}

BOOL parse_AudioSource(XMLN * p_node, onvif_AudioSource * p_res)
{
    XMLN * p_Channels = xml_node_soap_get(p_node, "Channels");
	if (p_Channels && p_Channels->data)
	{
	    p_res->Channels = atoi(p_Channels->data);
	}
	
    return TRUE;
}

BOOL parse_Datetime(XMLN * p_node, onvif_DateTime * p_datetime)
{
    XMLN * p_Time;
	XMLN * p_Hour;
	XMLN * p_Minute;
	XMLN * p_Second;
	XMLN * p_Date;
	XMLN * p_Year;
	XMLN * p_Month;
	XMLN * p_Day;

	p_Time = xml_node_soap_get(p_node, "Time");
	if (NULL == p_Time)
	{
	    return FALSE;
	}

	p_Hour = xml_node_soap_get(p_Time, "Hour");
	if (p_Hour && p_Hour->data)
	{
	    p_datetime->Time.Hour = atoi(p_Hour->data);
	}

	p_Minute = xml_node_soap_get(p_Time, "Minute");
	if (p_Minute && p_Minute->data)
	{
	    p_datetime->Time.Minute = atoi(p_Minute->data);
	}

	p_Second = xml_node_soap_get(p_Time, "Second");
	if (p_Second && p_Second->data)
	{
	    p_datetime->Time.Second = atoi(p_Second->data);
	}

	p_Date = xml_node_soap_get(p_node, "Date");
	if (NULL == p_Date)
	{
	    return FALSE;
	}

	p_Year = xml_node_soap_get(p_Date, "Year");
	if (p_Year && p_Year->data)
	{
	    p_datetime->Date.Year = atoi(p_Year->data);
	}

	p_Month = xml_node_soap_get(p_Date, "Month");
	if (p_Month && p_Month->data)
	{
	    p_datetime->Date.Month = atoi(p_Month->data);
	}

	p_Day = xml_node_soap_get(p_Date, "Day");
	if (p_Day && p_Day->data)
	{
	    p_datetime->Date.Day = atoi(p_Day->data);
	}

	return TRUE;
}

BOOL parse_GetSystemDateAndTime(XMLN * p_node, GetSystemDateAndTime_RES * p_res)
{
    XMLN * p_SystemDateAndTime;
	XMLN * p_DateTimeType;
	XMLN * p_DaylightSavings;
	XMLN * p_TimeZone;
	XMLN * p_UTCDateTime;
	XMLN * p_LocalDateTime;

	p_SystemDateAndTime = xml_node_soap_get(p_node, "SystemDateAndTime");
	if (NULL == p_SystemDateAndTime)
	{
	    return FALSE;
	}

	p_DateTimeType = xml_node_soap_get(p_SystemDateAndTime, "DateTimeType");
	if (p_DateTimeType && p_DateTimeType->data)
	{
		p_res->SystemDateTime.DateTimeType = onvif_StringToSetDateTimeType(p_DateTimeType->data);
	}

	p_DaylightSavings = xml_node_soap_get(p_SystemDateAndTime, "DaylightSavings");
	if (p_DaylightSavings && p_DaylightSavings->data)
	{
	    p_res->SystemDateTime.DaylightSavings = parse_Bool(p_DaylightSavings->data);
	}

	p_TimeZone = xml_node_soap_get(p_SystemDateAndTime, "TimeZone");
	if (p_TimeZone)
	{
	    XMLN * p_TZ;

		p_res->SystemDateTime.TimeZoneFlag = 1;
		
	    p_TZ = xml_node_soap_get(p_TimeZone, "TZ");
    	if (p_TZ && p_TZ->data)
    	{
    	    strncpy(p_res->SystemDateTime.TimeZone.TZ, p_TZ->data, sizeof(p_res->SystemDateTime.TimeZone.TZ)-1);
    	}
	}

	p_UTCDateTime = xml_node_soap_get(p_SystemDateAndTime, "UTCDateTime");
	if (p_UTCDateTime)
	{
	    p_res->UTCDateTimeFlag = parse_Datetime(p_UTCDateTime, &p_res->UTCDateTime);
	}

	p_LocalDateTime = xml_node_soap_get(p_SystemDateAndTime, "LocalDateTime");
	if (p_LocalDateTime)
	{
	    p_res->LocalDateTimeFlag = parse_Datetime(p_LocalDateTime, &p_res->LocalDateTime);
	}

	return TRUE;
}

BOOL parse_GetOptions(XMLN * p_node, GetOptions_RES * p_res)
{
	XMLN * p_ImagingOptions;
	XMLN * p_BacklightCompensation;
	XMLN * p_Brightness;
	XMLN * p_ColorSaturation;
	XMLN * p_Contrast;
	XMLN * p_Exposure;
	XMLN * p_Focus;
	XMLN * p_IrCutFilterModes;
	XMLN * p_Sharpness;
	XMLN * p_WideDynamicRange;
	XMLN * p_WhiteBalance;

	p_ImagingOptions = xml_node_soap_get(p_node, "ImagingOptions");
	if (NULL == p_ImagingOptions)
	{
	    return FALSE;
	}
	
	p_BacklightCompensation = xml_node_soap_get(p_ImagingOptions, "BacklightCompensation");
	if (p_BacklightCompensation)
	{
		XMLN * p_Mode;
		XMLN * p_Level;

		p_res->ImagingOptions.BacklightCompensationFlag = 1;
		
		p_Mode = xml_node_soap_get(p_BacklightCompensation, "Mode");
		while (p_Mode && p_Mode->data && soap_strcmp(p_Mode->name, "Mode") == 0)
		{
			if (strcasecmp(p_Mode->data, "OFF") == 0)
			{
				p_res->ImagingOptions.BacklightCompensation.Mode_OFF = 1;
			}
			else if (strcasecmp(p_Mode->data, "ON") == 0)
			{
				p_res->ImagingOptions.BacklightCompensation.Mode_ON = 1;
			}

			p_Mode = p_Mode->next;
		}

		p_Level = xml_node_soap_get(p_BacklightCompensation, "Level");
		if (p_Level)
		{
			p_res->ImagingOptions.BacklightCompensation.LevelFlag = 1;			
			parse_FloatRange(p_Level, &p_res->ImagingOptions.BacklightCompensation.Level);
		}
	}

	p_Brightness = xml_node_soap_get(p_ImagingOptions, "Brightness");
	if (p_Brightness)
	{
		p_res->ImagingOptions.BrightnessFlag = 1;
		parse_FloatRange(p_Brightness, &p_res->ImagingOptions.Brightness);
	}

	p_ColorSaturation = xml_node_soap_get(p_ImagingOptions, "ColorSaturation");
	if (p_ColorSaturation)
	{
		p_res->ImagingOptions.ColorSaturationFlag= 1;
		parse_FloatRange(p_ColorSaturation, &p_res->ImagingOptions.ColorSaturation);
	}

	p_Contrast = xml_node_soap_get(p_ImagingOptions, "Contrast");
	if (p_Contrast)
	{
		p_res->ImagingOptions.ContrastFlag = 1;
		parse_FloatRange(p_Contrast, &p_res->ImagingOptions.Contrast);
	}

	p_Exposure = xml_node_soap_get(p_ImagingOptions, "Exposure");
	if (p_Exposure)
	{
		XMLN * p_Mode;
		XMLN * p_Priority;
		XMLN * p_MinExposureTime;
		XMLN * p_MaxExposureTime;
		XMLN * p_MinGain;
		XMLN * p_MaxGain;
		XMLN * p_MinIris;
		XMLN * p_MaxIris;
		XMLN * p_ExposureTime;
		XMLN * p_Gain;
		XMLN * p_Iris;

		p_res->ImagingOptions.ExposureFlag = 1;
		
		p_Mode = xml_node_soap_get(p_Exposure, "Mode");
		while (p_Mode && p_Mode->data && soap_strcmp(p_Mode->name, "Mode") == 0)
		{
			if (strcasecmp(p_Mode->data, "Auto") == 0)
			{
				p_res->ImagingOptions.Exposure.Mode_AUTO = 1;
			}
			else if (strcasecmp(p_Mode->data, "Manual") == 0)
			{
				p_res->ImagingOptions.Exposure.Mode_MANUAL = 1;
			}

			p_Mode = p_Mode->next;
		}

		p_Priority = xml_node_soap_get(p_Exposure, "Priority");
		while (p_Priority && p_Priority->data && soap_strcmp(p_Priority->name, "Priority") == 0)
		{
			if (strcasecmp(p_Priority->data, "LowNoise") == 0)
			{
				p_res->ImagingOptions.Exposure.Priority_LowNoise = 1;
			}
			else if (strcasecmp(p_Priority->data, "FrameRate") == 0)
			{
				p_res->ImagingOptions.Exposure.Priority_FrameRate = 1;
			}

			p_Priority = p_Priority->next;
		}
		
		p_MinExposureTime = xml_node_soap_get(p_Exposure, "MinExposureTime");
		if (p_MinExposureTime)
		{
			p_res->ImagingOptions.Exposure.MinExposureTimeFlag = 1;
			parse_FloatRange(p_MinExposureTime, &p_res->ImagingOptions.Exposure.MinExposureTime);
		}

		p_MaxExposureTime = xml_node_soap_get(p_Exposure, "MaxExposureTime");
		if (p_MaxExposureTime)
		{
			p_res->ImagingOptions.Exposure.MaxExposureTimeFlag = 1;
			parse_FloatRange(p_MaxExposureTime, &p_res->ImagingOptions.Exposure.MaxExposureTime);
		}

		p_MinGain = xml_node_soap_get(p_Exposure, "MinGain");
		if (p_MinGain)
		{
			p_res->ImagingOptions.Exposure.MinGainFlag = 1;
			parse_FloatRange(p_MinGain, &p_res->ImagingOptions.Exposure.MinGain);
		}

		p_MaxGain = xml_node_soap_get(p_Exposure, "MaxGain");
		if (p_MaxGain)
		{
			p_res->ImagingOptions.Exposure.MaxGainFlag = 1;
			parse_FloatRange(p_MaxGain, &p_res->ImagingOptions.Exposure.MaxGain);
		}

		p_MinIris = xml_node_soap_get(p_Exposure, "MinIris");
		if (p_MinIris)
		{
			p_res->ImagingOptions.Exposure.MinIrisFlag = 1;
			parse_FloatRange(p_MinIris, &p_res->ImagingOptions.Exposure.MinIris);
		}

		p_MaxIris = xml_node_soap_get(p_Exposure, "MaxIris");
		if (p_MaxIris)
		{
			p_res->ImagingOptions.Exposure.MaxIrisFlag = 1;
			parse_FloatRange(p_MaxIris, &p_res->ImagingOptions.Exposure.MaxIris);
		}

		p_ExposureTime = xml_node_soap_get(p_Exposure, "ExposureTime");
		if (p_ExposureTime)
		{
			p_res->ImagingOptions.Exposure.ExposureTimeFlag = 1;
			parse_FloatRange(p_ExposureTime, &p_res->ImagingOptions.Exposure.ExposureTime);
		}

		p_Gain = xml_node_soap_get(p_Exposure, "Gain");
		if (p_Gain)
		{
			p_res->ImagingOptions.Exposure.GainFlag = 1;
			parse_FloatRange(p_Gain, &p_res->ImagingOptions.Exposure.Gain);
		}

		p_Iris = xml_node_soap_get(p_Exposure, "Iris");
		if (p_Iris)
		{
			p_res->ImagingOptions.Exposure.IrisFlag = 1;
			parse_FloatRange(p_Iris, &p_res->ImagingOptions.Exposure.Iris);
		}
	}

	p_Focus = xml_node_soap_get(p_ImagingOptions, "Focus");
	if (p_Focus)
	{
		XMLN * p_AutoFocusModes;
		XMLN * p_DefaultSpeed;
		XMLN * p_NearLimit;
		XMLN * p_FarLimit;
		
		p_res->ImagingOptions.FocusFlag = 1;
		
		p_AutoFocusModes = xml_node_soap_get(p_Focus, "AutoFocusModes");
		while (p_AutoFocusModes && p_AutoFocusModes->data && soap_strcmp(p_AutoFocusModes->name, "AutoFocusModes") == 0)
		{
			if (strcasecmp(p_AutoFocusModes->data, "Auto") == 0)
			{
				p_res->ImagingOptions.Focus.AutoFocusModes_AUTO = 1;
			}
			else if (strcasecmp(p_AutoFocusModes->data, "Manual") == 0)
			{
				p_res->ImagingOptions.Focus.AutoFocusModes_MANUAL = 1;
			}

			p_AutoFocusModes = p_AutoFocusModes->next;
		}

		p_DefaultSpeed = xml_node_soap_get(p_Focus, "DefaultSpeed");
		if (p_DefaultSpeed)
		{
			p_res->ImagingOptions.Focus.DefaultSpeedFlag = 1;
			parse_FloatRange(p_DefaultSpeed, &p_res->ImagingOptions.Focus.DefaultSpeed);
		}

		p_NearLimit = xml_node_soap_get(p_Focus, "NearLimit");
		if (p_NearLimit)
		{
			p_res->ImagingOptions.Focus.NearLimitFlag = 1;
			parse_FloatRange(p_NearLimit, &p_res->ImagingOptions.Focus.NearLimit);
		}

		p_FarLimit = xml_node_soap_get(p_Focus, "FarLimit");
		if (p_FarLimit)
		{
			p_res->ImagingOptions.Focus.FarLimitFlag = 1;
			parse_FloatRange(p_FarLimit, &p_res->ImagingOptions.Focus.FarLimit);
		}
	}
	
	p_IrCutFilterModes = xml_node_soap_get(p_ImagingOptions, "IrCutFilterModes");
	while (p_IrCutFilterModes && soap_strcmp(p_IrCutFilterModes->name, "IrCutFilterModes") == 0)
	{
		if (p_IrCutFilterModes->data)
		{
			if (strcasecmp(p_IrCutFilterModes->data, "ON") == 0)
			{
				p_res->ImagingOptions.IrCutFilterMode_ON = 1;
			}
			else if (strcasecmp(p_IrCutFilterModes->data, "OFF") == 0)
			{
				p_res->ImagingOptions.IrCutFilterMode_OFF = 1;
			}
			else if (strcasecmp(p_IrCutFilterModes->data, "Auto") == 0)
			{
				p_res->ImagingOptions.IrCutFilterMode_AUTO = 1;
			}
		}

		p_IrCutFilterModes = p_IrCutFilterModes->next;
	}

	p_Sharpness = xml_node_soap_get(p_ImagingOptions, "Sharpness");
	if (p_Sharpness)
	{
		p_res->ImagingOptions.SharpnessFlag = 1;
		parse_FloatRange(p_Sharpness, &p_res->ImagingOptions.Sharpness);
	}

	p_WideDynamicRange = xml_node_soap_get(p_ImagingOptions, "WideDynamicRange");
	if (p_WideDynamicRange)
	{
		XMLN * p_Mode;
		XMLN * p_Level;

		p_res->ImagingOptions.WideDynamicRangeFlag = 1;
		
		p_Mode = xml_node_soap_get(p_WideDynamicRange, "Mode");
		while (p_Mode && p_Mode->data && soap_strcmp(p_Mode->name, "Mode") == 0)
		{
			if (strcasecmp(p_Mode->data, "ON") == 0)
			{
				p_res->ImagingOptions.WideDynamicRange.Mode_ON = 1;
			}
			else if (strcasecmp(p_Mode->data, "OFF") == 0)
			{
				p_res->ImagingOptions.WideDynamicRange.Mode_OFF = 1;
			}

			p_Mode = p_Mode->next;
		}

		p_Level = xml_node_soap_get(p_WideDynamicRange, "Level");
		if (p_Level)
		{
			p_res->ImagingOptions.WideDynamicRange.LevelFlag = 1;
			parse_FloatRange(p_Level, &p_res->ImagingOptions.WideDynamicRange.Level);
		}
	}

	p_WhiteBalance = xml_node_soap_get(p_ImagingOptions, "WhiteBalance");
	if (p_WhiteBalance)
	{
		XMLN * p_Mode;
		XMLN * p_YrGain;
		XMLN * p_YbGain;

		p_res->ImagingOptions.WhiteBalanceFlag = 1;
		
		p_Mode = xml_node_soap_get(p_WhiteBalance, "Mode");
		while (p_Mode && p_Mode->data && soap_strcmp(p_Mode->name, "Mode") == 0)
		{
			if (strcasecmp(p_Mode->data, "Auto") == 0)
			{
				p_res->ImagingOptions.WhiteBalance.Mode_AUTO = 1;
			}
			else if (strcasecmp(p_Mode->data, "Manual") == 0)
			{
				p_res->ImagingOptions.WhiteBalance.Mode_MANUAL = 1;
			}

			p_Mode = p_Mode->next;
		}
		
		p_YrGain = xml_node_soap_get(p_WhiteBalance, "YrGain");
		if (p_YrGain)
		{
			p_res->ImagingOptions.WhiteBalance.YrGainFlag = 1;
			parse_FloatRange(p_YrGain, &p_res->ImagingOptions.WhiteBalance.YrGain);
		}

		p_YbGain = xml_node_soap_get(p_WhiteBalance, "YbGain");
		if (p_YbGain)
		{
			p_res->ImagingOptions.WhiteBalance.YbGainFlag = 1;
			parse_FloatRange(p_YrGain, &p_res->ImagingOptions.WhiteBalance.YbGain);
		}
	}
	
	return TRUE;
}

BOOL parse_img_GetStatus(XMLN * p_node, img_GetStatus_RES * p_res)
{
    XMLN * p_Status;

    p_Status = xml_node_soap_get(p_node, "Status");
	if (p_Status)
	{
	    XMLN * p_FocusStatus20;

	    p_FocusStatus20 = xml_node_soap_get(p_Status, "FocusStatus20");
	    if (p_FocusStatus20)
	    {
	        XMLN * p_Position;
	        XMLN * p_MoveStatus;
	        XMLN * p_Error;

            p_res->Status.FocusStatusFlag = 1;
            
	        p_Position = xml_node_soap_get(p_FocusStatus20, "Position");
	        if (p_Position && p_Position->data)
	        {
	            p_res->Status.FocusStatus.Position = (float)atof(p_Position->data);
	        }

	        p_MoveStatus = xml_node_soap_get(p_FocusStatus20, "MoveStatus");
	        if (p_MoveStatus && p_MoveStatus->data)
	        {
	            p_res->Status.FocusStatus.MoveStatus = onvif_StringToMoveStatus(p_MoveStatus->data);
	        }

	        p_Error = xml_node_soap_get(p_FocusStatus20, "Error");
	        if (p_Error && p_Error->data)
	        {
	            p_res->Status.FocusStatus.ErrorFlag = 1;
	            strncpy(p_res->Status.FocusStatus.Error, p_Error->data, sizeof(p_res->Status.FocusStatus.Error)-1);
	        }
	    }
	}

	return TRUE;
}

BOOL parse_img_GetMoveOptions(XMLN * p_node, img_GetMoveOptions_RES * p_res)
{
    XMLN * p_MoveOptions;

    p_MoveOptions = xml_node_soap_get(p_node, "MoveOptions");
	if (p_MoveOptions)
	{
	    XMLN * p_Absolute;
	    XMLN * p_Relative;
	    XMLN * p_Continuous;

	    p_Absolute = xml_node_soap_get(p_MoveOptions, "Absolute");
	    if (p_Absolute)
	    {
	        XMLN * p_Position;
	        XMLN * p_Speed;
	        
	        p_res->MoveOptions.AbsoluteFlag = 1;

	        p_Position = xml_node_soap_get(p_Absolute, "Position");
	        if (p_Position)
	        {
	            parse_FloatRange(p_Position, &p_res->MoveOptions.Absolute.Position);
	        }

	        p_Speed = xml_node_soap_get(p_Absolute, "Speed");
	        if (p_Speed)
	        {
	            p_res->MoveOptions.Absolute.SpeedFlag = 1;
	            parse_FloatRange(p_Speed, &p_res->MoveOptions.Absolute.Speed);
	        }
	    }

	    p_Relative = xml_node_soap_get(p_MoveOptions, "Absolute");
	    if (p_Relative)
	    {
	        XMLN * p_Distance;
	        XMLN * p_Speed;
	        
	        p_res->MoveOptions.RelativeFlag = 1;

	        p_Distance = xml_node_soap_get(p_Relative, "Distance");
	        if (p_Distance)
	        {
	            parse_FloatRange(p_Distance, &p_res->MoveOptions.Relative.Distance);
	        }

	        p_Speed = xml_node_soap_get(p_Relative, "Speed");
	        if (p_Speed)
	        {
	            p_res->MoveOptions.Relative.SpeedFlag = 1;
	            parse_FloatRange(p_Speed, &p_res->MoveOptions.Relative.Speed);
	        }
	    }

	    p_Continuous = xml_node_soap_get(p_MoveOptions, "Continuous");
	    if (p_Continuous)
	    {
	        XMLN * p_Speed;
	        
	        p_res->MoveOptions.ContinuousFlag = 1;

	        p_Speed = xml_node_soap_get(p_Continuous, "Speed");
	        if (p_Speed)
	        {
	            parse_FloatRange(p_Speed, &p_res->MoveOptions.Continuous.Speed);
	        }
	    }
	}

	return TRUE;
}

BOOL parse_Subscribe(XMLN * p_node, Subscribe_RES * p_res)
{
    XMLN * p_SubscriptionReference;
	XMLN * p_Address;

	p_SubscriptionReference = xml_node_soap_get(p_node, "SubscriptionReference");
    if (NULL == p_SubscriptionReference)
    {
        return FALSE;
    }

    p_Address = xml_node_soap_get(p_SubscriptionReference, "Address");
    if (p_Address && p_Address->data)
    {
    	onvif_parse_uri(p_Address->data, p_res->producter_addr, sizeof(p_res->producter_addr));
    }
    else if (p_SubscriptionReference->data)
    {
    	onvif_parse_uri(p_SubscriptionReference->data, p_res->producter_addr, sizeof(p_res->producter_addr));
    }
    else 
    {
        return FALSE;
    }

    return TRUE;
}

BOOL parse_CreatePullPointSubscription(XMLN * p_node, CreatePullPointSubscription_RES * p_res)
{
	XMLN * p_SubscriptionReference;
	XMLN * p_Address;
	XMLN * p_CurrentTime;
	XMLN * p_TerminationTime;

	p_SubscriptionReference = xml_node_soap_get(p_node, "SubscriptionReference");
    if (NULL == p_SubscriptionReference)
    {
        return FALSE;
    }

    p_Address = xml_node_soap_get(p_SubscriptionReference, "Address");
    if (p_Address && p_Address->data)
    {
    	onvif_parse_uri(p_Address->data, p_res->producter_addr, sizeof(p_res->producter_addr));
    }
    else if (p_SubscriptionReference->data)
    {
    	onvif_parse_uri(p_SubscriptionReference->data, p_res->producter_addr, sizeof(p_res->producter_addr));
    }
    else 
    {
        return FALSE;
    }

    p_CurrentTime = xml_node_soap_get(p_node, "CurrentTime");
    if (p_CurrentTime && p_CurrentTime->data)
    {
		parse_XSDDatetime(p_CurrentTime->data, &p_res->CurrentTime);
    }

    p_TerminationTime = xml_node_soap_get(p_node, "TerminationTime");
    if (p_TerminationTime && p_TerminationTime->data)
    {
		parse_XSDDatetime(p_TerminationTime->data, &p_res->TerminationTime);
    }

    return TRUE;
}

BOOL parse_NotifyMessage(XMLN * p_node, ONVIF_NotificationMessage ** p_res)
{
	time_t arrival_time;
	XMLN * p_NotificationMessage;

	arrival_time = time(NULL);
    
    p_NotificationMessage = xml_node_soap_get(p_node, "NotificationMessage");
    while (p_NotificationMessage && soap_strcmp(p_NotificationMessage->name, "NotificationMessage") == 0)
    {
        ONVIF_NotificationMessage * p_notify = onvif_add_NotificationMessage(p_res);
        if (p_notify)
        {
            if (parse_NotificationMessage(p_NotificationMessage, &p_notify->NotificationMessage) == FALSE)
            {
            	onvif_free_NotificationMessages(p_res);
                return FALSE;
            }
        }

        p_NotificationMessage = p_NotificationMessage->next;
    }

    return TRUE;
}

BOOL parse_PullMessages(XMLN * p_node, PullMessages_RES * p_res)
{
	XMLN * p_CurrentTime;
	XMLN * p_TerminationTime;	
	
	p_CurrentTime = xml_node_soap_get(p_node, "CurrentTime");
    if (p_CurrentTime && p_CurrentTime->data)
    {
		parse_XSDDatetime(p_CurrentTime->data, &p_res->CurrentTime);
    }

    p_TerminationTime = xml_node_soap_get(p_node, "TerminationTime");
    if (p_TerminationTime && p_TerminationTime->data)
    {
		parse_XSDDatetime(p_TerminationTime->data, &p_res->TerminationTime);
    }

    return parse_NotifyMessage(p_node, &p_res->NotifyMessages);
}

BOOL parse_SimpleItem(XMLN * p_node, onvif_SimpleItem * p_res)
{
    const char * p_Name;
	const char * p_Value;

	p_Name = xml_attr_get(p_node, "Name");
    if (p_Name)
    {
        strncpy(p_res->Name, p_Name, sizeof(p_res->Name)-1);
    }

    p_Value = xml_attr_get(p_node, "Value");
    if (p_Value)
    {
        strncpy(p_res->Value, p_Value, sizeof(p_res->Value)-1);
    }

    return TRUE;
}

BOOL parse_ElementItem(XMLN * p_node, onvif_ElementItem * p_req)
{
	const char * p_Name;

	p_Name = xml_attr_get(p_node, "Name");
	if (p_Name)
	{
		strncpy(p_req->Name, p_Name, sizeof(p_req->Name));
	}

	return TRUE;
}

BOOL parse_ItemList(XMLN * p_node, onvif_ItemList * p_res)
{
	XMLN * p_SimpleItem;
	XMLN * p_ElementItem;

	p_SimpleItem = xml_node_soap_get(p_node, "SimpleItem");
    while (p_SimpleItem && soap_strcmp(p_SimpleItem->name, "SimpleItem") == 0)
    {
        ONVIF_SimpleItem * p_item = onvif_add_SimpleItem(&p_res->SimpleItem);
        if (p_item)
        {
            parse_SimpleItem(p_SimpleItem, &p_item->SimpleItem);
        }

        p_SimpleItem = p_SimpleItem->next;
    }

    p_ElementItem = xml_node_soap_get(p_node, "ElementItem");
    while (p_ElementItem && soap_strcmp(p_ElementItem->name, "ElementItem") == 0)
    {
        ONVIF_ElementItem * p_item = onvif_add_ElementItem(&p_res->ElementItem);
        if (p_item)
        {
        	parse_ElementItem(p_ElementItem, &p_item->ElementItem);
        }

        p_ElementItem = p_ElementItem->next;
    }

    return TRUE;
}

BOOL parse_NotificationMessage(XMLN * p_node, onvif_NotificationMessage * p_res)
{
    XMLN * p_SubscriptionReference;
	XMLN * p_Topic;
	XMLN * p_ProducerReference;
	XMLN * p_Message;

	p_SubscriptionReference = xml_node_soap_get(p_node, "SubscriptionReference");
    if (p_SubscriptionReference)
    {
        XMLN * p_Address = xml_node_soap_get(p_SubscriptionReference, "Address");
        if (p_Address && p_Address->data)
        {
            strncpy(p_res->ConsumerAddress, p_Address->data, sizeof(p_res->ConsumerAddress)-1);
        }
    }

    p_Topic = xml_node_soap_get(p_node, "Topic");
    if (p_Topic && p_Topic->data)
    {
        strncpy(p_res->Topic, p_Topic->data, sizeof(p_res->Topic)-1);
    }

    p_ProducerReference = xml_node_soap_get(p_node, "ProducerReference");
    if (p_ProducerReference)
    {
        XMLN * p_Address = xml_node_soap_get(p_ProducerReference, "Address");
        if (p_Address && p_Address->data)
        {
            strncpy(p_res->ProducterAddress, p_Address->data, sizeof(p_res->ProducterAddress)-1);
        }
    }

    p_Message = xml_node_soap_get(p_node, "Message");
    if (p_Message)
    {
        XMLN * p_tt_Message = xml_node_soap_get(p_Message, "tt:Message");
        if (p_tt_Message)
        {
        	XMLN * p_Source;
			XMLN * p_Key;
			XMLN * p_Data;
            const char * p_UtcTime;
			const char * p_PropertyOperation;

			p_UtcTime = xml_attr_get(p_tt_Message, "UtcTime");
            if (p_UtcTime)
            {
                parse_XSDDatetime(p_UtcTime, &p_res->Message.UtcTime);
            }

            p_PropertyOperation = xml_attr_get(p_tt_Message, "PropertyOperation");
            if (p_PropertyOperation)
            {
            	p_res->Message.PropertyOperationFlag = 1;
            	p_res->Message.PropertyOperation = onvif_StringToPropertyOperation(p_PropertyOperation);
            }

            p_Source = xml_node_soap_get(p_tt_Message, "Source");
            if (p_Source)
            {
            	p_res->Message.SourceFlag = 1;
            	parse_ItemList(p_Source, &p_res->Message.Source);
            }

            p_Key = xml_node_soap_get(p_tt_Message, "Key");
            if (p_Key)
            {	
            	p_res->Message.KeyFlag = 1;
                parse_ItemList(p_Key, &p_res->Message.Key);
            }

            p_Data = xml_node_soap_get(p_tt_Message, "Data");
            if (p_Data)
            {
            	p_res->Message.DataFlag = 1;
                parse_ItemList(p_Data, &p_res->Message.Data);
            }
        }
    }
    
    return TRUE;
}

BOOL parse_Version(XMLN * p_node, onvif_Version * p_res)
{
    XMLN * p_Major;
    XMLN * p_Minor;

    p_Major = xml_node_soap_get(p_node, "Major");
    if (p_Major && p_Major->data)
    {
		p_res->Major = atoi(p_Major->data);
    }

    p_Minor = xml_node_soap_get(p_node, "Minor");
    if (p_Minor && p_Minor->data)
    {
		p_res->Minor = atoi(p_Minor->data);
    }

    return TRUE;
}

BOOL parse_DeviceService(XMLN * p_node, onvif_DevicesCapabilities * p_cap)
{
    XMLN * p_XAddr;
	XMLN * p_tds_Capabilities;
	XMLN * p_Version;

	p_XAddr = xml_node_soap_get(p_node, "XAddr");
    if (p_XAddr && p_XAddr->data)
    {
		parse_XAddr(p_XAddr->data, &p_cap->XAddr);
    }
    else
    {
        return FALSE;
    }

    p_tds_Capabilities = xml_node_soap_get(p_node, "Capabilities");
    if (p_tds_Capabilities)
    {
        XMLN * p_Capabilities = xml_node_soap_get(p_tds_Capabilities, "Capabilities");
        if (p_Capabilities)
        {
            XMLN * p_Network;
			XMLN * p_Security;
			XMLN * p_System;
			XMLN * p_Misc;

			p_Network = xml_node_soap_get(p_Capabilities, "Network");
            if (p_Network)
            {
                const char * p_IPFilter;
				const char * p_ZeroConfiguration;
				const char * p_IPVersion6;
				const char * p_DynDNS;
				const char * p_Dot11Configuration;
				const char * p_HostnameFromDHCP;
				const char * p_DHCPv6;
				const char * p_Dot1XConfigurations;
				const char * p_NTP;

				p_IPFilter = xml_attr_get(p_Network, "IPFilter");
                if (p_IPFilter)
                {
                    p_cap->IPFilter = parse_Bool(p_IPFilter);
                }

                p_ZeroConfiguration = xml_attr_get(p_Network, "ZeroConfiguration");
                if (p_ZeroConfiguration)
                {
                    p_cap->ZeroConfiguration = parse_Bool(p_ZeroConfiguration);
                }

                p_IPVersion6 = xml_attr_get(p_Network, "IPVersion6");
                if (p_IPVersion6)
                {
                    p_cap->IPVersion6 = parse_Bool(p_IPVersion6);
                }

                p_DynDNS = xml_attr_get(p_Network, "DynDNS");
                if (p_DynDNS)
                {
                    p_cap->DynDNS = parse_Bool(p_DynDNS);
                }

                p_Dot11Configuration = xml_attr_get(p_Network, "Dot11Configuration");
                if (p_Dot11Configuration)
                {
                    p_cap->Dot11Configuration = parse_Bool(p_Dot11Configuration);
                }

                p_HostnameFromDHCP = xml_attr_get(p_Network, "HostnameFromDHCP");
                if (p_HostnameFromDHCP)
                {
                    p_cap->HostnameFromDHCP = parse_Bool(p_HostnameFromDHCP);
                }

                p_DHCPv6 = xml_attr_get(p_Network, "DHCPv6");
                if (p_DHCPv6)
                {
                    p_cap->DHCPv6 = parse_Bool(p_DHCPv6);
                }

                p_Dot1XConfigurations = xml_attr_get(p_Network, "Dot1XConfigurations");
                if (p_Dot1XConfigurations)
                {
                    p_cap->Dot1XConfigurations = atoi(p_Dot1XConfigurations);
                }

                p_NTP = xml_attr_get(p_Network, "NTP");
                if (p_NTP)
                {
                    p_cap->NTP = atoi(p_NTP);
                }
            }

            p_Security = xml_node_soap_get(p_Capabilities, "Security");
            if (p_Security)
            {
                const char * p_TLS10;
				const char * p_TLS11;
				const char * p_TLS12;
				const char * p_OnboardKeyGeneration;
				const char * p_AccessPolicyConfig;
				const char * p_DefaultAccessPolicy;
				const char * p_Dot1X;
				const char * p_RemoteUserHandling;
				const char * p_X509Token;
				const char * p_SAMLToken;
				const char * p_KerberosToken;
				const char * p_UsernameToken;
				const char * p_HttpDigest;
				const char * p_RELToken;
				const char * p_SupportedEAPMethods;
				const char * p_MaxUsers;
				const char * p_MaxUserNameLength;
				const char * p_MaxPasswordLength;

				p_TLS10 = xml_attr_get(p_Security, "TLS1.0");
                if (p_TLS10)
                {
                    p_cap->TLS10 = parse_Bool(p_TLS10);
                }

                p_TLS11 = xml_attr_get(p_Security, "TLS1.1");
                if (p_TLS11)
                {
                    p_cap->TLS11 = parse_Bool(p_TLS11);
                }

                p_TLS12 = xml_attr_get(p_Security, "TLS1.2");
                if (p_TLS12)
                {
                    p_cap->TLS12 = parse_Bool(p_TLS12);
                }

                p_OnboardKeyGeneration = xml_attr_get(p_Security, "OnboardKeyGeneration");
                if (p_OnboardKeyGeneration)
                {
                    p_cap->OnboardKeyGeneration = parse_Bool(p_OnboardKeyGeneration);
                }

                p_AccessPolicyConfig = xml_attr_get(p_Security, "AccessPolicyConfig");
                if (p_AccessPolicyConfig)
                {
                    p_cap->AccessPolicyConfig = parse_Bool(p_AccessPolicyConfig);
                }

                p_DefaultAccessPolicy = xml_attr_get(p_Security, "DefaultAccessPolicy");
                if (p_DefaultAccessPolicy)
                {
                    p_cap->DefaultAccessPolicy = parse_Bool(p_DefaultAccessPolicy);
                }

                p_Dot1X = xml_attr_get(p_Security, "Dot1X");
                if (p_Dot1X)
                {
                    p_cap->Dot1X = parse_Bool(p_Dot1X);
                }

                p_RemoteUserHandling = xml_attr_get(p_Security, "RemoteUserHandling");
                if (p_RemoteUserHandling)
                {
                    p_cap->RemoteUserHandling = parse_Bool(p_RemoteUserHandling);
                }

                p_X509Token = xml_attr_get(p_Security, "X.509Token");
                if (p_X509Token)
                {
                    p_cap->X509Token = parse_Bool(p_X509Token);
                }

                p_SAMLToken = xml_attr_get(p_Security, "SAMLToken");
                if (p_SAMLToken)
                {
                    p_cap->SAMLToken = parse_Bool(p_SAMLToken);
                }

                p_KerberosToken = xml_attr_get(p_Security, "KerberosToken");
                if (p_KerberosToken)
                {
                    p_cap->KerberosToken = parse_Bool(p_KerberosToken);
                }

                p_UsernameToken = xml_attr_get(p_Security, "UsernameToken");
                if (p_UsernameToken)
                {
                    p_cap->UsernameToken = parse_Bool(p_UsernameToken);
                }

                p_HttpDigest = xml_attr_get(p_Security, "HttpDigest");
                if (p_HttpDigest)
                {
                    p_cap->HttpDigest = parse_Bool(p_HttpDigest);
                }

                p_RELToken = xml_attr_get(p_Security, "RELToken");
                if (p_RELToken)
                {
                    p_cap->RELToken = parse_Bool(p_RELToken);
                }

                p_SupportedEAPMethods = xml_attr_get(p_Security, "SupportedEAPMethods");
                if (p_SupportedEAPMethods)
                {
                    p_cap->SupportedEAPMethods = atoi(p_SupportedEAPMethods);
                }

                p_MaxUsers = xml_attr_get(p_Security, "MaxUsers");
                if (p_MaxUsers)
                {
                    p_cap->MaxUsers = atoi(p_MaxUsers);
                }

                p_MaxUserNameLength = xml_attr_get(p_Security, "MaxUserNameLength");
                if (p_MaxUserNameLength)
                {
                    p_cap->MaxUserNameLength = atoi(p_MaxUserNameLength);
                }

                p_MaxPasswordLength = xml_attr_get(p_Security, "MaxPasswordLength");
                if (p_MaxPasswordLength)
                {
                    p_cap->MaxPasswordLength = atoi(p_MaxPasswordLength);
                }
            }

            p_System = xml_node_soap_get(p_Capabilities, "System");
            if (p_System)
            {
                const char * p_DiscoveryResolve;
				const char * p_DiscoveryBye;
				const char * p_RemoteDiscovery;
				const char * p_SystemBackup;
				const char * p_SystemLogging;
				const char * p_FirmwareUpgrade;
				const char * p_HttpFirmwareUpgrade;
				const char * p_HttpSystemBackup;
				const char * p_HttpSystemLogging;
				const char * p_HttpSupportInformation;
				const char * p_StorageConfiguration;

				p_DiscoveryResolve = xml_attr_get(p_System, "DiscoveryResolve");
                if (p_DiscoveryResolve)
                {
                    p_cap->DiscoveryResolve = parse_Bool(p_DiscoveryResolve);
                }

                p_DiscoveryBye = xml_attr_get(p_System, "DiscoveryBye");
                if (p_DiscoveryBye)
                {
                    p_cap->DiscoveryBye = parse_Bool(p_DiscoveryBye);
                }

                p_RemoteDiscovery = xml_attr_get(p_System, "RemoteDiscovery");
                if (p_RemoteDiscovery)
                {
                    p_cap->RemoteDiscovery = parse_Bool(p_RemoteDiscovery);
                }

                p_SystemBackup = xml_attr_get(p_System, "SystemBackup");
                if (p_SystemBackup)
                {
                    p_cap->SystemBackup = parse_Bool(p_SystemBackup);
                }

                p_SystemLogging = xml_attr_get(p_System, "SystemLogging");
                if (p_SystemLogging)
                {
                    p_cap->SystemLogging = parse_Bool(p_SystemLogging);
                }

                p_FirmwareUpgrade = xml_attr_get(p_System, "FirmwareUpgrade");
                if (p_FirmwareUpgrade)
                {
                    p_cap->FirmwareUpgrade = parse_Bool(p_FirmwareUpgrade);
                }

                p_HttpFirmwareUpgrade = xml_attr_get(p_System, "HttpFirmwareUpgrade");
                if (p_HttpFirmwareUpgrade)
                {
                    p_cap->HttpFirmwareUpgrade = parse_Bool(p_HttpFirmwareUpgrade);
                }

                p_HttpSystemBackup = xml_attr_get(p_System, "HttpSystemBackup");
                if (p_HttpSystemBackup)
                {
                    p_cap->HttpSystemBackup = parse_Bool(p_HttpSystemBackup);
                }

                p_HttpSystemLogging = xml_attr_get(p_System, "HttpSystemLogging");
                if (p_HttpSystemLogging)
                {
                    p_cap->HttpSystemLogging = parse_Bool(p_HttpSystemLogging);
                }

                p_HttpSupportInformation = xml_attr_get(p_System, "HttpSupportInformation");
                if (p_HttpSupportInformation)
                {
                    p_cap->HttpSupportInformation = parse_Bool(p_HttpSupportInformation);
                }

				p_StorageConfiguration = xml_attr_get(p_System, "StorageConfiguration");
                if (p_StorageConfiguration)
                {
                    p_cap->StorageConfiguration = parse_Bool(p_StorageConfiguration);
                }                
            }

            p_Misc = xml_node_soap_get(p_Capabilities, "Misc");
            if (p_Misc)
            {
                const char * p_AuxiliaryCommands = xml_attr_get(p_Misc, "AuxiliaryCommands");
                if (p_AuxiliaryCommands)
                {
                    strncpy(p_cap->AuxiliaryCommands, p_AuxiliaryCommands, sizeof(p_cap->AuxiliaryCommands)-1);
                }
            }
        }
    }

    p_Version = xml_node_soap_get(p_node, "Version");
    if (p_Version)
    {
		parse_Version(p_Version, &p_cap->Version);
    }
    
    return TRUE;
}

BOOL parse_MediaService(XMLN * p_node, onvif_MediaCapabilities * p_cap)
{
    XMLN * p_XAddr;
	XMLN * p_tds_Capabilities;
    XMLN * p_Version;
    
	p_XAddr = xml_node_soap_get(p_node, "XAddr");
    if (p_XAddr && p_XAddr->data)
    {
        parse_XAddr(p_XAddr->data, &p_cap->XAddr);
    }
    else
    {
        return FALSE;
    }

    p_tds_Capabilities = xml_node_soap_get(p_node, "Capabilities");
    if (p_tds_Capabilities)
    {
        XMLN * p_Capabilities = xml_node_soap_get(p_tds_Capabilities, "Capabilities");
        if (p_Capabilities)
        {
        	XMLN * p_ProfileCapabilities;
			XMLN * p_StreamingCapabilities;
            const char * p_SnapshotUri;
			const char * p_Rotation;
			const char * p_VideoSourceMode;
			const char * p_OSD;
			const char * p_EXICompression;

			p_SnapshotUri = xml_attr_get(p_Capabilities, "SnapshotUri");
            if (p_SnapshotUri)
            {
                p_cap->SnapshotUri = parse_Bool(p_SnapshotUri);
            }

            p_Rotation = xml_attr_get(p_Capabilities, "Rotation");
            if (p_Rotation)
            {
                p_cap->Rotation = parse_Bool(p_Rotation);
            }

            p_VideoSourceMode = xml_attr_get(p_Capabilities, "VideoSourceMode");
            if (p_VideoSourceMode)
            {
                p_cap->VideoSourceMode = parse_Bool(p_VideoSourceMode);
            }

            p_OSD = xml_attr_get(p_Capabilities, "OSD");
            if (p_OSD)
            {
                p_cap->OSD = parse_Bool(p_OSD);
            }

            p_EXICompression = xml_attr_get(p_Capabilities, "EXICompression");
            if (p_EXICompression)
            {
                p_cap->EXICompression = parse_Bool(p_EXICompression);
            }

            p_ProfileCapabilities = xml_node_soap_get(p_Capabilities, "ProfileCapabilities");
            if (p_ProfileCapabilities)
            {
                const char * p_MaximumNumberOfProfiles = xml_attr_get(p_ProfileCapabilities, "MaximumNumberOfProfiles");
                if (p_MaximumNumberOfProfiles)
                {
                    p_cap->MaximumNumberOfProfiles = atoi(p_MaximumNumberOfProfiles);
                }
            }

            p_StreamingCapabilities = xml_node_soap_get(p_Capabilities, "StreamingCapabilities");
            if (p_StreamingCapabilities)
            {
                const char * p_RTPMulticast;
				const char * p_RTP_TCP;
				const char * p_RTP_RTSP_TCP;
				const char * p_NonAggregateControl;
				const char * p_NoRTSPStreaming;

				p_RTPMulticast = xml_attr_get(p_StreamingCapabilities, "RTPMulticast");
                if (p_RTPMulticast)
                {
                    p_cap->RTPMulticast = parse_Bool(p_RTPMulticast);
                }
                
                p_RTP_TCP = xml_attr_get(p_StreamingCapabilities, "RTP_TCP");
                if (p_RTP_TCP)
                {
                    p_cap->RTP_TCP = parse_Bool(p_RTP_TCP);
                }

                p_RTP_RTSP_TCP = xml_attr_get(p_StreamingCapabilities, "RTP_RTSP_TCP");
                if (p_RTP_RTSP_TCP)
                {
                    p_cap->RTP_RTSP_TCP = parse_Bool(p_RTP_RTSP_TCP);
                }

                p_NonAggregateControl = xml_attr_get(p_StreamingCapabilities, "NonAggregateControl");
                if (p_NonAggregateControl)
                {
                    p_cap->NonAggregateControl = parse_Bool(p_NonAggregateControl);
                }

                p_NoRTSPStreaming = xml_attr_get(p_StreamingCapabilities, "NoRTSPStreaming");
                if (p_NoRTSPStreaming)
                {
                    p_cap->NoRTSPStreaming = parse_Bool(p_NoRTSPStreaming);
                }
            }
        }
    }   

    p_Version = xml_node_soap_get(p_node, "Version");
    if (p_Version)
    {
		parse_Version(p_Version, &p_cap->Version);
    }
    
    return TRUE;
}

BOOL parse_MediaService2(XMLN * p_node, onvif_MediaCapabilities2 * p_cap)
{
	XMLN * p_XAddr;
	XMLN * p_tds_Capabilities;
    XMLN * p_Version;
    
	p_XAddr = xml_node_soap_get(p_node, "XAddr");
    if (p_XAddr && p_XAddr->data)
    {
        parse_XAddr(p_XAddr->data, &p_cap->XAddr);
    }
    else
    {
        return FALSE;
    }

    p_tds_Capabilities = xml_node_soap_get(p_node, "Capabilities");
    if (p_tds_Capabilities)
    {
        XMLN * p_Capabilities = xml_node_soap_get(p_tds_Capabilities, "Capabilities");
        if (p_Capabilities)
        {
        	XMLN * p_ProfileCapabilities;
			XMLN * p_StreamingCapabilities;
            const char * p_SnapshotUri;
			const char * p_Rotation;
			const char * p_VideoSourceMode;
			const char * p_OSD;

			p_SnapshotUri = xml_attr_get(p_Capabilities, "SnapshotUri");
            if (p_SnapshotUri)
            {
            	p_cap->SnapshotUriFlag = 1;
                p_cap->SnapshotUri = parse_Bool(p_SnapshotUri);
            }

            p_Rotation = xml_attr_get(p_Capabilities, "Rotation");
            if (p_Rotation)
            {
            	p_cap->RotationFlag = 1;
                p_cap->Rotation = parse_Bool(p_Rotation);
            }

            p_VideoSourceMode = xml_attr_get(p_Capabilities, "VideoSourceMode");
            if (p_VideoSourceMode)
            {
            	p_cap->VideoSourceModeFlag = 1;
                p_cap->VideoSourceMode = parse_Bool(p_VideoSourceMode);
            }

            p_OSD = xml_attr_get(p_Capabilities, "OSD");
            if (p_OSD)
            {
            	p_cap->OSDFlag = 1;
                p_cap->OSD = parse_Bool(p_OSD);
            }

            p_ProfileCapabilities = xml_node_soap_get(p_Capabilities, "ProfileCapabilities");
            if (p_ProfileCapabilities)
            {            	
                const char * p_MaximumNumberOfProfiles;
                const char * p_ConfigurationsSupported;

                p_MaximumNumberOfProfiles = xml_attr_get(p_ProfileCapabilities, "MaximumNumberOfProfiles");
                if (p_MaximumNumberOfProfiles)
                {
                	p_cap->ProfileCapabilities.MaximumNumberOfProfilesFlag = 1;
                    p_cap->ProfileCapabilities.MaximumNumberOfProfiles = atoi(p_MaximumNumberOfProfiles);
                }

                p_ConfigurationsSupported = xml_attr_get(p_ProfileCapabilities, "ConfigurationsSupported");
                if (p_ConfigurationsSupported)
                {
                	p_cap->ProfileCapabilities.ConfigurationsSupportedFlag = 1;
                    strncpy(p_cap->ProfileCapabilities.ConfigurationsSupported,
                    	p_ConfigurationsSupported, sizeof(p_cap->ProfileCapabilities.ConfigurationsSupported)-1);
                }
            }

            p_StreamingCapabilities = xml_node_soap_get(p_Capabilities, "StreamingCapabilities");
            if (p_StreamingCapabilities)
            {
                const char * p_RTPMulticast;
				const char * p_RTP_TCP;
				const char * p_NonAggregateControl;
				const char * p_RTSPStreaming;

				p_RTSPStreaming = xml_attr_get(p_StreamingCapabilities, "RTSPStreaming");
                if (p_RTSPStreaming)
                {
                	p_cap->StreamingCapabilities.RTSPStreamingFlag = 1;
                    p_cap->StreamingCapabilities.RTSPStreaming = parse_Bool(p_RTSPStreaming);
                }

				p_RTPMulticast = xml_attr_get(p_StreamingCapabilities, "RTPMulticast");
                if (p_RTPMulticast)
                {
                	p_cap->StreamingCapabilities.RTPMulticastFlag = 1;
                    p_cap->StreamingCapabilities.RTPMulticast = parse_Bool(p_RTPMulticast);
                }
                
                p_RTP_TCP = xml_attr_get(p_StreamingCapabilities, "RTP_TCP");
                if (p_RTP_TCP)
                {
                	p_cap->StreamingCapabilities.RTP_USCORERTSP_USCORETCPFlag = 1;
                    p_cap->StreamingCapabilities.RTP_USCORERTSP_USCORETCP = parse_Bool(p_RTP_TCP);
                }

                p_NonAggregateControl = xml_attr_get(p_StreamingCapabilities, "NonAggregateControl");
                if (p_NonAggregateControl)
                {
                	p_cap->StreamingCapabilities.NonAggregateControlFlag = 1;
                    p_cap->StreamingCapabilities.NonAggregateControl = parse_Bool(p_NonAggregateControl);
                }
            }
        }
    }   

    p_Version = xml_node_soap_get(p_node, "Version");
    if (p_Version)
    {
		parse_Version(p_Version, &p_cap->Version);
    }
    
    return TRUE;
}

BOOL parse_EventsService(XMLN * p_node, onvif_EventCapabilities * p_cap)
{
    XMLN * p_XAddr;
	XMLN * p_tds_Capabilities;
    XMLN * p_Version;
    
	p_XAddr = xml_node_soap_get(p_node, "XAddr");
    if (p_XAddr && p_XAddr->data)
    {
        parse_XAddr(p_XAddr->data, &p_cap->XAddr);
    }
    else
    {
        return FALSE;
    }

    p_tds_Capabilities = xml_node_soap_get(p_node, "Capabilities");
    if (p_tds_Capabilities)
    {
        XMLN * p_Capabilities = xml_node_soap_get(p_tds_Capabilities, "Capabilities");
        if (p_Capabilities)
        {
            const char * p_WSSubscriptionPolicySupport;
			const char * p_WSPullPointSupport;
			const char * p_WSPausableSubscriptionManagerInterfaceSupport;
			const char * p_MaxNotificationProducers;
			const char * p_MaxPullPoints;
			const char * p_PersistentNotificationStorage;

			p_WSSubscriptionPolicySupport = xml_attr_get(p_Capabilities, "WSSubscriptionPolicySupport");
            if (p_WSSubscriptionPolicySupport)
            {
                p_cap->WSSubscriptionPolicySupport = parse_Bool(p_WSSubscriptionPolicySupport);
            }

            p_WSPullPointSupport = xml_attr_get(p_Capabilities, "WSPullPointSupport");
            if (p_WSPullPointSupport)
            {
                p_cap->WSPullPointSupport = parse_Bool(p_WSPullPointSupport);
            }

            p_WSPausableSubscriptionManagerInterfaceSupport = xml_attr_get(p_Capabilities, "WSPausableSubscriptionManagerInterfaceSupport");
            if (p_WSPausableSubscriptionManagerInterfaceSupport)
            {
                p_cap->WSPausableSubscriptionManagerInterfaceSupport = parse_Bool(p_WSPausableSubscriptionManagerInterfaceSupport);
            }

            p_MaxNotificationProducers = xml_attr_get(p_Capabilities, "MaxNotificationProducers");
            if (p_MaxNotificationProducers)
            {
                p_cap->MaxNotificationProducers = atoi(p_MaxNotificationProducers);
            }

            p_MaxPullPoints = xml_attr_get(p_Capabilities, "MaxPullPoints");
            if (p_MaxPullPoints)
            {
                p_cap->MaxPullPoints = atoi(p_MaxPullPoints);
            }

            p_PersistentNotificationStorage = xml_attr_get(p_Capabilities, "PersistentNotificationStorage");
            if (p_PersistentNotificationStorage)
            {
                p_cap->PersistentNotificationStorage = parse_Bool(p_PersistentNotificationStorage);
            }
        }
    } 

    p_Version = xml_node_soap_get(p_node, "Version");
    if (p_Version)
    {
		parse_Version(p_Version, &p_cap->Version);
    }
    
    return TRUE;
}

BOOL parse_PTZService(XMLN * p_node, onvif_PTZCapabilities * p_cap)
{
    XMLN * p_XAddr;
	XMLN * p_tds_Capabilities;
    XMLN * p_Version;
    
	p_XAddr = xml_node_soap_get(p_node, "XAddr");
    if (p_XAddr && p_XAddr->data)
    {
        parse_XAddr(p_XAddr->data, &p_cap->XAddr);
    }
    else
    {
        return FALSE;
    }

    p_tds_Capabilities = xml_node_soap_get(p_node, "Capabilities");
    if (p_tds_Capabilities)
    {
        XMLN * p_Capabilities = xml_node_soap_get(p_tds_Capabilities, "Capabilities");
        if (p_Capabilities)
        {
            const char * p_EFlip;
			const char * p_Reverse;
			const char * p_GetCompatibleConfigurations;

			p_EFlip = xml_attr_get(p_Capabilities, "EFlip");
            if (p_EFlip)
            {
                p_cap->EFlip = parse_Bool(p_EFlip);
            }

            p_Reverse = xml_attr_get(p_Capabilities, "Reverse");
            if (p_Reverse)
            {
                p_cap->Reverse = parse_Bool(p_Reverse);
            }

            p_GetCompatibleConfigurations = xml_attr_get(p_Capabilities, "GetCompatibleConfigurations");
            if (p_GetCompatibleConfigurations)
            {
                p_cap->GetCompatibleConfigurations = parse_Bool(p_GetCompatibleConfigurations);
            }
        }
    } 

    p_Version = xml_node_soap_get(p_node, "Version");
    if (p_Version)
    {
		parse_Version(p_Version, &p_cap->Version);
    }
    
    return TRUE;
}

BOOL parse_ImagingService(XMLN * p_node, onvif_ImagingCapabilities * p_cap)
{
    XMLN * p_XAddr;
	XMLN * p_tds_Capabilities;
    XMLN * p_Version;
    
	p_XAddr = xml_node_soap_get(p_node, "XAddr");
    if (p_XAddr && p_XAddr->data)
    {
        parse_XAddr(p_XAddr->data, &p_cap->XAddr);
    }
    else
    {
        return FALSE;
    }

    p_tds_Capabilities = xml_node_soap_get(p_node, "Capabilities");
    if (p_tds_Capabilities)
    {
        XMLN * p_Capabilities = xml_node_soap_get(p_tds_Capabilities, "Capabilities");
        if (p_Capabilities)
        {
            const char * p_ImageStabilization = xml_attr_get(p_Capabilities, "ImageStabilization");
            if (p_ImageStabilization)
            {
                p_cap->ImageStabilization = parse_Bool(p_ImageStabilization);
            }
        }
    } 

    p_Version = xml_node_soap_get(p_node, "Version");
    if (p_Version)
    {
		parse_Version(p_Version, &p_cap->Version);
    }
    
    return TRUE;
}

BOOL parse_AnalyticsService(XMLN * p_node, onvif_AnalyticsCapabilities * p_cap)
{
	XMLN * p_XAddr;
	XMLN * p_tds_Capabilities;
	XMLN * p_Version;
	
    p_XAddr = xml_node_soap_get(p_node, "XAddr");
    if (p_XAddr && p_XAddr->data)
    {
        parse_XAddr(p_XAddr->data, &p_cap->XAddr);
    }
    else
    {
        return FALSE;
    }

    p_tds_Capabilities = xml_node_soap_get(p_node, "Capabilities");
    if (p_tds_Capabilities)
    {
        XMLN * p_Capabilities = xml_node_soap_get(p_tds_Capabilities, "Capabilities");
        if (p_Capabilities)
        {
            const char * p_RuleSupport;
			const char * p_AnalyticsModuleSupport;
			const char * p_CellBasedSceneDescriptionSupported;

			p_RuleSupport = xml_attr_get(p_Capabilities, "RuleSupport");
            if (p_RuleSupport)
            {
                p_cap->RuleSupport = parse_Bool(p_RuleSupport);
            }

            p_AnalyticsModuleSupport = xml_attr_get(p_Capabilities, "AnalyticsModuleSupport");
            if (p_AnalyticsModuleSupport)
            {
                p_cap->AnalyticsModuleSupport = parse_Bool(p_AnalyticsModuleSupport);
            }

            p_CellBasedSceneDescriptionSupported = xml_attr_get(p_Capabilities, "CellBasedSceneDescriptionSupported");
            if (p_CellBasedSceneDescriptionSupported)
            {
                p_cap->CellBasedSceneDescriptionSupported = parse_Bool(p_CellBasedSceneDescriptionSupported);
            }
        }
    }   

    p_Version = xml_node_soap_get(p_node, "Version");
    if (p_Version)
    {
		parse_Version(p_Version, &p_cap->Version);
    }
    
    return TRUE;
}

BOOL parse_StartFirmwareUpgrade(XMLN * p_node, StartFirmwareUpgrade_RES * p_res)
{
    XMLN * p_UploadUri;
    XMLN * p_UploadDelay;
    XMLN * p_ExpectedDownTime;

    p_UploadUri = xml_node_soap_get(p_node, "UploadUri");
	if (p_UploadUri && p_UploadUri->data)
	{
		strncpy(p_res->UploadUri, p_UploadUri->data, sizeof(p_res->UploadUri)-1);
	}
	else
	{
	    return FALSE;
	}

	p_UploadDelay = xml_node_soap_get(p_node, "UploadDelay");
	if (p_UploadDelay && p_UploadDelay->data)
	{
		p_res->UploadDelay = atoi(p_UploadDelay->data);
	}

	p_ExpectedDownTime = xml_node_soap_get(p_node, "ExpectedDownTime");
	if (p_ExpectedDownTime && p_ExpectedDownTime->data)
	{
		parse_XSDDuration(p_ExpectedDownTime->data, &p_res->ExpectedDownTime);
	}

	return TRUE;
}

BOOL parse_GetSystemUris(XMLN * p_node, GetSystemUris_RES * p_res)
{
    XMLN * p_SystemLogUris;
    XMLN * p_SupportInfoUri;
    XMLN * p_SystemBackupUri;

    p_SystemLogUris = xml_node_soap_get(p_node, "SystemLogUris");
    if (p_SystemLogUris)
    {
        XMLN * p_SystemLog;

        p_SystemLog = xml_node_soap_get(p_SystemLogUris, "SystemLog");
        while (p_SystemLog && soap_strcmp(p_SystemLog->name, "SystemLog") == 0)
        {
            int type = -1;
            XMLN * p_Type;
            XMLN * p_Uri;

            p_Type = xml_node_soap_get(p_SystemLog, "Type");
            if (p_Type && p_Type->data)
            {
                if (soap_strcmp(p_Type->data, "System") == 0)
                {
                    type = 0;
                }
                else if (soap_strcmp(p_Type->data, "Access") == 0)
                {
                    type = 1;
                }
            }

            p_Uri = xml_node_soap_get(p_SystemLog, "Uri");
            if (p_Uri && p_Uri->data)
            {
                if (0 == type)
                {
                    p_res->SystemLogUriFlag = 1;
                    strncpy(p_res->SystemLogUri, p_Uri->data, sizeof(p_res->SystemLogUri)-1);
                }
                else if (1 == type)
                {
                    p_res->AccessLogUriFlag = 1;
                    strncpy(p_res->AccessLogUri, p_Uri->data, sizeof(p_res->AccessLogUri)-1);
                }
            }
    
            p_SystemLog = p_SystemLog->next;
        }
    }

    p_SupportInfoUri = xml_node_soap_get(p_node, "SupportInfoUri");
    if (p_SupportInfoUri && p_SupportInfoUri->data)
    {
        p_res->SupportInfoUriFlag = 1;
        strncpy(p_res->SupportInfoUri, p_SupportInfoUri->data, sizeof(p_res->SupportInfoUri)-1);
    }

    p_SystemBackupUri = xml_node_soap_get(p_node, "SystemBackupUri");
    if (p_SystemBackupUri && p_SystemBackupUri->data)
    {
        p_res->SystemBackupUriFlag = 1;
        strncpy(p_res->SystemBackupUri, p_SystemBackupUri->data, sizeof(p_res->SystemBackupUri)-1);
    }

    return TRUE;
}

BOOL parse_StartSystemRestore(XMLN * p_node, StartSystemRestore_RES * p_res)
{
    XMLN * p_UploadUri;
    XMLN * p_ExpectedDownTime;

    p_UploadUri = xml_node_soap_get(p_node, "UploadUri");
	if (p_UploadUri && p_UploadUri->data)
	{
		strncpy(p_res->UploadUri, p_UploadUri->data, sizeof(p_res->UploadUri)-1);
	}
	else
	{
	    return FALSE;
	}

	p_ExpectedDownTime = xml_node_soap_get(p_node, "ExpectedDownTime");
	if (p_ExpectedDownTime && p_ExpectedDownTime->data)
	{
		parse_XSDDuration(p_ExpectedDownTime->data, &p_res->ExpectedDownTime);
	}

	return TRUE;
}

BOOL parse_SetVideoSourceMode(XMLN * p_node, SetVideoSourceMode_RES * p_res)
{
	XMLN * p_Reboot = xml_node_soap_get(p_node, "Reboot");
	if (p_Reboot && p_Reboot->data)
	{
		p_res->Reboot = parse_Bool(p_Reboot->data);
	}

	return TRUE;	
}

BOOL parse_VideoSourceMode(XMLN * p_node, onvif_VideoSourceMode * p_res)
{
	XMLN * p_MaxFramerate;
	XMLN * p_MaxResolution;
	XMLN * p_Encodings;
	XMLN * p_Reboot;
	XMLN * p_Description;

	p_MaxFramerate = xml_node_soap_get(p_node, "MaxFramerate");
	if (p_MaxFramerate && p_MaxFramerate->data)
	{
		p_res->MaxFramerate = (float)atof(p_MaxFramerate->data);
	}

	p_MaxResolution = xml_node_soap_get(p_node, "MaxResolution");
	if (p_MaxResolution)
	{
		parse_Resolution(p_MaxResolution, &p_res->MaxResolution);
	}

	p_Encodings = xml_node_soap_get(p_node, "Encodings");
	while (p_Encodings && soap_strcmp(p_Encodings->name, "Encodings") == 0)
	{
		if (strcasecmp(p_Encodings->data, "JPEG") == 0)
		{
			p_res->VideoEncoding_JPEG = 1;
		}
		else if (strcasecmp(p_Encodings->data, "MPEG4") == 0)
		{
			p_res->VideoEncoding_MPEG4 = 1;
		}
		else if (strcasecmp(p_Encodings->data, "H264") == 0)
		{
			p_res->VideoEncoding_H264 = 1;
		}

		p_Encodings = p_Encodings->next;
	}

	p_Reboot = xml_node_soap_get(p_node, "Reboot");
	if (p_Reboot && p_Reboot->data)
	{
		p_res->Reboot = parse_Bool(p_Reboot->data);
	}

	p_Description = xml_node_soap_get(p_node, "Description");
	if (p_Description && p_Description->data)
	{
		p_res->DescriptionFlag = 1;
		strncpy(p_res->Description, p_Description->data, sizeof(p_res->Description)-1);
	}

	return TRUE;    
}

BOOL parse_OSDColor(XMLN * p_node, onvif_OSDColor * p_res)
{
	XMLN * p_Color;	
	const char * p_Transparent;

	p_Transparent = xml_attr_get(p_node, "Transparent");
	if (p_Transparent)
	{
		p_res->TransparentFlag = 1;
		p_res->Transparent = atoi(p_Transparent);
	}
			
	p_Color = xml_node_soap_get(p_node, "Color");
	if (p_Color)
	{
		const char * p_X;
		const char * p_Y;
		const char * p_Z;
		const char * p_Colorspace;

		p_X = xml_attr_get(p_Color, "X");
		if (p_X)
		{
			p_res->X = (float)atof(p_X);
		}

		p_Y = xml_attr_get(p_Color, "Y");
		if (p_Y)
		{
			p_res->Y = (float)atof(p_Y);
		}

		p_Z = xml_attr_get(p_Color, "Z");
		if (p_Z)
		{
			p_res->Z = (float)atof(p_Z);
		}

		p_Colorspace = xml_attr_get(p_Color, "Colorspace");
		if (p_Colorspace)
		{
			p_res->ColorspaceFlag = 1;
			strncpy(p_res->Colorspace, p_Colorspace, sizeof(p_res->Colorspace)-1);
		}
	}

	return TRUE;
}

BOOL parse_OSDConfiguration(XMLN * p_node, onvif_OSDConfiguration * p_res)
{
	XMLN * p_VideoSourceConfigurationToken;
	XMLN * p_Type;
	XMLN * p_Position;
	XMLN * p_TextString;
	XMLN * p_Image;

	p_VideoSourceConfigurationToken = xml_node_soap_get(p_node, "VideoSourceConfigurationToken");
	if (p_VideoSourceConfigurationToken && p_VideoSourceConfigurationToken->data)
	{
		strncpy(p_res->VideoSourceConfigurationToken, p_VideoSourceConfigurationToken->data, sizeof(p_res->VideoSourceConfigurationToken)-1);
	}

	p_Type = xml_node_soap_get(p_node, "Type");
	if (p_Type && p_Type->data)
	{
		p_res->Type = onvif_StringToOSDType(p_Type->data);
	}

	p_Position = xml_node_soap_get(p_node, "Position");
	if (p_Position)
	{
		XMLN * p_Type;
		XMLN * p_Pos;

		p_Type = xml_node_soap_get(p_Position, "Type");
		if (p_Type && p_Type->data)
		{
			p_res->Position.Type = onvif_StringToOSDPosType(p_Type->data);
		}

		p_Pos = xml_node_soap_get(p_Position, "Pos");
		if (p_Pos)
		{
			p_res->Position.PosFlag = 1;
			parse_Vector(p_Pos, &p_res->Position.Pos);
		}
	}

	p_TextString = xml_node_soap_get(p_node, "TextString");
	if (p_TextString)
	{
		XMLN * p_Type;
		XMLN * p_DateFormat;
		XMLN * p_TimeFormat;
		XMLN * p_FontSize;
		XMLN * p_FontColor;
		XMLN * p_BackgroundColor;
		XMLN * p_PlainText;

		p_res->TextStringFlag = 1;
		
		p_Type = xml_node_soap_get(p_TextString, "Type");
		if (p_Type && p_Type->data)
		{
			p_res->TextString.Type = onvif_StringToOSDTextType(p_Type->data);
		}

		p_DateFormat = xml_node_soap_get(p_TextString, "DateFormat");
		if (p_DateFormat && p_DateFormat->data)
		{
			p_res->TextString.DateFormatFlag = 1;
			strncpy(p_res->TextString.DateFormat, p_DateFormat->data, sizeof(p_res->TextString.DateFormat)-1);
		}

		p_TimeFormat = xml_node_soap_get(p_TextString, "TimeFormat");
		if (p_TimeFormat && p_TimeFormat->data)
		{
			p_res->TextString.TimeFormatFlag = 1;
			strncpy(p_res->TextString.TimeFormat, p_TimeFormat->data, sizeof(p_res->TextString.TimeFormat)-1);
		}

		p_FontSize = xml_node_soap_get(p_TextString, "FontSize");
		if (p_FontSize && p_FontSize->data)
		{
			p_res->TextString.FontSizeFlag = 1;
			p_res->TextString.FontSize = atoi(p_FontSize->data);
		}

		p_FontColor = xml_node_soap_get(p_TextString, "FontColor");
		if (p_FontColor)
		{
			p_res->TextString.FontColorFlag = 1;			
			parse_OSDColor(p_FontColor, &p_res->TextString.FontColor);
		}

		p_BackgroundColor = xml_node_soap_get(p_TextString, "BackgroundColor");
		if (p_BackgroundColor)
		{
			p_res->TextString.BackgroundColorFlag = 1;			
			parse_OSDColor(p_BackgroundColor, &p_res->TextString.BackgroundColor);
		}

		p_PlainText = xml_node_soap_get(p_TextString, "PlainText");
		if (p_PlainText && p_PlainText->data)
		{
			p_res->TextString.PlainTextFlag = 1;
			strncpy(p_res->TextString.PlainText, p_PlainText->data, sizeof(p_res->TextString.PlainText)-1);
		}
	}

	p_Image = xml_node_soap_get(p_node, "Image");
	if (p_Image)
	{
		XMLN * p_ImgPath;

		p_res->ImageFlag = 1;
		
		p_ImgPath = xml_node_soap_get(p_Image, "ImgPath");
		if (p_ImgPath && p_ImgPath->data)
		{
			strncpy(p_res->Image.ImgPath, p_ImgPath->data, sizeof(p_res->Image.ImgPath)-1);
		}		
	}
	
	return TRUE;
}

BOOL parse_Color(XMLN * p_node, onvif_Color * p_res)
{
	const char * p_X;
	const char * p_Y;
	const char * p_Z;
	const char * p_Colorspace;

	p_X = xml_attr_get(p_node, "X");
	if (p_X)
	{
		p_res->X = (float)atof(p_X);
	}

	p_Y = xml_attr_get(p_node, "Y");
	if (p_Y)
	{
		p_res->X = (float)atof(p_Y);
	}

	p_Z = xml_attr_get(p_node, "Z");
	if (p_Z)
	{
		p_res->X = (float)atof(p_Z);
	}
	
	p_Colorspace = xml_attr_get(p_node, "Colorspace");
	if (p_Colorspace)
	{
		p_res->ColorspaceFlag = 1;
		strncpy(p_res->Colorspace, p_Colorspace, sizeof(p_res->Colorspace)-1);
	}	

	return TRUE;
}

BOOL parse_OSDColorOptions(XMLN * p_node, onvif_OSDColorOptions * p_res)
{
	XMLN * p_Color;
	XMLN * p_Transparent;

	p_Color = xml_node_soap_get(p_node, "Color");
	if (p_Color)
	{
		XMLN * p_ColorList;
		XMLN * p_ColorspaceRange;
		
		p_res->ColorFlag = 1;

		p_ColorList = xml_node_soap_get(p_Color, "ColorList");
		while (p_ColorList && soap_strcmp(p_ColorList->name, "ColorList") == 0)
		{
			int index = p_res->Color.ColorListSize;
			if (index < 10)
			{
				p_res->Color.ColorListSize++;
				parse_Color(p_ColorList, &p_res->Color.ColorList[index]);
			}
			
			p_ColorList = p_ColorList->next;
		}

		p_ColorspaceRange = xml_node_soap_get(p_Color, "ColorspaceRange");
		while (p_ColorspaceRange && soap_strcmp(p_ColorspaceRange->name, "ColorspaceRange") == 0)
		{
			int index = p_res->Color.ColorspaceRangeSize;
			if (index < 10)
			{
				XMLN * p_X;
				XMLN * p_Y;
				XMLN * p_Z;
				XMLN * p_Colorspace;

				p_res->Color.ColorspaceRangeSize++;
				
				p_X = xml_node_soap_get(p_ColorspaceRange, "X");
				if (p_X)
				{
					parse_FloatRange(p_X, &p_res->Color.ColorspaceRange[index].X);
				}

				p_Y = xml_node_soap_get(p_ColorspaceRange, "Y");
				if (p_Y)
				{
					parse_FloatRange(p_Y, &p_res->Color.ColorspaceRange[index].Y);
				}

				p_Z = xml_node_soap_get(p_ColorspaceRange, "Z");
				if (p_Z)
				{
					parse_FloatRange(p_Z, &p_res->Color.ColorspaceRange[index].Z);
				}

				p_Colorspace = xml_node_soap_get(p_ColorspaceRange, "Colorspace");
				if (p_Colorspace && p_Colorspace->data)
				{
					strncpy(p_res->Color.ColorspaceRange[index].Colorspace, p_Colorspace->data, sizeof(p_res->Color.ColorspaceRange[index].Colorspace)-1);
				}
			}
			
			p_ColorspaceRange = p_ColorspaceRange->next;
		}
	}

	p_Transparent = xml_node_soap_get(p_node, "Transparent");
	if (p_Transparent)
	{
		p_res->TransparentFlag = 1;
		parse_IntRange(p_Transparent, &p_res->Transparent);
	}

	return TRUE;
}

BOOL parse_GetOSDOptions(XMLN * p_node, GetOSDOptions_RES * p_res)
{
	XMLN * p_OSDOptions;

	p_OSDOptions = xml_node_soap_get(p_node, "OSDOptions");
	if (p_OSDOptions)
	{
		XMLN * p_MaximumNumberOfOSDs;
		XMLN * p_Type;
		XMLN * p_PositionOption;
		XMLN * p_TextOption;
		XMLN * p_ImageOption;

		p_MaximumNumberOfOSDs = xml_node_soap_get(p_OSDOptions, "MaximumNumberOfOSDs");
		if (p_MaximumNumberOfOSDs)
		{
			const char * p_Total;
			const char * p_Image;
			const char * p_PlainText;
			const char * p_Date;
			const char * p_Time;
			const char * p_DateAndTime;

			p_Total = xml_attr_get(p_MaximumNumberOfOSDs, "Total");
			if (p_Total)
			{
				p_res->OSDOptions.MaximumNumberOfOSDs.Total = atoi(p_Total);
			}

			p_Image = xml_attr_get(p_MaximumNumberOfOSDs, "Image");
			if (p_Image)
			{
				p_res->OSDOptions.MaximumNumberOfOSDs.ImageFlag = 1;
				p_res->OSDOptions.MaximumNumberOfOSDs.Image = atoi(p_Image);
			}

			p_PlainText = xml_attr_get(p_MaximumNumberOfOSDs, "PlainText");
			if (p_PlainText)
			{
				p_res->OSDOptions.MaximumNumberOfOSDs.PlainTextFlag = 1;
				p_res->OSDOptions.MaximumNumberOfOSDs.PlainText = atoi(p_PlainText);
			}

			p_Date = xml_attr_get(p_MaximumNumberOfOSDs, "Date");
			if (p_Date)
			{
				p_res->OSDOptions.MaximumNumberOfOSDs.DateFlag = 1;
				p_res->OSDOptions.MaximumNumberOfOSDs.Date = atoi(p_Date);
			}

			p_Time = xml_attr_get(p_MaximumNumberOfOSDs, "Time");
			if (p_Time)
			{
				p_res->OSDOptions.MaximumNumberOfOSDs.TimeFlag = 1;
				p_res->OSDOptions.MaximumNumberOfOSDs.Time = atoi(p_Time);
			}

			p_DateAndTime = xml_attr_get(p_MaximumNumberOfOSDs, "DateAndTime");
			if (p_DateAndTime)
			{
				p_res->OSDOptions.MaximumNumberOfOSDs.DateAndTimeFlag = 1;
				p_res->OSDOptions.MaximumNumberOfOSDs.DateAndTime = atoi(p_DateAndTime);
			}
		}

		p_Type = xml_node_soap_get(p_OSDOptions, "Type");
		while (p_Type && p_Type->data && soap_strcmp(p_Type->name, "Type") == 0)
		{
			if (soap_strcmp(p_Type->data, "Text") == 0)
			{
				p_res->OSDOptions.OSDType_Text = 1;
			}
			else if (soap_strcmp(p_Type->data, "Image") == 0)
			{
				p_res->OSDOptions.OSDType_Image = 1;
			}
			else if (soap_strcmp(p_Type->data, "Extended") == 0)
			{
				p_res->OSDOptions.OSDType_Extended = 1;
			}
			
			p_Type = p_Type->next;
		}

		p_PositionOption = xml_node_soap_get(p_OSDOptions, "PositionOption");
		while (p_PositionOption && p_PositionOption->data && soap_strcmp(p_PositionOption->name, "PositionOption") == 0)
		{
			if (soap_strcmp(p_PositionOption->data, "UpperLeft") == 0)
			{
				p_res->OSDOptions.OSDPosType_UpperLeft = 1;
			}
			else if (soap_strcmp(p_PositionOption->data, "UpperRight") == 0)
			{
				p_res->OSDOptions.OSDPosType_UpperRight = 1;
			}
			else if (soap_strcmp(p_PositionOption->data, "LowerLeft") == 0)
			{
				p_res->OSDOptions.OSDPosType_LowerLeft = 1;
			}
			else if (soap_strcmp(p_PositionOption->data, "LowerRight") == 0)
			{
				p_res->OSDOptions.OSDPosType_LowerRight = 1;
			}
			else if (soap_strcmp(p_PositionOption->data, "Custom") == 0)
			{
				p_res->OSDOptions.OSDPosType_Custom = 1;
			}
			
			p_PositionOption = p_PositionOption->next;
		}

		p_TextOption = xml_node_soap_get(p_OSDOptions, "TextOption");
		if (p_TextOption)
		{
			XMLN * p_Type;
			XMLN * p_FontSizeRange;
			XMLN * p_DateFormat;
			XMLN * p_TimeFormat;
			XMLN * p_FontColor;
			XMLN * p_BackgroundColor;
			
			p_res->OSDOptions.TextOptionFlag = 1;

			p_Type = xml_node_soap_get(p_TextOption, "Type");
			while (p_Type && p_Type->data && soap_strcmp(p_Type->name, "Type") == 0)
			{
				if (soap_strcmp(p_Type->data, "Plain") == 0)
				{
					p_res->OSDOptions.TextOption.OSDTextType_Plain = 1;
				}
				else if (soap_strcmp(p_Type->data, "Date") == 0)
				{
					p_res->OSDOptions.TextOption.OSDTextType_Date = 1;
				}
				else if (soap_strcmp(p_Type->data, "Time") == 0)
				{
					p_res->OSDOptions.TextOption.OSDTextType_Time = 1;
				}
				else if (soap_strcmp(p_Type->data, "DateAndTime") == 0)
				{
					p_res->OSDOptions.TextOption.OSDTextType_DateAndTime = 1;
				}
				
				p_Type = p_Type->next;
			}

			p_FontSizeRange = xml_node_soap_get(p_TextOption, "FontSizeRange");
			if (p_FontSizeRange)
			{
				p_res->OSDOptions.TextOption.FontSizeRangeFlag = 1;
				parse_IntRange(p_FontSizeRange, &p_res->OSDOptions.TextOption.FontSizeRange);
			}

			p_DateFormat = xml_node_soap_get(p_TextOption, "DateFormat");
			while (p_DateFormat && p_DateFormat->data && soap_strcmp(p_DateFormat->name, "DateFormat") == 0)
			{
				int index = p_res->OSDOptions.TextOption.DateFormatSize;				
				if (index < 10)
				{
					p_res->OSDOptions.TextOption.DateFormatSize++;
					strncpy(p_res->OSDOptions.TextOption.DateFormat[index], p_DateFormat->data, sizeof(p_res->OSDOptions.TextOption.DateFormat[0])-1);
				}			
				
				p_DateFormat = p_DateFormat->next;
			}

			p_TimeFormat = xml_node_soap_get(p_TextOption, "TimeFormat");
			while (p_TimeFormat && p_TimeFormat->data && soap_strcmp(p_TimeFormat->name, "TimeFormat") == 0)
			{
				int index = p_res->OSDOptions.TextOption.TimeFormatSize;
				if (index < 10)
				{
					p_res->OSDOptions.TextOption.TimeFormatSize++;
					strncpy(p_res->OSDOptions.TextOption.TimeFormat[index], p_TimeFormat->data, sizeof(p_res->OSDOptions.TextOption.TimeFormat[0])-1);
				}			
				
				p_TimeFormat = p_TimeFormat->next;
			}

			p_FontColor = xml_node_soap_get(p_TextOption, "FontColor");
			if (p_FontColor)
			{
				p_res->OSDOptions.TextOption.FontColorFlag = parse_OSDColorOptions(p_FontColor, &p_res->OSDOptions.TextOption.FontColor);
			}

			p_BackgroundColor = xml_node_soap_get(p_TextOption, "BackgroundColor");
			if (p_BackgroundColor)
			{
				p_res->OSDOptions.TextOption.BackgroundColorFlag = parse_OSDColorOptions(p_BackgroundColor, &p_res->OSDOptions.TextOption.BackgroundColor);				
			}
		}

		p_ImageOption = xml_node_soap_get(p_OSDOptions, "ImageOption");
		if (p_ImageOption)
		{
			XMLN * p_ImagePath;

			p_res->OSDOptions.ImageOptionFlag = 1;

			p_ImagePath = xml_node_soap_get(p_ImageOption, "ImagePath");
			while (p_ImagePath && p_ImagePath->data && soap_strcmp(p_ImagePath->name, "ImagePath") == 0)
			{
				int index = p_res->OSDOptions.ImageOption.ImagePathSize;
				if (index < 10)
				{
					p_res->OSDOptions.ImageOption.ImagePathSize++;
					strncpy(p_res->OSDOptions.ImageOption.ImagePath[index], p_ImagePath->data, sizeof(p_res->OSDOptions.ImageOption.ImagePath[0])-1);
				}
				
				p_ImagePath = p_ImagePath->next;
			}
		}
	}
	
	return TRUE;
}

BOOL parse_CreateOSD(XMLN * p_node, CreateOSD_RES * p_res)
{

	XMLN * p_OSDToken;
	
	p_OSDToken = xml_node_soap_get(p_node, "OSDToken");
	if (p_OSDToken && p_OSDToken->data)
	{
		strncpy(p_res->OSDToken, p_OSDToken->data, sizeof(p_res->OSDToken)-1);
	}

	return TRUE;
}



BOOL parse_Config(XMLN * p_node, onvif_Config * p_req)
{
	XMLN * p_Parameters;	
	const char * p_Name;
	const char * p_Type;

	p_Name = xml_attr_get(p_node, "Name");
	if (p_Name)
	{
		strncpy(p_req->Name, p_Name, sizeof(p_req->Name)-1);
	}

	p_Type = xml_attr_get(p_node, "Type");
	if (p_Type)
	{
		strncpy(p_req->Type, p_Type, sizeof(p_req->Type)-1);
	}

	p_Parameters = xml_node_soap_get(p_node, "Parameters");
	if (p_Parameters)
	{	
		XMLN * p_SimpleItem;
		XMLN * p_ElementItem;

		p_SimpleItem = xml_node_soap_get(p_Parameters, "SimpleItem");
		while (p_SimpleItem && soap_strcmp(p_SimpleItem->name, "SimpleItem") == 0)
		{
			ONVIF_SimpleItem * p_simple_item = onvif_add_SimpleItem(&p_req->Parameters.SimpleItem);
			if (p_simple_item)
			{
				if (FALSE == parse_SimpleItem(p_SimpleItem, &p_simple_item->SimpleItem))
				{
					onvif_free_SimpleItems(&p_req->Parameters.SimpleItem);
					break;
				}
			}
			
			p_SimpleItem = p_SimpleItem->next;
		}

		p_ElementItem = xml_node_soap_get(p_Parameters, "ElementItem");
		while (p_ElementItem && soap_strcmp(p_ElementItem->name, "ElementItem") == 0)
		{
			ONVIF_ElementItem * p_element_item = onvif_add_ElementItem(&p_req->Parameters.ElementItem);
			if (p_element_item)
			{
				if (FALSE == parse_ElementItem(p_ElementItem, &p_element_item->ElementItem))
				{
					onvif_free_ElementItems(&p_req->Parameters.ElementItem);
					break;
				}
			}
			
			p_ElementItem = p_ElementItem->next;
		}
	}

	return TRUE;
}

BOOL parse_AnalyticsEngineConfiguration(XMLN * p_node, onvif_AnalyticsEngineConfiguration * p_req)
{
	XMLN * p_AnalyticsModule;
	ONVIF_Config * p_config;

	p_AnalyticsModule = xml_node_soap_get(p_node, "AnalyticsModule");
	while (p_AnalyticsModule && soap_strcmp(p_AnalyticsModule->name, "AnalyticsModule") == 0)
	{
		p_config = onvif_add_Config(&p_req->AnalyticsModule);
		if (p_config)
		{
			parse_Config(p_AnalyticsModule, &p_config->Config);
		}
		
		p_AnalyticsModule = p_AnalyticsModule->next;
	}

	return TRUE;
}

BOOL parse_RuleEngineConfiguration(XMLN * p_node, onvif_RuleEngineConfiguration * p_req)
{
	XMLN * p_Rule;
	ONVIF_Config * p_config;

	p_Rule = xml_node_soap_get(p_node, "Rule");
	while (p_Rule && soap_strcmp(p_Rule->name, "Rule") == 0)
	{
		p_config = onvif_add_Config(&p_req->Rule);
		if (p_config)
		{
			parse_Config(p_Rule, &p_config->Config);
		}
		
		p_Rule = p_Rule->next;
	}

	return TRUE;
}

BOOL parse_VideoAnalyticsConfiguration(XMLN * p_node, onvif_VideoAnalyticsConfiguration * p_req)
{
	XMLN * p_Name;
	XMLN * p_UseCount;
	XMLN * p_AnalyticsEngineConfiguration;
	XMLN * p_RuleEngineConfiguration;	
	const char * p_token;

	p_token = xml_attr_get(p_node, "token");
	if (p_token)
	{
		strncpy(p_req->token, p_token, sizeof(p_req->token)-1);
	}
	
	p_Name = xml_node_soap_get(p_node, "Name");
	if (p_Name && p_Name->data)
	{
		strncpy(p_req->Name, p_Name->data, sizeof(p_req->Name)-1);
	}

	p_UseCount = xml_node_soap_get(p_node, "UseCount");
	if (p_UseCount && p_UseCount->data)
	{
		p_req->UseCount = atoi(p_UseCount->data);
	}

	p_AnalyticsEngineConfiguration = xml_node_soap_get(p_node, "AnalyticsEngineConfiguration");
	if (p_AnalyticsEngineConfiguration)
	{
		if (FALSE == parse_AnalyticsEngineConfiguration(p_AnalyticsEngineConfiguration, &p_req->AnalyticsEngineConfiguration))
		{
			return FALSE;
		}
	}

	p_RuleEngineConfiguration = xml_node_soap_get(p_node, "RuleEngineConfiguration");
	if (p_RuleEngineConfiguration)
	{
		if (FALSE == parse_RuleEngineConfiguration(p_RuleEngineConfiguration, &p_req->RuleEngineConfiguration))
		{
			return FALSE;
		}
	}
	
	return TRUE;
}

BOOL parse_GetVideoAnalyticsConfigurations(XMLN * p_node, GetVideoAnalyticsConfigurations_RES * p_res)
{
	XMLN * p_Configurations;

	p_Configurations = xml_node_soap_get(p_node, "Configurations");
	while (p_Configurations && soap_strcmp(p_Configurations->name, "Configurations") == 0)
	{
		ONVIF_VideoAnalyticsConfiguration * p_config = onvif_add_VideoAnalyticsConfiguration(&p_res->Configurations);
    	if (p_config)
    	{
	        if (parse_VideoAnalyticsConfiguration(p_Configurations, &p_config->Configuration) == FALSE)
	        {
	            onvif_free_VideoAnalyticsConfigurations(&p_res->Configurations);
	            return FALSE;
	        }
        }

        p_Configurations = p_Configurations->next;
	}

	return TRUE;
}

BOOL parse_GetRules(XMLN * p_node, GetRules_RES * p_res)
{
	XMLN * p_Rule;
	
	p_Rule = xml_node_soap_get(p_node, "Rule");
	while (p_Rule && soap_strcmp(p_Rule->name, "Rule") == 0)
	{
		ONVIF_Config * p_config = onvif_add_Config(&p_res->Rule);
		if (p_config)
		{
			if (parse_Config(p_Rule, &p_config->Config) == FALSE)
			{
				onvif_free_Configs(&p_res->Rule);
				return FALSE;
			}
		}
		
		p_Rule = p_Rule->next;
	}

	return TRUE;
}

BOOL parse_GetAnalyticsModules(XMLN * p_node, GetAnalyticsModules_RES * p_res)
{
	XMLN * p_Rule;
	
	p_Rule = xml_node_soap_get(p_node, "AnalyticsModule");
	while (p_Rule && soap_strcmp(p_Rule->name, "AnalyticsModule") == 0)
	{
		ONVIF_Config * p_config = onvif_add_Config(&p_res->AnalyticsModule);
		if (p_config)
		{
			if (parse_Config(p_Rule, &p_config->Config) == FALSE)
			{
				onvif_free_Configs(&p_res->AnalyticsModule);
				return FALSE;
			}
		}
		
		p_Rule = p_Rule->next;
	}

	return TRUE;
}

int parse_SimpleItemDescriptions(XMLN * p_node, const char * name, ONVIF_SimpleItemDescription * p_res)
{
	int idx = 0;
	XMLN * p_Item = xml_node_soap_get(p_node, name);
	while (p_Item && soap_strcmp(p_Item->name, name) == 0)
	{
		const char * p_Name;
		const char * p_Type;

		ONVIF_SimpleItemDescription * p_item = onvif_add_SimpleItemDescription(&p_res);

		p_Name = xml_attr_get(p_Item, "Name");
		if (p_Name)
		{
			strncpy(p_item->SimpleItemDescription.Name, p_Name, sizeof(p_item->SimpleItemDescription.Name)-1);
		}

		p_Type = xml_attr_get(p_Item, "Type");
		if (p_Type)
		{
			strncpy(p_item->SimpleItemDescription.Type, p_Type, sizeof(p_item->SimpleItemDescription.Type)-1);
		}

		p_Item = p_Item->next;
	}

	return idx;
}

BOOL parse_ItemListDescription(XMLN * p_node, onvif_ItemListDescription * p_res)
{
	parse_SimpleItemDescriptions(p_node, "SimpleItemDescription", p_res->SimpleItemDescription);
	parse_SimpleItemDescriptions(p_node, "ElementItemDescription", p_res->ElementItemDescription);

	return TRUE;
}

BOOL parse_ConfigDescription_Messages(XMLN * p_node, onvif_ConfigDescription_Messages * p_res)
{
	XMLN * p_Source;
	XMLN * p_Key;
	XMLN * p_Data;
	XMLN * p_ParentTopic;

	p_Source = xml_node_soap_get(p_node, "Source");
	if (p_Source)
	{
		p_res->SourceFlag = 1;
		parse_ItemListDescription(p_Source, &p_res->Source);
	}

	p_Key = xml_node_soap_get(p_node, "Key");
	if (p_Key)
	{
		p_res->KeyFlag = 1;
		parse_ItemListDescription(p_Key, &p_res->Key);
	}

	p_Data = xml_node_soap_get(p_node, "Data");
	if (p_Data)
	{
		p_res->DataFlag = 1;
		parse_ItemListDescription(p_Data, &p_res->Data);
	}

	p_ParentTopic = xml_node_soap_get(p_node, "ParentTopic");
	if (p_ParentTopic && p_ParentTopic->data)
	{
		strncpy(p_res->ParentTopic, p_ParentTopic->data, sizeof(p_ParentTopic->data)-1);
	}
	
	return TRUE;
}

BOOL parse_RuleDescription(XMLN * p_node, onvif_ConfigDescription * p_res)
{
	XMLN * p_Parameters;
	XMLN * p_Messages;
	const char * p_Name;

	p_Name = xml_attr_get(p_node, "Name");
	if (p_Name)
	{
		strncpy(p_res->Name, p_Name, sizeof(p_res->Name)-1);
	}

	p_Parameters = xml_node_soap_get(p_node, "Parameters");
	if (p_Parameters)
	{
		parse_ItemListDescription(p_Parameters, &p_res->Parameters);
	}

	p_Messages = xml_node_soap_get(p_node, "Messages");
	while (p_Messages && soap_strcmp(p_Messages->name, "Messages") == 0)
	{
		const char * p_IsProperty;
		ONVIF_ConfigDescription_Messages * p_item = onvif_add_ConfigDescription_Messages(&p_res->Messages);

		p_IsProperty = xml_attr_get(p_node, "IsProperty");
		if (p_IsProperty)
		{
			p_item->Messages.IsPropertyFlag = 1;
			p_item->Messages.IsProperty = parse_Bool(p_IsProperty);
		}

		parse_ConfigDescription_Messages(p_Messages, &p_item->Messages);		
	}

	return TRUE;
}

BOOL parse_GetSupportedRules(XMLN * p_node, GetSupportedRules_RES * p_res)
{
	XMLN * p_RuleContentSchemaLocation;
	XMLN * p_RuleDescription;

	p_RuleContentSchemaLocation = xml_node_soap_get(p_node, "RuleContentSchemaLocation");
	while (p_RuleContentSchemaLocation && p_RuleContentSchemaLocation->data && soap_strcmp(p_RuleContentSchemaLocation->name, "RuleContentSchemaLocation") == 0)
	{
		int idx = p_res->SupportedRules.sizeRuleContentSchemaLocation;

		strncpy(p_res->SupportedRules.RuleContentSchemaLocation[idx], p_RuleContentSchemaLocation->data, sizeof(p_res->SupportedRules.RuleContentSchemaLocation[idx])-1);

		p_res->SupportedRules.sizeRuleContentSchemaLocation++;
		if (p_res->SupportedRules.sizeRuleContentSchemaLocation >= 10)
		{
			break;
		}

		p_RuleContentSchemaLocation = p_RuleContentSchemaLocation->next;
	}

	p_RuleDescription = xml_node_soap_get(p_node, "RuleDescription");
	while (p_RuleDescription && soap_strcmp(p_RuleDescription->name, "RuleDescription") == 0)
	{
		ONVIF_ConfigDescription * p_cfg_desc = onvif_add_ConfigDescription(&p_res->SupportedRules.RuleDescription);
		if (p_cfg_desc)
		{	
			if (parse_RuleDescription(p_RuleDescription, &p_cfg_desc->ConfigDescription) == FALSE)
			{
				onvif_free_ConfigDescriptions(&p_res->SupportedRules.RuleDescription);
				return FALSE;
			}
		}
		
		p_RuleDescription = p_RuleDescription->next;
	}
	
	return TRUE;
}


BOOL parse_GetScopes(XMLN * p_node, GetScopes_RES * p_res)
{
	XMLN * p_Scopes;

	p_Scopes = xml_node_soap_get(p_node, "Scopes");
	while (p_Scopes && soap_strcmp(p_Scopes->name, "Scopes") == 0)
	{
		XMLN * p_ScopeDef;
		XMLN * p_ScopeItem;
		int idx = p_res->sizeScopes;
		
		p_ScopeDef = xml_node_soap_get(p_Scopes, "ScopeDef");
		if (p_ScopeDef && p_ScopeDef->data)
		{
			p_res->Scopes[idx].ScopeDef = onvif_StringToScopeDefinition(p_ScopeDef->data);
		}

		p_ScopeItem = xml_node_soap_get(p_Scopes, "ScopeItem");
		if (p_ScopeItem && p_ScopeItem->data)
		{
			strncpy(p_res->Scopes[idx].ScopeItem, p_ScopeItem->data, sizeof(p_res->Scopes[idx].ScopeItem)-1);
		}

		p_res->sizeScopes++;
		if (p_res->sizeScopes >= MAX_SCOPE_NUMS)
		{
			break;
		}
		
		p_Scopes = p_Scopes->next;
	}

	return TRUE;
}

BOOL parse_GetEndpointReference(XMLN * p_node, GetEndpointReference_RES * p_res)
{
    XMLN * p_GUID;

	p_GUID = xml_node_soap_get(p_node, "GUID");
	if (p_GUID && p_GUID->data)
	{
	    strncpy(p_res->GUID, p_GUID->data, sizeof(p_res->GUID)-1);
	}

	return TRUE;
}

BOOL parse_PTZPresetTourSpot(XMLN * p_node, onvif_PTZPresetTourSpot * p_res)
{
	XMLN * p_PresetDetail;
	XMLN * p_Speed;
	XMLN * p_StayTime;

	p_PresetDetail = xml_node_soap_get(p_node, "PresetDetail");
	if (p_PresetDetail)
	{
		XMLN * p_PresetToken;
		XMLN * p_Home;
		XMLN * p_PTZPosition;

		p_PresetToken = xml_node_soap_get(p_PresetDetail, "PresetToken");
		if (p_PresetToken && p_PresetToken->data)
		{
			p_res->PresetDetail.PresetTokenFlag = 1;
			strncpy(p_res->PresetDetail.PresetToken, p_PresetToken->data, sizeof(p_res->PresetDetail.PresetToken)-1);
		}

		p_Home = xml_node_soap_get(p_PresetDetail, "Home");
		if (p_Home && p_Home->data)
		{
			p_res->PresetDetail.HomeFlag = 1;
			p_res->PresetDetail.Home = parse_Bool(p_Home->data);			
		}

		p_PTZPosition = xml_node_soap_get(p_PresetDetail, "PTZPosition");
		if (p_PTZPosition)
		{
			p_res->PresetDetail.PTZPositionFlag = 1;
			parse_PTZVector(p_PTZPosition, &p_res->PresetDetail.PTZPosition);
		}
	}

	p_Speed = xml_node_soap_get(p_node, "Speed");
	if (p_Speed)
	{
		p_res->SpeedFlag = 1;
		parse_PTZSpeed(p_Speed, &p_res->Speed);
	}

	p_StayTime = xml_node_soap_get(p_node, "StayTime");
	if (p_StayTime && p_StayTime->data)
	{
		p_res->StayTimeFlag = 1;
		p_res->StayTime = atoi(p_StayTime->data);
	}
	
	return TRUE;
}

BOOL parse_PTZPresetTourStatus(XMLN * p_node, onvif_PTZPresetTourStatus * p_res)
{
	XMLN * p_State;
	XMLN * p_CurrentTourSpot;
	
	p_State = xml_node_soap_get(p_node, "State");
	if (p_State && p_State->data)
	{
		p_res->State = onvif_StringToPTZPresetTourState(p_State->data);
	}

	p_CurrentTourSpot = xml_node_soap_get(p_node, "CurrentTourSpot");
	if (p_CurrentTourSpot)
	{
		p_res->CurrentTourSpotFlag = parse_PTZPresetTourSpot(p_CurrentTourSpot, &p_res->CurrentTourSpot);
	}

	return TRUE;
}

BOOL parse_PTZPresetTourStartingCondition(XMLN * p_node, onvif_PTZPresetTourStartingCondition * p_res)
{
	const char * p_RandomPresetOrder;
	XMLN * p_RecurringTime;
	XMLN * p_RecurringDuration;
	XMLN * p_Direction;

	p_RandomPresetOrder = xml_attr_get(p_node, "RandomPresetOrder");
	if (p_RandomPresetOrder)
	{
		p_res->RandomPresetOrderFlag = 1;
		p_res->RandomPresetOrder = parse_Bool(p_RandomPresetOrder);
	}

	p_RecurringTime = xml_node_soap_get(p_node, "RecurringTime");
	if (p_RecurringTime && p_RecurringTime->data)
	{
		p_res->RecurringTimeFlag = 1;
		p_res->RecurringTime = atoi(p_RecurringTime->data);
	}

	p_RecurringDuration = xml_node_soap_get(p_node, "RecurringDuration");
	if (p_RecurringDuration && p_RecurringDuration->data)
	{
		p_res->RecurringDurationFlag = 1;
		parse_XSDDuration(p_RecurringDuration->data, &p_res->RecurringDuration);
	}

	p_Direction = xml_node_soap_get(p_node, "Direction");
	if (p_Direction && p_Direction->data)
	{
		p_res->DirectionFlag = 1;
		p_res->Direction = onvif_StringToPTZPresetTourDirection(p_Direction->data);
	}

	return TRUE;
}

BOOL parse_PresetTour(XMLN * p_node, onvif_PresetTour * p_res)
{
	const char * p_token;
	XMLN * p_Name;
	XMLN * p_Status;
	XMLN * p_AutoStart;
	XMLN * p_StartingCondition;
	XMLN * p_TourSpot;

	p_token = xml_attr_get(p_node, "token");
	if (p_token)
	{
		strncpy(p_res->token, p_token, sizeof(p_res->token)-1);
	}
	else
	{
		return FALSE;
	}

	p_Name = xml_node_soap_get(p_node, "Name");
	if (p_Name && p_Name->data)
	{
		strncpy(p_res->Name, p_token, sizeof(p_res->Name)-1);
	}
	
	p_Status = xml_node_soap_get(p_node, "Status");
	if (p_Status)
	{
		parse_PTZPresetTourStatus(p_Status, &p_res->Status);
	}

	p_AutoStart = xml_node_soap_get(p_node, "AutoStart");
	if (p_AutoStart && p_AutoStart->data)
	{
		p_res->AutoStart = parse_Bool(p_AutoStart->data);
	}

	p_StartingCondition = xml_node_soap_get(p_node, "StartingCondition");
	if (p_StartingCondition)
	{
		parse_PTZPresetTourStartingCondition(p_StartingCondition, &p_res->StartingCondition);
	}

	p_TourSpot = xml_node_soap_get(p_node, "TourSpot");
	while (p_TourSpot && soap_strcmp(p_TourSpot->name, "TourSpot") == 0)
	{
		ONVIF_PTZPresetTourSpot * p_tour_spot = onvif_add_PTZPresetTourSpot(&p_res->TourSpot);
		if (p_tour_spot)
		{
			if (parse_PTZPresetTourSpot(p_TourSpot, &p_tour_spot->PTZPresetTourSpot) == FALSE)
			{
				onvif_free_PTZPresetTourSpots(&p_res->TourSpot);
				break;
			}
		}
		
		p_TourSpot = p_TourSpot->next;
	}

	return TRUE;
}

BOOL parse_GetPresetTours(XMLN * p_node, GetPresetTours_RES * p_res)
{
	XMLN * p_PresetTour;

	p_PresetTour = xml_node_soap_get(p_node, "PresetTour");
	while (p_PresetTour && soap_strcmp(p_PresetTour->name, "PresetTour") == 0)
	{
		ONVIF_PresetTour * p_preset_tour = onvif_add_PresetTour(&p_res->PresetTour);
		if (p_preset_tour)
		{
			if (parse_PresetTour(p_PresetTour, &p_preset_tour->PresetTour) == FALSE)
			{
				onvif_free_PresetTours(&p_res->PresetTour);
				return FALSE;
			}
		}

		p_PresetTour = p_PresetTour->next;
	}

	return TRUE;
}

BOOL parse_GetPresetTour(XMLN * p_node, GetPresetTour_RES * p_res)
{
	BOOL ret = FALSE;
	XMLN * p_PresetTour;

	p_PresetTour = xml_node_soap_get(p_node, "PresetTour");
	if (p_PresetTour)
	{
		ret = parse_PresetTour(p_PresetTour, &p_res->PresetTour);
	}

	return ret;
}

BOOL parse_DurationRange(XMLN * p_node, onvif_DurationRange * p_res)
{
	XMLN * p_Min;
	XMLN * p_Max;

	p_Min = xml_node_soap_get(p_node, "Min");
	if (p_Min && p_Min->data)
	{
		parse_XSDDuration(p_Min->data, &p_res->Min);
	}

	p_Max = xml_node_soap_get(p_node, "Max");
	if (p_Max && p_Max->data)
	{
		parse_XSDDuration(p_Max->data, &p_res->Max);
	}

	return TRUE;
}

BOOL parse_GetPresetTourOptions(XMLN * p_node, GetPresetTourOptions_RES * p_res)
{
	XMLN * p_Options;

	p_Options = xml_node_soap_get(p_node, "Options");
	if (p_Options)
	{
		XMLN * p_AutoStart;
		XMLN * p_StartingCondition;
		XMLN * p_TourSpot;

		p_AutoStart = xml_node_soap_get(p_Options, "AutoStart");
		if (p_AutoStart && p_AutoStart->data)
		{
			p_res->Options.AutoStart = parse_Bool(p_AutoStart->data);
		}

		p_StartingCondition = xml_node_soap_get(p_Options, "StartingCondition");
		if (p_StartingCondition)
		{
			XMLN * p_RecurringTime;
			XMLN * p_RecurringDuration;
			XMLN * p_Direction;

			p_RecurringTime = xml_node_soap_get(p_StartingCondition, "RecurringTime");
			if (p_RecurringTime)
			{
				p_res->Options.StartingCondition.RecurringTimeFlag = 1;

				parse_IntRange(p_RecurringTime, &p_res->Options.StartingCondition.RecurringTime);
			}

			p_RecurringDuration = xml_node_soap_get(p_StartingCondition, "RecurringDuration");
			if (p_RecurringDuration)
			{
				p_res->Options.StartingCondition.RecurringDurationFlag = 1;
				
				parse_DurationRange(p_RecurringDuration, &p_res->Options.StartingCondition.RecurringDuration);
			}

			p_Direction = xml_node_soap_get(p_StartingCondition, "Direction");
			while (p_Direction && soap_strcmp(p_Direction->name, "Direction") == 0)
			{
				if (strcmp(p_Direction->data, "Forward") == 0)
				{
					p_res->Options.StartingCondition.PTZPresetTourDirection_Forward = 1;
				}
				else if (strcmp(p_Direction->data, "Backward") == 0)
				{
					p_res->Options.StartingCondition.PTZPresetTourDirection_Backward = 1;
				}
				else if (strcmp(p_Direction->data, "Extended") == 0)
				{
					p_res->Options.StartingCondition.PTZPresetTourDirection_Extended = 1;
				}
				
				p_Direction = p_Direction->next;
			}
		}

		p_TourSpot = xml_node_soap_get(p_Options, "TourSpot");
		if (p_TourSpot)
		{
			XMLN * p_PresetDetail;
			XMLN * p_StayTime;

			p_PresetDetail = xml_node_soap_get(p_TourSpot, "PresetDetail");
			if (p_PresetDetail)
			{
				XMLN * p_PresetToken;
				XMLN * p_Home;
				XMLN * p_PanTiltPositionSpace;
				XMLN * p_ZoomPositionSpace;

				p_PresetToken = xml_node_soap_get(p_PresetDetail, "PresetToken");
				while (p_PresetToken && p_PresetToken->data && soap_strcmp(p_PresetToken->name, "PresetToken") == 0)
				{
					int idx = p_res->Options.TourSpot.PresetDetail.sizePresetToken;

					strncpy(p_res->Options.TourSpot.PresetDetail.PresetToken[idx], p_PresetToken->data, sizeof(p_res->Options.TourSpot.PresetDetail.PresetToken[idx])-1);

					p_res->Options.TourSpot.PresetDetail.sizePresetToken++;
					if (p_res->Options.TourSpot.PresetDetail.sizePresetToken >= 10)
					{
						break;
					}
					
					p_PresetToken = p_PresetToken->next;
				}

				p_Home = xml_node_soap_get(p_PresetDetail, "Home");
				if (p_Home && p_Home->data)
				{
					p_res->Options.TourSpot.PresetDetail.HomeFlag = 1;
					p_res->Options.TourSpot.PresetDetail.Home = parse_Bool(p_Home->data);
				}

				p_PanTiltPositionSpace = xml_node_soap_get(p_PresetDetail, "PanTiltPositionSpace");
				if (p_PanTiltPositionSpace)
				{
					p_res->Options.TourSpot.PresetDetail.PanTiltPositionSpaceFlag = 1;
					parse_Space2DDescription(p_PanTiltPositionSpace, &p_res->Options.TourSpot.PresetDetail.PanTiltPositionSpace);
				}

				p_ZoomPositionSpace = xml_node_soap_get(p_PresetDetail, "ZoomPositionSpace");
				if (p_ZoomPositionSpace)
				{
					p_res->Options.TourSpot.PresetDetail.ZoomPositionSpaceFlag = 1;
					parse_Space1DDescription(p_ZoomPositionSpace, &p_res->Options.TourSpot.PresetDetail.ZoomPositionSpace);
				}
			}

			p_StayTime = xml_node_soap_get(p_TourSpot, "StayTime");
			if (p_StayTime)
			{
				parse_DurationRange(p_StayTime, &p_res->Options.TourSpot.StayTime);
			}
		}		
	}

	return TRUE;
}

BOOL parse_CreatePresetTour(XMLN * p_node, CreatePresetTour_RES * p_res)
{
	XMLN * p_PresetTourToken;

	p_PresetTourToken = xml_node_soap_get(p_node, "PresetTourToken");
	if (p_PresetTourToken && p_PresetTourToken->data)
	{
		strncpy(p_res->PresetTourToken, p_PresetTourToken->data, sizeof(p_res->PresetTourToken)-1);
	}
	else
	{
		return FALSE;
	}

	return TRUE;
}


BOOL parse_VideoEncoder2Configuration(XMLN * p_node, onvif_VideoEncoder2Configuration * p_req)
{
    XMLN * p_Name;
	XMLN * p_UseCount;
	XMLN * p_Encoding;
	XMLN * p_Resolution;
	XMLN * p_Quality;
	XMLN * p_RateControl;
	const char * p_token;
    const char * p_GovLength;
    const char * p_Profile;

    p_token = xml_attr_get(p_node, "token");
    if (p_token)
    {
        strncpy(p_req->token, p_token, sizeof(p_req->token)-1);
    }

    p_GovLength = xml_attr_get(p_node, "GovLength");
    if (p_GovLength)
    {
        p_req->GovLengthFlag = 1;
        p_req->GovLength = atoi(p_GovLength);
    }

    p_Profile = xml_attr_get(p_node, "Profile");
    if (p_Profile)
    {
        p_req->ProfileFlag = 1;
        strncpy(p_req->Profile, p_Profile, sizeof(p_req->Profile)-1);
    }
    
    p_Name = xml_node_soap_get(p_node, "Name");
    if (p_Name && p_Name->data)
    {
        strncpy(p_req->Name, p_Name->data, sizeof(p_req->Name)-1);
    }

    p_UseCount = xml_node_soap_get(p_node, "UseCount");
    if (p_UseCount && p_UseCount->data)
    {
        p_req->UseCount = atoi(p_UseCount->data);
    }

    p_Encoding = xml_node_soap_get(p_node, "Encoding");
    if (p_Encoding && p_Encoding->data)
    {
		strncpy(p_req->Encoding, p_Encoding->data, sizeof(p_req->Encoding)-1);
    }

    p_Resolution = xml_node_soap_get(p_node, "Resolution");
    if (p_Resolution)
    {
        XMLN * p_Width;
		XMLN * p_Height;

		p_Width = xml_node_soap_get(p_Resolution, "Width");
	    if (p_Width && p_Width->data)
	    {
	        p_req->Resolution.Width = atoi(p_Width->data);
	    }

	    p_Height = xml_node_soap_get(p_Resolution, "Height");
	    if (p_Height && p_Height->data)
	    {
	        p_req->Resolution.Height = atoi(p_Height->data);
	    }
    }

    p_RateControl = xml_node_soap_get(p_node, "RateControl");
    if (p_RateControl)
    {
    	XMLN * p_FrameRateLimit;
		XMLN * p_BitrateLimit;
		
		p_req->RateControlFlag = 1;
    	
        p_FrameRateLimit = xml_node_soap_get(p_RateControl, "FrameRateLimit");
	    if (p_FrameRateLimit && p_FrameRateLimit->data)
	    {
	        p_req->RateControl.FrameRateLimit = (float)atof(p_FrameRateLimit->data);
	    }

	    p_BitrateLimit = xml_node_soap_get(p_RateControl, "BitrateLimit");
	    if (p_BitrateLimit && p_BitrateLimit->data)
	    {
	        p_req->RateControl.BitrateLimit = atoi(p_BitrateLimit->data);
	    }
    }

	if (ONVIF_OK == parse_MulticastConfiguration(p_node, &p_req->Multicast))
	{
	    p_req->MulticastFlag = 1;
	}
	
	p_Quality = xml_node_soap_get(p_node, "Quality");
    if (p_Quality && p_Quality->data)
    {
        p_req->Quality = (float)atof(p_Quality->data);
    }

    return TRUE;
}

BOOL parse_VideoEncoder2ConfigurationOptions(XMLN * p_node, onvif_VideoEncoder2ConfigurationOptions * p_res)
{
    int i = 0;
    XMLN * p_Encoding;
    XMLN * p_QualityRange;
    XMLN * p_ResolutionsAvailable;
    XMLN * p_BitrateRange;
    const char * p_GovLengthRange;
    const char * p_FrameRatesSupported;
    const char * p_ProfilesSupported;
    const char * p_ConstantBitRateSupported;

    p_GovLengthRange = xml_attr_get(p_node, "GovLengthRange");
    if (p_GovLengthRange)
    {
        p_res->GovLengthRangeFlag = 1;
        strncpy(p_res->GovLengthRange, p_GovLengthRange, sizeof(p_res->GovLengthRange)-1);
    }

    p_FrameRatesSupported = xml_attr_get(p_node, "FrameRatesSupported");
    if (p_FrameRatesSupported)
    {
        p_res->FrameRatesSupportedFlag = 1;
        strncpy(p_res->FrameRatesSupported, p_FrameRatesSupported, sizeof(p_res->FrameRatesSupported)-1);
    }

    p_ProfilesSupported = xml_attr_get(p_node, "ProfilesSupported");
    if (p_ProfilesSupported)
    {
        p_res->ProfilesSupportedFlag = 1;
        strncpy(p_res->ProfilesSupported, p_ProfilesSupported, sizeof(p_res->ProfilesSupported)-1);
    }

    p_ConstantBitRateSupported = xml_attr_get(p_node, "ConstantBitRateSupported");
    if (p_ConstantBitRateSupported)
    {
        p_res->ConstantBitRateSupportedFlag = 1;
        p_res->ConstantBitRateSupported = parse_Bool(p_ConstantBitRateSupported);
    }
    
    p_Encoding = xml_node_soap_get(p_node, "Encoding");
    if (p_Encoding && p_Encoding->data)
    {
        strncpy(p_res->Encoding, p_Encoding->data, sizeof(p_res->Encoding)-1);
    }
    else
    {
        return FALSE;
    }

    p_QualityRange = xml_node_soap_get(p_node, "QualityRange");
    if (p_QualityRange)
	{
		parse_FloatRange(p_QualityRange, &p_res->QualityRange);
	}
	else
    {
        return FALSE;
    }

    p_ResolutionsAvailable = xml_node_soap_get(p_node, "ResolutionsAvailable");
	while (p_ResolutionsAvailable && soap_strcmp(p_ResolutionsAvailable->name, "ResolutionsAvailable") == 0)
	{
		parse_VideoResolution(p_ResolutionsAvailable, &p_res->ResolutionsAvailable[i++]);

		if (i >= MAX_RES_NUMS)
		{
			break;
		}
		
		p_ResolutionsAvailable = p_ResolutionsAvailable->next;
	}

	p_BitrateRange = xml_node_soap_get(p_node, "BitrateRange");
    if (p_BitrateRange)
	{
		parse_IntRange(p_BitrateRange, &p_res->BitrateRange);
	}
	else
    {
        return FALSE;
    }

	return TRUE;
}

BOOL parse_tr2_GetVideoEncoderConfigurationOptions(XMLN * p_node, tr2_GetVideoEncoderConfigurationOptions_RES * p_res)
{
    BOOL ret = TRUE;
    XMLN * p_Options;

    p_Options = xml_node_soap_get(p_node, "Options");
    while (p_Options && soap_strcmp(p_Options->name, "Options") == 0)
    {
        ONVIF_VideoEncoder2ConfigurationOptions * p_option = onvif_add_VideoEncoder2ConfigurationOptions(&p_res->Options);
        if (p_option)
        {
            if (parse_VideoEncoder2ConfigurationOptions(p_Options, &p_option->Options) == FALSE)
            {
                ret = FALSE;
                onvif_free_VideoEncoder2ConfigurationOptions(&p_res->Options);
                break;
            }
        }
        
        p_Options = p_Options->next;
    }
    
    return ret;
}

BOOL parse_tr2_CreateProfile(XMLN * p_node, tr2_CreateProfile_RES * p_res)
{
	XMLN * p_Token;

	p_Token = xml_node_soap_get(p_node, "Token");
	if (p_Token && p_Token->data)
	{
		strncpy(p_res->Token, p_Token->data, sizeof(p_res->Token)-1);
	}

	return TRUE;
}

BOOL parse_tr2_GetStreamUri(XMLN * p_node, tr2_GetStreamUri_RES * p_res)
{
	XMLN * p_Uri;

	p_Uri = xml_node_soap_get(p_node, "Uri");
	if (p_Uri && p_Uri->data)
	{
		strncpy(p_res->Uri, p_Uri->data, sizeof(p_res->Uri)-1);
	}

	return TRUE;
}

BOOL parse_MetadataConfiguration(XMLN * p_node, onvif_MetadataConfiguration * p_req)
{
	XMLN * p_Name;
	XMLN * p_PTZStatus;
	XMLN * p_Analytics;
	XMLN * p_SessionTimeout;
	const char * token;
	
	token = xml_attr_get(p_node, "token");
	if (token)
	{
		strncpy(p_req->token, token, sizeof(p_req->token)-1);
	}

	p_Name = xml_node_soap_get(p_node, "Name");
	if (p_Name && p_Name->data)
	{
		strncpy(p_req->Name, p_Name->data, sizeof(p_req->Name)-1);
	}

	p_PTZStatus = xml_node_soap_get(p_node, "PTZStatus");
	if (p_PTZStatus)
	{
		XMLN * p_Status;
		XMLN * p_Position;

		p_req->PTZStatusFlag = 1;
		
		p_Status = xml_node_soap_get(p_PTZStatus, "Status");
		if (p_Status && p_Status->data)
		{
			p_req->PTZStatus.Status = parse_Bool(p_Status->data);
		}

		p_Position = xml_node_soap_get(p_PTZStatus, "Position");
		if (p_Position && p_Position->data)
		{
			p_req->PTZStatus.Position = parse_Bool(p_Position->data);
		}
	}

	p_Analytics = xml_node_soap_get(p_node, "Analytics");
	if (p_Analytics && p_Analytics->data)
	{
		p_req->AnalyticsFlag = 1;
		p_req->Analytics = parse_Bool(p_Analytics->data);
	}

	parse_MulticastConfiguration(p_node, &p_req->Multicast);

	p_SessionTimeout = xml_node_soap_get(p_node, "SessionTimeout");
	if (p_SessionTimeout && p_SessionTimeout->data)
	{
		parse_XSDDuration(p_SessionTimeout->data, &p_req->SessionTimeout);
	}
	
	return TRUE;
}

BOOL parse_AudioEncoder2Configuration(XMLN * p_node, onvif_AudioEncoder2Configuration * p_req)
{
    XMLN * p_Name;
	XMLN * p_UseCount;
	XMLN * p_Encoding;
	XMLN * p_Bitrate;
	XMLN * p_SampleRate;
	const char * p_token;

    p_token = xml_attr_get(p_node, "token");
    if (p_token)
    {
        strncpy(p_req->token, p_token, sizeof(p_req->token)-1);
    }
    
    p_Name = xml_node_soap_get(p_node, "Name");
    if (p_Name && p_Name->data)
    {
        strncpy(p_req->Name, p_Name->data, sizeof(p_req->Name)-1);
    }

    p_UseCount = xml_node_soap_get(p_node, "UseCount");
    if (p_UseCount && p_UseCount->data)
    {
        p_req->UseCount = atoi(p_UseCount->data);
    }

    p_Encoding = xml_node_soap_get(p_node, "Encoding");
    if (p_Encoding && p_Encoding->data)
    {
		strncpy(p_req->Encoding, p_Encoding->data, sizeof(p_req->Encoding)-1);
    }

	if (ONVIF_OK == parse_MulticastConfiguration(p_node, &p_req->Multicast))
	{
	    p_req->MulticastFlag = 1;
	}
	
	p_Bitrate = xml_node_soap_get(p_node, "Bitrate");
    if (p_Bitrate && p_Bitrate->data)
    {
        p_req->Bitrate = atoi(p_Bitrate->data);
    }

    p_SampleRate = xml_node_soap_get(p_node, "SampleRate");
    if (p_SampleRate && p_SampleRate->data)
    {
        p_req->SampleRate = atoi(p_SampleRate->data);
    }

    return TRUE;
}

BOOL parse_AudioEncoder2ConfigurationOptions(XMLN * p_node, onvif_AudioEncoder2ConfigurationOptions * p_req)
{
	XMLN * p_Encoding;
	XMLN * p_BitrateList;
	XMLN * p_SampleRateList;

	p_Encoding = xml_node_soap_get(p_node, "Encoding");
    if (p_Encoding && p_Encoding->data)
    {
		strncpy(p_req->Encoding, p_Encoding->data, sizeof(p_req->Encoding)-1);
    }

    p_BitrateList = xml_node_soap_get(p_node, "BitrateList");
    if (p_BitrateList)
    {
    	parse_IntList(p_BitrateList, &p_req->BitrateList);
    }

	p_SampleRateList = xml_node_soap_get(p_node, "SampleRateList");
    if (p_SampleRateList)
    {
    	parse_IntList(p_SampleRateList, &p_req->SampleRateList);
    }

    return TRUE;
}

BOOL parse_tr2_GetAudioEncoderConfigurationOptions(XMLN * p_node, tr2_GetAudioEncoderConfigurationOptions_RES * p_res)
{
	BOOL ret = TRUE;
    XMLN * p_Options;

    p_Options = xml_node_soap_get(p_node, "Options");
    while (p_Options && soap_strcmp(p_Options->name, "Options") == 0)
    {
        ONVIF_AudioEncoder2ConfigurationOptions * p_option = onvif_add_AudioEncoder2ConfigurationOptions(&p_res->Options);
        if (p_option)
        {
            if (parse_AudioEncoder2ConfigurationOptions(p_Options, &p_option->Options) == FALSE)
            {
                ret = FALSE;
                onvif_free_AudioEncoder2ConfigurationOptions(&p_res->Options);
                break;
            }
        }
        
        p_Options = p_Options->next;
    }
    
    return ret;
}

BOOL parse_tr2_GetVideoEncoderInstances(XMLN * p_node, tr2_GetVideoEncoderInstances_RES * p_res)
{
	XMLN * p_Info;
	XMLN * p_Codec;
	XMLN * p_Total;

	p_Info = xml_node_soap_get(p_node, "Info");
	if (p_Info)
	{
		p_Codec = xml_node_soap_get(p_Info, "Codec");
		while (p_Codec && soap_strcmp(p_Codec->name, "Codec") == 0)
		{
			int idx = p_res->Info.sizeCodec;
			XMLN * p_Encoding;
			XMLN * p_Number;

			p_Encoding = xml_node_soap_get(p_Codec, "Encoding");
			if (p_Encoding && p_Encoding->data)
			{
				strncpy(p_res->Info.Codec[idx].Encoding, p_Encoding->data, sizeof(p_res->Info.Codec[idx].Encoding)-1);
			}

			p_Number = xml_node_soap_get(p_Codec, "Number");
			if (p_Number && p_Number->data)
			{
				p_res->Info.Codec[idx].Number = atoi(p_Number->data);
			}
			
			p_res->Info.sizeCodec++;
			if (p_res->Info.sizeCodec >= 10)
			{
				break;
			}
		}

		p_Total = xml_node_soap_get(p_Info, "Total");
		if (p_Total && p_Total->data)
		{
			p_res->Info.Total = atoi(p_Total->data);
		}
	}

	return TRUE;	
}

BOOL parse_MediaProfile(XMLN * p_node, onvif_MediaProfile * p_req)
{
	XMLN * p_Name;
    XMLN * p_Configurations;

    p_Name = xml_node_soap_get(p_node, "Name");
	if (p_Name && p_Name->data)
	{
		strncpy(p_req->Name, p_Name->data, sizeof(p_req->Name)-1);
	}

	p_Configurations = xml_node_soap_get(p_node, "Configurations");
	if (p_Configurations)
	{
		XMLN * p_VideoSource;
		XMLN * p_AudioSource;
		XMLN * p_VideoEncoder;
		XMLN * p_AudioEncoder;
		XMLN * p_Analytics;
		XMLN * p_PTZ;
		XMLN * p_Metadata;
		//XMLN * p_AudioOutput;
		//XMLN * p_AudioDecoder;

		p_VideoSource = xml_node_soap_get(p_Configurations, "VideoSource");
	    if (p_VideoSource)
	    {
        	const char * p_token;
			
            p_req->Configurations.VideoSourceFlag = 1;

            p_token = xml_attr_get(p_VideoSource, "token");
            if (p_token)
            {
            	strncpy(p_req->Configurations.VideoSource.token, p_token, sizeof(p_req->Configurations.VideoSource.token)-1);
            }	

            if (!parse_VideoSourceConfiguration(p_VideoSource, &p_req->Configurations.VideoSource))
            {
            	return FALSE;
            }
	    }

		p_AudioSource = xml_node_soap_get(p_Configurations, "AudioSource");
	    if (p_AudioSource)
	    {
        	const char * p_token;
			
            p_req->Configurations.AudioSourceFlag = 1;

            p_token = xml_attr_get(p_AudioSource, "token");  
            if (p_token)
            {
            	strncpy(p_req->Configurations.AudioSource.token, p_token, sizeof(p_req->Configurations.AudioSource.token)-1);
            }	

            if (!parse_AudioSourceConfiguration(p_AudioSource, &p_req->Configurations.AudioSource))
            {
            	return FALSE;
            }
	    }
	    
	    p_VideoEncoder = xml_node_soap_get(p_Configurations, "VideoEncoder");
	    if (p_VideoEncoder)
	    {
        	const char * p_token;
			
            p_req->Configurations.VideoEncoderFlag = 1;

            p_token = xml_attr_get(p_VideoEncoder, "token");
            if (p_token)
            {
            	strncpy(p_req->Configurations.VideoEncoder.token, p_token, sizeof(p_req->Configurations.VideoEncoder.token)-1);
            }	

            if (!parse_VideoEncoder2Configuration(p_VideoEncoder, &p_req->Configurations.VideoEncoder))
            {
                return FALSE;           
            }
	    }

		p_AudioEncoder = xml_node_soap_get(p_Configurations, "AudioEncoder");
	    if (p_AudioEncoder)
	    {
        	const char * p_token;
			
            p_req->Configurations.AudioEncoderFlag = 1;

            p_token = xml_attr_get(p_AudioEncoder, "token");
            if (p_token)
            {
            	strncpy(p_req->Configurations.AudioEncoder.token, p_token, sizeof(p_req->Configurations.AudioEncoder.token)-1);
            }	

            if (!parse_AudioEncoder2Configuration(p_AudioEncoder, &p_req->Configurations.AudioEncoder))
            {
                return FALSE;           
            }
	    }

		p_Analytics = xml_node_soap_get(p_Configurations, "Analytics");
	    if (p_Analytics)
	    {
	    	const char * p_token;
	    	XMLN * p_Name;
	    	XMLN * p_UseCount;
	    	
	    	p_req->Configurations.AnalyticsFlag = 1;

            p_token = xml_attr_get(p_Analytics, "token");
            if (p_token)
            {
            	strncpy(p_req->Configurations.Analytics.token, p_token, sizeof(p_req->Configurations.Analytics.token)-1);
            }
            
			p_Name = xml_node_soap_get(p_Analytics, "Name");
			if (p_Name && p_Name->data)
			{
				strncpy(p_req->Configurations.Analytics.Name, p_Name->data, sizeof(p_req->Configurations.Analytics.Name)-1);
			}

			p_UseCount = xml_node_soap_get(p_Analytics, "UseCount");
			if (p_UseCount && p_UseCount->data)
			{
				p_req->Configurations.Analytics.UseCount = atoi(p_UseCount->data);
			}
	    }
	    
	    p_PTZ = xml_node_soap_get(p_Configurations, "PTZ");
	    if (p_PTZ)
	    {
        	const char * p_token;
			
            p_req->Configurations.PTZFlag = 1;

            p_token = xml_attr_get(p_PTZ, "token");	
            if (p_token)
            {
            	strncpy(p_req->Configurations.PTZ.token, p_token, sizeof(p_req->Configurations.PTZ.token)-1);
            }	

            if (!parse_PTZConfiguration(p_PTZ, &p_req->Configurations.PTZ))
            {
                return FALSE;           
            }
	    }   

		p_Metadata = xml_node_soap_get(p_Configurations, "Metadata");
	    if (p_Metadata)
	    {
        	const char * p_token;
			
            p_req->Configurations.MetadataFlag = 1;

            p_token = xml_attr_get(p_Metadata, "token");	
            if (p_token)
            {
            	strncpy(p_req->Configurations.Metadata.token, p_token, sizeof(p_req->Configurations.Metadata.token)-1);
            }	

            if (!parse_MetadataConfiguration(p_Metadata, &p_req->Configurations.Metadata))
            {
                return FALSE;           
            }
	    }   
		
	}
    
	return TRUE;
}

#ifdef PROFILE_G_SUPPORT

BOOL parse_RecordingService(XMLN * p_node, onvif_RecordingCapabilities * p_cap)
{
	XMLN * p_XAddr;
	XMLN * p_tds_Capabilities;
	XMLN * p_Version;
	
    p_XAddr = xml_node_soap_get(p_node, "XAddr");
    if (p_XAddr && p_XAddr->data)
    {
        parse_XAddr(p_XAddr->data, &p_cap->XAddr);
    }
    else
    {
        return FALSE;
    }

    p_tds_Capabilities = xml_node_soap_get(p_node, "Capabilities");
    if (p_tds_Capabilities)
    {
        XMLN * p_Capabilities = xml_node_soap_get(p_tds_Capabilities, "Capabilities");
        if (p_Capabilities)
        {
            const char * p_DynamicRecordings;
			const char * p_DynamicTracks;
			const char * p_Encoding;
			const char * p_MaxRate;
			const char * p_MaxTotalRate;
			const char * p_MaxRecordings;
			const char * p_MaxRecordingJobs;
			const char * p_Options;
			const char * p_MetadataRecording;

			p_DynamicRecordings = xml_attr_get(p_Capabilities, "DynamicRecordings");
            if (p_DynamicRecordings)
            {
                p_cap->DynamicRecordings = parse_Bool(p_DynamicRecordings);
            }

            p_DynamicTracks = xml_attr_get(p_Capabilities, "DynamicTracks");
            if (p_DynamicTracks)
            {
                p_cap->DynamicTracks = parse_Bool(p_DynamicTracks);
            }

            p_Encoding = xml_attr_get(p_Capabilities, "Encoding");
            if (p_Encoding)
            {
                parse_EncodingList(p_Encoding, p_cap);
            }

            p_MaxRate = xml_attr_get(p_Capabilities, "MaxRate");
            if (p_MaxRate)
            {
                p_cap->MaxRate = (float)atof(p_MaxRate);
            }

            p_MaxTotalRate = xml_attr_get(p_Capabilities, "MaxTotalRate");
            if (p_MaxTotalRate)
            {
                p_cap->MaxTotalRate = (float)atof(p_MaxTotalRate);
            }

            p_MaxRecordings = xml_attr_get(p_Capabilities, "MaxRecordings");
            if (p_MaxRecordings)
            {
                p_cap->MaxRecordings = atoi(p_MaxRecordings);
            }

            p_MaxRecordingJobs = xml_attr_get(p_Capabilities, "MaxRecordingJobs");
            if (p_MaxRecordingJobs)
            {
                p_cap->MaxRecordingJobs = atoi(p_MaxRecordingJobs);
            }

            p_Options = xml_attr_get(p_Capabilities, "Options");
            if (p_Options)
            {
                p_cap->Options = parse_Bool(p_Options);
            }

            p_MetadataRecording = xml_attr_get(p_Capabilities, "MetadataRecording");
            if (p_MetadataRecording)
            {
                p_cap->MetadataRecording = parse_Bool(p_MetadataRecording);
            }
        }
    }

    p_Version = xml_node_soap_get(p_node, "Version");
    if (p_Version)
    {
		parse_Version(p_Version, &p_cap->Version);
    }
    
    return TRUE;
}

BOOL parse_SearchService(XMLN * p_node, onvif_SearchCapabilities * p_cap)
{	
	XMLN * p_XAddr;
	XMLN * p_tds_Capabilities;
	XMLN * p_Version;
	
    p_XAddr = xml_node_soap_get(p_node, "XAddr");
    if (p_XAddr && p_XAddr->data)
    {
        parse_XAddr(p_XAddr->data, &p_cap->XAddr);
    }
    else
    {
        return FALSE;
    }

    p_tds_Capabilities = xml_node_soap_get(p_node, "Capabilities");
    if (p_tds_Capabilities)
    {
        XMLN * p_Capabilities = xml_node_soap_get(p_tds_Capabilities, "Capabilities");
        if (p_Capabilities)
        {
            const char * p_MetadataSearch;
			const char * p_GeneralStartEvents;

			p_MetadataSearch = xml_attr_get(p_Capabilities, "MetadataSearch");
            if (p_MetadataSearch)
            {
                p_cap->MetadataSearch = parse_Bool(p_MetadataSearch);
            }

            p_GeneralStartEvents = xml_attr_get(p_Capabilities, "GeneralStartEvents");
            if (p_GeneralStartEvents)
            {
                p_cap->GeneralStartEvents = parse_Bool(p_GeneralStartEvents);
            }
        }
    }   

    p_Version = xml_node_soap_get(p_node, "Version");
    if (p_Version)
    {
		parse_Version(p_Version, &p_cap->Version);
    }
    
    return TRUE;
}

BOOL parse_ReplayService(XMLN * p_node, onvif_ReplayCapabilities * p_cap)
{
	XMLN * p_XAddr;
	XMLN * p_tds_Capabilities;
	XMLN * p_Version;
	
    p_XAddr = xml_node_soap_get(p_node, "XAddr");
    if (p_XAddr && p_XAddr->data)
    {
        parse_XAddr(p_XAddr->data, &p_cap->XAddr);
    }
    else
    {
        return FALSE;
    }

    p_tds_Capabilities = xml_node_soap_get(p_node, "Capabilities");
    if (p_tds_Capabilities)
    {
        XMLN * p_Capabilities = xml_node_soap_get(p_tds_Capabilities, "Capabilities");
        if (p_Capabilities)
        {
            const char * p_ReversePlayback;
			const char * p_SessionTimeoutRange;
			const char * p_RTP_RTSP_TCP;

			p_ReversePlayback = xml_attr_get(p_Capabilities, "ReversePlayback");
            if (p_ReversePlayback)
            {
                p_cap->ReversePlayback = parse_Bool(p_ReversePlayback);
            }

            p_SessionTimeoutRange = xml_attr_get(p_Capabilities, "SessionTimeoutRange");
            if (p_SessionTimeoutRange)
            {
                parse_FloatRangeList(p_SessionTimeoutRange, &p_cap->SessionTimeoutRange);
            }

            p_RTP_RTSP_TCP = xml_attr_get(p_Capabilities, "RTP_RTSP_TCP");
            if (p_RTP_RTSP_TCP)
            {
                p_cap->RTP_RTSP_TCP = parse_Bool(p_RTP_RTSP_TCP);
            }
        }
    }   

    p_Version = xml_node_soap_get(p_node, "Version");
    if (p_Version)
    {
		parse_Version(p_Version, &p_cap->Version);
    }
    
    return TRUE;
}

BOOL parse_CreateRecording(XMLN * p_node, CreateRecording_RES * p_res)
{
    XMLN * p_RecordingToken;
    
    p_RecordingToken = xml_node_soap_get(p_node, "RecordingToken");
    if (p_RecordingToken && p_RecordingToken->data)
    {
        strncpy(p_res->RecordingToken, p_RecordingToken->data, sizeof(p_res->RecordingToken)-1);
    }
    
    return TRUE;
}

BOOL parse_RecordingConfiguration(XMLN * p_node, onvif_RecordingConfiguration * p_req)
{
	XMLN * p_Source;
	XMLN * p_Content;
	XMLN * p_MaximumRetentionTime;

	p_Source = xml_node_soap_get(p_node, "Source");
	if (p_Source)
	{
		XMLN * p_SourceId;
		XMLN * p_Name;
		XMLN * p_Location;
		XMLN * p_Description;
		XMLN * p_Address;

		p_SourceId = xml_node_soap_get(p_Source, "SourceId");
		if (p_SourceId && p_SourceId->data)
		{
			strncpy(p_req->Source.SourceId, p_SourceId->data, sizeof(p_req->Source.SourceId)-1);
		}

		p_Name = xml_node_soap_get(p_Source, "Name");
		if (p_Name && p_Name->data)
		{
			strncpy(p_req->Source.Name, p_Name->data, sizeof(p_req->Source.Name)-1);
		}

		p_Location = xml_node_soap_get(p_Source, "Location");
		if (p_Location && p_Location->data)
		{
			strncpy(p_req->Source.Location, p_Location->data, sizeof(p_req->Source.Location)-1);
		}

		p_Description = xml_node_soap_get(p_Source, "Description");
		if (p_Description && p_Description->data)
		{
			strncpy(p_req->Source.Description, p_Description->data, sizeof(p_req->Source.Description)-1);
		}

		p_Address = xml_node_soap_get(p_Source, "Address");
		if (p_Address && p_Address->data)
		{
			strncpy(p_req->Source.Address, p_Address->data, sizeof(p_req->Source.Address)-1);
		}
	}

	p_Content = xml_node_soap_get(p_node, "Content");
	if (p_Content && p_Content->data)
	{
		strncpy(p_req->Content, p_Content->data, sizeof(p_req->Content)-1);
	}

	p_MaximumRetentionTime = xml_node_soap_get(p_node, "MaximumRetentionTime");
	if (p_MaximumRetentionTime && p_MaximumRetentionTime->data)
	{
		p_req->MaximumRetentionTimeFlag = parse_XSDDuration(p_MaximumRetentionTime->data, (int *)&p_req->MaximumRetentionTime);
	}

	return TRUE;
}

BOOL parse_TrackConfiguration(XMLN * p_node, onvif_TrackConfiguration * p_req)
{
	XMLN * p_TrackType;
	XMLN * p_Description;

	p_TrackType = xml_node_soap_get(p_node, "TrackType");
	if (p_TrackType && p_TrackType->data)
	{
		p_req->TrackType = onvif_StringToTrackType(p_TrackType->data);		
	}

	p_Description = xml_node_soap_get(p_node, "Description");
	if (p_Description && p_Description->data)
	{
		strncpy(p_req->Description, p_Description->data, sizeof(p_req->Description)-1);
	}

	return TRUE;
}

BOOL parse_RecordingItem(XMLN * p_node, onvif_Recording * p_res)
{
    XMLN * p_RecordingToken;
    XMLN * p_Configuration;
    XMLN * p_Tracks;

    p_RecordingToken = xml_node_soap_get(p_node, "RecordingToken");
	if (p_RecordingToken && p_RecordingToken->data)
	{
	    strncpy(p_res->RecordingToken, p_RecordingToken->data, sizeof(p_res->RecordingToken)-1);
	}

	p_Configuration = xml_node_soap_get(p_node, "Configuration");
	if (p_Configuration)
	{
	    parse_RecordingConfiguration(p_Configuration, &p_res->Configuration);
	}

	p_Tracks = xml_node_soap_get(p_node, "Tracks");
	if (p_Tracks)
	{
	    XMLN * p_Track;

	    p_Track = xml_node_soap_get(p_Tracks, "Track");
	    while (p_Track && soap_strcmp(p_Track->name, "Track") == 0)
	    {
	        ONVIF_Track * p_item = onvif_add_Track(&p_res->Tracks);
	        if (p_item)
	        {
	            XMLN * p_TrackToken;
	            XMLN * p_Configuration;
	            
	            p_TrackToken = xml_node_soap_get(p_Track, "TrackToken");
	            if (p_TrackToken && p_TrackToken->data)
	            {
	                strncpy(p_item->Track.TrackToken, p_TrackToken->data, sizeof(p_item->Track.TrackToken)-1);
	            }

	            p_Configuration = xml_node_soap_get(p_Track, "Configuration");
	            if (p_Configuration)
	            {
	                parse_TrackConfiguration(p_Configuration, &p_item->Track.Configuration);
	            }
	        }

	        p_Track = p_Track->next;
	    }	    
	}

	return TRUE;
}

BOOL parse_GetRecordings(XMLN * p_node, GetRecordings_RES * p_res)
{
    XMLN * p_RecordingItem;

    p_RecordingItem = xml_node_soap_get(p_node, "RecordingItem");
	while (p_RecordingItem && soap_strcmp(p_RecordingItem->name, "RecordingItem") == 0)
	{
	    ONVIF_Recording * p_Recording = onvif_add_Recording(&p_res->Recordings);
	    if (p_Recording)
	    {
	        parse_RecordingItem(p_RecordingItem, &p_Recording->Recording);
	    }
	    
	    p_RecordingItem = p_RecordingItem->next;
	}
	
    return TRUE;
}
   
BOOL parse_GetRecordingConfiguration(XMLN * p_node, GetRecordingConfiguration_RES * p_res)
{
    XMLN * p_RecordingConfiguration;
    
    p_RecordingConfiguration = xml_node_soap_get(p_node, "RecordingConfiguration");
	if (p_RecordingConfiguration)
	{
	    parse_RecordingConfiguration(p_RecordingConfiguration, &p_res->RecordingConfiguration);
	}
    
    return TRUE;
}
 
BOOL parse_GetRecordingOptions(XMLN * p_node, GetRecordingOptions_RES * p_res)
{
    XMLN * p_Options;

    p_Options = xml_node_soap_get(p_node, "Options");
	if (p_Options)
	{
	    XMLN * p_Job;
	    XMLN * p_Track;
	    
	    p_Job = xml_node_soap_get(p_Options, "Job");
    	if (p_Job)
    	{
    	    const char * p_Spare;
    	    const char * p_CompatibleSources;

    	    p_Spare = xml_attr_get(p_Job, "Spare");
    	    if (p_Spare)
    	    {
    	        p_res->Options.Job.SpareFlag = 1;
    	        p_res->Options.Job.Spare = atoi(p_Spare);
    	    }

    	    p_CompatibleSources = xml_attr_get(p_Job, "CompatibleSources");
    	    if (p_CompatibleSources)
    	    {
    	        p_res->Options.Job.CompatibleSourcesFlag = 1;
    	        strncpy(p_res->Options.Job.CompatibleSources, p_CompatibleSources, sizeof(p_res->Options.Job.CompatibleSources)-1);
    	    }
    	}
    	
	    p_Track = xml_node_soap_get(p_Options, "Track");
    	if (p_Track)
    	{
    	    const char * p_SpareTotal;
    	    const char * p_SpareVideo;
    	    const char * p_SpareAudio;
    	    const char * p_SpareMetadata;

    	    p_SpareTotal = xml_attr_get(p_Track, "SpareTotal");
    	    if (p_SpareTotal)
    	    {
    	        p_res->Options.Track.SpareTotalFlag = 1;
    	        p_res->Options.Track.SpareTotal = atoi(p_SpareTotal);
    	    }

    	    p_SpareVideo = xml_attr_get(p_Track, "SpareVideo");
    	    if (p_SpareVideo)
    	    {
    	        p_res->Options.Track.SpareVideoFlag = 1;
    	        p_res->Options.Track.SpareVideo = atoi(p_SpareVideo);
    	    }

    	    p_SpareAudio = xml_attr_get(p_Track, "SpareAudio");
    	    if (p_SpareAudio)
    	    {
    	        p_res->Options.Track.SpareAudioFlag = 1;
    	        p_res->Options.Track.SpareAudio = atoi(p_SpareAudio);
    	    }

    	    p_SpareMetadata = xml_attr_get(p_Track, "SpareMetadata");
    	    if (p_SpareMetadata)
    	    {
    	        p_res->Options.Track.SpareMetadataFlag = 1;
    	        p_res->Options.Track.SpareMetadata = atoi(p_SpareMetadata);
    	    }
    	}	    
	}
    
    return TRUE;
}
 
BOOL parse_CreateTrack(XMLN * p_node, CreateTrack_RES * p_res)
{
    XMLN * p_TrackToken;
    
    p_TrackToken = xml_node_soap_get(p_node, "TrackToken");
    if (p_TrackToken && p_TrackToken->data)
    {
        strncpy(p_res->TrackToken, p_TrackToken->data, sizeof(p_res->TrackToken)-1);
    }
    
    return TRUE;
}

BOOL parse_GetTrackConfiguration(XMLN * p_node, GetTrackConfiguration_RES * p_res)
{
    XMLN * p_TrackConfiguration;

    p_TrackConfiguration = xml_node_soap_get(p_node, "TrackConfiguration");
    if (p_TrackConfiguration)
    {
        parse_TrackConfiguration(p_TrackConfiguration, &p_res->TrackConfiguration);
    }
    
    return TRUE;
}

BOOL parse_RecordingJobConfiguration(XMLN * p_node, onvif_RecordingJobConfiguration * p_req)
{
	XMLN * p_RecordingToken;
	XMLN * p_Mode;
	XMLN * p_Priority;
	XMLN * p_Source;

	p_RecordingToken = xml_node_soap_get(p_node, "RecordingToken");
	if (p_RecordingToken && p_RecordingToken->data)
	{
		strncpy(p_req->RecordingToken, p_RecordingToken->data, sizeof(p_req->RecordingToken)-1);
	}

	p_Mode = xml_node_soap_get(p_node, "Mode");
	if (p_Mode && p_Mode->data)
	{
		strncpy(p_req->Mode, p_Mode->data, sizeof(p_req->Mode)-1);
	}

	p_Priority = xml_node_soap_get(p_node, "Priority");
	if (p_Priority && p_Priority->data)
	{
		p_req->Priority = atoi(p_Priority->data);
	}

	p_Source = xml_node_soap_get(p_node, "Source");
	while (p_Source && soap_strcmp(p_Source->name, "Source") == 0)
	{
		int i = p_req->sizeSource;
		XMLN * p_SourceToken;
		XMLN * p_AutoCreateReceiver;
		XMLN * p_Tracks;

		p_SourceToken = xml_node_soap_get(p_Source, "SourceToken");
		if (p_SourceToken)
		{
			const char * p_Type;
			XMLN * p_Token;

			p_req->Source[i].SourceTokenFlag = 1;
			
			p_Type = xml_attr_get(p_SourceToken, "Type");
			if (p_Type)
			{
				p_req->Source[i].SourceToken.TypeFlag = 1;
				strncpy(p_req->Source[i].SourceToken.Type, p_Type, sizeof(p_req->Source[i].SourceToken.Type)-1);
			}

			p_Token = xml_node_soap_get(p_SourceToken, "Token");
			if (p_Token && p_Token->data)
			{
				strncpy(p_req->Source[i].SourceToken.Token, p_Token->data, sizeof(p_req->Source[i].SourceToken.Token)-1);
			}
		}

		p_AutoCreateReceiver = xml_node_soap_get(p_Source, "AutoCreateReceiver");
		if (p_AutoCreateReceiver && p_AutoCreateReceiver->data)
		{
			p_req->Source[i].AutoCreateReceiverFlag = 1;
			p_req->Source[i].AutoCreateReceiver = parse_Bool(p_AutoCreateReceiver->data);
		}

		p_Tracks = xml_node_soap_get(p_Source, "Tracks");
		while (p_Tracks && soap_strcmp(p_Tracks->name, "Tracks") == 0)
		{
			int j = p_req->Source[i].sizeTracks;
			XMLN * p_SourceTag;
			XMLN * p_Destination;

			p_SourceTag = xml_node_soap_get(p_Tracks, "SourceTag");
			if (p_SourceTag && p_SourceTag->data)
			{
				strncpy(p_req->Source[i].Tracks[j].SourceTag, p_SourceTag->data, sizeof(p_req->Source[i].Tracks[j].SourceTag)-1);
			}

			p_Destination = xml_node_soap_get(p_Tracks, "Destination");
			if (p_Destination && p_Destination->data)
			{
				strncpy(p_req->Source[i].Tracks[j].Destination, p_Destination->data, sizeof(p_req->Source[i].Tracks[j].Destination)-1);
			}
			
			p_Tracks = p_Tracks->next;

			p_req->Source[i].sizeTracks++;
			if (p_req->Source[i].sizeTracks >= 5)
			{
				break;
			}
		}
		
		p_Source = p_Source->next;

		p_req->sizeSource++;
		if (p_req->sizeSource >= 5)
		{
			break;
		}
	}

	return TRUE;
} 

BOOL parse_CreateRecordingJob(XMLN * p_node, CreateRecordingJob_RES * p_res)
{
    XMLN * p_JobToken;
    XMLN * p_JobConfiguration;

    p_JobToken = xml_node_soap_get(p_node, "JobToken");
    if (p_JobToken && p_JobToken->data)
    {
        strncpy(p_res->JobToken, p_JobToken->data, sizeof(p_res->JobToken)-1);
    }
    
    p_JobConfiguration = xml_node_soap_get(p_node, "JobConfiguration");
    if (p_JobConfiguration)
    {
        parse_RecordingJobConfiguration(p_JobConfiguration, &p_res->JobConfiguration);
    }
    
    return TRUE;
}

BOOL parse_RecordingJobItem(XMLN * p_node, onvif_RecordingJob * p_res)
{
    XMLN * p_JobToken;
    XMLN * p_JobConfiguration;

    p_JobToken = xml_node_soap_get(p_node, "JobToken");
    if (p_JobToken && p_JobToken->data)
    {
        strncpy(p_res->JobToken, p_JobToken->data, sizeof(p_res->JobToken)-1);
    }

    p_JobConfiguration = xml_node_soap_get(p_node, "JobConfiguration");
    if (p_JobConfiguration)
    {
        parse_RecordingJobConfiguration(p_JobConfiguration, &p_res->JobConfiguration);
    }

    return TRUE;
}

BOOL parse_GetRecordingJobs(XMLN * p_node, GetRecordingJobs_RES * p_res)
{
    XMLN * p_JobItem;

    p_JobItem = xml_node_soap_get(p_node, "JobItem");
	while (p_JobItem && soap_strcmp(p_JobItem->name, "JobItem") == 0)
	{
	    ONVIF_RecordingJob * p_RecordingJob = onvif_add_RecordingJob(&p_res->RecordingJobs);
	    if (p_RecordingJob)
	    {
	        parse_RecordingJobItem(p_JobItem, &p_RecordingJob->RecordingJob);
	    }
	    
	    p_JobItem = p_JobItem->next;
	}
	
    return TRUE;
}
 
BOOL parse_SetRecordingJobConfiguration(XMLN * p_node, SetRecordingJobConfiguration_RES * p_res)
{
    XMLN * p_JobConfiguration;
    
    p_JobConfiguration = xml_node_soap_get(p_node, "JobConfiguration");
    if (p_JobConfiguration)
    {
        parse_RecordingJobConfiguration(p_JobConfiguration, &p_res->JobConfiguration);
    }
    
    return TRUE;
}
 
BOOL parse_GetRecordingJobConfiguration(XMLN * p_node, GetRecordingJobConfiguration_RES * p_res)
{
    XMLN * p_JobConfiguration;
    
    p_JobConfiguration = xml_node_soap_get(p_node, "JobConfiguration");
    if (p_JobConfiguration)
    {
        parse_RecordingJobConfiguration(p_JobConfiguration, &p_res->JobConfiguration);
    }
    
    return TRUE;
}

BOOL parse_RecordingJobStateTrack(XMLN * p_node, onvif_RecordingJobStateTrack * p_req)
{
    XMLN * p_SourceTag;
    XMLN * p_Destination;
    XMLN * p_Error;
    XMLN * p_State;

    p_SourceTag = xml_node_soap_get(p_node, "SourceTag");
    if (p_SourceTag && p_SourceTag->data)
    {
        strncpy(p_req->SourceTag, p_SourceTag->data, sizeof(p_req->SourceTag)-1);
    }

    p_Destination = xml_node_soap_get(p_node, "Destination");
    if (p_Destination && p_Destination->data)
    {
        strncpy(p_req->Destination, p_Destination->data, sizeof(p_req->Destination)-1);
    }

    p_Error = xml_node_soap_get(p_node, "Error");
    if (p_Error && p_Error->data)
    {
        strncpy(p_req->Error, p_Error->data, sizeof(p_req->Error)-1);
    }

    p_State = xml_node_soap_get(p_node, "State");
    if (p_State && p_State->data)
    {
        strncpy(p_req->State, p_State->data, sizeof(p_req->State)-1);
    }

    return TRUE;
}

BOOL parse_RecordingJobStateSource(XMLN * p_node, onvif_RecordingJobStateSource * p_req)
{
    XMLN * p_SourceToken;
    XMLN * p_State;
    XMLN * p_Tracks;

    p_SourceToken = xml_node_soap_get(p_node, "SourceToken");
    if (p_SourceToken)
    {
        XMLN * p_Token;
        const char * p_Type;

        p_Type = xml_attr_get(p_SourceToken, "Type");
        if (p_Type)
        {
            p_req->SourceToken.TypeFlag = 1;
            strncpy(p_req->SourceToken.Type, p_Type, sizeof(p_req->SourceToken.Type)-1);
        }

        p_Token = xml_node_soap_get(p_SourceToken, "Token");
        if (p_Token && p_Token->data)
        {
            strncpy(p_req->SourceToken.Token, p_Token->data, sizeof(p_req->SourceToken.Token)-1);
        }
    }

    p_State = xml_node_soap_get(p_node, "State");
    if (p_State && p_State->data)
    {
        strncpy(p_req->State, p_State->data, sizeof(p_req->State)-1);
    }

    p_Tracks = xml_node_soap_get(p_node, "Tracks");
    if (p_Tracks)
    {    
        XMLN * p_Track;
        
        p_Track = xml_node_soap_get(p_Tracks, "Track");        
        while (p_Track && soap_strcmp(p_Track->name, "Track") == 0)
        {
            int idx = p_req->sizeTrack;

            parse_RecordingJobStateTrack(p_Track, &p_req->Track[idx]);

            p_req->sizeTrack++;
            if (p_req->sizeTrack >= 5)
            {
                break;
            }
                
            p_Track = p_Track->next;
        }
    }

    return TRUE;
}

BOOL parse_GetRecordingJobState(XMLN * p_node, GetRecordingJobState_RES * p_res)
{
    XMLN * p_State;

    p_State = xml_node_soap_get(p_node, "State");
    if (p_State)
    {
        XMLN * p_RecordingToken;
        XMLN * p_State1;
        XMLN * p_Sources;

        p_RecordingToken = xml_node_soap_get(p_State, "RecordingToken");
        if (p_RecordingToken && p_RecordingToken->data)
        {
            strncpy(p_res->State.RecordingToken, p_RecordingToken->data, sizeof(p_res->State.RecordingToken)-1);
        }
        
        p_State1 = xml_node_soap_get(p_State, "State");
        if (p_State1 && p_State1->data)
        {
            strncpy(p_res->State.State, p_State1->data, sizeof(p_res->State.State)-1);
        }

        p_Sources = xml_node_soap_get(p_State, "Sources");
        while (p_Sources && soap_strcmp(p_Sources->name, "Sources") == 0)
        {
            int idx = p_res->State.sizeSources;

            parse_RecordingJobStateSource(p_Sources, &p_res->State.Sources[idx]);

            p_res->State.sizeSources++;
            if (p_res->State.sizeSources >= 5)
            {
                break;
            }
            
            p_Sources = p_Sources->next;
        }
        
    }
    
    return TRUE;
}

BOOL parse_GetReplayUri(XMLN * p_node, GetReplayUri_RES * p_res)
{
    XMLN * p_Uri = xml_node_soap_get(p_node, "Uri");
    if (p_Uri && p_Uri->data)
    {
        onvif_parse_uri(p_Uri->data, p_res->Uri, sizeof(p_res->Uri));
    }
    else
    {
        return FALSE;
    }

    return TRUE;
}

BOOL parse_GetRecordingSummary(XMLN * p_node, GetRecordingSummary_RES * p_res)
{
	XMLN * p_Summary = xml_node_soap_get(p_node, "Summary");
	if (p_Summary)
	{
		XMLN * p_DataFrom;
		XMLN * p_DataUntil;
		XMLN * p_NumberRecordings;

		p_DataFrom = xml_node_soap_get(p_Summary, "DataFrom");
		if (p_DataFrom && p_DataFrom->data)
		{
			parse_XSDDatetime(p_DataFrom->data, &p_res->DataFrom);
		}

		p_DataUntil = xml_node_soap_get(p_Summary, "DataUntil");
		if (p_DataUntil && p_DataUntil->data)
		{
			parse_XSDDatetime(p_DataUntil->data, &p_res->DataUntil);
		}

		p_NumberRecordings = xml_node_soap_get(p_Summary, "NumberRecordings");
		if (p_NumberRecordings && p_NumberRecordings->data)
		{
			p_res->NumberRecordings = atoi(p_NumberRecordings->data);
		}
	}
	else
	{
		return FALSE;
	}

	return TRUE;
}

BOOL parse_TrackInformation(XMLN * p_node, onvif_TrackInformation * p_track)
{
	XMLN * p_TrackToken;
	XMLN * p_TrackType;
	XMLN * p_Description;
	XMLN * p_DataFrom;
	XMLN * p_DataTo;

	p_TrackToken = xml_node_soap_get(p_node, "TrackToken");
	if (p_TrackToken && p_TrackToken->data)
	{
		strncpy(p_track->TrackToken, p_TrackToken->data, sizeof(p_track->TrackToken)-1);
	}

	p_TrackType = xml_node_soap_get(p_node, "TrackType");
	if (p_TrackType && p_TrackType->data)
	{
		p_track->TrackType = onvif_StringToTrackType(p_TrackType->data);
	}

	p_Description = xml_node_soap_get(p_node, "Description");
	if (p_Description && p_Description->data)
	{
		strncpy(p_track->Description, p_Description->data, sizeof(p_track->Description)-1);
	}

	p_DataFrom = xml_node_soap_get(p_node, "DataFrom");
	if (p_DataFrom && p_DataFrom->data)
	{
		parse_XSDDatetime(p_DataFrom->data, &p_track->DataFrom);
	}

	p_DataTo = xml_node_soap_get(p_node, "DataTo");
	if (p_DataTo && p_DataTo->data)
	{
		parse_XSDDatetime(p_DataTo->data, &p_track->DataTo);
	}

	return TRUE;
}

BOOL parse_RecordingInformation(XMLN * p_node, onvif_RecordingInformation * p_recording)
{
	XMLN * p_RecordingToken;
	XMLN * p_Source;
	XMLN * p_EarliestRecording;
	XMLN * p_LatestRecording;
	XMLN * p_Content;
	XMLN * p_Track;
	XMLN * p_RecordingStatus;

	p_RecordingToken = xml_node_soap_get(p_node, "RecordingToken");
	if (p_RecordingToken && p_RecordingToken->data)
	{
		strncpy(p_recording->RecordingToken, p_RecordingToken->data, sizeof(p_recording->RecordingToken)-1);
	}

	p_Source = xml_node_soap_get(p_node, "Source");
	if (p_Source)
	{
		XMLN * p_SourceId;
		XMLN * p_Name;
		XMLN * p_Location;
		XMLN * p_Description;
		XMLN * p_Address;

		p_SourceId = xml_node_soap_get(p_Source, "SourceId");
		if (p_SourceId && p_SourceId->data)
		{
			strncpy(p_recording->Source.SourceId, p_SourceId->data, sizeof(p_recording->Source.SourceId)-1);
		}

		p_Name = xml_node_soap_get(p_Source, "Name");
		if (p_Name && p_Name->data)
		{
			strncpy(p_recording->Source.Name, p_Name->data, sizeof(p_recording->Source.Name)-1);
		}

		p_Location = xml_node_soap_get(p_Source, "Location");
		if (p_Location && p_Location->data)
		{
			strncpy(p_recording->Source.Location, p_Location->data, sizeof(p_recording->Source.Location)-1);
		}

		p_Description = xml_node_soap_get(p_Source, "Description");
		if (p_Description && p_Description->data)
		{
			strncpy(p_recording->Source.Description, p_Description->data, sizeof(p_recording->Source.Description)-1);
		}

		p_Address = xml_node_soap_get(p_Source, "Address");
		if (p_Address && p_Address->data)
		{
			strncpy(p_recording->Source.Address, p_Address->data, sizeof(p_recording->Source.Address)-1);
		}
	}

	p_EarliestRecording = xml_node_soap_get(p_node, "EarliestRecording");
	if (p_EarliestRecording && p_EarliestRecording->data)
	{
		p_recording->EarliestRecordingFlag = 1;
		parse_XSDDatetime(p_EarliestRecording->data, &p_recording->EarliestRecording);
	}

	p_LatestRecording = xml_node_soap_get(p_node, "LatestRecording");
	if (p_LatestRecording && p_LatestRecording->data)
	{
		p_recording->LatestRecordingFlag = 1;
		parse_XSDDatetime(p_LatestRecording->data, &p_recording->LatestRecording);
	}

	p_Content = xml_node_soap_get(p_node, "Content");
	if (p_Content && p_Content->data)
	{
		strncpy(p_recording->Content, p_Content->data, sizeof(p_recording->Content)-1);
	}

	p_Track = xml_node_soap_get(p_node, "Track");
	while (p_Track && soap_strcmp(p_Track->name, "Track") == 0)
	{
		int idx = p_recording->sizeTrack;		
		
		parse_TrackInformation(p_Track, &p_recording->Track[idx]);

		p_recording->sizeTrack++;
		if (p_recording->sizeTrack >= 5)
		{
			break;
		}

		p_Track = p_Track->next;
	}

	p_RecordingStatus = xml_node_soap_get(p_node, "RecordingStatus");
	if (p_RecordingStatus && p_RecordingStatus->data)
	{
		p_recording->RecordingStatus = onvif_StringToRecordingStatus(p_RecordingStatus->data);
	}

	return TRUE;
}

BOOL parse_GetRecordingInformation(XMLN * p_node, GetRecordingInformation_RES * p_res)
{
	XMLN * p_RecordingInformation = xml_node_soap_get(p_node, "RecordingInformation");
	if (NULL == p_RecordingInformation)
	{
		return FALSE;
	}

	return parse_RecordingInformation(p_RecordingInformation, &p_res->RecordingInformation);
}

BOOL parse_TrackAttributes(XMLN * p_node, onvif_TrackAttributes * p_track_attr)
{
	XMLN * p_TrackInformation;
	XMLN * p_VideoAttributes;
	XMLN * p_AudioAttributes;
	XMLN * p_MetadataAttributes;

	p_TrackInformation = xml_node_soap_get(p_node, "TrackInformation");
	if (p_TrackInformation)
	{
		parse_TrackInformation(p_TrackInformation, &p_track_attr->TrackInformation);
	}

	p_VideoAttributes = xml_node_soap_get(p_node, "VideoAttributes");
	if (p_VideoAttributes)
	{
		XMLN * p_Bitrate;
		XMLN * p_Width;
		XMLN * p_Height;
		XMLN * p_Encoding;
		XMLN * p_Framerate;

		p_Bitrate = xml_node_soap_get(p_VideoAttributes, "Bitrate");
		if (p_Bitrate && p_Bitrate->data)
		{
			p_track_attr->VideoAttributes.Bitrate = atoi(p_Bitrate->data);
		}

		p_Width = xml_node_soap_get(p_VideoAttributes, "Width");
		if (p_Width && p_Width->data)
		{
			p_track_attr->VideoAttributes.Width = atoi(p_Width->data);
		}

		p_Height = xml_node_soap_get(p_VideoAttributes, "Height");
		if (p_Height && p_Height->data)
		{
			p_track_attr->VideoAttributes.Height = atoi(p_Height->data);
		}

		p_Encoding = xml_node_soap_get(p_VideoAttributes, "Encoding");
		if (p_Encoding && p_Encoding->data)
		{
			p_track_attr->VideoAttributes.Encoding = onvif_StringToVideoEncoding(p_Encoding->data);
		}

		p_Framerate = xml_node_soap_get(p_VideoAttributes, "Framerate");
		if (p_Framerate && p_Framerate->data)
		{
			p_track_attr->VideoAttributes.Framerate = (float)atof(p_Framerate->data);
		}
	}

	p_AudioAttributes = xml_node_soap_get(p_node, "AudioAttributes");
	if (p_AudioAttributes)
	{
		XMLN * p_Bitrate;
		XMLN * p_Encoding;
		XMLN * p_Samplerate;

		p_Bitrate = xml_node_soap_get(p_AudioAttributes, "Bitrate");
		if (p_Bitrate && p_Bitrate->data)
		{
			p_track_attr->AudioAttributes.Bitrate = atoi(p_Bitrate->data);
		}
		
		p_Encoding = xml_node_soap_get(p_AudioAttributes, "Encoding");
		if (p_Encoding && p_Encoding->data)
		{
			p_track_attr->AudioAttributes.Encoding = onvif_StringToAudioEncoding(p_Encoding->data);
		}

		p_Samplerate = xml_node_soap_get(p_AudioAttributes, "Samplerate");
		if (p_Samplerate && p_Samplerate->data)
		{
			p_track_attr->AudioAttributes.Samplerate = atoi(p_Samplerate->data);
		}
	}

	p_MetadataAttributes = xml_node_soap_get(p_node, "MetadataAttributes");
	if (p_MetadataAttributes)
	{
		XMLN * p_CanContainPTZ;
		XMLN * p_CanContainAnalytics;
		XMLN * p_CanContainNotifications;

		p_CanContainPTZ = xml_node_soap_get(p_MetadataAttributes, "CanContainPTZ");
		if (p_CanContainPTZ && p_CanContainPTZ->data)
		{
			p_track_attr->MetadataAttributes.CanContainPTZ = parse_Bool(p_CanContainPTZ->data);
		}
		
		p_CanContainAnalytics = xml_node_soap_get(p_MetadataAttributes, "CanContainAnalytics");
		if (p_CanContainAnalytics && p_CanContainAnalytics->data)
		{
			p_track_attr->MetadataAttributes.CanContainAnalytics = parse_Bool(p_CanContainAnalytics->data);
		}

		p_CanContainNotifications = xml_node_soap_get(p_MetadataAttributes, "CanContainNotifications");
		if (p_CanContainNotifications && p_CanContainNotifications->data)
		{
			p_track_attr->MetadataAttributes.CanContainNotifications = parse_Bool(p_CanContainNotifications->data);
		}
	}

	return TRUE;
}

BOOL parse_GetMediaAttributes(XMLN * p_node, GetMediaAttributes_RES * p_res)
{
	XMLN * p_MediaAttributes;
	XMLN * p_RecordingToken;
	XMLN * p_TrackAttributes;
	XMLN * p_From;
	XMLN * p_Until;

	p_MediaAttributes = xml_node_soap_get(p_node, "MediaAttributes");
	if (NULL == p_MediaAttributes)
	{
		return FALSE;
	}

	p_RecordingToken = xml_node_soap_get(p_MediaAttributes, "RecordingToken");
	if (p_RecordingToken && p_RecordingToken->data)
	{
		strncpy(p_res->MediaAttributes.RecordingToken, p_RecordingToken->data, sizeof(p_res->MediaAttributes.RecordingToken)-1);
	}

	p_TrackAttributes = xml_node_soap_get(p_MediaAttributes, "TrackAttributes");
	while (p_TrackAttributes && soap_strcmp(p_TrackAttributes->name, "TrackAttributes") == 0)
	{
		int idx = p_res->MediaAttributes.sizeTrackAttributes;
		
		parse_TrackAttributes(p_TrackAttributes, &p_res->MediaAttributes.TrackAttributes[idx]);

		p_res->MediaAttributes.sizeTrackAttributes++;
		if (p_res->MediaAttributes.sizeTrackAttributes >= 5)
		{
			break;
		}

		p_TrackAttributes = p_TrackAttributes->next;
	}

	p_From = xml_node_soap_get(p_MediaAttributes, "From");
	if (p_From && p_From->data)
	{
		parse_XSDDatetime(p_From->data, &p_res->MediaAttributes.From);
	}

	p_Until = xml_node_soap_get(p_MediaAttributes, "Until");
	if (p_Until && p_Until->data)
	{
		parse_XSDDatetime(p_Until->data, &p_res->MediaAttributes.Until);
	}

	return TRUE;
}

BOOL parse_FindRecordings(XMLN * p_node, FindRecordings_RES * p_res)
{
	XMLN * p_SearchToken = xml_node_soap_get(p_node, "SearchToken");
	if (p_SearchToken && p_SearchToken->data)
	{
		strncpy(p_res->SearchToken, p_SearchToken->data, sizeof(p_res->SearchToken)-1);
	}
	else
	{
		return FALSE;
	}

	return TRUE;
}

BOOL parse_GetRecordingSearchResults(XMLN * p_node, GetRecordingSearchResults_RES * p_res)
{
	XMLN * p_ResultList;
	XMLN * p_SearchState;
	XMLN * p_RecordingInformation;

	p_ResultList = xml_node_soap_get(p_node, "ResultList");
	if (NULL == p_ResultList)
	{
		return FALSE;
	}

	p_SearchState = xml_node_soap_get(p_ResultList, "SearchState");
	if (p_SearchState && p_SearchState->data)
	{
		p_res->ResultList.SearchState = onvif_StringToSearchState(p_SearchState->data);
	}
	
	p_RecordingInformation = xml_node_soap_get(p_ResultList, "RecordingInformation");
	while (p_RecordingInformation && soap_strcmp(p_RecordingInformation->name, "RecordingInformation") == 0)
	{
		ONVIF_RecordingInformation * p_recording = onvif_add_RecordingInformation(&p_res->ResultList.RecordInformation);
		if (p_recording)
		{
			parse_RecordingInformation(p_RecordingInformation, &p_recording->RecordingInformation);
		}
		
		p_RecordingInformation = p_RecordingInformation->next;
	}

	return TRUE;
}

BOOL parse_FindEvents(XMLN * p_node, FindEvents_RES * p_res)
{
	XMLN * p_SearchToken = xml_node_soap_get(p_node, "SearchToken");
	if (p_SearchToken && p_SearchToken->data)
	{
		strncpy(p_res->SearchToken, p_SearchToken->data, sizeof(p_res->SearchToken)-1);
	}
	else
	{
		return FALSE;
	}

	return TRUE;
}

BOOL parse_GetSearchState(XMLN * p_node, GetSearchState_RES * p_res)
{
	XMLN * p_State = xml_node_soap_get(p_node, "State");
	if (p_State && p_State->data)
	{
		p_res->State = onvif_StringToSearchState(p_State->data);
	}
	else
	{
		return FALSE;
	}

	return TRUE;
}

BOOL parse_EndSearch(XMLN * p_node, EndSearch_RES * p_res)
{
	XMLN * p_Endpoint = xml_node_soap_get(p_node, "Endpoint");
	if (p_Endpoint && p_Endpoint->data)
	{
		parse_XSDDatetime(p_Endpoint->data, &p_res->Endpoint);
	}
	else
	{
		return FALSE;
	}

	return TRUE;
}

#endif // end of PROFILE_G_SUPPORT

#ifdef PROFILE_C_SUPPORT

BOOL parse_AccessControlService(XMLN * p_node, onvif_AccessControlCapabilities * p_cap)
{
    XMLN * p_XAddr;
	XMLN * p_Capabilities;
	XMLN * p_Version;
	
    p_XAddr = xml_node_soap_get(p_node, "XAddr");
    if (p_XAddr && p_XAddr->data)
    {
        parse_XAddr(p_XAddr->data, &p_cap->XAddr);
    }
    else
    {
        return FALSE;
    }

    p_Capabilities = xml_node_soap_get(p_node, "Capabilities");
    if (p_Capabilities)
    {
        const char * p_MaxLimit;

        p_MaxLimit = xml_attr_get(p_Capabilities, "MaxLimit");
        if (p_MaxLimit)
        {
            p_cap->MaxLimit = atoi(p_MaxLimit);
        }
    }

    p_Version = xml_node_soap_get(p_node, "Version");
    if (p_Version)
    {
		parse_Version(p_Version, &p_cap->Version);
    }

    return TRUE;
}

BOOL parse_DoorControlService(XMLN * p_node, onvif_DoorControlCapabilities * p_cap)
{
    XMLN * p_XAddr;
	XMLN * p_Capabilities;
	XMLN * p_Version;
	
    p_XAddr = xml_node_soap_get(p_node, "XAddr");
    if (p_XAddr && p_XAddr->data)
    {
        parse_XAddr(p_XAddr->data, &p_cap->XAddr);
    }
    else
    {
        return FALSE;
    }

    p_Capabilities = xml_node_soap_get(p_node, "Capabilities");
    if (p_Capabilities)
    {
        const char * p_MaxLimit;

        p_MaxLimit = xml_attr_get(p_Capabilities, "MaxLimit");
        if (p_MaxLimit)
        {
            p_cap->MaxLimit = atoi(p_MaxLimit);
        }
    }

    p_Version = xml_node_soap_get(p_node, "Version");
    if (p_Version)
    {
		parse_Version(p_Version, &p_cap->Version);
    }

    return TRUE;
}

BOOL parse_AccessPointInfo(XMLN * p_node, onvif_AccessPointInfo * p_req)
{
    XMLN * p_Name;
    XMLN * p_Description;
    XMLN * p_AreaFrom;
    XMLN * p_AreaTo;
    XMLN * p_EntityType;
    XMLN * p_Entity;
    XMLN * p_Capabilities;
    const char * p_token;

    p_token = xml_attr_get(p_node, "token");
    if (p_token)
    {
        strncpy(p_req->token, p_token, sizeof(p_req->token)-1);
    }

    p_Name = xml_node_soap_get(p_node, "Name");
    if (p_Name && p_Name->data)
    {
        strncpy(p_req->Name, p_Name->data, sizeof(p_req->Name)-1);
    }

    p_Description = xml_node_soap_get(p_node, "Description");
    if (p_Description && p_Description->data)
    {
        p_req->DescriptionFlag = 1;
        strncpy(p_req->Description, p_Description->data, sizeof(p_req->Description)-1);
    }

    p_AreaFrom = xml_node_soap_get(p_node, "AreaFrom");
    if (p_AreaFrom && p_AreaFrom->data)
    {
        p_req->AreaFromFlag = 1;
        strncpy(p_req->AreaFrom, p_AreaFrom->data, sizeof(p_req->AreaFrom)-1);
    }

    p_AreaTo = xml_node_soap_get(p_node, "AreaTo");
    if (p_AreaTo && p_AreaTo->data)
    {
        p_req->AreaToFlag = 1;
        strncpy(p_req->AreaTo, p_AreaTo->data, sizeof(p_req->AreaTo)-1);
    }

    p_EntityType = xml_node_soap_get(p_node, "EntityType");
    if (p_EntityType && p_EntityType->data)
    {
        p_req->EntityTypeFlag = 1;
        strncpy(p_req->EntityType, p_EntityType->data, sizeof(p_req->EntityType)-1);
    }

    p_Entity = xml_node_soap_get(p_node, "Entity");
    if (p_Entity && p_Entity->data)
    {
        strncpy(p_req->Entity, p_Entity->data, sizeof(p_req->Entity)-1);
    }

    p_Capabilities = xml_node_soap_get(p_node, "Capabilities");
    if (p_Capabilities)
    {    
        const char * p_DisableAccessPoint;
        const char * p_Duress;
        const char * p_AnonymousAccess;
        const char * p_AccessTaken;
        const char * p_ExternalAuthorization;

        p_DisableAccessPoint = xml_attr_get(p_Capabilities, "DisableAccessPoint");
        if (p_DisableAccessPoint)
        {
            p_req->Capabilities.DisableAccessPoint = parse_Bool(p_DisableAccessPoint);
        }

        p_Duress = xml_attr_get(p_Capabilities, "Duress");
        if (p_Duress)
        {
            p_req->Capabilities.Duress = parse_Bool(p_Duress);
        }

        p_AnonymousAccess = xml_attr_get(p_Capabilities, "AnonymousAccess");
        if (p_AnonymousAccess)
        {
            p_req->Capabilities.AnonymousAccess = parse_Bool(p_AnonymousAccess);
        }

        p_AccessTaken = xml_attr_get(p_Capabilities, "AccessTaken");
        if (p_AccessTaken)
        {
            p_req->Capabilities.AccessTaken = parse_Bool(p_AccessTaken);
        }

        p_ExternalAuthorization = xml_attr_get(p_Capabilities, "ExternalAuthorization");
        if (p_ExternalAuthorization)
        {
            p_req->Capabilities.ExternalAuthorization = parse_Bool(p_ExternalAuthorization);
        }
    }

    return TRUE;
}

BOOL parse_GetAccessPointInfoList(XMLN * p_node, GetAccessPointInfoList_RES * p_res)
{
    XMLN * p_NextStartReference;
    XMLN * p_AccessPointInfo;

    p_NextStartReference = xml_node_soap_get(p_node, "NextStartReference");
    if (p_NextStartReference && p_NextStartReference->data)
    {
        p_res->NextStartReferenceFlag = 1;
        strncpy(p_res->NextStartReference, p_NextStartReference->data, sizeof(p_res->NextStartReference)-1);
    }

    p_AccessPointInfo = xml_node_soap_get(p_node, "AccessPointInfo");
    while (p_AccessPointInfo && soap_strcmp(p_AccessPointInfo->name, "AccessPointInfo") == 0)
    {
        ONVIF_AccessPointInfo * p_info = onvif_add_AccessPointInfo(&p_res->AccessPointInfo);
        if (p_info)
        {
            parse_AccessPointInfo(p_AccessPointInfo, &p_info->AccessPointInfo);
        }

        p_AccessPointInfo = p_AccessPointInfo->next;
    }

    return TRUE;
}

BOOL parse_GetAccessPointInfo(XMLN * p_node, GetAccessPointInfo_RES * p_res)
{
    XMLN * p_AccessPointInfo;

    p_AccessPointInfo = xml_node_soap_get(p_node, "AccessPointInfo");
    while (p_AccessPointInfo && soap_strcmp(p_AccessPointInfo->name, "AccessPointInfo") == 0)
    {
        ONVIF_AccessPointInfo * p_info = onvif_add_AccessPointInfo(&p_res->AccessPointInfo);
        if (p_info)
        {
            parse_AccessPointInfo(p_AccessPointInfo, &p_info->AccessPointInfo);
        }

        p_AccessPointInfo = p_AccessPointInfo->next;
    }

    return TRUE;
}

BOOL parse_DoorInfo(XMLN * p_node, onvif_DoorInfo * p_req)
{
    XMLN * p_Name;
    XMLN * p_Description;
    XMLN * p_Capabilities;
    const char * p_token;

    p_token = xml_attr_get(p_node, "token");
    if (p_token)
    {
        strncpy(p_req->token, p_token, sizeof(p_req->token)-1);
    }

    p_Name = xml_node_soap_get(p_node, "Name");
    if (p_Name && p_Name->data)
    {
        strncpy(p_req->Name, p_Name->data, sizeof(p_req->Name)-1);
    }

    p_Description = xml_node_soap_get(p_node, "Description");
    if (p_Description && p_Description->data)
    {
        p_req->DescriptionFlag = 1;
        strncpy(p_req->Description, p_Description->data, sizeof(p_req->Description)-1);
    }

    p_Capabilities = xml_node_soap_get(p_node, "Capabilities");
    if (p_Capabilities)
    {
        const char * p_Access;        
        const char * p_AccessTimingOverride;
        const char * p_Lock;
        const char * p_Unlock;
        const char * p_Block;
        const char * p_DoubleLock;
        const char * p_LockDown;
        const char * p_LockOpen; 
        const char * p_DoorMonitor;
        const char * p_LockMonitor;
        const char * p_DoubleLockMonitor;
        const char * p_Alarm;
        const char * p_Tamper;
        const char * p_Fault;

        p_Access = xml_attr_get(p_Capabilities, "Access");
        if (p_Access)
        {
            p_req->Capabilities.Access = parse_Bool(p_Access);
        }

        p_AccessTimingOverride = xml_attr_get(p_Capabilities, "AccessTimingOverride");
        if (p_AccessTimingOverride)
        {
            p_req->Capabilities.AccessTimingOverride = parse_Bool(p_AccessTimingOverride);
        }

        p_Lock = xml_attr_get(p_Capabilities, "Lock");
        if (p_Lock)
        {
            p_req->Capabilities.Lock = parse_Bool(p_Lock);
        }

        p_Unlock = xml_attr_get(p_Capabilities, "Unlock");
        if (p_Unlock)
        {
            p_req->Capabilities.Unlock = parse_Bool(p_Unlock);
        }

        p_Block = xml_attr_get(p_Capabilities, "Block");
        if (p_Block)
        {
            p_req->Capabilities.Block = parse_Bool(p_Block);
        }

        p_DoubleLock = xml_attr_get(p_Capabilities, "DoubleLock");
        if (p_DoubleLock)
        {
            p_req->Capabilities.DoubleLock = parse_Bool(p_DoubleLock);
        }

        p_LockDown = xml_attr_get(p_Capabilities, "LockDown");
        if (p_LockDown)
        {
            p_req->Capabilities.LockDown = parse_Bool(p_LockDown);
        }

        p_LockOpen = xml_attr_get(p_Capabilities, "LockOpen");
        if (p_LockOpen)
        {
            p_req->Capabilities.LockOpen = parse_Bool(p_LockOpen);
        }

        p_DoorMonitor = xml_attr_get(p_Capabilities, "DoorMonitor");
        if (p_DoorMonitor)
        {
            p_req->Capabilities.DoorMonitor = parse_Bool(p_DoorMonitor);
        }

        p_LockMonitor = xml_attr_get(p_Capabilities, "LockMonitor");
        if (p_LockMonitor)
        {
            p_req->Capabilities.LockMonitor = parse_Bool(p_LockMonitor);
        }

        p_DoubleLockMonitor = xml_attr_get(p_Capabilities, "DoubleLockMonitor");
        if (p_DoubleLockMonitor)
        {
            p_req->Capabilities.DoubleLockMonitor = parse_Bool(p_DoubleLockMonitor);
        }

        p_Alarm = xml_attr_get(p_Capabilities, "Alarm");
        if (p_Alarm)
        {
            p_req->Capabilities.Alarm = parse_Bool(p_Alarm);
        }

        p_Tamper = xml_attr_get(p_Capabilities, "Tamper");
        if (p_Tamper)
        {
            p_req->Capabilities.Tamper = parse_Bool(p_Tamper);
        }

        p_Fault = xml_attr_get(p_Capabilities, "Fault");
        if (p_Fault)
        {
            p_req->Capabilities.Fault = parse_Bool(p_Fault);
        }
    }

    return TRUE;
}

BOOL parse_GetDoorInfoList(XMLN * p_node, GetDoorInfoList_RES * p_res)
{
    XMLN * p_NextStartReference;
    XMLN * p_DoorInfo;

    p_NextStartReference = xml_node_soap_get(p_node, "NextStartReference");
    if (p_NextStartReference && p_NextStartReference->data)
    {
        p_res->NextStartReferenceFlag = 1;
        strncpy(p_res->NextStartReference, p_NextStartReference->data, sizeof(p_res->NextStartReference)-1);
    }

    p_DoorInfo = xml_node_soap_get(p_node, "DoorInfo");
    while (p_DoorInfo && soap_strcmp(p_DoorInfo->name, "DoorInfo") == 0)
    {
        ONVIF_DoorInfo * p_info = onvif_add_DoorInfo(&p_res->DoorInfo);
        if (p_info)
        {
            parse_DoorInfo(p_DoorInfo, &p_info->DoorInfo);
        }

        p_DoorInfo = p_DoorInfo->next;
    }

    return TRUE;
}

BOOL parse_GetDoorInfo(XMLN * p_node, GetDoorInfo_RES * p_res)
{
    XMLN * p_DoorInfo;

    p_DoorInfo = xml_node_soap_get(p_node, "DoorInfo");
    while (p_DoorInfo && soap_strcmp(p_DoorInfo->name, "DoorInfo") == 0)
    {
        ONVIF_DoorInfo * p_info = onvif_add_DoorInfo(&p_res->DoorInfo);
        if (p_info)
        {
            parse_DoorInfo(p_DoorInfo, &p_info->DoorInfo);
        }

        p_DoorInfo = p_DoorInfo->next;
    }

    return TRUE;
}

BOOL parse_AreaInfo(XMLN * p_node, onvif_AreaInfo * p_req)
{
    XMLN * p_Name;
    XMLN * p_Description;
    const char * p_token;

    p_token = xml_attr_get(p_node, "token");
    if (p_token)
    {
        strncpy(p_req->token, p_token, sizeof(p_req->token)-1);
    }

    p_Name = xml_node_soap_get(p_node, "Name");
    if (p_Name && p_Name->data)
    {
        strncpy(p_req->Name, p_Name->data, sizeof(p_req->Name)-1);
    }

    p_Description = xml_node_soap_get(p_node, "Description");
    if (p_Description && p_Description->data)
    {
        p_req->DescriptionFlag = 1;
        strncpy(p_req->Description, p_Description->data, sizeof(p_req->Description)-1);
    }

    return TRUE;
}

BOOL parse_GetAreaInfoList(XMLN * p_node, GetAreaInfoList_RES * p_res)
{
    XMLN * p_NextStartReference;
    XMLN * p_AreaInfo;

    p_NextStartReference = xml_node_soap_get(p_node, "NextStartReference");
    if (p_NextStartReference && p_NextStartReference->data)
    {
        p_res->NextStartReferenceFlag = 1;
        strncpy(p_res->NextStartReference, p_NextStartReference->data, sizeof(p_res->NextStartReference)-1);
    }

    p_AreaInfo = xml_node_soap_get(p_node, "AreaInfo");
    while (p_AreaInfo && soap_strcmp(p_AreaInfo->name, "AreaInfo") == 0)
    {
        ONVIF_AreaInfo * p_info = onvif_add_AreaInfo(&p_res->AreaInfo);
        if (p_info)
        {
            parse_AreaInfo(p_AreaInfo, &p_info->AreaInfo);
        }

        p_AreaInfo = p_AreaInfo->next;
    }

    return TRUE;
}

BOOL parse_GetAreaInfo(XMLN * p_node, GetAreaInfo_RES * p_res)
{
    XMLN * p_AreaInfo;

    p_AreaInfo = xml_node_soap_get(p_node, "AreaInfo");
    while (p_AreaInfo && soap_strcmp(p_AreaInfo->name, "AreaInfo") == 0)
    {
        ONVIF_AreaInfo * p_info = onvif_add_AreaInfo(&p_res->AreaInfo);
        if (p_info)
        {
            parse_AreaInfo(p_AreaInfo, &p_info->AreaInfo);
        }

        p_AreaInfo = p_AreaInfo->next;
    }

    return TRUE;
}

BOOL parse_GetAccessPointState(XMLN * p_node, GetAccessPointState_RES * p_res)
{
    XMLN * p_AccessPointState;

    p_AccessPointState = xml_node_soap_get(p_node, "AccessPointState");
    if (p_AccessPointState)
    {
        XMLN * p_Enabled;
        
        p_Enabled = xml_node_soap_get(p_AccessPointState, "Enabled");
        if (p_Enabled && p_Enabled->data)
        {
            p_res->Enabled = parse_Bool(p_Enabled->data);
        }        
    }

    return TRUE;
}

BOOL parse_GetDoorState(XMLN * p_node, GetDoorState_RES * p_res)
{
    XMLN * p_DoorState;

    p_DoorState = xml_node_soap_get(p_node, "DoorState");
    if (p_DoorState)
    {
        XMLN * p_DoorPhysicalState;
        XMLN * p_LockPhysicalState;
        XMLN * p_DoubleLockPhysicalState;
        XMLN * p_Alarm;
        XMLN * p_Tamper;
        XMLN * p_Fault;
        XMLN * p_DoorMode;

        p_DoorPhysicalState = xml_node_soap_get(p_DoorState, "DoorPhysicalState");
        if (p_DoorPhysicalState && p_DoorPhysicalState->data)
        {
            p_res->DoorState.DoorPhysicalStateFlag = 1;
            p_res->DoorState.DoorPhysicalState = onvif_StringToDoorPhysicalState(p_DoorPhysicalState->data);
        }

        p_LockPhysicalState = xml_node_soap_get(p_DoorState, "LockPhysicalState");
        if (p_LockPhysicalState && p_LockPhysicalState->data)
        {
            p_res->DoorState.LockPhysicalStateFlag = 1;
            p_res->DoorState.LockPhysicalState = onvif_StringToLockPhysicalState(p_LockPhysicalState->data);
        }

        p_DoubleLockPhysicalState = xml_node_soap_get(p_DoorState, "DoubleLockPhysicalState");
        if (p_DoubleLockPhysicalState && p_DoubleLockPhysicalState->data)
        {
            p_res->DoorState.DoubleLockPhysicalStateFlag = 1;
            p_res->DoorState.DoubleLockPhysicalState = onvif_StringToLockPhysicalState(p_DoubleLockPhysicalState->data);
        }

        p_Alarm = xml_node_soap_get(p_DoorState, "Alarm");
        if (p_Alarm && p_Alarm->data)
        {
            p_res->DoorState.AlarmFlag = 1;
            p_res->DoorState.Alarm = onvif_StringToDoorAlarmState(p_Alarm->data);
        }

        p_Tamper = xml_node_soap_get(p_DoorState, "Tamper");
        if (p_Tamper)
        {
            XMLN * p_Reason;
            XMLN * p_State;
        
            p_res->DoorState.TamperFlag = 1;

            p_Reason = xml_node_soap_get(p_Tamper, "Reason");
            if (p_Reason && p_Reason->data)
            {
                p_res->DoorState.Tamper.ReasonFlag = 1;
                strncpy(p_res->DoorState.Tamper.Reason, p_Reason->data, sizeof(p_res->DoorState.Tamper.Reason)-1);
            }

            p_State = xml_node_soap_get(p_Tamper, "State");
            if (p_State && p_State->data)
            {
                p_res->DoorState.Tamper.State = onvif_StringToDoorTamperState(p_State->data);
            }
        }

        p_Fault = xml_node_soap_get(p_DoorState, "Fault");
        if (p_Fault)
        {
            XMLN * p_Reason;
            XMLN * p_State;
        
            p_res->DoorState.FaultFlag = 1;

            p_Reason = xml_node_soap_get(p_Fault, "Reason");
            if (p_Reason && p_Reason->data)
            {
                p_res->DoorState.Fault.ReasonFlag = 1;
                strncpy(p_res->DoorState.Fault.Reason, p_Reason->data, sizeof(p_res->DoorState.Fault.Reason)-1);
            }

            p_State = xml_node_soap_get(p_Fault, "State");
            if (p_State && p_State->data)
            {
                p_res->DoorState.Fault.State = onvif_StringToDoorFaultState(p_State->data);
            }
        }

        p_DoorMode = xml_node_soap_get(p_DoorState, "DoorMode");
        if (p_DoorMode && p_DoorMode->data)
        {
            p_res->DoorState.DoorMode = onvif_StringToDoorMode(p_DoorMode->data);
        }
    }

    return TRUE;
}

#endif // end of PROFILE_C_SUPPORT




