/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2010-2016, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#include "sys_inc.h"
#include "onvif_event.h"
#include "soap_parser.h"
#include "onvif_cln.h"


/***************************************************************************************/
onvif_event_notify_cb g_notify_cb = 0;
void * g_notify_cb_data = 0;

onvif_subscribe_disconnect_cb g_subscribe_disconnect_cb = 0;
void * g_subscribe_disconnect_cb_data = 0;

/***************************************************************************************/
ONVIF_API void onvif_set_event_notify_cb(onvif_event_notify_cb cb, void * pdata)
{
    g_notify_cb = cb;
    g_notify_cb_data = pdata;
}

ONVIF_API void onvif_set_subscribe_disconnect_cb(onvif_subscribe_disconnect_cb cb, void * pdata)
{
	g_subscribe_disconnect_cb = cb;
    g_subscribe_disconnect_cb_data = pdata;
}

ONVIF_API void onvif_event_notify(HTTPCLN * p_user, HTTPMSG * rx_msg, XMLN * p_xml)
{
    Notify_REQ req;
	
    memset(&req, 0, sizeof(req));
    strncpy(req.PostUrl, rx_msg->first_line.value_string, sizeof(req.PostUrl)-1);

	if (parse_NotifyMessage(p_xml, &req.notify) == FALSE)
	{
		return;
	}

    if (g_notify_cb)    
    {
        g_notify_cb(&req, g_notify_cb_data);
    }
}


void onvif_event_timer(ONVIF_DEVICE * p_dev)
{
    Renew_REQ req;
    req.TerminationTime = p_dev->events.init_term_time;
    
	if (onvif_Renew(p_dev, &req, NULL) == FALSE)
	{
		log_print(LOG_ERR, "onvif event renew failed, %s\r\n", p_dev->binfo.XAddr.host);

		if (g_subscribe_disconnect_cb)    
	    {
	        g_subscribe_disconnect_cb(p_dev, g_subscribe_disconnect_cb_data);
	    }
	}
}

#if __WIN32_OS__

#ifdef _WIN64
void CALLBACK onvif_event_timer_win(UINT uTimerID, UINT uMsg, DWORD_PTR dwUser, DWORD_PTR dw1, DWORD_PTR dw2)
#else
void CALLBACK onvif_event_timer_win(UINT uID,UINT uMsg,DWORD dwUser,DWORD dw1,DWORD dw2)
#endif
{
    ONVIF_DEVICE * p_dev = (ONVIF_DEVICE *) dwUser;

    onvif_event_timer(p_dev);
}

ONVIF_API void onvif_event_timer_init(ONVIF_DEVICE * p_dev)
{
	p_dev->events.timer_id = timeSetEvent(p_dev->events.init_term_time / 2 * 1000,0,onvif_event_timer_win,(DWORD_PTR)p_dev,TIME_PERIODIC);
}

ONVIF_API void onvif_event_timer_deinit(ONVIF_DEVICE * p_dev)
{
    if (p_dev->events.timer_id != 0)
    {
    	timeKillEvent(p_dev->events.timer_id);
    	p_dev->events.timer_id = 0;
	}
}

#elif __LINUX_OS__

void * onvif_event_timer_task(void * argv)
{
	struct timeval tv;	
	ONVIF_DEVICE * p_dev = (ONVIF_DEVICE *) argv;
	
	while (p_dev->events.event_timer_run)
	{		
		tv.tv_sec = p_dev->events.init_term_time / 2;
		tv.tv_usec = 0;
		
		select(1,NULL,NULL,NULL,&tv);
		
		onvif_event_timer(p_dev);
	}

	p_dev->events.timer_id = 0;
	
	return NULL;
}

void onvif_event_timer_init(ONVIF_DEVICE * p_dev)
{
	p_dev->events.event_timer_run = TRUE;

	pthread_t tid = sys_os_create_thread((void *)onvif_event_timer_task, p_dev);
	if (tid == 0)
	{
		log_print(LOG_ERR, "onvif_timer_init::pthread_create onvif_event_timer_task\r\n");
		return;
	}

    p_dev->events.timer_id = tid;
}

void onvif_event_timer_deinit(ONVIF_DEVICE * p_dev)
{
	p_dev->events.event_timer_run = FALSE;
	
	while (p_dev->events.timer_id != 0)
	{
		usleep(1000);
	}
}

#endif



