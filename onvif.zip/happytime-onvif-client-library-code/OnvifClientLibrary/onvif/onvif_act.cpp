/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2010-2016, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#include "sys_inc.h"
#include "onvif_act.h"


/***************************************************************************************/
OVFACTS g_onvif_acts[] = 
{
	// device
	{eGetCapabilities, "http://www.onvif.org/ver10/device/wsdl/GetCapabilities"},
	{eGetServices, "http://www.onvif.org/ver10/device/wsdl/GetServices"},
	{eGetDeviceInformation, "http://www.onvif.org/ver10/device/wsdl/GetDeviceInformation"},
	{eGetUsers, "http://www.onvif.org/ver10/device/wsdl/GetUsers"},
	{eCreateUsers, "http://www.onvif.org/ver10/device/wsdl/CreateUsers"},
	{eDeleteUsers, "http://www.onvif.org/ver10/device/wsdl/DeleteUsers"},
	{eSetUser, "http://www.onvif.org/ver10/device/wsdl/SetUser"},
	{eGetRemoteUser, "http://www.onvif.org/ver10/device/wsdl/GetRemoteUser"},
	{eSetRemoteUser, "http://www.onvif.org/ver10/device/wsdl/SetRemoteUser"},
	{eGetNetworkInterfaces, "http://www.onvif.org/ver10/device/wsdl/GetNetworkInterfaces"},	
	{eSetNetworkInterfaces, "http://www.onvif.org/ver10/device/wsdl/SetNetworkInterfaces"},
	{eGetNTP, "http://www.onvif.org/ver10/device/wsdl/GetNTP"},
	{eSetNTP, "http://www.onvif.org/ver10/device/wsdl/SetNTP"},
	{eGetHostname, "http://www.onvif.org/ver10/device/wsdl/GetHostname"},
	{eSetHostname, "http://www.onvif.org/ver10/device/wsdl/SetHostname"},
	{eSetHostnameFromDHCP, "http://www.onvif.org/ver10/device/wsdl/SetHostnameFromDHCP"},
	{eGetDNS, "http://www.onvif.org/ver10/device/wsdl/GetDNS"},
	{eSetDNS, "http://www.onvif.org/ver10/device/wsdl/SetDNS"},
	{eGetDynamicDNS, "http://www.onvif.org/ver10/device/wsdl/GetDynamicDNS"},
	{eSetDynamicDNS, "http://www.onvif.org/ver10/device/wsdl/SetDynamicDNS"},
	{eGetNetworkProtocols, "http://www.onvif.org/ver10/device/wsdl/GetNetworkProtocols"},
	{eSetNetworkProtocols, "http://www.onvif.org/ver10/device/wsdl/SetNetworkProtocols"},
	{eGetDiscoveryMode, "http://www.onvif.org/ver10/device/wsdl/GetDiscoveryMode"},
	{eSetDiscoveryMode, "http://www.onvif.org/ver10/device/wsdl/SetDiscoveryMode"},
	{eGetNetworkDefaultGateway, "http://www.onvif.org/ver10/device/wsdl/GetNetworkDefaultGateway"},
	{eSetNetworkDefaultGateway, "http://www.onvif.org/ver10/device/wsdl/SetNetworkDefaultGateway"},
	{eGetZeroConfiguration, "http://www.onvif.org/ver10/device/wsdl/GetZeroConfiguration"},
	{eSetZeroConfiguration, "http://www.onvif.org/ver10/device/wsdl/SetZeroConfiguration"},
	{eGetEndpointReference, "http://www.onvif.org/ver10/device/wsdl/GetEndpointReference"},
	{eGetSystemDateAndTime, "http://www.onvif.org/ver10/device/wsdl/GetSystemDateAndTime"},
	{eSetSystemDateAndTime, "http://www.onvif.org/ver10/device/wsdl/SetSystemDateAndTime"},
	{eSystemReboot, "http://www.onvif.org/ver10/device/wsdl/SystemReboot"},
	{eSetSystemFactoryDefault, "http://www.onvif.org/ver10/device/wsdl/SetSystemFactoryDefault"},
	{eGetSystemLog, "http://www.onvif.org/ver10/device/wsdl/GetSystemLog"},
	{eGetScopes, "http://www.onvif.org/ver10/device/wsdl/GetScopes"},
	{eSetScopes, "http://www.onvif.org/ver10/device/wsdl/SetScopes"},
	{eAddScopes, "http://www.onvif.org/ver10/device/wsdl/AddScopes"},
	{eRemoveScopes, "http://www.onvif.org/ver10/device/wsdl/RemoveScopes"},
	{eStartFirmwareUpgrade, "http://www.onvif.org/ver10/device/wsdl/StartFirmwareUpgrade"},
	{eGetSystemUris, "http://www.onvif.org/ver10/device/wsdl/GetSystemUris"},
	{eStartSystemRestore, "http://www.onvif.org/ver10/device/wsdl/StartSystemRestore"},
	// end of device

	// media
	{eGetVideoSources, "http://www.onvif.org/ver10/media/wsdl/GetVideoSources"},
	{eGetAudioSources, "http://www.onvif.org/ver10/media/wsdl/GetAudioSources"},
	{eCreateProfile, "http://www.onvif.org/ver10/media/wsdl/CreateProfile"},
	{eGetProfile, "http://www.onvif.org/ver10/media/wsdl/GetProfile"},
	{eGetProfiles, "http://www.onvif.org/ver10/media/wsdl/GetProfiles"},
	{eAddVideoEncoderConfiguration, "http://www.onvif.org/ver10/media/wsdl/AddVideoEncoderConfiguration"},
	{eAddVideoSourceConfiguration, "http://www.onvif.org/ver10/media/wsdl/AddVideoSourceConfiguration"},
	{eAddAudioEncoderConfiguration, "http://www.onvif.org/ver10/media/wsdl/AddAudioEncoderConfiguration"},
	{eAddAudioSourceConfiguration, "http://www.onvif.org/ver10/media/wsdl/AddAudioSourceConfiguration"},
	{eGetVideoSourceModes, "http://www.onvif.org/ver10/media/wsdl/GetVideoSourceModes"},
	{eSetVideoSourceMode, "http://www.onvif.org/ver10/media/wsdl/SetVideoSourceMode"},
	{eAddPTZConfiguration, "http://www.onvif.org/ver10/media/wsdl/AddPTZConfiguration"},
	{eRemoveVideoEncoderConfiguration, "http://www.onvif.org/ver10/media/wsdl/RemoveVideoEncoderConfiguration"},
	{eRemoveVideoSourceConfiguration, "http://www.onvif.org/ver10/media/wsdl/RemoveVideoSourceConfiguration"},
	{eRemoveAudioEncoderConfiguration, "http://www.onvif.org/ver10/media/wsdl/RemoveAudioEncoderConfiguration"},
	{eRemoveAudioSourceConfiguration, "http://www.onvif.org/ver10/media/wsdl/RemoveAudioSourceConfiguration"},
	{eRemovePTZConfiguration, "http://www.onvif.org/ver10/media/wsdl/RemovePTZConfiguration"},
	{eDeleteProfile, "http://www.onvif.org/ver10/media/wsdl/DeleteProfile"},
	{eGetVideoSourceConfigurations, "http://www.onvif.org/ver10/media/wsdl/GetVideoSourceConfigurations"},
	{eGetVideoEncoderConfigurations, "http://www.onvif.org/ver10/media/wsdl/GetVideoEncoderConfigurations"},	
	{eGetAudioSourceConfigurations, "http://www.onvif.org/ver10/media/wsdl/GetAudioSourceConfigurations"},
	{eGetAudioEncoderConfigurations, "http://www.onvif.org/ver10/media/wsdl/GetAudioEncoderConfigurations"},
	{eGetVideoSourceConfiguration, "http://www.onvif.org/ver10/media/wsdl/GetVideoSourceConfiguration"},
	{eGetVideoEncoderConfiguration, "http://www.onvif.org/ver10/media/wsdl/GetVideoEncoderConfiguration"},
	{eGetAudioSourceConfiguration, "http://www.onvif.org/ver10/media/wsdl/GetAudioSourceConfiguration"},
	{eGetAudioEncoderConfiguration, "http://www.onvif.org/ver10/media/wsdl/GetAudioEncoderConfiguration"},
	{eSetVideoSourceConfiguration, "http://www.onvif.org/ver10/media/wsdl/SetVideoSourceConfiguration"},
	{eSetVideoEncoderConfiguration, "http://www.onvif.org/ver10/media/wsdl/SetVideoEncoderConfiguration"},	
	{eSetAudioSourceConfiguration, "http://www.onvif.org/ver10/media/wsdl/SetAudioSourceConfiguration"},
	{eSetAudioEncoderConfiguration, "http://www.onvif.org/ver10/media/wsdl/SetAudioEncoderConfiguration"},
	{eGetVideoSourceConfigurationOptions, "http://www.onvif.org/ver10/media/wsdl/GetVideoSourceConfigurationOptions"},
	{eGetVideoEncoderConfigurationOptions, "http://www.onvif.org/ver10/media/wsdl/GetVideoEncoderConfigurationOptions"},	
	{eGetAudioSourceConfigurationOptions, "http://www.onvif.org/ver10/media/wsdl/GetAudioSourceConfigurationOptions"},
	{eGetAudioEncoderConfigurationOptions, "http://www.onvif.org/ver10/media/wsdl/GetAudioEncoderConfigurationOptions"},	
	{eGetStreamUri,	"http://www.onvif.org/ver10/media/wsdl/GetStreamUri"},	
	{eSetSynchronizationPoint, "http://www.onvif.org/ver10/media/wsdl/SetSynchronizationPoint"},
	{eGetSnapshotUri, "http://www.onvif.org/ver10/media/wsdl/GetSnapshotUri"},
	// end of media

	// media 2
	{etr2GetVideoEncoderConfigurations, "http://www.onvif.org/ver20/media/wsdl/GetVideoEncoderConfigurations"},
	{etr2SetVideoEncoderConfiguration, "http://www.onvif.org/ver20/media/wsdl/SetVideoEncoderConfiguration"},
	{etr2GetVideoEncoderConfigurationOptions, "http://www.onvif.org/ver20/media/wsdl/GetVideoEncoderConfigurationOptions"},
	{etr2GetProfiles, "http://www.onvif.org/ver20/media/wsdl/GetProfiles"},
    {etr2CreateProfile, "http://www.onvif.org/ver20/media/wsdl/CreateProfile"},
    {etr2DeleteProfile, "http://www.onvif.org/ver20/media/wsdl/DeleteProfile"},
    {etr2GetStreamUri, "http://www.onvif.org/ver20/media/wsdl/GetStreamUri"},
    {etr2GetVideoSourceConfigurations, "http://www.onvif.org/ver20/media/wsdl/GetVideoSourceConfigurations"},
    {etr2GetVideoSourceConfigurationOptions, "http://www.onvif.org/ver20/media/wsdl/GetVideoSourceConfigurationOptions"},
    {etr2SetVideoSourceConfiguration, "http://www.onvif.org/ver20/media/wsdl/SetVideoSourceConfiguration"},
    {etr2SetSynchronizationPoint, "http://www.onvif.org/ver20/media/wsdl/SetSynchronizationPoint"},
    {etr2GetMetadataConfigurations, "http://www.onvif.org/ver20/media/wsdl/GetMetadataConfigurations"},
    {etr2GetMetadataConfigurationOptions, "http://www.onvif.org/ver20/media/wsdl/GetMetadataConfigurationOptions"},
    {etr2SetMetadataConfiguration, "http://www.onvif.org/ver20/media/wsdl/SetMetadataConfiguration"},
    {etr2GetAudioEncoderConfigurations, "http://www.onvif.org/ver20/media/wsdl/GetAudioEncoderConfigurations"},
    {etr2GetAudioSourceConfigurations, "http://www.onvif.org/ver20/media/wsdl/GetAudioSourceConfigurations"},
    {etr2GetAudioSourceConfigurationOptions, "http://www.onvif.org/ver20/media/wsdl/GetAudioSourceConfigurationOptions"},
    {etr2SetAudioSourceConfiguration, "http://www.onvif.org/ver20/media/wsdl/SetAudioSourceConfiguration"},
    {etr2SetAudioEncoderConfiguration, "http://www.onvif.org/ver20/media/wsdl/SetAudioEncoderConfiguration"},
    {etr2GetAudioEncoderConfigurationOptions, "http://www.onvif.org/ver20/media/wsdl/GetAudioEncoderConfigurationOptions"},
    {etr2AddConfiguration, "http://www.onvif.org/ver20/media/wsdl/AddConfiguration"},
    {etr2RemoveConfiguration, "http://www.onvif.org/ver20/media/wsdl/RemoveConfiguration"},
    {etr2GetVideoEncoderInstances, "http://www.onvif.org/ver20/media/wsdl/GetVideoEncoderInstances"},
	// end of media 2
	
	// PTZ
	{eGetNodes, "http://www.onvif.org/ver20/ptz/wsdl/GetNodes"},
	{eGetNode, "http://www.onvif.org/ver20/ptz/wsdl/GetNode"},
	{eGetPresets, "http://www.onvif.org/ver20/ptz/wsdl/GetPresets"},
	{eSetPreset, "http://www.onvif.org/ver20/ptz/wsdl/SetPreset"},
	{eRemovePreset, "http://www.onvif.org/ver20/ptz/wsdl/RemovePreset"},
	{eGotoPreset, "http://www.onvif.org/ver20/ptz/wsdl/GotoPreset"},
	{eGotoHomePosition, "http://www.onvif.org/ver20/ptz/wsdl/GotoHomePosition"},
	{eSetHomePosition, "http://www.onvif.org/ver20/ptz/wsdl/SetHomePosition"},
	{eGetStatus, "http://www.onvif.org/ver20/ptz/wsdl/GetStatus"},
	{eContinuousMove, "http://www.onvif.org/ver20/ptz/wsdl/ContinuousMove"},	
	{eRelativeMove, "http://www.onvif.org/ver20/ptz/wsdl/RelativeMove"},
	{eAbsoluteMove, "http://www.onvif.org/ver20/ptz/wsdl/AbsoluteMove"},
	{ePTZStop, "http://www.onvif.org/ver20/ptz/wsdl/Stop"},
	{eGetConfigurations, "http://www.onvif.org/ver20/ptz/wsdl/GetConfigurations"},
	{eGetConfiguration, "http://www.onvif.org/ver20/ptz/wsdl/GetConfiguration"},
	{eSetConfiguration, "http://www.onvif.org/ver20/ptz/wsdl/SetConfiguration"},
	{eGetConfigurationOptions, "http://www.onvif.org/ver20/ptz/wsdl/GetConfigurationOptions"},
	{eGetPresetTours, "http://www.onvif.org/ver20/ptz/wsdl/GetPresetTours"},
	{eGetPresetTour, "http://www.onvif.org/ver20/ptz/wsdl/GetPresetTour"},
	{eGetPresetTourOptions, "http://www.onvif.org/ver20/ptz/wsdl/GetPresetTourOptions"},
	{eCreatePresetTour, "http://www.onvif.org/ver20/ptz/wsdl/CreatePresetTour"},
	{eModifyPresetTour, "http://www.onvif.org/ver20/ptz/wsdl/ModifyPresetTour"},
	{eOperatePresetTour, "http://www.onvif.org/ver20/ptz/wsdl/OperatePresetTour"},
	{eRemovePresetTour, "http://www.onvif.org/ver20/ptz/wsdl/RemovePresetTour"},
	// end of PTZ

	// event
	{eGetEventProperties, "http://www.onvif.org/ver10/events/wsdl/EventPortType/GetEventPropertiesRequest"},
	{eRenew, "http://docs.oasis-open.org/wsn/bw-2/SubscriptionManager/RenewRequest"},
	{eUnsubscribe, "http://docs.oasis-open.org/wsn/bw-2/SubscriptionManager/UnsubscribeRequest"},
	{eSubscribe, "http://docs.oasis-open.org/wsn/bw-2/NotificationProducer/SubscribeRequest"},
	{eCreatePullPointSubscription, "http://www.onvif.org/ver10/events/wsdl/EventPortType/CreatePullPointSubscriptionRequest"},
    {ePullMessages, "http://www.onvif.org/ver10/events/wsdl/PullPointSubscription/PullMessagesRequest"},
	// end of event

	// image
	{eGetImagingSettings, "http://www.onvif.org/ver20/imaging/wsdl/GetImagingSettings"},
	{eSetImagingSettings, "http://www.onvif.org/ver20/imaging/wsdl/SetImagingSettings"},
	{eGetOptions, "http://www.onvif.org/ver20/imaging/wsdl/GetOptions"},	
	{eimgMove, "http://www.onvif.org/ver20/imaging/wsdl/Move"},
	{eimgStop, "http://www.onvif.org/ver20/imaging/wsdl/FocusStop"},
	{eimgGetStatus, "http://www.onvif.org/ver20/imaging/wsdl/GetStatus"},
	{eimgGetMoveOptions, "http://www.onvif.org/ver20/imaging/wsdl/GetMoveOptions"},
	// end of image

	{eGetOSDs, "http://www.onvif.org/ver10/media/wsdl/GetOSDs"},
	{eGetOSD, "http://www.onvif.org/ver10/media/wsdl/GetOSD"},
	{eSetOSD, "http://www.onvif.org/ver10/media/wsdl/SetOSD"},
	{eGetOSDOptions, "http://www.onvif.org/ver10/media/wsdl/GetOSDOptions"},
	{eCreateOSD, "http://www.onvif.org/ver10/media/wsdl/CreateOSD"},
	{eDeleteOSD, "http://www.onvif.org/ver10/media/wsdl/DeleteOSD"},

	{eGetVideoAnalyticsConfigurations, "http://www.onvif.org/ver10/media/wsdl/GetVideoAnalyticsConfigurations"},
	{eAddVideoAnalyticsConfiguration, "http://www.onvif.org/ver10/media/wsdl/AddVideoAnalyticsConfiguration"},
	{eGetVideoAnalyticsConfiguration, "http://www.onvif.org/ver10/media/wsdl/GetVideoAnalyticsConfigurations"},
	{eRemoveVideoAnalyticsConfiguration, "http://www.onvif.org/ver10/media/wsdl/RemoveVideoAnalyticsConfiguration"},
	{eSetVideoAnalyticsConfiguration, "http://www.onvif.org/ver10/media/wsdl/SetVideoAnalyticsConfiguration"},
	{eGetSupportedRules, "http://www.onvif.org/ver20/analytics/wsdl/GetSupportedRules"},
	{eCreateRules, "http://www.onvif.org/ver20/analytics/wsdl/CreateRules"},
	{eDeleteRules, "http://www.onvif.org/ver20/analytics/wsdl/DeleteRules"},
	{eGetRules, "http://www.onvif.org/ver20/analytics/wsdl/GetRules"},
	{eModifyRules, "http://www.onvif.org/ver20/analytics/wsdl/ModifyRules"},
	{eCreateAnalyticsModules, "http://www.onvif.org/ver20/analytics/wsdl/CreateAnalyticsModules"},
	{eDeleteAnalyticsModules, "http://www.onvif.org/ver20/analytics/wsdl/DeleteAnalyticsModules"},
	{eGetAnalyticsModules, "http://www.onvif.org/ver20/analytics/wsdl/GetAnalyticsModules"},
	{eModifyAnalyticsModules, "http://www.onvif.org/ver20/analytics/wsdl/ModifyAnalyticsModules"},

#ifdef PROFILE_G_SUPPORT
    // recording service interfaces
    {eCreateRecording, "http://www.onvif.org/ver10/recording/wsdl/CreateRecording"},
    {eDeleteRecording, "http://www.onvif.org/ver10/recording/wsdl/DeleteRecording"},
    {eGetRecordings, "http://www.onvif.org/ver10/recording/wsdl/GetRecordings"},
    {eSetRecordingConfiguration, "http://www.onvif.org/ver10/recording/wsdl/SetRecordingConfiguration"},
    {eGetRecordingConfiguration, "http://www.onvif.org/ver10/recording/wsdl/GetRecordingConfiguration"},
    {eGetRecordingOptions, "http://www.onvif.org/ver10/recording/wsdl/GetRecordingOptions"},
    {eCreateTrack, "http://www.onvif.org/ver10/recording/wsdl/CreateTrack"},
    {eDeleteTrack, "http://www.onvif.org/ver10/recording/wsdl/DeleteTrack"},
    {eGetTrackConfiguration, "http://www.onvif.org/ver10/recording/wsdl/GetTrackConfiguration"},
    {eSetTrackConfiguration, "http://www.onvif.org/ver10/recording/wsdl/SetTrackConfiguration"},
    {eCreateRecordingJob, "http://www.onvif.org/ver10/recording/wsdl/CreateRecordingJob"},
    {eDeleteRecordingJob, "http://www.onvif.org/ver10/recording/wsdl/DeleteRecordingJob"},
    {eGetRecordingJobs, "http://www.onvif.org/ver10/recording/wsdl/GetRecordingJobs"},
    {eSetRecordingJobConfiguration, "http://www.onvif.org/ver10/recording/wsdl/SetRecordingJobConfiguration"},
    {eGetRecordingJobConfiguration, "http://www.onvif.org/ver10/recording/wsdl/GetRecordingJobConfiguration"},
    {eSetRecordingJobMode, "http://www.onvif.org/ver10/recording/wsdl/SetRecordingJobMode"},
    {eGetRecordingJobState, "http://www.onvif.org/ver10/recording/wsdl/GetRecordingJobState"},

    {eGetReplayUri, "http://www.onvif.org/ver10/replay/wsdl/GetReplayUri"},

    {eGetRecordingSummary, "http://www.onvif.org/ver10/search/wsdl/GetRecordingSummary"},
    {eGetRecordingInformation, "http://www.onvif.org/ver10/search/wsdl/GetRecordingInformation"},
    {eGetMediaAttributes, "http://www.onvif.org/ver10/search/wsdl/GetMediaAttributes"},
    {eFindRecordings, "http://www.onvif.org/ver10/search/wsdl/FindRecordings"},
    {eGetRecordingSearchResults, "http://www.onvif.org/ver10/search/wsdl/GetRecordingSearchResults"},
    {eFindEvents, "http://www.onvif.org/ver10/search/wsdl/FindEvents"},
    {eGetEventSearchResults, "http://www.onvif.org/ver10/search/wsdl/GetEventSearchResults"},
    {eGetSearchState, "http://www.onvif.org/ver10/search/wsdl/GetSearchState"},
    {eEndSearch, "http://www.onvif.org/ver10/search/wsdl/EndSearch"},
#endif // end of PROFILE_G_SUPPORT

#ifdef PROFILE_C_SUPPORT
	{eGetAccessPointInfoList, "http://www.onvif.org/ver10/accesscontrol/wsdl/GetAccessPointInfoList"},
    {eGetAccessPointInfo, "http://www.onvif.org/ver10/accesscontrol/wsdl/GetAccessPointInfo"},
    {eGetDoorInfoList, "http://www.onvif.org/ver10/doorcontrol/wsdl/GetDoorInfoList"},
    {eGetDoorInfo, "http://www.onvif.org/ver10/doorcontrol/wsdl/GetDoorInfo"},
    {eGetAreaInfoList, "http://www.onvif.org/ver10/accesscontrol/wsdl/GetAreaInfoList"},
    {eGetAreaInfo, "http://www.onvif.org/ver10/accesscontrol/wsdl/GetAreaInfo"},
    {eGetAccessPointState, "http://www.onvif.org/ver10/accesscontrol/wsdl/GetAccessPointState"},
    {eGetDoorState, "http://www.onvif.org/ver10/doorcontrol/wsdl/GetDoorState"},
    {eAccessDoor, "http://www.onvif.org/ver10/doorcontrol/wsdl/AccessDoor"},
    {eLockDoor, "http://www.onvif.org/ver10/doorcontrol/wsdl/LockDoor"},
    {eUnlockDoor, "http://www.onvif.org/ver10/doorcontrol/wsdl/UnlockDoor"},
    {eDoubleLockDoor, "http://www.onvif.org/ver10/doorcontrol/wsdl/DoubleLockDoor"},
    {eBlockDoor, "http://www.onvif.org/ver10/doorcontrol/wsdl/BlockDoor"},
    {eLockDownDoor, "http://www.onvif.org/ver10/doorcontrol/wsdl/LockDownDoor"},
    {eLockDownReleaseDoor, "http://www.onvif.org/ver10/doorcontrol/wsdl/LockDownReleaseDoor"},
    {eLockOpenDoor, "http://www.onvif.org/ver10/doorcontrol/wsdl/LockOpenDoor"},
    {eLockOpenReleaseDoor, "http://www.onvif.org/ver10/doorcontrol/wsdl/LockOpenReleaseDoor"},
    {eEnableAccessPoint, "http://www.onvif.org/ver10/accesscontrol/wsdl/EnableAccessPoint"},
    {eDisableAccessPoint, "http://www.onvif.org/ver10/accesscontrol/wsdl/DisableAccessPoint"},
#endif // end of PROFILE_C_SUPPORT
};


/***************************************************************************************/
ONVIF_API OVFACTS * onvif_find_action_by_type(eOnvifAction type)
{
	int i;
	
	if (type < eActionNull || type >= eActionMax)
	{
		return NULL;
	}
	
	for (i=0; i<(sizeof(g_onvif_acts)/sizeof(OVFACTS)); i++)
	{
		if (g_onvif_acts[i].type == type)
		{
			return &g_onvif_acts[i];
		}	
	}

	return NULL;
}



