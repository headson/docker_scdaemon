/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2010-2016, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#include "sys_inc.h"
#include "http.h"
#include "onvif_pkt.h"
#include "soap.h"
#include "soap_parser.h"
#include "http_cln.h"
#include "rfc_md5.h"
#include "base64.h"

#ifdef HTTPS
#if __WIN32_OS__
#include "openssl/applink.c"
#endif

#pragma comment(lib, "ssleay32.lib")
#endif

#define MAX_CTT_LEN     (2*1024*1024)


/***************************************************************************************/
BOOL http_get_digest_info(HTTPMSG * rx_msg, HD_AUTH_INFO * auth_info)
{
	HDRV * chap_id = NULL;
	
	chap_id = find_http_headline(rx_msg,"WWW-Authenticate");
	if(chap_id == NULL)
		return FALSE;

	char word_buf[128];
	int	 next_offset;

//	memset(auth_info,0,sizeof(HD_AUTH_INFO));
	auth_info->auth_response[0] = '\0';
	auth_info->auth_uri[0] = '\0';

	word_buf[0] = '\0';
	GetLineWord(chap_id->value_string,0,strlen(chap_id->value_string),
		word_buf,sizeof(word_buf),&next_offset,WORD_TYPE_STRING);
	if(strcasecmp(word_buf,"digest") != 0)
		return FALSE;
	
	word_buf[0] = '\0';
	if(GetNameValuePair(chap_id->value_string+next_offset,
		strlen(chap_id->value_string)-next_offset,"realm",word_buf,sizeof(word_buf)) == FALSE)
		return FALSE;
	strcpy(auth_info->auth_realm,word_buf);

	word_buf[0] = '\0';
	if(GetNameValuePair(chap_id->value_string+next_offset,
		strlen(chap_id->value_string)-next_offset,"nonce",word_buf,sizeof(word_buf)) == FALSE)
		return FALSE;
	strcpy(auth_info->auth_nonce,word_buf);
	
	return TRUE;
}

BOOL http_calc_auth_digest(HD_AUTH_INFO * auth_info, const char * method)
{
    MD5_CTX Md5Ctx;
	HASH HA1;
	HASH HA2;
	HASH HA3;

	HASHHEX HA1Hex;
	HASHHEX HA2Hex;
	HASHHEX HA3Hex;	

	MD5Init(&Md5Ctx);
	MD5Update(&Md5Ctx, (unsigned char *)auth_info->auth_name, strlen(auth_info->auth_name));
	MD5Update(&Md5Ctx, (unsigned char *)&(":"), 1);
	MD5Update(&Md5Ctx, (unsigned char *)auth_info->auth_realm, strlen(auth_info->auth_realm));
	MD5Update(&Md5Ctx, (unsigned char *)&(":"), 1);
	MD5Update(&Md5Ctx, (unsigned char *)auth_info->auth_pwd, strlen(auth_info->auth_pwd));
	MD5Final(HA1, &Md5Ctx);

	CvtHex(HA1, HA1Hex);

	MD5Init(&Md5Ctx);
	MD5Update(&Md5Ctx, (unsigned char *)method, strlen(method));
	MD5Update(&Md5Ctx, (unsigned char *)&(":"), 1);
	MD5Update(&Md5Ctx, (unsigned char *)auth_info->auth_uri, strlen(auth_info->auth_uri));
	MD5Final(HA2, &Md5Ctx);

	CvtHex(HA2, HA2Hex);

	MD5Init(&Md5Ctx);
	MD5Update(&Md5Ctx, (unsigned char *)HA1Hex, HASHHEXLEN);
	MD5Update(&Md5Ctx, (unsigned char *)&(":"), 1);
	MD5Update(&Md5Ctx, (unsigned char *)auth_info->auth_nonce, strlen(auth_info->auth_nonce));
	MD5Update(&Md5Ctx, (unsigned char *)&(":"), 1);
	MD5Update(&Md5Ctx, (unsigned char *)HA2Hex, HASHHEXLEN);
	MD5Final(HA3, &Md5Ctx);

	CvtHex(HA3, HA3Hex);

	strcpy(auth_info->auth_response, HA3Hex);
	
	return TRUE;
}

BOOL http_tcp_rx(HTTPREQ * p_user)
{
#ifdef HTTPS
	int pending;
#endif
	int rlen;
	HTTPMSG * rx_msg;

	if (p_user->p_rbuf == NULL)
	{
		p_user->p_rbuf = p_user->rcv_buf;
		p_user->mlen = sizeof(p_user->rcv_buf)-1;
		p_user->rcv_dlen = 0;
		p_user->ctt_len = 0;
		p_user->hdr_len = 0;
	}

#ifdef HTTPS

READ:

	if (p_user->https)
	{
		rlen = SSL_read(p_user->ssl,p_user->p_rbuf+p_user->rcv_dlen,p_user->mlen-p_user->rcv_dlen);
	}
	else
	{
		rlen = recv(p_user->cfd,p_user->p_rbuf+p_user->rcv_dlen,p_user->mlen-p_user->rcv_dlen,0);
	}
#else
	rlen = recv(p_user->cfd,p_user->p_rbuf+p_user->rcv_dlen,p_user->mlen-p_user->rcv_dlen,0);
#endif	
	if (rlen < 0)
	{
		log_print(LOG_INFO, "http_tcp_rx::recv return = %d, dlen[%d], mlen[%d]\r\n",rlen,p_user->rcv_dlen,p_user->mlen);	
		closesocket(p_user->cfd);
		p_user->cfd = 0;
		return FALSE;
	}

	p_user->rcv_dlen += rlen;
	p_user->p_rbuf[p_user->rcv_dlen] = '\0';    

    if (0 == rlen)
	{
	    if (p_user->rcv_dlen < p_user->ctt_len + p_user->hdr_len && p_user->ctt_len == MAX_CTT_LEN)
	    {
            // without Content-Length filed, when recv finish, fix the ctt length
            p_user->ctt_len = p_user->rcv_dlen - p_user->hdr_len;
        }
        else
        {
            log_print(LOG_INFO, "http_tcp_rx::recv return = %d, dlen[%d], mlen[%d]\r\n",rlen,p_user->rcv_dlen,p_user->mlen);	
    		closesocket(p_user->cfd);
    		p_user->cfd = 0;
    		return FALSE;
        }
	}
	
// rx_analyse_point:

	if (p_user->rcv_dlen < 16)
		return TRUE;

	if (is_http_msg(p_user->p_rbuf) == FALSE)	
		return FALSE;

	rx_msg = NULL;

	if (p_user->hdr_len == 0)
	{
		int parse_len;
		int http_pkt_len;

		http_pkt_len = http_pkt_find_end(p_user->p_rbuf);
		if (http_pkt_len == 0) 
		{
			return TRUE;
		}
		p_user->hdr_len = http_pkt_len;

		rx_msg = http_get_msg_buf();
		if (rx_msg == NULL)
		{
			log_print(LOG_ERR, "http_tcp_rx::get_msg_buf ret null!!!\r\n");
			return FALSE;
		}

		memcpy(rx_msg->msg_buf,p_user->p_rbuf,http_pkt_len);
		rx_msg->msg_buf[http_pkt_len] = '\0';
		log_print(LOG_DBG, "RX << %s\r\n",rx_msg->msg_buf);
		
		parse_len = http_msg_parse_part1(rx_msg->msg_buf,http_pkt_len,rx_msg);
		if (parse_len != http_pkt_len)
		{
			log_print(LOG_ERR, "http_tcp_rx::http_msg_parse_part1=%d, http_pkt_len=%d!!!\r\n",parse_len,http_pkt_len);
			free_http_msg(rx_msg);
			return FALSE;
		}
		p_user->ctt_len = rx_msg->ctt_len;
	}

    if (p_user->ctt_len == 0 && p_user->rcv_dlen > p_user->hdr_len)
    {
        // without Content-Length filed
        p_user->ctt_len = MAX_CTT_LEN;
    }
    
	if ((p_user->ctt_len + p_user->hdr_len) > p_user->mlen)
	{
		if (p_user->dyn_recv_buf)
		{
			free(p_user->dyn_recv_buf);
		}

		p_user->dyn_recv_buf = (char *)malloc(p_user->ctt_len + p_user->hdr_len + 1);
		if (NULL == p_user->dyn_recv_buf)
		{
		    if(rx_msg) free_http_msg(rx_msg);
		    return FALSE;
		}
		
		memcpy(p_user->dyn_recv_buf, p_user->rcv_buf, p_user->rcv_dlen);
		p_user->p_rbuf = p_user->dyn_recv_buf;
		p_user->mlen = p_user->ctt_len + p_user->hdr_len;

		if(rx_msg) free_http_msg(rx_msg);

#ifdef HTTPS 
		if (p_user->https)
		{
			pending = SSL_pending(p_user->ssl);
			if (pending > 0)
			{
        		goto READ;
			}
		}
#endif

		return TRUE;
	}

	if (p_user->rcv_dlen >= (p_user->ctt_len + p_user->hdr_len))
	{
		if (rx_msg == NULL)
		{
			int nlen;
			int parse_len;

			nlen = p_user->ctt_len + p_user->hdr_len;
			if (nlen >= 2048)
			{
				rx_msg = http_get_msg_large_buf(nlen+1);
				if (rx_msg == NULL)
					return FALSE;
			}
			else
			{
				rx_msg = http_get_msg_buf();
				if (rx_msg == NULL)
					return FALSE;
			}

			memcpy(rx_msg->msg_buf,p_user->p_rbuf,p_user->hdr_len);
			rx_msg->msg_buf[p_user->hdr_len] = '\0';
			log_print(LOG_DBG, "RX << %s\r\n",rx_msg->msg_buf);
			
			parse_len = http_msg_parse_part1(rx_msg->msg_buf,p_user->hdr_len,rx_msg);
			if (parse_len != p_user->hdr_len)
			{
				log_print(LOG_ERR, "http_tcp_rx::http_msg_parse_part1=%d, sip_pkt_len=%d!!!\r\n",parse_len,p_user->hdr_len);
				free_http_msg(rx_msg);
				return FALSE;
			}				
		}

		if (p_user->ctt_len > 0)
		{
			int parse_len;
			
			memcpy(rx_msg->msg_buf+p_user->hdr_len, p_user->p_rbuf+p_user->hdr_len, p_user->ctt_len);
			rx_msg->msg_buf[p_user->hdr_len + p_user->ctt_len] = '\0';

			if (ctt_is_string(rx_msg->ctt_type))
				log_print(LOG_DBG, "%s\r\n\r\n",rx_msg->msg_buf+p_user->hdr_len);

			parse_len = http_msg_parse_part2(rx_msg->msg_buf+p_user->hdr_len,p_user->ctt_len,rx_msg);
			if (parse_len != p_user->ctt_len)
			{
				log_print(LOG_ERR, "http_tcp_rx::http_msg_parse_part2=%d, sdp_pkt_len=%d!!!\r\n",parse_len,p_user->ctt_len);
				free_http_msg(rx_msg);
				return FALSE;
			}
		}

		p_user->rx_msg = rx_msg;
	}

	if (p_user->rx_msg != rx_msg) 
	{
        free_http_msg(rx_msg);
    }
	
	return TRUE;
}

BOOL http_tcp_tx(HTTPREQ * p_user, char * p_data, int len)
{
	int offset = 0;
	int slen = 0;
	
	if (p_user->cfd <= 0)
		return FALSE;

#ifdef HTTPS
	if (p_user->https)
	{
		slen = SSL_write(p_user->ssl, p_data, len);
	}
	else
	{
		slen = send(p_user->cfd, p_data, len, 0);
	}
#else	
	slen = send(p_user->cfd, p_data, len, 0);
#endif	
	if (slen != len)
		return FALSE;

	return TRUE;
}

BOOL http_onvif_req(HTTPREQ * p_user, char * action, char * p_xml, int len)
{
	BOOL ret;
	int offset = 0;
	char * bufs = (char *)malloc(len + 1024);
	if (NULL == bufs)
	{
		return FALSE;
	}
	
	offset += sprintf(bufs+offset, "POST %s HTTP/1.1\r\n", p_user->url);
	offset += sprintf(bufs+offset, "Host: %s:%d\r\n", p_user->host, p_user->port);
	offset += sprintf(bufs+offset, "User-Agent: Happytimesoft/1.0\r\n");
	offset += sprintf(bufs+offset, "Content-Type: application/soap+xml; charset=utf-8; action=\"%s\"\r\n", action);
	offset += sprintf(bufs+offset, "Content-Length: %d\r\n", len);

	if (p_user->need_auth)
    {
        if (p_user->auth_mode == 1)			// digest auth
        {
            http_calc_auth_digest(&p_user->auth_info, "POST");
        
    	    offset += sprintf(bufs+offset, "Authorization: Digest username=\"%s\",realm=\"%s\","
    	    	"nonce=\"%s\",uri=\"%s\",response=\"%s\"\r\n",
    			p_user->auth_info.auth_name, p_user->auth_info.auth_realm, p_user->auth_info.auth_nonce, 
    			p_user->auth_info.auth_uri, p_user->auth_info.auth_response);
		}
		else if (p_user->auth_mode == 0)	// basic auth
		{
    		char buff[128] = {'\0'};
    		char basic[256] = {'\0'};
    		sprintf(buff, "%s:%s", p_user->user, p_user->pass);
    		base64_encode((unsigned char *)buff, strlen(buff), basic, sizeof(basic));
    		
    		offset += sprintf(bufs+offset, "Authorization: Basic %s\r\n", basic);
		}
	}
	
	offset += sprintf(bufs+offset, "Connection: close\r\n\r\n");

	memcpy(bufs+offset, p_xml, len);
	offset += len;
	bufs[offset] = '\0';

    log_print(LOG_DBG, "TX >> %s\r\n\r\n", bufs);
    
	ret = http_tcp_tx(p_user, bufs, offset);

	free(bufs);

	return ret;
}

BOOL http_tcp_rx_timeout(HTTPREQ * p_http, int timeout)
{
	BOOL ret = FALSE;
	int count = 0;
	int sret;
	fd_set fdr;
	struct timeval tv;
	
	while (1)
	{
		tv.tv_sec = 0;
		tv.tv_usec = 100 * 1000;
		
		FD_ZERO(&fdr);
		FD_SET(p_http->cfd, &fdr);

		sret = select((int)(p_http->cfd+1), &fdr, NULL, NULL, &tv);
		if (sret == 0)
		{
		    count++;
		    if (count >= timeout / 100)
		    {
		        log_print(LOG_WARN, "http_tcp_rx_timeout::timeout!!!\r\n");
		        break;
		    }
			continue;
		}
		else if(sret < 0)
		{
			log_print(LOG_ERR, "http_tcp_rx_timeout::select err[%s], sret[%d]!!!\r\n", sys_os_get_socket_error(), sret);
			break;
		}
		
		if (FD_ISSET(p_http->cfd, &fdr))
		{
			if (http_tcp_rx(p_http) == FALSE)
			{
				break;
			}	
			else if (p_http->rx_msg != NULL)
			{
				ret = TRUE;
				break;
			}	
		}
	}

	return ret;
}

void http_free_req(HTTPREQ * p_http)
{
	if (p_http->cfd > 0)
	{
		closesocket(p_http->cfd);
		p_http->cfd = 0;
	}

#ifdef HTTPS
	if (p_http->ssl)
	{
		SSL_free(p_http->ssl);
		p_http->ssl = NULL;
	}
#endif

	if (p_http->dyn_recv_buf)
	{
		free(p_http->dyn_recv_buf);
		p_http->dyn_recv_buf = NULL;
	}	
	
	if (p_http->rx_msg)
	{
		free_http_msg(p_http->rx_msg);
		p_http->rx_msg = NULL;
	}

	p_http->rcv_dlen = 0;
	p_http->hdr_len = 0;
	p_http->ctt_len = 0;
	p_http->p_rbuf = NULL;
	p_http->mlen = 0;
	p_http->need_auth = FALSE;	
	p_http->auth_mode = 0;
	memset(p_http->rcv_buf, 0, sizeof(p_http->rcv_buf));
}

ONVIF_API BOOL http_onvif_trans(HTTPREQ * p_http, int timeout, eOnvifAction act, ONVIF_DEVICE * p_dev, void * p_req, void * p_res)
{
	int  addr_len;
	int  count = 0;
	int  xml_len;
	BOOL ret =  FALSE;
	char * p_buf = NULL;
	char * rx_xml = NULL;
	XMLN * p_node = NULL;
	XMLN * p_body = NULL;	
	OVFACTS * p_ent;
	struct sockaddr_in local_addr;

    p_dev->authFailed = 0;
    p_dev->errCode = ONVIF_OK;    
    
#ifdef DEMO
#if __WIN32_OS__
	static int cnt = 0;
	if (cnt++ >= 20)
	{
		cnt = 0;
		ShellExecute(NULL, NULL, L"www.happytimesoft.com", NULL, L".", 5);
	}
#endif
#endif

#ifdef HTTPS
	SSL_CTX* ctx = NULL;
	const SSL_METHOD* meth = NULL;

	if (p_http->https)
	{
		SSLeay_add_ssl_algorithms();  
		meth = SSLv23_client_method();  
		SSL_load_error_strings();  
		ctx = SSL_CTX_new(meth);
		if (NULL == ctx)
		{
		    p_dev->errCode = ONVIF_ERR_MallocFailure;
		    
			log_print(LOG_ERR, "SSL_CTX_new failed!\r\n");
			return FALSE;
		}
	}
#else
	if (p_http->https)
	{
	    p_dev->errCode = ONVIF_ERR_NotSupportHttps;
	    
		log_print(LOG_ERR, "the server require ssl connection, unsupport!\r\n");
		return FALSE;
	}
#endif

	p_buf = (char *)malloc(10*1024);
	if (NULL == p_buf)
	{
	    p_dev->errCode = ONVIF_ERR_MallocFailure;
		goto FAILED;
	}
	
	p_ent = onvif_find_action_by_type(act);
	if (p_ent == NULL)
	{
	    // it should not to here!!!
	    
		goto FAILED;
	}

RETRY:

	// build xml bufs	
	xml_len = build_onvif_req_xml(p_buf, 10*1024, act, p_dev, p_req);

	// connect onvif device
	p_http->cfd = tcp_connect_timeout(inet_addr(p_http->host), p_http->port, timeout);
	if (p_http->cfd <= 0)
	{
	    p_dev->errCode = ONVIF_ERR_ConnFailure;
		goto FAILED;
	}

#ifdef HTTPS
	if (p_http->https)
	{
		p_http->ssl = SSL_new(ctx); 
		if (NULL == p_http->ssl)
		{
		    p_dev->errCode = ONVIF_ERR_MallocFailure;
		    
			log_print(LOG_ERR, "SSL_new failed!\r\n");
			goto FAILED;
		}
		
		SSL_set_fd(p_http->ssl, p_http->cfd);  
		if (SSL_connect(p_http->ssl) == -1)
		{
		    p_dev->errCode = ONVIF_ERR_ConnFailure;
		    
			log_print(LOG_ERR, "SSL_connect failed!\r\n");
			goto FAILED;
		}
	}
#endif

	addr_len = sizeof(local_addr);
    if (getsockname(p_http->cfd, (struct sockaddr *)&local_addr, (socklen_t*) &addr_len) == 0)
    {
        p_dev->local_ip = local_addr.sin_addr.s_addr;
    }
	
	if (FALSE == http_onvif_req(p_http, p_ent->action_url, p_buf, xml_len))
	{
	    p_dev->errCode = ONVIF_ERR_MallocFailure;
		goto FAILED;
	}

	if (FALSE == http_tcp_rx_timeout(p_http, timeout))
	{
	    p_dev->errCode = ONVIF_ERR_RecvTimeout;
		goto FAILED;
	}
	
	if (p_http->rx_msg->msg_sub_type != 200)
	{
		if (p_http->rx_msg->msg_sub_type == 401 && p_http->need_auth == FALSE)
		{
			if (http_get_digest_info(p_http->rx_msg, &p_http->auth_info))
			{
				http_free_req(p_http);
				
				p_http->auth_mode = 1;
				strcpy(p_http->auth_info.auth_uri, p_http->url);
				strcpy(p_http->auth_info.auth_name, p_dev->username);
				strcpy(p_http->auth_info.auth_pwd, p_dev->password);			
			}
			else
			{
				http_free_req(p_http);
				
				p_http->auth_mode = 0;
			}
			
			p_http->need_auth = TRUE;
			
			goto RETRY;
		}

		if (p_http->rx_msg->msg_sub_type == 401)
	    {
	        p_dev->authFailed = TRUE;
			p_dev->errCode = ONVIF_ERR_HttpResponseError;
	    }
	}

	rx_xml = get_http_ctt(p_http->rx_msg);
	if (NULL == rx_xml)
	{
	    p_dev->errCode = ONVIF_ERR_NullContent;
		goto FAILED;
	}

    p_node = xxx_hxml_parse(rx_xml, p_http->rx_msg->ctt_len);
	if (p_node == NULL || p_node->name == NULL)
	{
	    p_dev->errCode = ONVIF_ERR_ParseFailed;
	    
		log_print(LOG_WARN, "http_onvif_trans::xxx_hxml_parse ret null!!!\r\n");
		goto FAILED;
	}
	
    if (soap_strcmp(p_node->name, "s:Envelope") != 0)
	{	
	    p_dev->errCode = ONVIF_ERR_ParseFailed;
	    
		log_print(LOG_WARN, "http_onvif_trans::node name[%s] != [s:Envelope]!!!\r\n", p_node->name);
		goto FAILED;
	}

	p_body = xml_node_soap_get(p_node, "s:Body");
	if (p_body == NULL)
	{
	    p_dev->errCode = ONVIF_ERR_ParseFailed;
	    
		log_print(LOG_WARN, "http_onvif_trans::xml_node_soap_get[s:Body] ret null!!!\r\n");
		goto FAILED;
	}

    if (p_http->rx_msg->msg_sub_type != 200)
	{
	    if (parse_Fault(p_body, &p_dev->fault))
	    {
	        if (soap_strcmp(p_dev->fault.Code, "Sender") == 0 && 
	            soap_strcmp(p_dev->fault.Subcode, "NotAuthorized") == 0)
	        {
	            if (p_dev->needAuth == FALSE)
	            {
	            	http_free_req(p_http);

	            	p_dev->needAuth = TRUE;
	            	goto RETRY;
	            }

	            p_dev->authFailed = TRUE;
	        }
	    }
	    
	    p_dev->errCode = ONVIF_ERR_HttpResponseError;
		goto FAILED;
	}
	
	if (!onvif_rly_handler(p_body, act, p_dev, p_res))
	{
	    p_dev->errCode = ONVIF_ERR_HandleFailed;	    
		goto FAILED;
	}
    
	ret = TRUE;

FAILED:

	free(p_buf);
	
	http_free_req(p_http);

#ifdef HTTPS
	if (ctx)
	{
		SSL_CTX_free(ctx);
	}
#endif

	if (p_node)
	{
		xml_node_del(p_node);
	}
	
	return ret;	
}

BOOL http_onvif_file_upload_req(HTTPREQ * p_http, const char * filename)
{
	BOOL ret = FALSE;
	int len, rlen, offset = 0;
	char * p_buf = NULL;
	FILE * fp = NULL;
	
	fp = fopen(filename, "rb");
	if (NULL == fp)
	{
		return FALSE;
	}
	
	fseek(fp, 0, SEEK_END);
	
	len = ftell(fp);
	if (len <= 0)
	{
		goto FAILED;
	}
	fseek(fp, 0, SEEK_SET);
	
	p_buf = (char *) malloc(len + 1024*2);
	if (NULL == p_buf)
	{
		goto FAILED;
	}
	
	offset += sprintf(p_buf+offset, "POST %s HTTP/1.1\r\n", p_http->url);
	offset += sprintf(p_buf+offset, "Host: %s:%d\r\n", p_http->host, p_http->port);
	offset += sprintf(p_buf+offset, "User-Agent: Happytimesoft/1.0\r\n");

	if (p_http->need_auth)
    {
        if (p_http->auth_mode == 1)			// digest auth
        {
            http_calc_auth_digest(&p_http->auth_info, "POST");
        
    	    offset += sprintf(p_buf+offset, "Authorization: Digest username=\"%s\",realm=\"%s\","
    	    	"nonce=\"%s\",uri=\"%s\",response=\"%s\"\r\n",
    			p_http->auth_info.auth_name, p_http->auth_info.auth_realm, p_http->auth_info.auth_nonce, 
    			p_http->auth_info.auth_uri, p_http->auth_info.auth_response);
		}
		else if (p_http->auth_mode == 0)	// basic auth
		{
    		char buff[128] = {'\0'};
    		char basic[256] = {'\0'};
    		sprintf(buff, "%s:%s", p_http->user, p_http->pass);
    		base64_encode((unsigned char *)buff, strlen(buff), basic, sizeof(basic));
    		
    		offset += sprintf(p_buf+offset, "Authorization: Basic %s\r\n", basic);
		}
	}
	
	offset += sprintf(p_buf+offset, "Content-Type: application/octet-stream\r\n");
	offset += sprintf(p_buf+offset, "Content-Length: %d\r\n", len);
	offset += sprintf(p_buf+offset, "Connection: close\r\n\r\n");

	rlen = fread(p_buf+offset, 1, len, fp);
	if (rlen != len)
	{
		goto FAILED;
	}

	ret = http_tcp_tx(p_http, p_buf, len+offset);
	
FAILED:

	if (fp)
	{
		fclose(fp);
	}

	if (p_buf)
	{
		free(p_buf);
	}

	return ret;	
}

ONVIF_API BOOL http_onvif_file_upload(HTTPREQ * p_http, int timeout, const char * filename)
{
	BOOL ret = FALSE;	

#ifdef HTTPS
	SSL_CTX* ctx = NULL;
	const SSL_METHOD* meth = NULL;

	if (p_http->https)
	{
		SSLeay_add_ssl_algorithms();  
		meth = SSLv23_client_method();  
		SSL_load_error_strings();  
		ctx = SSL_CTX_new(meth);
		if (NULL == ctx)
		{
			log_print(LOG_ERR, "SSL_CTX_new failed!\r\n");
			return FALSE;
		}
	}
#else
	if (p_http->https)
	{
		log_print(LOG_ERR, "the server require ssl connection, unsupport!\r\n");
		return FALSE;
	}
#endif

RETRY:

	// connect onvif device
	p_http->cfd = tcp_connect_timeout(inet_addr(p_http->host), p_http->port, timeout);
	if (p_http->cfd <= 0)
	{
		goto FAILED;
	}

#ifdef HTTPS
	if (p_http->https)
	{
		p_http->ssl = SSL_new(ctx); 
		if (NULL == p_http->ssl)
		{
			log_print(LOG_ERR, "SSL_new failed!\r\n");
			goto FAILED;
		}
		
		SSL_set_fd(p_http->ssl, p_http->cfd);  
		if (SSL_connect(p_http->ssl) == -1)
		{
			log_print(LOG_ERR, "SSL_connect failed!\r\n");
			goto FAILED;
		}
	}
#endif

	if (FALSE == http_onvif_file_upload_req(p_http, filename))
	{
		goto FAILED;
	}

	if (FALSE == http_tcp_rx_timeout(p_http, timeout))
	{
		goto FAILED;
	}

	if (p_http->rx_msg->msg_sub_type == 401 && p_http->need_auth == FALSE)
	{
		if (http_get_digest_info(p_http->rx_msg, &p_http->auth_info))
		{
			http_free_req(p_http);
			
			p_http->auth_mode = 1;
			strcpy(p_http->auth_info.auth_uri, p_http->url);
			strcpy(p_http->auth_info.auth_name, p_http->user);
			strcpy(p_http->auth_info.auth_pwd, p_http->pass);			
		}
		else
		{
			http_free_req(p_http);
			
			p_http->auth_mode = 0;
		}

		p_http->need_auth = TRUE;
		
		goto RETRY;
	}
	
	ret = (p_http->rx_msg->msg_sub_type == 200) ? TRUE : FALSE;

FAILED:	
	
	http_free_req(p_http);

#ifdef HTTPS
	if (ctx)
	{
		SSL_CTX_free(ctx);
	}
#endif

	return ret;	
}

BOOL http_onvif_download_req(HTTPREQ * p_http)
{
	int  offset = 0;
	char bufs[2048] = {'\0'};
	
	offset += sprintf(bufs+offset, "GET %s HTTP/1.1\r\n", p_http->url);
	offset += sprintf(bufs+offset, "Host: %s:%d\r\n", p_http->host, p_http->port);
	offset += sprintf(bufs+offset, "User-Agent: Happytimesoft/1.0\r\n");

	if (p_http->need_auth)
    {
        if (p_http->auth_mode == 1)			// digest auth
        {
            http_calc_auth_digest(&p_http->auth_info, "GET");
        
    	    offset += sprintf(bufs+offset, "Authorization: Digest username=\"%s\",realm=\"%s\","
    	    	"nonce=\"%s\",uri=\"%s\",response=\"%s\"\r\n",
    			p_http->auth_info.auth_name, p_http->auth_info.auth_realm, p_http->auth_info.auth_nonce, 
    			p_http->auth_info.auth_uri, p_http->auth_info.auth_response);
		}
		else if (p_http->auth_mode == 0)	// basic auth
		{
    		char buff[128] = {'\0'};
    		char basic[256] = {'\0'};
    		sprintf(buff, "%s:%s", p_http->user, p_http->pass);
    		base64_encode((unsigned char *)buff, strlen(buff), basic, sizeof(basic));
    		
    		offset += sprintf(bufs+offset, "Authorization: Basic %s\r\n", basic);
		}
	}
	
	offset += sprintf(bufs+offset, "Connection: close\r\n\r\n");

	return http_tcp_tx(p_http, bufs, offset);
}

ONVIF_API BOOL http_onvif_download(HTTPREQ * p_http, int timeout, unsigned char ** pp_buf, int * buflen)
{
	BOOL ret = FALSE;
    char * p_ctx;
	
	if (NULL == pp_buf || NULL == buflen)
	{
		return FALSE;
	}

#ifdef HTTPS
	SSL_CTX* ctx = NULL;
	const SSL_METHOD* meth = NULL;

	if (p_http->https)
	{
		SSLeay_add_ssl_algorithms();  
		meth = SSLv23_client_method();  
		SSL_load_error_strings();  
		ctx = SSL_CTX_new(meth);
		if (NULL == ctx)
		{
			log_print(LOG_ERR, "SSL_CTX_new failed!\r\n");
			return FALSE;
		}
	}
#else
	if (p_http->https)
	{
		log_print(LOG_ERR, "the server require ssl connection, unsupport!\r\n");
		return FALSE;
	}
#endif

RETRY:

	// connect onvif device
	p_http->cfd = tcp_connect_timeout(inet_addr(p_http->host), p_http->port, timeout);
	if (p_http->cfd <= 0)
	{
		goto FAILED;
	}

#ifdef HTTPS
	if (p_http->https)
	{
		p_http->ssl = SSL_new(ctx); 
		if (NULL == p_http->ssl)
		{
			log_print(LOG_ERR, "SSL_new failed!\r\n");
			goto FAILED;
		}
		
		SSL_set_fd(p_http->ssl, p_http->cfd);  
		if (SSL_connect(p_http->ssl) == -1)
		{
			log_print(LOG_ERR, "SSL_connect failed!\r\n");
			goto FAILED;
		}
	}
#endif

	if (FALSE == http_onvif_download_req(p_http))
	{
		goto FAILED;
	}
	
	if (FALSE == http_tcp_rx_timeout(p_http, timeout))
	{
		goto FAILED;
	}

	if (p_http->rx_msg->msg_sub_type == 401 && p_http->need_auth == FALSE)
	{
		if (http_get_digest_info(p_http->rx_msg, &p_http->auth_info))
		{
			http_free_req(p_http);
			
			p_http->auth_mode = 1;
			strcpy(p_http->auth_info.auth_uri, p_http->url);
			strcpy(p_http->auth_info.auth_name, p_http->user);
			strcpy(p_http->auth_info.auth_pwd, p_http->pass);			
		}
		else
		{
			http_free_req(p_http);
			
			p_http->auth_mode = 0;
		}
		
		p_http->need_auth = TRUE;
		
		goto RETRY;
	}
	
	if (p_http->rx_msg->msg_sub_type != 200)
	{
		goto FAILED;
	}
	
    p_ctx = get_http_ctt(p_http->rx_msg);
	if (NULL == p_ctx)
	{
		goto FAILED;
	}

	if (buflen)
	{
	    *buflen = p_http->ctt_len;
	}

	if (pp_buf)
	{
    	*pp_buf = (unsigned char *) malloc(*buflen);
    	if (*pp_buf)
    	{
    		ret = TRUE;
    		memcpy(*pp_buf, p_ctx, *buflen);
    	}
	}

FAILED:

	http_free_req(p_http);

#ifdef HTTPS
	if (ctx)
	{
		SSL_CTX_free(ctx);
	}
#endif

	return ret;
}




