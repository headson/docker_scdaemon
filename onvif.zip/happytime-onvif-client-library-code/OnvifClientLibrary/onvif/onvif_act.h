/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2010-2016, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#ifndef ONVIF_ACT_H
#define ONVIF_ACT_H

/*************************************************************************/
typedef enum 
{
	eActionNull = 0,
		
	eGetCapabilities,
	eGetServices,
	eGetDeviceInformation,
	eGetUsers,
	eCreateUsers,
	eDeleteUsers,
	eSetUser,
	eGetRemoteUser,
	eSetRemoteUser,
	eGetNetworkInterfaces,
	eSetNetworkInterfaces,
	eGetNTP,
	eSetNTP,
	eGetHostname,
	eSetHostname,
	eSetHostnameFromDHCP,
	eGetDNS,
	eSetDNS,
	eGetDynamicDNS,
	eSetDynamicDNS,
	eGetNetworkProtocols,
	eSetNetworkProtocols,
	eGetDiscoveryMode,
	eSetDiscoveryMode,
	eGetNetworkDefaultGateway,
	eSetNetworkDefaultGateway,
	eGetZeroConfiguration,
	eSetZeroConfiguration,
	eGetEndpointReference,
	eGetSystemDateAndTime,
	eSetSystemDateAndTime,
	eSystemReboot,
	eSetSystemFactoryDefault,
	eGetSystemLog,
	eGetScopes,
	eSetScopes,
	eAddScopes,
	eRemoveScopes,
    eStartFirmwareUpgrade,
    eGetSystemUris,
    eStartSystemRestore,
    
	eGetVideoSources,
	eGetAudioSources,
	eCreateProfile,
	eGetProfile,
	eGetProfiles,
	eAddVideoEncoderConfiguration,
	eAddVideoSourceConfiguration,
	eAddAudioEncoderConfiguration,
	eAddAudioSourceConfiguration,
	eGetVideoSourceModes,
	eSetVideoSourceMode,
	eAddPTZConfiguration,
	eRemoveVideoEncoderConfiguration,
	eRemoveVideoSourceConfiguration,
	eRemoveAudioEncoderConfiguration,
	eRemoveAudioSourceConfiguration,
	eRemovePTZConfiguration,
	eDeleteProfile,
	eGetVideoSourceConfigurations,
	eGetVideoEncoderConfigurations,	
	eGetAudioSourceConfigurations,
	eGetAudioEncoderConfigurations,
	eGetVideoSourceConfiguration,
	eGetVideoEncoderConfiguration,
	eGetAudioSourceConfiguration,
	eGetAudioEncoderConfiguration,
	eSetVideoSourceConfiguration,
	eSetVideoEncoderConfiguration,	
	eSetAudioSourceConfiguration,
	eSetAudioEncoderConfiguration,
	eGetVideoSourceConfigurationOptions,
	eGetVideoEncoderConfigurationOptions,	
	eGetAudioSourceConfigurationOptions,
	eGetAudioEncoderConfigurationOptions,	
	eGetStreamUri,	
    eSetSynchronizationPoint,
	eGetSnapshotUri,

    // onvif media 2 service interfaces
    etr2GetVideoEncoderConfigurations,
    etr2SetVideoEncoderConfiguration,
    etr2GetVideoEncoderConfigurationOptions,
    etr2GetProfiles,
    etr2CreateProfile,
    etr2DeleteProfile,
    etr2GetStreamUri,
    etr2GetVideoSourceConfigurations,
    etr2GetVideoSourceConfigurationOptions,
    etr2SetVideoSourceConfiguration,
    etr2SetSynchronizationPoint,
    etr2GetMetadataConfigurations,
    etr2GetMetadataConfigurationOptions,
    etr2SetMetadataConfiguration,
    etr2GetAudioEncoderConfigurations,
    etr2GetAudioSourceConfigurations,
    etr2GetAudioSourceConfigurationOptions,
    etr2SetAudioSourceConfiguration,
    etr2SetAudioEncoderConfiguration,
    etr2GetAudioEncoderConfigurationOptions,
    etr2AddConfiguration,
    etr2RemoveConfiguration,
    etr2GetVideoEncoderInstances,
    
	eGetNodes,
	eGetNode,
	eGetPresets,
	eSetPreset,
	eRemovePreset,
	eGotoPreset,
	eGotoHomePosition,
	eSetHomePosition,
	eGetStatus,
	eContinuousMove,
	eRelativeMove,
	eAbsoluteMove,
	ePTZStop,
	eGetConfigurations,
	eGetConfiguration,
	eSetConfiguration,	
	eGetConfigurationOptions,
	eGetPresetTours,
	eGetPresetTour,
	eGetPresetTourOptions,
	eCreatePresetTour,
	eModifyPresetTour,
	eOperatePresetTour,
	eRemovePresetTour,

	eGetEventProperties,
	eRenew,
	eUnsubscribe,
	eSubscribe,
    eCreatePullPointSubscription,
    ePullMessages,
	
	eGetImagingSettings,
	eSetImagingSettings,
	eGetOptions,
	eimgMove,
	eimgStop,
	eimgGetStatus,
	eimgGetMoveOptions,

    // recording service interfaces
    eCreateRecording,
    eDeleteRecording,
    eGetRecordings,
    eSetRecordingConfiguration,
    eGetRecordingConfiguration,
    eGetRecordingOptions,
    eCreateTrack,
    eDeleteTrack,
    eGetTrackConfiguration,
    eSetTrackConfiguration,
    eCreateRecordingJob,
    eDeleteRecordingJob,
    eGetRecordingJobs,
    eSetRecordingJobConfiguration,
    eGetRecordingJobConfiguration,
    eSetRecordingJobMode,
    eGetRecordingJobState,
    
	eGetReplayUri,

	eGetRecordingSummary,
	eGetRecordingInformation,
	eGetMediaAttributes,
	eFindRecordings,
	eGetRecordingSearchResults,
	eFindEvents,
	eGetEventSearchResults,
	eGetSearchState,
	eEndSearch,

	eGetOSDs,
	eGetOSD,
	eSetOSD,
	eGetOSDOptions,
	eCreateOSD,
	eDeleteOSD,

	eGetVideoAnalyticsConfigurations,
	eAddVideoAnalyticsConfiguration,
	eGetVideoAnalyticsConfiguration,
	eRemoveVideoAnalyticsConfiguration,
	eSetVideoAnalyticsConfiguration,
	eGetSupportedRules,
	eCreateRules,
	eDeleteRules,
	eGetRules,
	eModifyRules,
	eCreateAnalyticsModules,
	eDeleteAnalyticsModules,
	eGetAnalyticsModules,
	eModifyAnalyticsModules,

    // profile C (access control and door control) interface
	eGetAccessPointInfoList,
    eGetAccessPointInfo,
    eGetDoorInfoList,
    eGetDoorInfo,
    eGetAreaInfoList,
    eGetAreaInfo,
    eGetAccessPointState,
    eGetDoorState,
    eAccessDoor,
    eLockDoor,
    eUnlockDoor,
    eDoubleLockDoor,
    eBlockDoor,
    eLockDownDoor,
    eLockDownReleaseDoor,
    eLockOpenDoor,
    eLockOpenReleaseDoor,
    eEnableAccessPoint,
    eDisableAccessPoint,

	eActionMax
}eOnvifAction;

typedef struct
{
	eOnvifAction	type;
	char			action_url[256];
} OVFACTS;

#ifdef __cplusplus
extern "C" {
#endif

ONVIF_API OVFACTS * onvif_find_action_by_type(eOnvifAction type);

#ifdef __cplusplus
}
#endif

#endif


