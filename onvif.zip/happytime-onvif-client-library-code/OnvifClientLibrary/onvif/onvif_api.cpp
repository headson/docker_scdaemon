/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2010-2016, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#include "onvif_api.h"
#include "onvif_cln.h"
#include "http_srv.h"
#include "onvif_event.h"
#include "onvif_utils.h"
#include "soap_parser.h"
#include "http_cln.h"


/***************************************************************************************/
ONVIF_API BOOL GetCapabilities(ONVIF_DEVICE * p_dev)
{
	GetCapabilities_RES res;
	memcpy(&res.Capabilities, &p_dev->Capabilities, sizeof(onvif_Capabilities));
	
    if (!onvif_GetCapabilities(p_dev, NULL, &res))
    {
    	return FALSE;
    }
    else
    {
    	memcpy(&p_dev->Capabilities, &res.Capabilities, sizeof(onvif_Capabilities));
    }

    return TRUE;
}

ONVIF_API BOOL GetServices(ONVIF_DEVICE * p_dev)
{
	GetServices_REQ req;
	GetServices_RES res;

	req.IncludeCapability = TRUE;
	memcpy(&res.Capabilities, &p_dev->Capabilities, sizeof(onvif_Capabilities));
	
    if (!onvif_GetServices(p_dev, &req, &res))
    {
    	return FALSE;
    }
    else
    {
    	memcpy(&p_dev->Capabilities, &res.Capabilities, sizeof(onvif_Capabilities));
    }

    return TRUE;
}

ONVIF_API BOOL GetSystemDateAndTime(ONVIF_DEVICE * p_dev)
{
	GetSystemDateAndTime_RES res;
	memset(&res, 0, sizeof(res));
	
	if (onvif_GetSystemDateAndTime(p_dev, NULL, &res) == FALSE)
	{
		return FALSE;
	}

	if (res.UTCDateTimeFlag)
	{
		char str[64];

		sprintf(str, "%04d-%02d-%02d %02d:%02d:%02d", 
			res.UTCDateTime.Date.Year, res.UTCDateTime.Date.Month, res.UTCDateTime.Date.Day,
			res.UTCDateTime.Time.Hour, res.UTCDateTime.Time.Minute, res.UTCDateTime.Time.Second);
		p_dev->devTime = get_time_by_string(str);
		p_dev->timeType = 1;
	}
	else if (res.LocalDateTimeFlag)
	{
		char str[64];

		sprintf(str, "%04d-%02d-%02d %02d:%02d:%02d", 
			res.LocalDateTime.Date.Year, res.LocalDateTime.Date.Month, res.LocalDateTime.Date.Day,
			res.LocalDateTime.Time.Hour, res.LocalDateTime.Time.Minute, res.LocalDateTime.Time.Second);
		p_dev->devTime = get_time_by_string(str);
		p_dev->timeType = 0;
	}
	else
	{
	    p_dev->devTime = 0;
	    p_dev->timeType = 0;
	}

	p_dev->getTime = time(NULL);
	
	return TRUE;
}

ONVIF_API BOOL GetDeviceInformation(ONVIF_DEVICE * p_dev)
{
	GetDeviceInformation_RES res;	
	memset(&res, 0, sizeof(res));
	
    if (!onvif_GetDeviceInformation(p_dev, NULL, &res))
    {
    	return FALSE;
    }
    else
    {
    	memcpy(&p_dev->DeviceInformation, &res.DeviceInformation, sizeof(onvif_DeviceInformation));
    }

	return TRUE;
}

ONVIF_API BOOL GetProfiles(ONVIF_DEVICE * p_dev)
{
    GetProfiles_RES res;
	memset(&res, 0, sizeof(res));
	
    if (!onvif_GetProfiles(p_dev, NULL, &res))
    {
    	return FALSE;
    }
   
    onvif_free_Profiles(&p_dev->profiles);

    p_dev->profiles = res.Profiles;

	return TRUE;
}

ONVIF_API BOOL GetStreamUris(ONVIF_DEVICE * p_dev)
{
    ONVIF_Profile * p_profile = p_dev->profiles;

    while (p_profile)
    {
        GetStreamUri_REQ req;
        GetStreamUri_RES res;

        memset(&res, 0, sizeof(res));
        
        req.StreamSetup.Transport.Protocol = TransportProtocol_RTSP;
        req.StreamSetup.Stream = StreamType_RTP_Unicast;
        strcpy(req.ProfileToken, p_profile->token);

        if (onvif_GetStreamUri(p_dev, &req, &res))
        {
            strcpy(p_profile->stream_uri, res.Uri);
        }

        p_profile = p_profile->next;
    }

    return TRUE;
}

ONVIF_API BOOL GetVideoSourceConfigurations(ONVIF_DEVICE * p_dev)
{
	GetVideoSourceConfigurations_RES res;
	memset(&res, 0, sizeof(res));
	
    if (!onvif_GetVideoSourceConfigurations(p_dev, NULL, &res))
    {
    	return FALSE;
    }
   
    onvif_free_VideoSourceConfigurations(&p_dev->video_src_cfg);

    p_dev->video_src_cfg = res.Configurations;

	return TRUE;
}

ONVIF_API BOOL GetAudioSourceConfigurations(ONVIF_DEVICE * p_dev)
{
	GetAudioSourceConfigurations_RES res;
	memset(&res, 0, sizeof(res));
	
    if (!onvif_GetAudioSourceConfigurations(p_dev, NULL, &res))
    {
    	return FALSE;
    }
   
    onvif_free_AudioSourceConfigurations(&p_dev->audio_src_cfg);

    p_dev->audio_src_cfg = res.Configurations;

	return TRUE;
}

ONVIF_API BOOL GetVideoEncoderConfigurations(ONVIF_DEVICE * p_dev)
{
	GetVideoEncoderConfigurations_RES res;
	memset(&res, 0, sizeof(res));
	
    if (!onvif_GetVideoEncoderConfigurations(p_dev, NULL, &res))
    {
    	return FALSE;
    }
   
    onvif_free_VideoEncoderConfigurations(&p_dev->video_enc);

    p_dev->video_enc = res.Configurations;

	return TRUE;
}

ONVIF_API BOOL GetAudioEncoderConfigurations(ONVIF_DEVICE * p_dev)
{
	GetAudioEncoderConfigurations_RES res;
	memset(&res, 0, sizeof(res));
	
    if (!onvif_GetAudioEncoderConfigurations(p_dev, NULL, &res))
    {
    	return FALSE;
    }
   
    onvif_free_AudioEncoderConfigurations(&p_dev->audio_enc);

    p_dev->audio_enc = res.Configurations;

	return TRUE;
}

ONVIF_API BOOL GetNodes(ONVIF_DEVICE * p_dev)
{
	GetNodes_RES res;
	memset(&res, 0, sizeof(res));
	
	if (p_dev->Capabilities.ptz.support == 0)
	{
		return FALSE;
	}
	
    if (!onvif_GetNodes(p_dev, NULL, &res))
    {
    	return FALSE;
    }

    onvif_free_PTZNodes(&p_dev->ptznodes);

    p_dev->ptznodes = res.PTZNode;

	return TRUE;
}

ONVIF_API BOOL GetConfigurations(ONVIF_DEVICE * p_dev)
{
	GetConfigurations_RES res;
	memset(&res, 0, sizeof(res));
	
    if (p_dev->Capabilities.ptz.support == 0)
	{
		return FALSE;
	}
	
    if (!onvif_GetConfigurations(p_dev, NULL, &res))
    {
    	return FALSE;
    }

    onvif_free_PTZConfigurations(&p_dev->ptz_cfg);

    p_dev->ptz_cfg = res.PTZConfiguration;

	return TRUE;
}

ONVIF_API BOOL GetVideoSources(ONVIF_DEVICE * p_dev)
{
    GetVideoSources_RES res;
	memset(&res, 0, sizeof(res));
	
    if (!onvif_GetVideoSources(p_dev, NULL, &res))
    {
    	return FALSE;
    }

    onvif_free_VideoSources(&p_dev->video_src);

    p_dev->video_src = res.VideoSources;

	return TRUE;
}

ONVIF_API BOOL GetAudioSources(ONVIF_DEVICE * p_dev)
{
    GetAudioSources_RES res;
	memset(&res, 0, sizeof(res));
	
    if (!onvif_GetAudioSources(p_dev, NULL, &res))
    {
    	return FALSE;
    }

    onvif_free_AudioSources(&p_dev->audio_src);

    p_dev->audio_src = res.AudioSources;

	return TRUE;
}

ONVIF_API BOOL GetImagingSettings(ONVIF_DEVICE * p_dev)
{
	ONVIF_VideoSource * p_v_src;
	
    if (p_dev->Capabilities.image.support == 0)
	{
		return FALSE;
	}

	p_v_src = p_dev->video_src;

    while (p_v_src)
    {
        GetImagingSettings_REQ req;
		GetImagingSettings_RES res;

        memset(&req, 0, sizeof(req));
        memset(&res, 0, sizeof(res));
        
		strcpy(req.VideoSourceToken, p_v_src->VideoSource.token);
		
	    if (onvif_GetImagingSettings(p_dev, &req, &res))
	    {
			memcpy(&p_v_src->VideoSource.ImagingSettings, &res.ImagingSettings, sizeof(onvif_ImagingSettings));
	    }

        p_v_src = p_v_src->next;
    }	

	return TRUE;
}

ONVIF_API BOOL Subscribe(ONVIF_DEVICE * p_dev, int index)
{
	int port;
	struct in_addr addr;
	Subscribe_REQ req;
	Subscribe_RES res;
	
    if (p_dev->local_ip == 0)
    {
        p_dev->local_ip = get_default_if_ip();
    }

    port = 30100+index;

    addr.s_addr = p_dev->local_ip;
    
    sprintf(p_dev->events.reference_addr, "http://%s:%d/subscription%d", inet_ntoa(addr), port, index);
    
    if (http_srv_init(&p_dev->events.http_srv, p_dev->local_ip, port, 2) < 0)
    {
        return FALSE;
    }

    memset(&req, 0, sizeof(req));
    memset(&res, 0, sizeof(res));
    
	req.InitialTerminationTime = p_dev->events.init_term_time;
    strcpy(req.ConsumerReference, p_dev->events.reference_addr);	
	
    if (onvif_Subscribe(p_dev, &req, &res) == FALSE)
    {
    	http_srv_deinit(&p_dev->events.http_srv);
        return FALSE;
    }
    
	strcpy(p_dev->events.producter_addr, res.producter_addr);
	
    p_dev->events.subscribe = TRUE;
    
    onvif_event_timer_init(p_dev);
    
    return TRUE;
}

ONVIF_API BOOL Unsubscribe(ONVIF_DEVICE * p_dev)
{
    onvif_event_timer_deinit(p_dev);
    
    http_srv_deinit(&p_dev->events.http_srv);
    
    onvif_Unsubscribe(p_dev, NULL, NULL);

    p_dev->events.subscribe = FALSE;
    
    return TRUE;
}

ONVIF_API BOOL GetSnapshot(ONVIF_DEVICE * p_dev, const char * profile_token, unsigned char ** p_buf, int * buflen)
{
	if (NULL == profile_token)
	{
		return FALSE;
	}

	GetSnapshotUri_REQ req;
	GetSnapshotUri_RES res;
	
	strcpy(req.ProfileToken, profile_token);
	memset(&res, 0, sizeof(res));	
	
	if (FALSE == onvif_GetSnapshotUri(p_dev, &req, &res))
	{
		return FALSE;
	}

	onvif_parse_uri(res.Uri, res.Uri, sizeof(res.Uri));

	HTTPREQ http_req;
	memset(&http_req, 0, sizeof(http_req));

	onvif_XAddr xaddr;
	memset(&xaddr, 0, sizeof(xaddr));
	parse_XAddr(res.Uri, &xaddr);

	http_req.https = xaddr.https;
	http_req.port = xaddr.port;
	strcpy(http_req.host, xaddr.host);	
	strcpy(http_req.url, xaddr.url);
	strcpy(http_req.user, p_dev->username);
	strcpy(http_req.pass, p_dev->password);

	return http_onvif_download(&http_req, 60000, p_buf, buflen);
}

ONVIF_API void FreeSnapshotBuff(unsigned char * p_buf)
{
	if (p_buf)
	{
		free(p_buf);
	}
}

ONVIF_API BOOL FirmwareUpgrade(ONVIF_DEVICE * p_dev, const char * filename)
{	
	StartFirmwareUpgrade_RES res;
    memset(&res, 0, sizeof(res));
    
	if (FALSE == onvif_StartFirmwareUpgrade(p_dev, NULL, &res))
	{
	    return FALSE;
	}

	onvif_parse_uri(res.UploadUri, res.UploadUri, sizeof(res.UploadUri));
	
	HTTPREQ req;
	memset(&req, 0, sizeof(req));

	onvif_XAddr xaddr;
	memset(&xaddr, 0, sizeof(xaddr));
	parse_XAddr(res.UploadUri, &xaddr);

	req.https = xaddr.https;
	req.port = xaddr.port;
	strcpy(req.host, xaddr.host);	
	strcpy(req.url, xaddr.url);
	strcpy(req.user, p_dev->username);
	strcpy(req.pass, p_dev->password);
	
	if (http_onvif_file_upload(&req, 60000, filename))
	{
	    return TRUE;
	}
	else
	{		
	    return FALSE;
	}
}

ONVIF_API BOOL SystemBackup(ONVIF_DEVICE * p_dev, const char * filename)
{
	GetSystemUris_RES res;
	memset(&res, 0, sizeof(res));	
	
	if (FALSE == onvif_GetSystemUris(p_dev, NULL, &res))
	{
		return FALSE;
	}

	if (0 == res.SystemBackupUriFlag)
	{
	    return FALSE;
	}

	onvif_parse_uri(res.SystemBackupUri, res.SystemBackupUri, sizeof(res.SystemBackupUri));

	HTTPREQ http_req;
	memset(&http_req, 0, sizeof(http_req));

	onvif_XAddr xaddr;
	memset(&xaddr, 0, sizeof(xaddr));
	parse_XAddr(res.SystemBackupUri, &xaddr);

	http_req.https = xaddr.https;
	http_req.port = xaddr.port;
	strcpy(http_req.host, xaddr.host);	
	strcpy(http_req.url, xaddr.url);
	strcpy(http_req.user, p_dev->username);
	strcpy(http_req.pass, p_dev->password);

    int buflen = 0;
    unsigned char * p_buf = NULL;

	if (http_onvif_download(&http_req, 60000, &p_buf, &buflen) == FALSE)
	{
	    return FALSE;
	}

    if (NULL == p_buf)
    {
        return FALSE;
    }

    FILE * fp = fopen(filename, "wb");
    if (fp)
    {
        fwrite(p_buf, 1, buflen, fp);
        fclose(fp);
    }
    else
    {
        free(p_buf);
        return FALSE;
    }

    free(p_buf);

	return TRUE;
}

ONVIF_API BOOL SystemRestore(ONVIF_DEVICE * p_dev, const char * filename)
{
    StartSystemRestore_RES res;
    memset(&res, 0, sizeof(res));
    
	if (FALSE == onvif_StartSystemRestore(p_dev, NULL, &res))
	{
	    return FALSE;
	}

	onvif_parse_uri(res.UploadUri, res.UploadUri, sizeof(res.UploadUri));
	
	HTTPREQ req;
	memset(&req, 0, sizeof(req));

	onvif_XAddr xaddr;
	memset(&xaddr, 0, sizeof(xaddr));
	parse_XAddr(res.UploadUri, &xaddr);

	req.https = xaddr.https;
	req.port = xaddr.port;
	strcpy(req.host, xaddr.host);	
	strcpy(req.url, xaddr.url);
	strcpy(req.user, p_dev->username);
	strcpy(req.pass, p_dev->password);
	
	if (http_onvif_file_upload(&req, 60000, filename))
	{
	    return TRUE;
	}
	else
	{		
	    return FALSE;
	}
}



