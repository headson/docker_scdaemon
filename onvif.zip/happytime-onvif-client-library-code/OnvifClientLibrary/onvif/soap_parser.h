/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2010-2016, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#ifndef SOAP_PARSER_H
#define SOAP_PARSER_H

#include "sys_inc.h"
#include "onvif.h"
#include "xml_node.h"
#include "onvif_res.h"

#ifdef __cplusplus
extern "C" {
#endif

ONVIF_API BOOL parse_Bool(const char * pdata);
ONVIF_API int  parse_XAddr(const char * pdata, onvif_XAddr * p_xaddr);
ONVIF_API int  parse_DeviceType(const char * pdata);

BOOL parse_Fault(XMLN * p_node, onvif_Fault * p_res);

BOOL parse_Profile(XMLN * p_node, ONVIF_Profile * p_profile);
BOOL parse_VideoSourceConfiguration(XMLN * p_node, onvif_VideoSourceConfiguration * p_res);
BOOL parse_AudioSourceConfiguration(XMLN * p_node, onvif_AudioSourceConfiguration * p_res);
BOOL parse_VideoEncoderConfiguration(XMLN * p_node, onvif_VideoEncoderConfiguration * p_res);
BOOL parse_AudioEncoderConfiguration(XMLN * p_node, onvif_AudioEncoderConfiguration * p_res);
BOOL parse_PTZConfiguration(XMLN * p_node, onvif_PTZConfiguration * p_res);
BOOL parse_PTZNode(XMLN * p_node, onvif_PTZNode * p_res);
BOOL parse_Preset(XMLN * p_node, onvif_PTZPreset * p_res);
BOOL parse_NetworkInterface(XMLN * p_node, onvif_NetworkInterface * p_net_inf);
BOOL parse_ImagingSettings(XMLN * p_node, onvif_ImagingSettings * p_res);
BOOL parse_VideoSource(XMLN * p_node, onvif_VideoSource * p_res);
BOOL parse_AudioSource(XMLN * p_node, onvif_AudioSource * p_res);

BOOL parse_SetNetworkInterfaces(XMLN * p_node, SetNetworkInterfaces_RES * p_res);
BOOL parse_GetCapabilities(XMLN * p_node, GetCapabilities_RES * p_res);
BOOL parse_GetDeviceInformation(XMLN * p_node, GetDeviceInformation_RES * p_res);
BOOL parse_GetStreamUri(XMLN * p_node, GetStreamUri_RES * p_res);

BOOL parse_GetConfigurationOptions(XMLN * p_node, GetConfigurationOptions_RES * p_res);
BOOL parse_SetHostnameFromDHCP(XMLN * p_node, SetHostnameFromDHCP_RES * p_res);
BOOL parse_GetNTP(XMLN * p_node, GetNTP_RES * p_res);
BOOL parse_GetHostname(XMLN * p_node, GetHostname_RES * p_res);
BOOL parse_GetDNS(XMLN * p_node, GetDNS_RES * p_res);
BOOL parse_GetDynamicDNS(XMLN * p_node, GetDynamicDNS_RES * p_res);
BOOL parse_GetNetworkProtocols(XMLN * p_node, GetNetworkProtocols_RES * p_res);
BOOL parse_GetDiscoveryMode(XMLN * p_node, GetDiscoveryMode_RES * p_res);
BOOL parse_GetNetworkDefaultGateway(XMLN * p_node, GetNetworkDefaultGateway_RES * p_res);
BOOL parse_GetZeroConfiguration(XMLN * p_node, GetZeroConfiguration_RES * p_res);
BOOL parse_GetSnapshotUri(XMLN * p_node, GetSnapshotUri_RES * p_res);
BOOL parse_GetVideoSourceConfigurationOptions(XMLN * p_node, GetVideoSourceConfigurationOptions_RES * p_res);
BOOL parse_GetVideoEncoderConfigurationOptions(XMLN * p_node, GetVideoEncoderConfigurationOptions_RES * p_res);
BOOL parse_GetAudioEncoderConfigurationOptions(XMLN * p_node, GetAudioEncoderConfigurationOptions_RES * p_res);
BOOL parse_SetPreset(XMLN * p_node, SetPreset_RES * p_res);
BOOL parse_GetStatus(XMLN * p_node, GetStatus_RES * p_res);
BOOL parse_GetSystemDateAndTime(XMLN * p_node, GetSystemDateAndTime_RES * p_res);
BOOL parse_GetOptions(XMLN * p_node, GetOptions_RES * p_res);
BOOL parse_img_GetStatus(XMLN * p_node, img_GetStatus_RES * p_res);
BOOL parse_img_GetMoveOptions(XMLN * p_node, img_GetMoveOptions_RES * p_res);
BOOL parse_Subscribe(XMLN * p_node, Subscribe_RES * p_res);
BOOL parse_NotificationMessage(XMLN * p_node, onvif_NotificationMessage * p_res);
BOOL parse_CreatePullPointSubscription(XMLN * p_node, CreatePullPointSubscription_RES * p_res);
BOOL parse_NotifyMessage(XMLN * p_node, ONVIF_NotificationMessage ** p_res);
BOOL parse_PullMessages(XMLN * p_node, PullMessages_RES * p_res);

BOOL parse_DeviceService(XMLN * p_node, onvif_DevicesCapabilities * p_cap);
BOOL parse_MediaService(XMLN * p_node, onvif_MediaCapabilities * p_cap);
BOOL parse_MediaService2(XMLN * p_node, onvif_MediaCapabilities2 * p_cap);
BOOL parse_EventsService(XMLN * p_node, onvif_EventCapabilities * p_cap);
BOOL parse_PTZService(XMLN * p_node, onvif_PTZCapabilities * p_cap);
BOOL parse_ImagingService(XMLN * p_node, onvif_ImagingCapabilities * p_cap);
BOOL parse_RecordingService(XMLN * p_node, onvif_RecordingCapabilities * p_cap);
BOOL parse_SearchService(XMLN * p_node, onvif_SearchCapabilities * p_cap);
BOOL parse_ReplayService(XMLN * p_node, onvif_ReplayCapabilities * p_cap);
BOOL parse_AnalyticsService(XMLN * p_node, onvif_AnalyticsCapabilities * p_cap);
BOOL parse_AccessControlService(XMLN * p_node, onvif_AccessControlCapabilities * p_cap);
BOOL parse_DoorControlService(XMLN * p_node, onvif_DoorControlCapabilities * p_cap);

BOOL parse_StartFirmwareUpgrade(XMLN * p_node, StartFirmwareUpgrade_RES * p_res);
BOOL parse_GetSystemUris(XMLN * p_node, GetSystemUris_RES * p_res);
BOOL parse_StartSystemRestore(XMLN * p_node, StartSystemRestore_RES * p_res);
BOOL parse_User(XMLN * p_node, onvif_User * p_user);
BOOL parse_GetRemoteUser(XMLN * p_node, GetRemoteUser_RES * p_res);

BOOL parse_SetVideoSourceMode(XMLN * p_node, SetVideoSourceMode_RES * p_res);
BOOL parse_VideoSourceMode(XMLN * p_node, onvif_VideoSourceMode * p_res);

BOOL parse_OSDConfiguration(XMLN * p_node, onvif_OSDConfiguration * p_res);
BOOL parse_GetOSDOptions(XMLN * p_node, GetOSDOptions_RES * p_res);
BOOL parse_CreateOSD(XMLN * p_node, CreateOSD_RES * p_res);

BOOL parse_VideoAnalyticsConfiguration(XMLN * p_node, onvif_VideoAnalyticsConfiguration * p_req);
BOOL parse_GetVideoAnalyticsConfigurations(XMLN * p_node, GetVideoAnalyticsConfigurations_RES * p_res);
BOOL parse_GetRules(XMLN * p_node, GetRules_RES * p_res);
BOOL parse_GetAnalyticsModules(XMLN * p_node, GetAnalyticsModules_RES * p_res);
BOOL parse_GetSupportedRules(XMLN * p_node, GetSupportedRules_RES * p_res);

BOOL parse_GetScopes(XMLN * p_node, GetScopes_RES * p_res);
BOOL parse_GetEndpointReference(XMLN * p_node, GetEndpointReference_RES * p_res);

BOOL parse_GetPresetTours(XMLN * p_node, GetPresetTours_RES * p_res);
BOOL parse_GetPresetTour(XMLN * p_node, GetPresetTour_RES * p_res);
BOOL parse_GetPresetTourOptions(XMLN * p_node, GetPresetTourOptions_RES * p_res);
BOOL parse_CreatePresetTour(XMLN * p_node, CreatePresetTour_RES * p_res);

BOOL parse_VideoEncoder2Configuration(XMLN * p_node, onvif_VideoEncoder2Configuration * p_req);
BOOL parse_tr2_GetVideoEncoderConfigurationOptions(XMLN * p_node, tr2_GetVideoEncoderConfigurationOptions_RES * p_res);
BOOL parse_tr2_CreateProfile(XMLN * p_node, tr2_CreateProfile_RES * p_res);
BOOL parse_tr2_GetStreamUri(XMLN * p_node, tr2_GetStreamUri_RES * p_res);
BOOL parse_MetadataConfiguration(XMLN * p_node, onvif_MetadataConfiguration * p_req);
BOOL parse_AudioEncoder2Configuration(XMLN * p_node, onvif_AudioEncoder2Configuration * p_req);
BOOL parse_tr2_GetAudioEncoderConfigurationOptions(XMLN * p_node, tr2_GetAudioEncoderConfigurationOptions_RES * p_res);
BOOL parse_tr2_GetVideoEncoderInstances(XMLN * p_node, tr2_GetVideoEncoderInstances_RES * p_res);
BOOL parse_MediaProfile(XMLN * p_node, onvif_MediaProfile * p_req);

BOOL parse_CreateRecording(XMLN * p_node, CreateRecording_RES * p_res);
BOOL parse_GetRecordings(XMLN * p_node, GetRecordings_RES * p_res);
BOOL parse_GetRecordingConfiguration(XMLN * p_node, GetRecordingConfiguration_RES * p_res);
BOOL parse_GetRecordingOptions(XMLN * p_node, GetRecordingOptions_RES * p_res);
BOOL parse_CreateTrack(XMLN * p_node, CreateTrack_RES * p_res);
BOOL parse_GetTrackConfiguration(XMLN * p_node, GetTrackConfiguration_RES * p_res);
BOOL parse_CreateRecordingJob(XMLN * p_node, CreateRecordingJob_RES * p_res);
BOOL parse_GetRecordingJobs(XMLN * p_node, GetRecordingJobs_RES * p_res);
BOOL parse_SetRecordingJobConfiguration(XMLN * p_node, SetRecordingJobConfiguration_RES * p_res);
BOOL parse_GetRecordingJobConfiguration(XMLN * p_node, GetRecordingJobConfiguration_RES * p_res);
BOOL parse_GetRecordingJobState(XMLN * p_node, GetRecordingJobState_RES * p_res);

BOOL parse_GetReplayUri(XMLN * p_node, GetReplayUri_RES * p_res);
BOOL parse_GetRecordingSummary(XMLN * p_node, GetRecordingSummary_RES * p_res);
BOOL parse_GetRecordingInformation(XMLN * p_node, GetRecordingInformation_RES * p_res);
BOOL parse_GetMediaAttributes(XMLN * p_node, GetMediaAttributes_RES * p_res);
BOOL parse_FindRecordings(XMLN * p_node, FindRecordings_RES * p_res);
BOOL parse_GetRecordingSearchResults(XMLN * p_node, GetRecordingSearchResults_RES * p_res);
BOOL parse_FindEvents(XMLN * p_node, FindEvents_RES * p_res);
BOOL parse_GetSearchState(XMLN * p_node, GetSearchState_RES * p_res);
BOOL parse_EndSearch(XMLN * p_node, EndSearch_RES * p_res);

BOOL parse_GetAccessPointInfoList(XMLN * p_node, GetAccessPointInfoList_RES * p_res);
BOOL parse_GetAccessPointInfo(XMLN * p_node, GetAccessPointInfo_RES * p_res);
BOOL parse_GetDoorInfoList(XMLN * p_node, GetDoorInfoList_RES * p_res);
BOOL parse_GetDoorInfo(XMLN * p_node, GetDoorInfo_RES * p_res);
BOOL parse_GetAreaInfoList(XMLN * p_node, GetAreaInfoList_RES * p_res);
BOOL parse_GetAreaInfo(XMLN * p_node, GetAreaInfo_RES * p_res);
BOOL parse_GetAccessPointState(XMLN * p_node, GetAccessPointState_RES * p_res);
BOOL parse_GetDoorState(XMLN * p_node, GetDoorState_RES * p_res);

#ifdef __cplusplus
}
#endif

#endif


