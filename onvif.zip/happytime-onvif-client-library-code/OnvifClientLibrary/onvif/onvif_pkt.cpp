/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2010-2016, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#include "sys_inc.h"
#include "onvif_pkt.h"
#include "sha1.h"
#include "onvif_utils.h"
#include "onvif.h"
#include "onvif_req.h"
#include "base64.h"
#include "onvif_api.h"


/***************************************************************************************/
static const char xml_hdr[] = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";

static const char onvif_xmlns[] = 
	"<s:Envelope "
	"xmlns:s=\"http://www.w3.org/2003/05/soap-envelope\" " 
	"xmlns:enc=\"http://www.w3.org/2003/05/soap-encoding\" " 
	"xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" " 
	"xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" " 
	"xmlns:wsa=\"http://www.w3.org/2005/08/addressing\" "	
	"xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\" " 
	"xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\" " 
	"xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\" " 
	"xmlns:wsnt=\"http://docs.oasis-open.org/wsn/b-2\" "
	"xmlns:tt=\"http://www.onvif.org/ver10/schema\" " 
	"xmlns:tds=\"http://www.onvif.org/ver10/device/wsdl\" "
	"xmlns:trt=\"http://www.onvif.org/ver10/media/wsdl\" " 
	"xmlns:tr2=\"http://www.onvif.org/ver20/media/wsdl\" " 
	"xmlns:tev=\"http://www.onvif.org/ver10/events/wsdl\" "
    "xmlns:tptz=\"http://www.onvif.org/ver20/ptz/wsdl\" "
    "xmlns:timg=\"http://www.onvif.org/ver20/imaging/wsdl\" "
    "xmlns:tan=\"http://www.onvif.org/ver20/analytics/wsdl\" "
#ifdef PROFILE_G_SUPPORT    
    "xmlns:trp=\"http://www.onvif.org/ver10/replay/wsdl\" "
    "xmlns:tse=\"http://www.onvif.org/ver10/search/wsdl\" "
    "xmlns:trc=\"http://www.onvif.org/ver10/recording/wsdl\" "
#endif    
#ifdef PROFILE_C_SUPPORT
    "xmlns:tac=\"http://www.onvif.org/ver10/accesscontrol/wsdl\" "
    "xmlns:tdc=\"http://www.onvif.org/ver10/doorcontrol/wsdl\" "
    "xmlns:pt=\"http://www.onvif.org/ver10/pacs\" "
#endif
	"xmlns:ter=\"http://www.onvif.org/ver10/error\" >";

static const char soap_body[] = 
    "<s:Body>";

static const char soap_tailer[] =
    "</s:Body></s:Envelope>";

    
/***************************************************************************************/
#define NONCELEN	20
#define SHA1_SIZE	20

void onvif_calc_nonce(char nonce[NONCELEN])
{ 
	static int count = 0xCA53;
  	char buf[NONCELEN + 1];
  	
  	/* we could have used raw binary instead of hex as below */
  	sprintf(buf, "%8.8x%4.4hx%8.8x", (int)time(NULL), count++, (int)rand());
  	memcpy(nonce, buf, NONCELEN);
}

void onvif_calc_digest(const char *created, const char *nonce, int noncelen, const char *password, char hash[SHA1_SIZE])
{
	sha1_context ctx;
	
	sha1_starts(&ctx);
	sha1_update(&ctx, (unsigned char *)nonce, noncelen);
	sha1_update(&ctx, (unsigned char *)created, strlen(created));
	sha1_update(&ctx, (unsigned char *)password, strlen(password));
	sha1_finish(&ctx, (unsigned char *)hash);
}

int build_onvif_req_header(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, const char * to)
{
	int offset = 0;
	
	if (p_dev->needAuth && p_dev->username[0] != '\0' && p_dev->password[0] != '\0')
	{
		char HA[SHA1_SIZE], HABase64[100];
		char nonce[NONCELEN], nonceBase64[100];
		char created[64] = {'\0'};
		time_t curtime = time(NULL);
		time_t createdtime;

		if (curtime - p_dev->getTime > 60)
		{
			// Prevents circular calls
			p_dev->getTime = curtime;
				
			GetSystemDateAndTime(p_dev);
		}

		if (p_dev->devTime != 0)
		{
		    createdtime = p_dev->devTime + (curtime - p_dev->getTime);
		}
		else
		{
		    createdtime = curtime;
		}

		onvif_format_datetime_str(createdtime, p_dev->timeType ? 0 : 1, "%Y-%m-%dT%H:%M:%SZ", created, sizeof(created));

		onvif_calc_nonce(nonce);

		base64_encode((unsigned char*)nonce, NONCELEN, nonceBase64, sizeof(nonceBase64));

		onvif_calc_digest(created, nonce, NONCELEN, p_dev->password, HA);

		base64_encode((unsigned char*)HA, SHA1_SIZE, HABase64, sizeof(HABase64));

        offset += snprintf(p_buf+offset, mlen-offset, "<s:Header>");
        if (to != NULL)
        {
            offset += snprintf(p_buf+offset, mlen-offset, "<wsa:To>%s</wsa:To>", to);
        }
		offset += snprintf(p_buf+offset, mlen-offset, "<wsse:Security>"
        	"<wsse:UsernameToken>"
        	"<wsse:Username>%s</wsse:Username>"
        	"<wsse:Password "
        	"Type=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest\">"
        	"%s</wsse:Password>"
        	"<wsse:Nonce>%s</wsse:Nonce>"
        	"<wsu:Created>%s</wsu:Created>"
        	"</wsse:UsernameToken>"
        	"</wsse:Security>", p_dev->username, HABase64, nonceBase64, created);
		offset += snprintf(p_buf+offset, mlen-offset, "</s:Header>");
	}
	else if (to != NULL)
	{
	    offset += snprintf(p_buf+offset, mlen-offset, "<s:Header>");
	    offset += snprintf(p_buf+offset, mlen-offset, "<wsa:To>%s</wsa:To>", to);
	    offset += snprintf(p_buf+offset, mlen-offset, "</s:Header>");
	}

	return offset;
}

int build_onvif_req_header_ex(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, const char * to, const char * action)
{
	int offset = 0;
	char uuid[100] = {'\0'};
	
	if (p_dev->username[0] != '\0' && p_dev->password[0] != '\0')
	{
		char HA[SHA1_SIZE], HABase64[100];
		char nonce[NONCELEN], nonceBase64[100];		
        char created[64] = {'\0'};        
		time_t curtime = time(NULL);
		time_t createdtime;

		if (curtime - p_dev->getTime > 60)
		{
			// Prevents circular calls
			p_dev->getTime = curtime;
				
			GetSystemDateAndTime(p_dev);
		}

		if (p_dev->devTime != 0)
		{
		    createdtime = p_dev->devTime + (curtime - p_dev->getTime);
		}
		else
		{
		    createdtime = curtime;
		}

		onvif_format_datetime_str(createdtime, p_dev->timeType ? 0 : 1, "%Y-%m-%dT%H:%M:%SZ", created, sizeof(created));

		onvif_calc_nonce(nonce);

		base64_encode((unsigned char*)nonce, NONCELEN, nonceBase64, sizeof(nonceBase64));

		onvif_calc_digest(created, nonce, NONCELEN, p_dev->password, HA);

		base64_encode((unsigned char*)HA, SHA1_SIZE, HABase64, sizeof(HABase64));

        offset += snprintf(p_buf+offset, mlen-offset, "<s:Header>");
        offset += snprintf(p_buf+offset, mlen-offset, "<wsa:Action>%s</wsa:Action>", action);
        offset += snprintf(p_buf+offset, mlen-offset, "<wsa:MessageID>urn:uuid:%s</wsa:MessageID>", onvif_uuid_create(uuid, sizeof(uuid)));
        offset += snprintf(p_buf+offset, mlen-offset, "<wsa:ReplyTo><wsa:Address>http://www.w3.org/2005/08/addressing/anonymous</wsa:Address></wsa:ReplyTo>");
        if (to != NULL)
        {
            offset += snprintf(p_buf+offset, mlen-offset, "<wsa:To>%s</wsa:To>", to);
        }
		offset += snprintf(p_buf+offset, mlen-offset, "<wsse:Security>"
        	"<wsse:UsernameToken>"
        	"<wsse:Username>%s</wsse:Username>"
        	"<wsse:Password "
        	"Type=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest\">"
        	"%s</wsse:Password>"
        	"<wsse:Nonce>%s</wsse:Nonce>"
        	"<wsu:Created>%s</wsu:Created>"
        	"</wsse:UsernameToken>"
        	"</wsse:Security>", p_dev->username, HABase64, nonceBase64, created);
		offset += snprintf(p_buf+offset, mlen-offset, "</s:Header>");
	}
	else if (to != NULL)
	{
	    offset += snprintf(p_buf+offset, mlen-offset, "<s:Header>");
	    offset += snprintf(p_buf+offset, mlen-offset, "<wsa:Action>%s</wsa:Action>", action);
        offset += snprintf(p_buf+offset, mlen-offset, "<wsa:MessageID>urn:uuid:%s</wsa:MessageID>", onvif_uuid_create(uuid, sizeof(uuid)));
        offset += snprintf(p_buf+offset, mlen-offset, "<wsa:ReplyTo><wsa:Address>http://www.w3.org/2005/08/addressing/anonymous</wsa:Address></wsa:ReplyTo>");
	    offset += snprintf(p_buf+offset, mlen-offset, "<wsa:To>%s</wsa:To>", to);
	    offset += snprintf(p_buf+offset, mlen-offset, "</s:Header>");
	}

	return offset;
}


/***************************************************************************************/
int build_GetCapabilities_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	GetCapabilities_REQ * p_req = (GetCapabilities_REQ *) argv;
	
    int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tds:GetCapabilities>"
			"<tds:Category>%s</tds:Category>"
		"</tds:GetCapabilities>", 
	    p_req ? onvif_CapabilityCategoryToString(p_req->Category) : "All");
	    
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_GetServices_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    GetServices_REQ * p_req = (GetServices_REQ *) argv;
	
    int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tds:GetServices>"
			"<tds:IncludeCapability>%s</tds:IncludeCapability>"
		"</tds:GetServices>", 
	    p_req ? (p_req->IncludeCapability ? "true" : "false") : "false");
	    
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_GetDeviceInformation_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:GetDeviceInformation />");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_User_xml(char * p_buf, int mlen, onvif_User * p_req)
{
	int offset = 0;

	offset = snprintf(p_buf, mlen, 
		"<tds:User>"
			"<tt:Username>%s</tt:Username>"
			"<tt:Password>%s</tt:Password>"
			"<tt:UserLevel>%s</tt:UserLevel>"
		"</tds:User>",
		p_req->Username,
		p_req->Password,
		onvif_UserLevelToString(p_req->UserLevel));

	return offset;		
}

int build_GetUsers_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:GetUsers />");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_CreateUsers_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset = snprintf(p_buf, mlen, xml_hdr);
	CreateUsers_REQ * p_req = (CreateUsers_REQ *) argv;
    assert(p_req);
    
	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:CreateUsers>");
	offset += build_User_xml(p_buf+offset, mlen-offset, &p_req->User);
	offset += snprintf(p_buf+offset, mlen-offset, "</tds:CreateUsers>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_DeleteUsers_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset = snprintf(p_buf, mlen, xml_hdr);
	DeleteUsers_REQ * p_req = (DeleteUsers_REQ *) argv;
    assert(p_req);
    
	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:DeleteUsers>");
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:Username>%s</tds:Username>", p_req->Username);	
	offset += snprintf(p_buf+offset, mlen-offset, "</tds:DeleteUsers>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_SetUser_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset = snprintf(p_buf, mlen, xml_hdr);
	SetUser_REQ * p_req = (SetUser_REQ *) argv;
    assert(p_req);
    
	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:SetUser>");
	offset += build_User_xml(p_buf+offset, mlen-offset, &p_req->User);
	offset += snprintf(p_buf+offset, mlen-offset, "</tds:SetUser>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetRemoteUser_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:GetRemoteUser />");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_SetRemoteUser_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset = snprintf(p_buf, mlen, xml_hdr);
    SetRemoteUser_REQ * p_req = (SetRemoteUser_REQ *) argv;
    assert(p_req);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:SetRemoteUser>");

	if (p_req->RemoteUserFlag)
	{
	    offset += snprintf(p_buf+offset, mlen-offset, "<tds:RemoteUser>");
	    
    	offset += snprintf(p_buf+offset, mlen-offset, "<tt:Username>%s<tt:Username>", p_req->RemoteUser.Username);
    	
    	if (p_req->RemoteUser.PasswordFlag)
    	{
    	    offset += snprintf(p_buf+offset, mlen-offset, "<tt:Password>%s<tt:Password>", p_req->RemoteUser.Password);
    	}

	    offset += snprintf(p_buf+offset, mlen-offset, "<tt:UseDerivedPassword>%s<tt:UseDerivedPassword>", 
	        p_req->RemoteUser.UseDerivedPassword ? "true" : "false");
    	    
    	offset += snprintf(p_buf+offset, mlen-offset, "</tds:RemoteUser>");
	}
	
	offset += snprintf(p_buf+offset, mlen-offset, "</tds:SetRemoteUser>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_GetNetworkInterfaces_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:GetNetworkInterfaces />");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_Dot11Configuration_xml(char * p_buf, int mlen, onvif_Dot11Configuration * p_req)
{
    int offset = 0;

    offset += snprintf(p_buf+offset, mlen-offset, 
        "<tt:SSID>%s</tt:SSID>"
        "<tt:Mode>%s</tt:Mode>"
        "<tt:Alias>%s</tt:Alias>"
        "<tt:Priority>%d</tt:Priority>", 
        p_req->SSID,
        onvif_Dot11StationModeToString(p_req->Mode),
        p_req->Alias,
        p_req->Priority);

    offset += snprintf(p_buf+offset, mlen-offset, "<tt:Security>");
    
    offset += snprintf(p_buf+offset, mlen-offset, "<tt:Mode>%s</tt:Mode>", 
        onvif_Dot11SecurityModeToString(p_req->Security.Mode));

    if (p_req->Security.AlgorithmFlag)
    {
        offset += snprintf(p_buf+offset, mlen-offset, "<tt:Algorithm>%s</tt:Algorithm>", 
            onvif_Dot11CipherToString(p_req->Security.Algorithm));
    }

    if (p_req->Security.PSKFlag)
    {
        offset += snprintf(p_buf+offset, mlen-offset, "<tt:PSK>");
        
        if (p_req->Security.PSK.KeyFlag)
        {
            offset += snprintf(p_buf+offset, mlen-offset, "<tt:Key>%s</tt:Key>", p_req->Security.PSK.Key);
        }

        if (p_req->Security.PSK.PassphraseFlag)
        {
            offset += snprintf(p_buf+offset, mlen-offset, "<tt:Passphrase>%s</tt:Passphrase>", p_req->Security.PSK.Passphrase);
        }
        
        offset += snprintf(p_buf+offset, mlen-offset, "</tt:PSK>");
    }

    if (p_req->Security.Dot1XFlag)
    {
        offset += snprintf(p_buf+offset, mlen-offset, "<tt:Dot1X>%s</tt:Dot1X>", p_req->Security.Dot1X);
    }
    
    offset += snprintf(p_buf+offset, mlen-offset, "</tt:Security>");
    return offset;
}

int build_SetNetworkInterfaces_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int i;
	int offset;
	SetNetworkInterfaces_REQ * p_req = (SetNetworkInterfaces_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);
	
	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:SetNetworkInterfaces>");
    offset += snprintf(p_buf+offset, mlen-offset, 
    	"<tds:InterfaceToken>%s</tds:InterfaceToken>", 
    	p_req->NetworkInterface.token);

	offset += snprintf(p_buf+offset, mlen-offset, "<tds:NetworkInterface>");
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tt:Enabled>%s</tt:Enabled>", 
		p_req->NetworkInterface.Enabled ? "true" : "false");

	if (p_req->NetworkInterface.InfoFlag && p_req->NetworkInterface.Info.MTUFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:MTU>%d</tt:MTU>", p_req->NetworkInterface.Info.MTU);
	}

	if (p_req->NetworkInterface.IPv4Flag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:IPv4>");
		offset += snprintf(p_buf+offset, mlen-offset, 
			"<tt:Enabled>%s</tt:Enabled>", 
			p_req->NetworkInterface.IPv4.Enabled ? "true" : "false");

		if (p_req->NetworkInterface.IPv4.Config.DHCP == FALSE)
		{
			offset += snprintf(p_buf+offset, mlen-offset, 
				"<tt:Manual>"
					"<tt:Address>%s</tt:Address>"
		       		"<tt:PrefixLength>%d</tt:PrefixLength>"
	       		"</tt:Manual>", 
	       		p_req->NetworkInterface.IPv4.Config.Address, 
	       		p_req->NetworkInterface.IPv4.Config.PrefixLength);
		}

		offset += snprintf(p_buf+offset, mlen-offset, 
			"<tt:DHCP>%s</tt:DHCP>",
			p_req->NetworkInterface.IPv4.Config.DHCP ? "true" : "false");
		
		offset += snprintf(p_buf+offset, mlen-offset, "</tt:IPv4>");
	}

	if (p_req->NetworkInterface.ExtensionFlag)
    {
        offset += snprintf(p_buf+offset, mlen-offset, "<tt:Extension>");
        offset += snprintf(p_buf+offset, mlen-offset, "<tt:InterfaceType>%d</tt:InterfaceType>", p_req->NetworkInterface.Extension.InterfaceType);

        for (i = 0; i < p_req->NetworkInterface.Extension.sizeDot11; i++)
        {
            offset += snprintf(p_buf+offset, mlen-offset, "<tt:Dot11>");
            offset += build_Dot11Configuration_xml(p_buf+offset, mlen-offset, &p_req->NetworkInterface.Extension.Dot11[i]);
            offset += snprintf(p_buf+offset, mlen-offset, "</tt:Dot11>");
        }

        offset += snprintf(p_buf+offset, mlen-offset, "</tt:Extension>");
    }
    
	offset += snprintf(p_buf+offset, mlen-offset, "</tds:NetworkInterface>");
	offset += snprintf(p_buf+offset, mlen-offset, "</tds:SetNetworkInterfaces>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_GetNTP_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:GetNTP />");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_SetNTP_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	SetNTP_REQ * p_req = (SetNTP_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:SetNTP>");
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:FromDHCP>%s</tds:FromDHCP>", p_req->NTPInformation.FromDHCP ? "true" : "false");

	if (p_req->NTPInformation.FromDHCP == FALSE)
	{
		int i;
		for (i = 0; i < MAX_NTP_SERVER; i++)
		{
			if (p_req->NTPInformation.NTPServer[i][0] == '\0')
			{
				continue;
			}

			if (is_ip_address(p_req->NTPInformation.NTPServer[i]))
			{
    			offset += snprintf(p_buf+offset, mlen-offset, 
    				"<tds:NTPManual>"
    					"<tt:Type>IPv4</tt:Type>"
    					"<tt:IPv4Address>%s</tt:IPv4Address>"
    				"</tds:NTPManual>", 
    				p_req->NTPInformation.NTPServer[i]);
			}
			else
			{
			    offset += snprintf(p_buf+offset, mlen-offset, 
			    	"<tds:NTPManual>"
			    		"<tt:Type>DNS</tt:Type>"
    					"<tt:DNSName>%s</tt:DNSName>"
    				"</tds:NTPManual>", 
    				p_req->NTPInformation.NTPServer[i]);
			}
		}	
	}
	
	offset += snprintf(p_buf+offset, mlen-offset, "</tds:SetNTP>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetHostname_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:GetHostname />");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_SetHostname_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	SetHostname_REQ * p_req = (SetHostname_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tds:SetHostname>"
			"<tds:Name>%s</tds:Name>"
		"</tds:SetHostname>", 
		p_req->Name);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_SetHostnameFromDHCP_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	SetHostnameFromDHCP_REQ * p_req = (SetHostnameFromDHCP_REQ *) argv;
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tds:SetHostnameFromDHCP>"
			"<tds:FromDHCP>%s</tds:FromDHCP>"
	    "</tds:SetHostnameFromDHCP>", 
	    p_req ? (p_req->FromDHCP ? "true" : "false") : "false");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;	
}

int build_GetDNS_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:GetDNS />");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_SetDNS_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int i;
	int offset;
	SetDNS_REQ * p_req = (SetDNS_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:SetDNS>");
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tds:FromDHCP>%s</tds:FromDHCP>", 
		p_req->DNSInformation.FromDHCP ? "true" : "false");

	if (p_req->DNSInformation.SearchDomainFlag)
	{
		for (i = 0; i < MAX_SEARCHDOMAIN; i++)
		{
			if (p_req->DNSInformation.SearchDomain[i][0] == '\0')
			{
				continue;
			}
			
			offset += snprintf(p_buf+offset, mlen-offset, 
				"<tds:SearchDomain>%s</tds:SearchDomain>", 
				p_req->DNSInformation.SearchDomain[i]);
		}
	}

	if (p_req->DNSInformation.FromDHCP == FALSE)
	{
		for (i = 0; i < MAX_DNS_SERVER; i++)
		{
			if (p_req->DNSInformation.DNSServer[i][0] == '\0')
			{
				continue;
			}
			
			offset += snprintf(p_buf+offset, mlen-offset, 
				"<tds:DNSManual>"
					"<tt:Type>IPv4</tt:Type>"
					"<tt:IPv4Address>%s</tt:IPv4Address>"
				"</tds:DNSManual>", 
				p_req->DNSInformation.DNSServer[i]);
		}
	}
	
	offset += snprintf(p_buf+offset, mlen-offset, "</tds:SetDNS>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetDynamicDNS_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:GetDynamicDNS />");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;		
}

int build_SetDynamicDNS_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	SetDynamicDNS_REQ * p_req = (SetDynamicDNS_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tds:SetDynamicDNS>"
			"<tds:Type>%s</tds:Type>"
        	"<tds:Name>%s</tds:Name>"
        	"<tds:TTL>PT%dS</tds:TTL>"
        "</tds:SetDynamicDNS>", 
        onvif_DynamicDNSTypeToString(p_req->DynamicDNSInformation.Type), 
        p_req->DynamicDNSInformation.Name, p_req->DynamicDNSInformation.TTL);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetNetworkProtocols_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:GetNetworkProtocols />");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_SetNetworkProtocols_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int i;	
	int offset;
	SetNetworkProtocols_REQ * p_req = (SetNetworkProtocols_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:SetNetworkProtocols>");

	if (p_req->NetworkProtocol.HTTPFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tds:NetworkProtocols>");
		offset += snprintf(p_buf+offset, mlen-offset, 	
			"<tt:Name>HTTP</tt:Name>"
			"<tt:Enabled>%s</tt:Enabled>", 
			p_req->NetworkProtocol.HTTPEnabled ? "true" : "false");

		for (i = 0; i < MAX_SERVER_PORT; i++)
		{
			if (p_req->NetworkProtocol.HTTPPort[i] != 0)
			{
				offset += snprintf(p_buf+offset, mlen-offset, "<tt:Port>%d</tt:Port>", p_req->NetworkProtocol.HTTPPort[i]);
			}
		}
		
		offset += snprintf(p_buf+offset, mlen-offset, "</tds:NetworkProtocols>");
	}

	if (p_req->NetworkProtocol.HTTPSFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tds:NetworkProtocols>");
		offset += snprintf(p_buf+offset, mlen-offset, 
			"<tt:Name>HTTPS</tt:Name>"
			"<tt:Enabled>%s</tt:Enabled>", 
			p_req->NetworkProtocol.HTTPSEnabled ? "true" : "false");

		for (i = 0; i < MAX_SERVER_PORT; i++)
		{
			if (p_req->NetworkProtocol.HTTPSPort[i] != 0)
			{
				offset += snprintf(p_buf+offset, mlen-offset, "<tt:Port>%d</tt:Port>", p_req->NetworkProtocol.HTTPSPort[i]);
			}
		}
		
		offset += snprintf(p_buf+offset, mlen-offset, "</tds:NetworkProtocols>");
	}

	if (p_req->NetworkProtocol.RTSPFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tds:NetworkProtocols>");
		offset += snprintf(p_buf+offset, mlen-offset, 
			"<tt:Name>RTSP</tt:Name>"
			"<tt:Enabled>%s</tt:Enabled>", 
			p_req->NetworkProtocol.RTSPEnabled ? "true" : "false");

		for (i = 0; i < MAX_SERVER_PORT; i++)
		{
			if (p_req->NetworkProtocol.RTSPPort[i] != 0)
			{
				offset += snprintf(p_buf+offset, mlen-offset, "<tt:Port>%d</tt:Port>", p_req->NetworkProtocol.RTSPPort[i]);
			}
		}
		
		offset += snprintf(p_buf+offset, mlen-offset, "</tds:NetworkProtocols>");
	}
	
	offset += snprintf(p_buf+offset, mlen-offset, "</tds:SetNetworkProtocols>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetDiscoveryMode_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:GetDiscoveryMode />");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_SetDiscoveryMode_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	SetDiscoveryMode_REQ * p_req = (SetDiscoveryMode_REQ *) argv;
	
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tds:SetDiscoveryMode>"
    		"<tds:DiscoveryMode>%s</tds:DiscoveryMode>"
   		"</tds:SetDiscoveryMode>",
   		p_req ? onvif_DiscoveryModeToString(p_req->DiscoveryMode) : "Discoverable");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetNetworkDefaultGateway_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:GetNetworkDefaultGateway />");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_SetNetworkDefaultGateway_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int i;
	int offset;
	SetNetworkDefaultGateway_REQ * p_req = (SetNetworkDefaultGateway_REQ *) argv;
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:SetNetworkDefaultGateway>");

	for (i = 0; i < MAX_GATEWAY && p_req; i++)
	{
		if (p_req->IPv4Address[i][0] != '\0')
		{
			offset += snprintf(p_buf+offset, mlen-offset, "<tds:IPv4Address>%s</tds:IPv4Address>", p_req->IPv4Address[i]);
		}
	}
	
	offset += snprintf(p_buf+offset, mlen-offset, "</tds:SetNetworkDefaultGateway>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetZeroConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:GetZeroConfiguration />");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_SetZeroConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset = snprintf(p_buf, mlen, xml_hdr);
    SetZeroConfiguration_REQ * p_req = (SetZeroConfiguration_REQ *) argv;	
	assert(p_req);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
	    "<tds:SetZeroConfiguration>"
	        "<tds:InterfaceToken>%s</tds:InterfaceToken>"
            "<tds:Enabled>%s</tds:Enabled>"
	    "</tds:SetZeroConfiguration>",
	    p_req->InterfaceToken,
	    p_req->Enabled ? "true" : "false");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetEndpointReference_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:GetEndpointReference />");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetSystemDateAndTime_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:GetSystemDateAndTime />");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_SetSystemDateAndTime_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	SetSystemDateAndTime_REQ * p_req = (SetSystemDateAndTime_REQ *) argv;	
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:SetSystemDateAndTime>");
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tds:DateTimeType>%s</tds:DateTimeType>"
		"<tds:DaylightSavings>%s</tds:DaylightSavings>",
		onvif_SetDateTimeTypeToString(p_req->SystemDateTime.DateTimeType),
		p_req->SystemDateTime.DaylightSavings ? "true" : "false");
		
    if (p_req->SystemDateTime.TimeZoneFlag && p_req->SystemDateTime.TimeZone.TZ[0] != '\0')
    {
	    offset += snprintf(p_buf+offset, mlen-offset, 
	        "<tds:TimeZone><tt:TZ>%s</tt:TZ></tds:TimeZone>", 
	        p_req->SystemDateTime.TimeZone.TZ);
	}

    if (p_req->SystemDateTime.DateTimeType == SetDateTimeType_Manual)
	{		
		offset += snprintf(p_buf+offset, mlen-offset, "<tds:UTCDateTime>");
		offset += snprintf(p_buf+offset, mlen-offset, 
			"<tt:Time>"
				"<tt:Hour>%d</tt:Hour>"
				"<tt:Minute>%d</tt:Minute>"
				"<tt:Second>%d</tt:Second>"
			"</tt:Time>",
			p_req->UTCDateTime.Time.Hour, 
			p_req->UTCDateTime.Time.Minute, 
			p_req->UTCDateTime.Time.Second);	
		offset += snprintf(p_buf+offset, mlen-offset, 
			"<tt:Date>"
				"<tt:Year>%d</tt:Year>"
				"<tt:Month>%d</tt:Month>"
				"<tt:Day>%d</tt:Day>"
			"</tt:Date>",
			p_req->UTCDateTime.Date.Year, 
			p_req->UTCDateTime.Date.Month,
			p_req->UTCDateTime.Date.Day);		
		offset += snprintf(p_buf+offset, mlen-offset, "</tds:UTCDateTime>");
	}
	
	offset += snprintf(p_buf+offset, mlen-offset, "</tds:SetSystemDateAndTime>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_SystemReboot_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:SystemReboot />");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_SetSystemFactoryDefault_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	SetSystemFactoryDefault_REQ * p_req = (SetSystemFactoryDefault_REQ *) argv;
	
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tds:SetSystemFactoryDefault>"
			"<tds:FactoryDefault>%s</tds:FactoryDefault>"
		"</tds:SetSystemFactoryDefault>", 
		p_req ? (onvif_FactoryDefaultTypeToString(p_req->FactoryDefault)) : "Soft");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer); 
	return offset;
}

int build_GetSystemLog_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    GetSystemLog_REQ * p_req = (GetSystemLog_REQ *) argv;
    
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tds:GetSystemLog>"
        	"<tds:LogType>%s</tds:LogType>"
        "</tds:GetSystemLog>", 
        p_req ? (onvif_SystemLogTypeToString(p_req->LogType)) : "System");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}
		
int build_GetScopes_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:GetScopes />");	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
		
int build_SetScopes_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int i;
	SetScopes_REQ * p_req = (SetScopes_REQ *) argv;
	
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:SetScopes>");
	
	for (i = 0; i < p_req->sizeScopes; i++)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:Scopes>%s</tt:Scopes>", p_req->Scopes[i]);
	}
	
	offset += snprintf(p_buf+offset, mlen-offset, "</tds:SetScopes>");	
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
		
int build_AddScopes_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int i;
	AddScopes_REQ * p_req = (AddScopes_REQ *) argv;
	
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:AddScopes>");
	
	for (i = 0; i < p_req->sizeScopeItem; i++)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:ScopeItem>%s</tt:ScopeItem>", p_req->ScopeItem[i]);
	}
	
	offset += snprintf(p_buf+offset, mlen-offset, "</tds:AddScopes>");	
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
		
int build_RemoveScopes_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int i;
	RemoveScopes_REQ * p_req = (RemoveScopes_REQ *) argv;
	
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:RemoveScopes>");
	
	for (i = 0; i < p_req->sizeScopeItem; i++)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:ScopeItem>%s</tt:ScopeItem>", p_req->ScopeItem[i]);
	}
	
	offset += snprintf(p_buf+offset, mlen-offset, "</tds:RemoveScopes>");	
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_StartFirmwareUpgrade_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:StartFirmwareUpgrade />");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetSystemUris_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:GetSystemUris />");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_StartSystemRestore_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tds:StartSystemRestore />");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetVideoSources_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<trt:GetVideoSources />");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}
		
int build_GetAudioSources_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<trt:GetAudioSources />");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_CreateProfile_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
    CreateProfile_REQ * p_req = (CreateProfile_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<trt:CreateProfile><trt:Name>%s</trt:Name>", p_req->Name);
	if (p_req->TokenFlag && p_req->Token[0] != '\0')
	{
        offset += snprintf(p_buf+offset, mlen-offset, "<trt:Token>%s</trt:Token>", p_req->Token);
    }
    offset += snprintf(p_buf+offset, mlen-offset, "</trt:CreateProfile>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}
		
int build_GetProfile_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GetProfile_REQ * p_req = (GetProfile_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:GetProfile>"
			"<trt:ProfileToken>%s</trt:ProfileToken>"
	    "</trt:GetProfile>", 
	    p_req->ProfileToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetProfiles_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<trt:GetProfiles />");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_AddVideoEncoderConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	AddVideoEncoderConfiguration_REQ * p_req = (AddVideoEncoderConfiguration_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:AddVideoEncoderConfiguration>"
       	 	"<trt:ProfileToken>%s</trt:ProfileToken>"
       	 	"<trt:ConfigurationToken>%s</trt:ConfigurationToken>"
        "</trt:AddVideoEncoderConfiguration>",
        p_req->ProfileToken, p_req->ConfigurationToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

		
int build_AddVideoSourceConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	AddVideoSourceConfiguration_REQ * p_req = (AddVideoSourceConfiguration_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:AddVideoSourceConfiguration>"
        	"<trt:ProfileToken>%s</trt:ProfileToken>"
        	"<trt:ConfigurationToken>%s</trt:ConfigurationToken>"
        "</trt:AddVideoSourceConfiguration>", 
        p_req->ProfileToken, p_req->ConfigurationToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_AddAudioEncoderConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	AddAudioEncoderConfiguration_REQ * p_req = (AddAudioEncoderConfiguration_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:AddAudioEncoderConfiguration>"
        	"<trt:ProfileToken>%s</trt:ProfileToken>"
        	"<trt:ConfigurationToken>%s</trt:ConfigurationToken>"
        "</trt:AddAudioEncoderConfiguration>", 
        p_req->ProfileToken, p_req->ConfigurationToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}
		
int build_AddAudioSourceConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	AddAudioSourceConfiguration_REQ * p_req = (AddAudioSourceConfiguration_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:AddAudioSourceConfiguration>"
        	"<trt:ProfileToken>%s</trt:ProfileToken>"
        	"<trt:ConfigurationToken>%s</trt:ConfigurationToken>"
        "</trt:AddAudioSourceConfiguration>", 
        p_req->ProfileToken, p_req->ConfigurationToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetVideoSourceModes_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GetVideoSourceModes_REQ * p_req = (GetVideoSourceModes_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);
	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:GetVideoSourceModes>"
        	"<trt:VideoSourceToken>%s</trt:VideoSourceToken>"
        "</trt:GetVideoSourceModes>", 
        p_req->VideoSourceToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_SetVideoSourceMode_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	SetVideoSourceMode_REQ * p_req = (SetVideoSourceMode_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);
	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:SetVideoSourceMode>"
        	"<trt:VideoSourceToken>%s</trt:VideoSourceToken>"
        	"<trt:VideoSourceModeToken>%s</trt:VideoSourceModeToken>"
        "</trt:SetVideoSourceMode>", 
        p_req->VideoSourceToken, p_req->VideoSourceModeToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_AddPTZConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	AddPTZConfiguration_REQ * p_req = (AddPTZConfiguration_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:AddPTZConfiguration>"
        	"<trt:ProfileToken>%s</trt:ProfileToken>"
        	"<trt:ConfigurationToken>%s</trt:ConfigurationToken>"
        "</trt:AddPTZConfiguration>", 
        p_req->ProfileToken, p_req->ConfigurationToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_RemoveVideoEncoderConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	RemoveVideoEncoderConfiguration_REQ * p_req = (RemoveVideoEncoderConfiguration_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:RemoveVideoEncoderConfiguration>"
        	"<trt:ProfileToken>%s</trt:ProfileToken>"
        "</trt:RemoveVideoEncoderConfiguration>",
        p_req->ProfileToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_RemoveVideoSourceConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	RemoveVideoSourceConfiguration_REQ * p_req = (RemoveVideoSourceConfiguration_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:RemoveVideoSourceConfiguration>"
        	"<trt:ProfileToken>%s</trt:ProfileToken>"
        "</trt:RemoveVideoSourceConfiguration>", 
        p_req->ProfileToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_RemoveAudioEncoderConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	RemoveAudioEncoderConfiguration_REQ * p_req = (RemoveAudioEncoderConfiguration_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:RemoveAudioEncoderConfiguration>"
        	"<trt:ProfileToken>%s</trt:ProfileToken>"
        "</trt:RemoveAudioEncoderConfiguration>", 
        p_req->ProfileToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_RemoveAudioSourceConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	RemoveAudioSourceConfiguration_REQ * p_req = (RemoveAudioSourceConfiguration_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:RemoveAudioSourceConfiguration>"
        	"<trt:ProfileToken>%s</trt:ProfileToken>"
        "</trt:RemoveAudioSourceConfiguration>", 
        p_req->ProfileToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_RemovePTZConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	RemovePTZConfiguration_REQ * p_req = (RemovePTZConfiguration_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:RemovePTZConfiguration>"
        	"<trt:ProfileToken>%s</trt:ProfileToken>"
        "</trt:RemovePTZConfiguration>", 
        p_req->ProfileToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_DeleteProfile_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	DeleteProfile_REQ * p_req = (DeleteProfile_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:DeleteProfile>"
        	"<trt:ProfileToken>%s</trt:ProfileToken>"
        "</trt:DeleteProfile>", 
        p_req->ProfileToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetVideoSourceConfigurations_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<trt:GetVideoSourceConfigurations />");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetVideoEncoderConfigurations_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<trt:GetVideoEncoderConfigurations />");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_GetAudioSourceConfigurations_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<trt:GetAudioSourceConfigurations />");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_GetAudioEncoderConfigurations_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<trt:GetAudioEncoderConfigurations />");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
	
int build_GetVideoSourceConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
    GetVideoSourceConfiguration_REQ * p_req = (GetVideoSourceConfiguration_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:GetVideoSourceConfiguration>"
        	"<trt:ConfigurationToken>%s</trt:ConfigurationToken>"
        "</trt:GetVideoSourceConfiguration>", 
        p_req->ConfigurationToken);

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_GetVideoEncoderConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GetVideoEncoderConfiguration_REQ * p_req = (GetVideoEncoderConfiguration_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:GetVideoEncoderConfiguration>"
        	"<trt:ConfigurationToken>%s</trt:ConfigurationToken>"
        "</trt:GetVideoEncoderConfiguration>", 
        p_req->ConfigurationToken);

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_GetAudioSourceConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GetAudioSourceConfiguration_REQ * p_req = (GetAudioSourceConfiguration_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:GetAudioSourceConfiguration>"
        	"<trt:ConfigurationToken>%s</trt:ConfigurationToken>"
        "</trt:GetAudioSourceConfiguration>", 
        p_req->ConfigurationToken);

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_GetAudioEncoderConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GetAudioEncoderConfiguration_REQ * p_req = (GetAudioEncoderConfiguration_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:GetAudioEncoderConfiguration>"
        	"<trt:ConfigurationToken>%s</trt:ConfigurationToken>"
        "</trt:GetAudioEncoderConfiguration>",
        p_req->ConfigurationToken);

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_MulticastConfiguration_xml(char * p_buf, int mlen, onvif_MulticastConfiguration * p_req)
{
	int offset = 0;
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tt:Multicast>"
			"<tt:Address>"
				"<tt:Type>IPv4</tt:Type>"
				"<tt:IPv4Address>%s</tt:IPv4Address>"
			"</tt:Address>"
			"<tt:Port>%d</tt:Port>"
			"<tt:TTL>%d</tt:TTL>"
			"<tt:AutoStart>%s</tt:AutoStart>"
		"</tt:Multicast>", 
	    p_req->IPv4Address,
	    p_req->Port,
	    p_req->TTL,
	    p_req->AutoStart ? "true" : "false");

	return offset;	    
}

int build_MetadataConfiguration_xml(char * p_buf, int mlen, onvif_MetadataConfiguration * p_req)
{
	int offset = 0;

	offset += snprintf(p_buf+offset, mlen-offset,
		"<tt:Name>%s</tt:Name>"
    	"<tt:UseCount>%d</tt:UseCount>",
    	p_req->Name,
    	p_req->UseCount);

	if (p_req->PTZStatusFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset,
			"<tt:PTZStatus>"
				"<tt:Status>%s</tt:Status>"
				"<tt:Position>%s</tt:Position>"
			"</tt:PTZStatus>",
	    	p_req->PTZStatus.Status ? "true" : "false",
	    	p_req->PTZStatus.Position ? "true" : "false");
	}

	if (p_req->AnalyticsFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset,
			"<tt:Analytics>%s</tt:Analytics>",
	    	p_req->Analytics ? "true" : "false");
	}

    offset += build_MulticastConfiguration_xml(p_buf+offset, mlen-offset, &p_req->Multicast);

	offset += snprintf(p_buf+offset, mlen-offset,
			"<tt:SessionTimeout>PT%dS</tt:SessionTimeout>",
	    	p_req->SessionTimeout);

    return offset;
}

int build_VideoSourceConfiguration_xml(char * p_buf, int mlen, onvif_VideoSourceConfiguration * p_req)
{
	int offset = 0;

	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tt:Name>%s</tt:Name>"
		"<tt:UseCount>%d</tt:UseCount>"
		"<tt:SourceToken>%s</tt:SourceToken>"
 		"<tt:Bounds x=\"%d\" y=\"%d\" width=\"%d\" height=\"%d\"></tt:Bounds>",
     	p_req->Name,
     	p_req->UseCount, 
     	p_req->SourceToken,
     	p_req->Bounds.x,
     	p_req->Bounds.y,
     	p_req->Bounds.width, 
     	p_req->Bounds.height);

	if (p_req->ExtensionFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:Extension>");
		
		if (p_req->Extension.RotateFlag)
		{
			offset += snprintf(p_buf+offset, mlen-offset, "<tt:Rotate>");

			offset += snprintf(p_buf+offset, mlen-offset, "<tt:Mode>%s</tt:Mode>", 
				onvif_RotateModeToString(p_req->Extension.Rotate.Mode));

			if (p_req->Extension.Rotate.DegreeFlag)
			{
				offset += snprintf(p_buf+offset, mlen-offset, "<tt:Degree>%d</tt:Degree>",
					p_req->Extension.Rotate.Degree);
			}
			
			offset += snprintf(p_buf+offset, mlen-offset, "</tt:Rotate>");
		}
		
		offset += snprintf(p_buf+offset, mlen-offset, "</tt:Extension>");
	}

	return offset;
}

int build_SetVideoSourceConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	SetVideoSourceConfiguration_REQ * p_req = (SetVideoSourceConfiguration_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:SetVideoSourceConfiguration>"
		"<trt:Configuration token=\"%s\">",
		p_req->VideoSourceConfiguration.token);
	offset += build_VideoSourceConfiguration_xml(p_buf+offset, mlen-offset, &p_req->VideoSourceConfiguration);
	offset += snprintf(p_buf+offset, mlen-offset, 
		"</trt:Configuration>"
		"<trt:ForcePersistence>%s</trt:ForcePersistence>"
		"</trt:SetVideoSourceConfiguration>",
		p_req->ForcePersistence ? "true" : "false");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_SetVideoEncoderConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	SetVideoEncoderConfiguration_REQ * p_req = (SetVideoEncoderConfiguration_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<trt:SetVideoEncoderConfiguration>");
	offset += snprintf(p_buf+offset, mlen-offset, "<trt:Configuration token=\"%s\">", p_req->VideoEncoderConfiguration.token);
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tt:Name>%s</tt:Name>"
		"<tt:UseCount>%d</tt:UseCount>"
		"<tt:Encoding>%s</tt:Encoding>",
		p_req->VideoEncoderConfiguration.Name,
		p_req->VideoEncoderConfiguration.UseCount, 
		onvif_VideoEncodingToString(p_req->VideoEncoderConfiguration.Encoding));
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tt:Resolution>"
			"<tt:Width>%d</tt:Width>"
			"<tt:Height>%d</tt:Height>"
		"</tt:Resolution>",
		p_req->VideoEncoderConfiguration.Resolution.Width,
		p_req->VideoEncoderConfiguration.Resolution.Height);
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tt:Quality>%d</tt:Quality>", 
		p_req->VideoEncoderConfiguration.Quality);

	if (p_req->VideoEncoderConfiguration.RateControlFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, 
			"<tt:RateControl>"
				"<tt:FrameRateLimit>%d</tt:FrameRateLimit>"
	      		"<tt:EncodingInterval>%d</tt:EncodingInterval>"
	      		"<tt:BitrateLimit>%d</tt:BitrateLimit>"
	      	"</tt:RateControl>",
	      	p_req->VideoEncoderConfiguration.RateControl.FrameRateLimit, 
	      	p_req->VideoEncoderConfiguration.RateControl.EncodingInterval, 
	      	p_req->VideoEncoderConfiguration.RateControl.BitrateLimit);
	}
	
	if (p_req->VideoEncoderConfiguration.Encoding == VideoEncoding_H264)
	{
		offset += snprintf(p_buf+offset, mlen-offset, 
			"<tt:H264>"
				"<tt:GovLength>%d</tt:GovLength>"
    			"<tt:H264Profile>%s</tt:H264Profile>"
    		"</tt:H264>", 
    		p_req->VideoEncoderConfiguration.H264.GovLength,
	    	onvif_H264ProfileToString(p_req->VideoEncoderConfiguration.H264.H264Profile));
	}
	if (p_req->VideoEncoderConfiguration.Encoding == VideoEncoding_MPEG4)
	{
		offset += snprintf(p_buf+offset, mlen-offset, 
			"<tt:MPEG4>"
				"<tt:GovLength>%d</tt:GovLength>"
    			"<tt:Mpeg4Profile>%s</tt:Mpeg4Profile>"
    		"</tt:MPEG4>", 
    		p_req->VideoEncoderConfiguration.MPEG4.GovLength,
	    	onvif_Mpeg4ProfileToString(p_req->VideoEncoderConfiguration.MPEG4.Mpeg4Profile));
	}

	offset += build_MulticastConfiguration_xml(p_buf+offset, mlen-offset, &p_req->VideoEncoderConfiguration.Multicast);

	offset += snprintf(p_buf+offset, mlen-offset,
		"<tt:SessionTimeout>PT%dS</tt:SessionTimeout>",
		p_req->VideoEncoderConfiguration.SessionTimeout);
		
	offset += snprintf(p_buf+offset, mlen-offset, "</trt:Configuration>");
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:ForcePersistence>%s</trt:ForcePersistence>",
		p_req->ForcePersistence ? "true" : "false");
		
	offset += snprintf(p_buf+offset, mlen-offset, "</trt:SetVideoEncoderConfiguration>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_AudioSourceConfiguration_xml(char * p_buf, int mlen, onvif_AudioSourceConfiguration * p_req)
{
	int offset = 0;

	offset += snprintf(p_buf+offset, mlen-offset,
		"<tt:Name>%s</tt:Name>"
		"<tt:UseCount>%d</tt:UseCount>"
		"<tt:SourceToken>%s</tt:SourceToken>",
     	p_req->Name, 
     	p_req->UseCount, 
     	p_req->SourceToken);

     return offset;
}

int build_SetAudioSourceConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	SetAudioSourceConfiguration_REQ * p_req = (SetAudioSourceConfiguration_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:SetAudioSourceConfiguration>"
		"<trt:Configuration token=\"%s\">",
		p_req->AudioSourceConfiguration.token);
	offset += build_AudioSourceConfiguration_xml(p_buf+offset, mlen-offset, &p_req->AudioSourceConfiguration);
    offset += snprintf(p_buf+offset, mlen-offset, 
    	"<trt:ForcePersistence>%s</trt:ForcePersistence>",
    	p_req->ForcePersistence ? "true" : "false");
    offset += snprintf(p_buf+offset, mlen-offset, 
    	"</trt:Configuration>"
    	"</trt:SetAudioSourceConfiguration>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_SetAudioEncoderConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	SetAudioEncoderConfiguration_REQ * p_req = (SetAudioEncoderConfiguration_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:SetAudioEncoderConfiguration>"
			"<trt:Configuration token=\"%s\">"
				"<tt:Name>%s</tt:Name>"
				"<tt:UseCount>%d</tt:UseCount>"
				"<tt:Encoding>%s</tt:Encoding>"
				"<tt:Bitrate>%d</tt:Bitrate>"
	     		"<tt:SampleRate>%d</tt:SampleRate>",
		p_req->AudioEncoderConfiguration.token, 
     	p_req->AudioEncoderConfiguration.Name, 
     	p_req->AudioEncoderConfiguration.UseCount, 
     	onvif_AudioEncodingToString(p_req->AudioEncoderConfiguration.Encoding), 
     	p_req->AudioEncoderConfiguration.Bitrate, 
     	p_req->AudioEncoderConfiguration.SampleRate);

	offset += build_MulticastConfiguration_xml(p_buf+offset, mlen-offset, &p_req->AudioEncoderConfiguration.Multicast);

	offset += snprintf(p_buf+offset, mlen-offset, 
				"<tt:SessionTimeout>PT%dS</tt:SessionTimeout>"
			"</trt:Configuration>"
			"<trt:ForcePersistence>%s</trt:ForcePersistence>"
		"</trt:SetAudioEncoderConfiguration>",
	    p_req->AudioEncoderConfiguration.SessionTimeout,
	    p_req->ForcePersistence ? "true" : "false");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_GetVideoSourceConfigurationOptions_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    GetVideoSourceConfigurationOptions_REQ * p_req = (GetVideoSourceConfigurationOptions_REQ *) argv;
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<trt:GetVideoSourceConfigurationOptions>");
	if (p_req && p_req->ConfigurationTokenFlag && p_req->ConfigurationToken[0] != '\0')
	{
	    offset += snprintf(p_buf+offset, mlen-offset, "<trt:ConfigurationToken>%s</trt:ConfigurationToken>", p_req->ConfigurationToken);
	}
	if (p_req && p_req->ProfileTokenFlag && p_req->ProfileToken[0] != '\0')
	{
	    offset += snprintf(p_buf+offset, mlen-offset, "<trt:ProfileToken>%s</trt:ProfileToken>", p_req->ProfileToken);
	}
    offset += snprintf(p_buf+offset, mlen-offset, "</trt:GetVideoSourceConfigurationOptions>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_GetVideoEncoderConfigurationOptions_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	GetVideoEncoderConfigurationOptions_REQ * p_req = (GetVideoEncoderConfigurationOptions_REQ *) argv;
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<trt:GetVideoEncoderConfigurationOptions>");
	if (p_req && p_req->ConfigurationTokenFlag && p_req->ConfigurationToken[0] != '\0')
	{
	    offset += snprintf(p_buf+offset, mlen-offset, "<trt:ConfigurationToken>%s</trt:ConfigurationToken>", p_req->ConfigurationToken);
	}
	if (p_req && p_req->ProfileTokenFlag && p_req->ProfileToken[0] != '\0')
	{
	    offset += snprintf(p_buf+offset, mlen-offset, "<trt:ProfileToken>%s</trt:ProfileToken>", p_req->ProfileToken);
	}
    offset += snprintf(p_buf+offset, mlen-offset, "</trt:GetVideoEncoderConfigurationOptions>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_GetAudioSourceConfigurationOptions_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	GetAudioSourceConfigurationOptions_REQ * p_req = (GetAudioSourceConfigurationOptions_REQ *) argv;
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<trt:GetAudioSourceConfigurationOptions>");
	if (p_req && p_req->ConfigurationTokenFlag && p_req->ConfigurationToken[0] != '\0')
	{
	    offset += snprintf(p_buf+offset, mlen-offset, "<trt:ConfigurationToken>%s</trt:ConfigurationToken>", p_req->ConfigurationToken);
	}
	if (p_req && p_req->ProfileTokenFlag && p_req->ProfileToken[0] != '\0')
	{
	    offset += snprintf(p_buf+offset, mlen-offset, "<trt:ProfileToken>%s</trt:ProfileToken>", p_req->ProfileToken);
	}
    offset += snprintf(p_buf+offset, mlen-offset, "</trt:GetAudioSourceConfigurationOptions>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_GetAudioEncoderConfigurationOptions_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	GetAudioEncoderConfigurationOptions_REQ * p_req = (GetAudioEncoderConfigurationOptions_REQ *) argv;
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<trt:GetAudioEncoderConfigurationOptions>");
	if (p_req && p_req->ConfigurationTokenFlag && p_req->ConfigurationToken[0] != '\0')
	{
	    offset += snprintf(p_buf+offset, mlen-offset, "<trt:ConfigurationToken>%s</trt:ConfigurationToken>", p_req->ConfigurationToken);
	}
	if (p_req && p_req->ProfileTokenFlag && p_req->ProfileToken[0] != '\0')
	{
	    offset += snprintf(p_buf+offset, mlen-offset, "<trt:ProfileToken>%s</trt:ProfileToken>", p_req->ProfileToken);
	}
    offset += snprintf(p_buf+offset, mlen-offset, "</trt:GetAudioEncoderConfigurationOptions>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_GetStreamUri_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GetStreamUri_REQ * p_req = (GetStreamUri_REQ *) argv;
	assert(p_req);
	
    offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);

	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:GetStreamUri>"
			"<trt:StreamSetup>"
				"<tt:Stream>%s</tt:Stream>"
				"<tt:Transport>"
					"<tt:Protocol>%s</tt:Protocol>"
				"</tt:Transport>"
			"</trt:StreamSetup>"
			"<trt:ProfileToken>%s</trt:ProfileToken>"
		"</trt:GetStreamUri>",
		onvif_StreamTypeToString(p_req->StreamSetup.Stream),
		onvif_TransportProtocolToString(p_req->StreamSetup.Transport.Protocol),
		p_req->ProfileToken);

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_SetSynchronizationPoint_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	SetSynchronizationPoint_REQ * p_req = (SetSynchronizationPoint_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:SetSynchronizationPoint>"
        	"<trt:ProfileToken>%s</trt:ProfileToken>"
        "</trt:SetSynchronizationPoint>", 
        p_req->ProfileToken);

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
		
int build_GetSnapshotUri_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GetSnapshotUri_REQ * p_req = (GetSnapshotUri_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:GetSnapshotUri>"
        	"<trt:ProfileToken>%s</trt:ProfileToken>"
        "</trt:GetSnapshotUri>", 
        p_req->ProfileToken);

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_GetNodes_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tptz:GetNodes />");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_GetNode_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GetNode_REQ * p_req = (GetNode_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:GetNode>"
			"<tptz:NodeToken>%s</tptz:NodeToken>"
		"</trt:GetNode>", 
		p_req->NodeToken);

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_GetPresets_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GetPresets_REQ * p_req = (GetPresets_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tptz:GetPresets>"
			"<tptz:ProfileToken>%s""</tptz:ProfileToken>"
		"</tptz:GetPresets>", 
		p_req->ProfileToken);

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_SetPreset_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	SetPreset_REQ * p_req = (SetPreset_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tptz:SetPreset>");
	offset += snprintf(p_buf+offset, mlen-offset, "<tptz:ProfileToken>%s</tptz:ProfileToken>", p_req->ProfileToken);

	if (p_req->PresetNameFlag && p_req->PresetName[0] != '\0')
	{
	    offset += snprintf(p_buf+offset, mlen-offset, "<tptz:PresetName>%s</tptz:PresetName>", p_req->PresetName);
	}	 

	if (p_req->PresetTokenFlag && p_req->PresetToken[0] != '\0')
	{
	    offset += snprintf(p_buf+offset, mlen-offset, "<tptz:PresetToken>%s</tptz:PresetToken>", p_req->PresetToken);
	}

	offset += snprintf(p_buf+offset, mlen-offset, "</tptz:SetPreset>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_RemovePreset_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	RemovePreset_REQ * p_req = (RemovePreset_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tptz:RemovePreset>"
			"<tptz:ProfileToken>%s</tptz:ProfileToken>"
			"<tptz:PresetToken>%s</tptz:PresetToken>"
		"</tptz:RemovePreset>", 
		p_req->ProfileToken, 
		p_req->PresetToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_PTZSpeed(char * p_buf, int mlen, onvif_PTZSpeed * p_req)
{
	int offset = 0;

	if (p_req->PanTiltFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, 
			"<tt:PanTilt x=\"%0.6f\" y=\"%0.6f\"></tt:PanTilt>",
			p_req->PanTilt.x, p_req->PanTilt.y);
	}

	if (p_req->ZoomFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, 
		        "<tt:Zoom x=\"%0.6f\"></tt:Zoom>", 
		        p_req->Zoom.x);	 
	}

	return offset;
}

int build_GotoPreset_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GotoPreset_REQ * p_req = (GotoPreset_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tptz:GotoPreset>");
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tptz:ProfileToken>%s</tptz:ProfileToken>"
    	"<tptz:PresetToken>%s</tptz:PresetToken>", 
    	p_req->ProfileToken, 
    	p_req->PresetToken);

    if (p_req->SpeedFlag)
    {
    	offset += snprintf(p_buf+offset, mlen-offset, "<tptz:Speed>");
	    offset += build_PTZSpeed(p_buf+offset, mlen-offset, &p_req->Speed);	    
	    offset += snprintf(p_buf+offset, mlen-offset, "</tptz:Speed>");
    }

    offset += snprintf(p_buf+offset, mlen-offset, "</tptz:GotoPreset>");
    
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GotoHomePosition_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GotoHomePosition_REQ * p_req = (GotoHomePosition_REQ *) argv;	
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tptz:GotoHomePosition>");
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tptz:ProfileToken>%s</tptz:ProfileToken>",
		p_req->ProfileToken);
		
	if (p_req->SpeedFlag)
    {
	    offset += snprintf(p_buf+offset, mlen-offset, "<tptz:Speed>");
	    offset += build_PTZSpeed(p_buf+offset, mlen-offset, &p_req->Speed);	    
	    offset += snprintf(p_buf+offset, mlen-offset, "</tptz:Speed>");
    }
        
    offset += snprintf(p_buf+offset, mlen-offset, "</tptz:GotoHomePosition>");	
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_SetHomePosition_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	SetHomePosition_REQ * p_req = (SetHomePosition_REQ *) argv;	
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tptz:SetHomePosition>"
			"<tptz:ProfileToken>%s</tptz:ProfileToken>"
		"</tptz:SetHomePosition>", 
		p_req->ProfileToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetStatus_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GetStatus_REQ * p_req = (GetStatus_REQ *) argv;	
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tptz:GetStatus>"
			"<tptz:ProfileToken>%s</tptz:ProfileToken>"
		"</tptz:GetStatus>", 
		p_req->ProfileToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_ContinuousMove_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	ContinuousMove_REQ * p_req = (ContinuousMove_REQ *) argv;
	assert(p_req);
	
    offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tptz:ContinuousMove>");
	offset += snprintf(p_buf+offset, mlen-offset, "<tptz:ProfileToken>%s</tptz:ProfileToken>", p_req->ProfileToken);

	offset += snprintf(p_buf+offset, mlen-offset, "<tptz:Velocity>");
   	offset += build_PTZSpeed(p_buf+offset, mlen-offset, &p_req->Velocity);
	offset += snprintf(p_buf+offset, mlen-offset, "</tptz:Velocity>");
	
	if (p_req->TimeoutFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tptz:Timeout>PT%dS</tptz:Timeout>", p_req->Timeout);
	}
	
	offset += snprintf(p_buf+offset, mlen-offset, "</tptz:ContinuousMove>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_PTZVector(char * p_buf, int mlen, onvif_PTZVector * p_req)
{
	int offset = 0;

	if (p_req->PanTiltFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, 
			"<tt:PanTilt x=\"%0.6f\" y=\"%0.6f\"></tt:PanTilt>", 
    	    p_req->PanTilt.x, p_req->PanTilt.y);
    }

    if (p_req->ZoomFlag)
    {
    	offset += snprintf(p_buf+offset, mlen-offset, 
    		"<tt:Zoom x=\"%0.6f\"></tt:Zoom>", p_req->Zoom.x);
    }
    
	return offset;
}

int build_RelativeMove_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	RelativeMove_REQ * p_req = (RelativeMove_REQ *) argv;
	assert(p_req);
	
    offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tptz:RelativeMove>");
	offset += snprintf(p_buf+offset, mlen-offset, "<tptz:ProfileToken>%s</tptz:ProfileToken>", p_req->ProfileToken);
	offset += snprintf(p_buf+offset, mlen-offset, "<tptz:Translation>");
   	offset += build_PTZVector(p_buf+offset, mlen-offset, &p_req->Translation);
	offset += snprintf(p_buf+offset, mlen-offset, "</tptz:Translation>");

	if (p_req->SpeedFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tptz:Speed>");
	   	offset += build_PTZSpeed(p_buf+offset, mlen-offset, &p_req->Speed);
		offset += snprintf(p_buf+offset, mlen-offset, "</tptz:Speed>");
	}
	
	offset += snprintf(p_buf+offset, mlen-offset, "</tptz:RelativeMove>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}
		
int build_AbsoluteMove_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	AbsoluteMove_REQ * p_req = (AbsoluteMove_REQ *) argv;
	assert(p_req);
	
    offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tptz:AbsoluteMove>");
	offset += snprintf(p_buf+offset, mlen-offset, "<tptz:ProfileToken>%s</tptz:ProfileToken>", p_req->ProfileToken);
	offset += snprintf(p_buf+offset, mlen-offset, "<tptz:Position>");
   	offset += build_PTZVector(p_buf+offset, mlen-offset, &p_req->Position);
	offset += snprintf(p_buf+offset, mlen-offset, "</tptz:Position>");

	if (p_req->SpeedFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tptz:Speed>");
	   	offset += build_PTZSpeed(p_buf+offset, mlen-offset, &p_req->Speed);
		offset += snprintf(p_buf+offset, mlen-offset, "</tptz:Speed>");
	}
	
	offset += snprintf(p_buf+offset, mlen-offset, "</tptz:AbsoluteMove>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_ptz_Stop_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	PTZStop_REQ * p_req = (PTZStop_REQ *) argv;
	assert(p_req);
	
    offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tptz:Stop>");
	offset += snprintf(p_buf+offset, mlen-offset, "<tptz:ProfileToken>%s</tptz:ProfileToken>", p_req->ProfileToken);

	if (p_req->PanTiltFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tptz:PanTilt>%s</tptz:PanTilt>", p_req->PanTilt ? "true" : "false");
	}

	if (p_req->ZoomFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tptz:Zoom>%s</tptz:Zoom>", p_req->Zoom ? "true" : "false");
	}
	
	offset += snprintf(p_buf+offset, mlen-offset, "</tptz:Stop>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetConfigurations_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{	
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tptz:GetConfigurations />");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GetConfiguration_REQ * p_req = (GetConfiguration_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tptz:GetConfiguration>"
			"<tptz:PTZConfigurationToken>%s</tptz:PTZConfigurationToken>"
		"</tptz:GetConfiguration>", 
		p_req->ConfigurationToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_PTZConfiguration_xml(char * p_buf, int mlen, onvif_PTZConfiguration * p_req)
{
	int offset = 0;
	
	offset += snprintf(p_buf+offset, mlen-offset,
    	"<tt:Name>%s</tt:Name>"
    	"<tt:UseCount>%d</tt:UseCount>"
    	"<tt:NodeToken>%s</tt:NodeToken>",     	
    	p_req->Name, 
    	p_req->UseCount,
    	p_req->NodeToken);

   offset += snprintf(p_buf+offset, mlen-offset,  	
	    "<tt:DefaultAbsolutePantTiltPositionSpace>"
	    	"http://www.onvif.org/ver10/tptz/PanTiltSpaces/PositionGenericSpace"
    	"</tt:DefaultAbsolutePantTiltPositionSpace>"
	    "<tt:DefaultAbsoluteZoomPositionSpace>"
	    	"http://www.onvif.org/ver10/tptz/ZoomSpaces/PositionGenericSpace"
    	"</tt:DefaultAbsoluteZoomPositionSpace>"
	    "<tt:DefaultRelativePanTiltTranslationSpace>"
	    	"http://www.onvif.org/ver10/tptz/PanTiltSpaces/TranslationGenericSpace"
    	"</tt:DefaultRelativePanTiltTranslationSpace>"
	    "<tt:DefaultRelativeZoomTranslationSpace>"
	    	"http://www.onvif.org/ver10/tptz/ZoomSpaces/TranslationGenericSpace"
	    "</tt:DefaultRelativeZoomTranslationSpace>"
	    "<tt:DefaultContinuousPanTiltVelocitySpace>"
	   	 	"http://www.onvif.org/ver10/tptz/PanTiltSpaces/VelocityGenericSpace"
	    "</tt:DefaultContinuousPanTiltVelocitySpace>"
	    "<tt:DefaultContinuousZoomVelocitySpace>"
	    	"http://www.onvif.org/ver10/tptz/ZoomSpaces/VelocityGenericSpace"
	    "</tt:DefaultContinuousZoomVelocitySpace>");

	if (p_req->DefaultPTZSpeedFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:DefaultPTZSpeed>"); 	    
		if (p_req->DefaultPTZSpeed.PanTiltFlag)
		{
			offset += snprintf(p_buf+offset, mlen-offset, 
				"<tt:PanTilt x=\"%0.6f\" y=\"%0.6f\" space=\"http://www.onvif.org/ver10/tptz/PanTiltSpaces/GenericSpeedSpace\" />",
				p_req->DefaultPTZSpeed.PanTilt.x, 
				p_req->DefaultPTZSpeed.PanTilt.y);
		}
		if (p_req->DefaultPTZSpeed.ZoomFlag)
		{
			offset += snprintf(p_buf+offset, mlen-offset, 
				"<tt:Zoom x=\"%0.6f\" space=\"http://www.onvif.org/ver10/tptz/ZoomSpaces/ZoomGenericSpeedSpace\" />",
				p_req->DefaultPTZSpeed.Zoom.x);
		}	
		offset += snprintf(p_buf+offset, mlen-offset, "</tt:DefaultPTZSpeed>"); 
	}

	if (p_req->DefaultPTZTimeoutFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset,  	 	
	    	"<tt:DefaultPTZTimeout>PT%dS</tt:DefaultPTZTimeout>", 
	    	p_req->DefaultPTZTimeout);
    }	

	if (p_req->PanTiltLimitsFlag)
	{
	    offset += snprintf(p_buf+offset, mlen-offset,  	 	
			"<tt:PanTiltLimits>"
				"<tt:Range>"
					"<tt:URI>http://www.onvif.org/ver10/tptz/PanTiltSpaces/PositionGenericSpace</tt:URI>"
					"<tt:XRange>"
						"<tt:Min>%0.6f</tt:Min>"
						"<tt:Max>%0.6f</tt:Max>"
					"</tt:XRange>"
					"<tt:YRange>"
						"<tt:Min>%0.6f</tt:Min>"
						"<tt:Max>%0.6f</tt:Max>"
					"</tt:YRange>"
				"</tt:Range>"
			"</tt:PanTiltLimits>",
			p_req->PanTiltLimits.XRange.Min, 
			p_req->PanTiltLimits.XRange.Max,
			p_req->PanTiltLimits.YRange.Min, 
			p_req->PanTiltLimits.YRange.Max);
	}

	if (p_req->ZoomLimitsFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset,  	 	
			"<tt:ZoomLimits>"
				"<tt:Range>"
					"<tt:URI>http://www.onvif.org/ver10/tptz/ZoomSpaces/PositionGenericSpace</tt:URI>"
					"<tt:XRange>"
						"<tt:Min>%0.6f</tt:Min>"
						"<tt:Max>%0.6f</tt:Max>"
					"</tt:XRange>"
				"</tt:Range>"
			"</tt:ZoomLimits>",
			p_req->ZoomLimits.XRange.Min,
			p_req->ZoomLimits.XRange.Max);
	}

    if (p_req->ExtensionFlag)
    {
        offset += snprintf(p_buf+offset, mlen-offset, "<tt:Extension>");
        if (p_req->Extension.PTControlDirectionFlag)
        {
            offset += snprintf(p_buf+offset, mlen-offset, "<tt:PTControlDirection>");
            if (p_req->Extension.PTControlDirection.EFlipFlag)
            {
                offset += snprintf(p_buf+offset, mlen-offset, 
                    "<tt:EFlip>"
                        "<tt:Mode>%s</tt:Mode>"
                    "</tt:EFlip>",
                    onvif_EFlipModeToString(p_req->Extension.PTControlDirection.EFlip));                
            }
            if (p_req->Extension.PTControlDirection.ReverseFlag)
            {
                offset += snprintf(p_buf+offset, mlen-offset, 
                    "<tt:Reverse>"
                        "<tt:Mode>%s</tt:Mode>"
                    "</tt:Reverse>",
                    onvif_ReverseModeToString(p_req->Extension.PTControlDirection.Reverse));
            }
            offset += snprintf(p_buf+offset, mlen-offset, "</tt:PTControlDirection>");
        }    
        offset += snprintf(p_buf+offset, mlen-offset, "</tt:Extension>");
    }

	return offset;
}

int build_SetConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	SetConfiguration_REQ * p_req = (SetConfiguration_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tptz:SetConfiguration>");	
	offset += snprintf(p_buf+offset, mlen-offset, "<tptz:PTZConfiguration token=\"%s\" MoveRamp=\"%d\" PresetRamp=\"%d\" PresetTourRamp=\"%d\">",
		p_req->PTZConfiguration.token, p_req->PTZConfiguration.MoveRamp, p_req->PTZConfiguration.PresetTourRamp, p_req->PTZConfiguration.PresetTourRamp);
	offset += build_PTZConfiguration_xml(p_buf+offset, mlen-offset, &p_req->PTZConfiguration);	
	offset += snprintf(p_buf+offset, mlen-offset, "</tptz:PTZConfiguration>");
    offset += snprintf(p_buf+offset, mlen-offset, "<tptz:ForcePersistence>%s</tptz:ForcePersistence>", p_req->ForcePersistence ? "true" : "false");
	offset += snprintf(p_buf+offset, mlen-offset, "</tptz:SetConfiguration>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetConfigurationOptions_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GetConfigurationOptions_REQ * p_req = (GetConfigurationOptions_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tptz:GetConfigurationOptions>"
			"<tptz:ConfigurationToken>%s</tptz:ConfigurationToken>"
		"</tptz:GetConfigurationOptions>", 
		p_req->ConfigurationToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetPresetTours_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GetPresetTours_REQ * p_req = (GetPresetTours_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tptz:GetPresetTours>"
    		"<tptz:ProfileToken>%s</tptz:ProfileToken>"
   		"</tptz:GetPresetTours>", 
		p_req->ProfileToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetPresetTour_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GetPresetTour_REQ * p_req = (GetPresetTour_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tptz:GetPresetTour>"
    		"<tptz:ProfileToken>%s</tptz:ProfileToken>"
    		"<tptz:PresetTourToken>%s</tptz:PresetTourToken>"
   		"</tptz:GetPresetTour>", 
		p_req->ProfileToken, 
		p_req->PresetTourToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetPresetTourOptions_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GetPresetTourOptions_REQ * p_req = (GetPresetTourOptions_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tptz:GetPresetTourOptions>"
    		"<tptz:ProfileToken>%s</tptz:ProfileToken>"
    		"<tptz:PresetTourToken>%s</tptz:PresetTourToken>"
   		"</tptz:GetPresetTourOptions>", 
		p_req->ProfileToken, 
		p_req->PresetTourToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_CreatePresetTour_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	CreatePresetTour_REQ * p_req = (CreatePresetTour_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tptz:CreatePresetTour>"
    		"<tptz:ProfileToken>%s</tptz:ProfileToken>"
   		"</tptz:CreatePresetTour>", 
		p_req->ProfileToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_PTZPresetTourSpot_xml(char * p_buf, int mlen, onvif_PTZPresetTourSpot * p_req)
{
	int offset = 0;

	offset += snprintf(p_buf+offset, mlen-offset, "<tt:PresetDetail>");

	if (p_req->PresetDetail.PresetTokenFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:PresetToken>%s</tt:PresetToken>", p_req->PresetDetail.PresetToken);
	}

	if (p_req->PresetDetail.HomeFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:Home>%s</tt:Home>", p_req->PresetDetail.Home ? "true" : "false");
	}

	if (p_req->PresetDetail.PTZPositionFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:PTZPosition>");
		offset += build_PTZVector(p_buf+offset, mlen-offset, &p_req->PresetDetail.PTZPosition);
		offset += snprintf(p_buf+offset, mlen-offset, "</tt:PTZPosition>");
	}
	
	offset += snprintf(p_buf+offset, mlen-offset, "</tt:PresetDetail>");

	if (p_req->SpeedFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:Speed>");
		offset += build_PTZSpeed(p_buf+offset, mlen-offset, &p_req->Speed);
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:Speed>");
	}

	if (p_req->StayTimeFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:StayTime>%d<tt:StayTime>", p_req->StayTime);
	}

	return offset;
}

int build_PTZPresetTourStatus_xml(char * p_buf, int mlen, onvif_PTZPresetTourStatus * p_req)
{
	int offset = 0;
	offset += snprintf(p_buf+offset, mlen-offset, "<tt:Status>");
	offset += snprintf(p_buf+offset, mlen-offset, "<tt:State>%s</tt:State>", onvif_PTZPresetTourStateToString(p_req->State));

	if (p_req->CurrentTourSpotFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:CurrentTourSpot>");
		offset += build_PTZPresetTourSpot_xml(p_buf+offset, mlen-offset, &p_req->CurrentTourSpot);		
		offset += snprintf(p_buf+offset, mlen-offset, "</tt:CurrentTourSpot>");
	}
	
	offset += snprintf(p_buf+offset, mlen-offset, "</tt:Status>");
	
	return offset;
}

int build_PresetTour_xml(char * p_buf, int mlen, onvif_PresetTour * p_req)
{
	int offset = 0;
	ONVIF_PTZPresetTourSpot * p_TourSpot = p_req->TourSpot;
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tt:Name>%s</tt:Name>", p_req->Name);
	offset += build_PTZPresetTourStatus_xml(p_buf+offset, mlen-offset, &p_req->Status);
	offset += snprintf(p_buf+offset, mlen-offset, "<tt:AutoStart>%s</tt:AutoStart>", p_req->AutoStart ? "true" : "false");
	
	if (p_req->StartingCondition.RandomPresetOrderFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:StartingCondition RandomPresetOrder=\"%s\">", p_req->StartingCondition.RandomPresetOrder ? "true" : "false");
	}
	else
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:StartingCondition>");
	}

	if (p_req->StartingCondition.RecurringTimeFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:RecurringTime>%d</tt:RecurringTime>", p_req->StartingCondition.RecurringTime);
	}

	if (p_req->StartingCondition.RecurringDurationFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:RecurringDuration>PT%dS</tt:RecurringDuration>", p_req->StartingCondition.RecurringDuration);
	}

	if (p_req->StartingCondition.DirectionFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:Direction>%s</tt:Direction>", 
			onvif_PTZPresetTourDirectionToString(p_req->StartingCondition.Direction));
	}
	
	offset += snprintf(p_buf+offset, mlen-offset, "</tt:StartingCondition>");

	while (p_TourSpot)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:TourSpot>");
		offset += build_PTZPresetTourSpot_xml(p_buf+offset, mlen-offset, &p_TourSpot->PTZPresetTourSpot);
		offset += snprintf(p_buf+offset, mlen-offset, "</tt:TourSpot>");
		
		p_TourSpot = p_TourSpot->next;
	}

	return offset;
}

int build_ModifyPresetTour_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	ModifyPresetTour_REQ * p_req = (ModifyPresetTour_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tptz:ModifyPresetTour>");
   	offset += snprintf(p_buf+offset, mlen-offset, "<tptz:ProfileToken>%s</tptz:ProfileToken>", p_req->ProfileToken);
	offset += snprintf(p_buf+offset, mlen-offset, "<tptz:PresetTour token=\"%s\">", p_req->PresetTour.token);
	offset += build_PresetTour_xml(p_buf+offset, mlen-offset, &p_req->PresetTour);
   	offset += snprintf(p_buf+offset, mlen-offset, "</tptz:PresetTour>");
   	offset += snprintf(p_buf+offset, mlen-offset, "</tptz:ModifyPresetTour>");	
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_OperatePresetTour_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	OperatePresetTour_REQ * p_req = (OperatePresetTour_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tptz:OperatePresetTour>"
    		"<tptz:ProfileToken>%s</tptz:ProfileToken>"
    		"<tptz:PresetTourToken>%s</tptz:PresetTourToken>"
    		"<tptz:Operation>%s</tptz:Operation>"
   		"</tptz:OperatePresetTour>", 
		p_req->ProfileToken, 
		p_req->PresetTourToken,
		onvif_PTZPresetTourOperationToString(p_req->Operation));
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_RemovePresetTour_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	RemovePresetTour_REQ * p_req = (RemovePresetTour_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tptz:RemovePresetTour>"
    		"<tptz:ProfileToken>%s</tptz:ProfileToken>"
    		"<tptz:PresetTourToken>%s</tptz:PresetTourToken>"
   		"</tptz:RemovePresetTour>", 
		p_req->ProfileToken, 
		p_req->PresetTourToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}


int build_GetEventProperties_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tev:GetEventProperties />");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}
    
int build_Renew_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	Renew_REQ * p_req = (Renew_REQ *) argv;
	
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header_ex(p_buf+offset, mlen-offset, p_dev, p_dev->events.producter_addr, "http://docs.oasis-open.org/wsn/bw-2/SubscriptionManager/RenewRequest");
	// offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, p_dev->events.producter_addr);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
	    "<wsnt:Renew>"
	    	"<wsnt:TerminationTime>PT%dS</wsnt:TerminationTime>"
	    "</wsnt:Renew>", 
		p_req ? (p_req->TerminationTime) : 60);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_Unsubscribe_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header_ex(p_buf+offset, mlen-offset, p_dev, p_dev->events.producter_addr, "http://docs.oasis-open.org/wsn/bw-2/SubscriptionManager/UnsubscribeRequest");
	// offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, p_dev->events.producter_addr);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<wsnt:Unsubscribe />");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_EventFilter(char * p_buf, int mlen, onvif_EventFilter * p_filter)
{
	int i;
	int offset = 0;

	for (i = 0; i < p_filter->sizeTopicExpression; i++)
	{
		offset += snprintf(p_buf+offset, mlen-offset, 
			"<wsnt:TopicExpression dialect=\"%s\">%s</wsnt:TopicExpression>",
			p_filter->TopicExpression[i].Dialect, p_filter->TopicExpression[i].Expression);
	}

	for (i = 0; i < p_filter->sizeMessageContent; i++)
	{
		offset += snprintf(p_buf+offset, mlen-offset, 
			"<wsnt:MessageContent dialect=\"%s\">%s</wsnt:MessageContent>",
			p_filter->MessageContent[i].Dialect, p_filter->MessageContent[i].Expression);
	}	

	return offset;
}

int build_Subscribe_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	char to[256];
	Subscribe_REQ * p_req = (Subscribe_REQ *) argv;
	assert(p_req);

	snprintf(to, 256, "http://%s:%d%s", p_dev->Capabilities.events.XAddr.host, p_dev->Capabilities.events.XAddr.port, p_dev->Capabilities.events.XAddr.url);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header_ex(p_buf+offset, mlen-offset, p_dev, to, "http://docs.oasis-open.org/wsn/bw-2/NotificationProducer/SubscribeRequest");
	// offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	offset += snprintf(p_buf+offset, mlen-offset, "<wsnt:Subscribe>");
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<wsnt:ConsumerReference>"
	    	"<wsa:Address>%s</wsa:Address>"
	    "</wsnt:ConsumerReference>",
	    p_req->ConsumerReference);

	if (p_req->FiltersFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tev:Filter>");
		offset += build_EventFilter(p_buf+offset, mlen-offset, &p_req->Filter);
		offset += snprintf(p_buf+offset, mlen-offset, "</tev:Filter>");
	}
		    
	offset += snprintf(p_buf+offset, mlen-offset,
		"<wsnt:InitialTerminationTime>PT%dS</wsnt:InitialTerminationTime>",
		p_req->InitialTerminationTime);	
		
	offset += snprintf(p_buf+offset, mlen-offset, "</wsnt:Subscribe>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_CreatePullPointSubscription_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	char to[256];
	CreatePullPointSubscription_REQ * p_req = (CreatePullPointSubscription_REQ *)argv;
	
	int offset = snprintf(p_buf, mlen, xml_hdr);

	snprintf(to, 256, "http://%s:%d%s", p_dev->Capabilities.events.XAddr.host, p_dev->Capabilities.events.XAddr.port, p_dev->Capabilities.events.XAddr.url);
	
	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header_ex(p_buf+offset, mlen-offset, p_dev, to, "http://www.onvif.org/ver10/events/wsdl/EventPortType/CreatePullPointSubscriptionRequest");
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<wsnt:CreatePullPointSubscription>");

	if (p_req->FiltersFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tev:Filter>");
		offset += build_EventFilter(p_buf+offset, mlen-offset, &p_req->Filter);
		offset += snprintf(p_buf+offset, mlen-offset, "</tev:Filter>");
	}
		    
	offset += snprintf(p_buf+offset, mlen-offset,
		"<wsnt:InitialTerminationTime>PT%dS</wsnt:InitialTerminationTime>",
		p_req->InitialTerminationTime);	
		
	offset += snprintf(p_buf+offset, mlen-offset, "</wsnt:CreatePullPointSubscription>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_PullMessages_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	char to[256];
	PullMessages_REQ * p_req = (PullMessages_REQ *)argv;
	
	int offset = snprintf(p_buf, mlen, xml_hdr);

	snprintf(to, 256, "http://%s:%d%s", p_dev->Capabilities.events.XAddr.host, p_dev->Capabilities.events.XAddr.port, p_dev->Capabilities.events.XAddr.url);
	
	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header_ex(p_buf+offset, mlen-offset, p_dev, to, "http://www.onvif.org/ver10/events/wsdl/PullPointSubscription/PullMessagesRequest");
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tev:PullMessages>"
			"<tev:Timeout>PT%dS</tev:Timeout>"
    		"<tev:MessageLimit>%d</tev:MessageLimit>"
		"</tev:PullMessages>",
		p_req->Timeout,
		p_req->MessageLimit);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetImagingSettings_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GetImagingSettings_REQ * p_req = (GetImagingSettings_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<timg:GetImagingSettings>"
			"<timg:VideoSourceToken>%s</timg:VideoSourceToken>"
		"</timg:GetImagingSettings>",
		p_req->VideoSourceToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_SetImagingSettings_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	SetImagingSettings_REQ * p_req = (SetImagingSettings_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<timg:SetImagingSettings>");
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<timg:VideoSourceToken>%s</timg:VideoSourceToken>", 
		p_req->VideoSourceToken);

	offset += snprintf(p_buf+offset, mlen-offset, "<timg:ImagingSettings>");	

	if (p_req->ImagingSettings.BacklightCompensationFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:BacklightCompensation>");
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:Mode>%s</tt:Mode>", onvif_BacklightCompensationModeToString(p_req->ImagingSettings.BacklightCompensation.Mode));
		if (p_req->ImagingSettings.BacklightCompensation.LevelFlag)
		{
			offset += snprintf(p_buf+offset, mlen-offset, "<tt:Level>%0.6f</tt:Level>", p_req->ImagingSettings.BacklightCompensation.Level);
		}	
		offset += snprintf(p_buf+offset, mlen-offset, "</tt:BacklightCompensation>");
	}

	if (p_req->ImagingSettings.BrightnessFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:Brightness>%0.6f</tt:Brightness>", p_req->ImagingSettings.Brightness);
	}
	if (p_req->ImagingSettings.ColorSaturationFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:ColorSaturation>%0.6f</tt:ColorSaturation>", p_req->ImagingSettings.ColorSaturation);
	}
	if (p_req->ImagingSettings.ContrastFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:Contrast>%0.6f</tt:Contrast>", p_req->ImagingSettings.Contrast);
	}

	if (p_req->ImagingSettings.ExposureFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:Exposure>");
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:Mode>%s</tt:Mode>", onvif_ExposureModeToString(p_req->ImagingSettings.Exposure.Mode));
		if (p_req->ImagingSettings.Exposure.PriorityFlag)
		{
			offset += snprintf(p_buf+offset, mlen-offset, "<tt:Priority>%s</tt:Priority>", onvif_ExposurePriorityToString(p_req->ImagingSettings.Exposure.Priority));
		}
		if (p_req->ImagingSettings.Exposure.MinExposureTimeFlag)
		{
			offset += snprintf(p_buf+offset, mlen-offset, "<tt:MinExposureTime>%0.6f</tt:MinExposureTime>", p_req->ImagingSettings.Exposure.MinExposureTime);
		}
		if (p_req->ImagingSettings.Exposure.MaxExposureTimeFlag)
		{
			offset += snprintf(p_buf+offset, mlen-offset, "<tt:MaxExposureTime>%0.6f</tt:MaxExposureTime>", p_req->ImagingSettings.Exposure.MaxExposureTime);
		}
		if (p_req->ImagingSettings.Exposure.MinGainFlag)
		{
			offset += snprintf(p_buf+offset, mlen-offset, "<tt:MinGain>%0.6f</tt:MinGain>", p_req->ImagingSettings.Exposure.MinGain);
		}
		if (p_req->ImagingSettings.Exposure.MaxGainFlag)
		{
			offset += snprintf(p_buf+offset, mlen-offset, "<tt:MaxGain>%0.6f</tt:MaxGain>", p_req->ImagingSettings.Exposure.MaxGain);
		}
		if (p_req->ImagingSettings.Exposure.MinIrisFlag)
		{
			offset += snprintf(p_buf+offset, mlen-offset, "<tt:MinIris>%0.6f</tt:MinIris>", p_req->ImagingSettings.Exposure.MinIris);
		}
		if (p_req->ImagingSettings.Exposure.MaxIrisFlag)
		{
	    	offset += snprintf(p_buf+offset, mlen-offset, "<tt:MaxIris>%0.6f</tt:MaxIris>", p_req->ImagingSettings.Exposure.MaxIris);
	    }	
	    if (p_req->ImagingSettings.Exposure.ExposureTimeFlag)
	    {
	    	offset += snprintf(p_buf+offset, mlen-offset, "<tt:ExposureTime>%0.6f</tt:ExposureTime>", p_req->ImagingSettings.Exposure.ExposureTime);
	    }	
	    if (p_req->ImagingSettings.Exposure.GainFlag)
	    {
	    	offset += snprintf(p_buf+offset, mlen-offset, "<tt:Gain>%0.6f</tt:Gain>", p_req->ImagingSettings.Exposure.Gain);
	    }	
	    if (p_req->ImagingSettings.Exposure.IrisFlag)
	    {
	    	offset += snprintf(p_buf+offset, mlen-offset, "<tt:Iris>%0.6f</tt:Iris>", p_req->ImagingSettings.Exposure.Iris);
	    }
		offset += snprintf(p_buf+offset, mlen-offset, "</tt:Exposure>");			
	}

	if (p_req->ImagingSettings.FocusFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:Focus>");
	    offset += snprintf(p_buf+offset, mlen-offset, "<tt:AutoFocusMode>%s</tt:AutoFocusMode>", onvif_AutoFocusModeToString(p_req->ImagingSettings.Focus.AutoFocusMode));
	    if (p_req->ImagingSettings.Focus.DefaultSpeedFlag)
	    {
	    	offset += snprintf(p_buf+offset, mlen-offset, "<tt:DefaultSpeed>%0.6f</tt:DefaultSpeed>", p_req->ImagingSettings.Focus.DefaultSpeed);
	    }
	    if (p_req->ImagingSettings.Focus.NearLimitFlag)
	    {
	    	offset += snprintf(p_buf+offset, mlen-offset, "<tt:NearLimit>%0.6f</tt:NearLimit>", p_req->ImagingSettings.Focus.NearLimit);
	    }
	    if (p_req->ImagingSettings.Focus.FarLimitFlag)
	    {
	    	offset += snprintf(p_buf+offset, mlen-offset, "<tt:FarLimit>%0.6f</tt:FarLimit>", p_req->ImagingSettings.Focus.FarLimit);
	    }	
	    offset += snprintf(p_buf+offset, mlen-offset, "</tt:Focus>");
    }

    if (p_req->ImagingSettings.IrCutFilterFlag)
    {
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:IrCutFilter>%s</tt:IrCutFilter>", onvif_IrCutFilterModeToString(p_req->ImagingSettings.IrCutFilter));
	}

	if (p_req->ImagingSettings.SharpnessFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:Sharpness>%0.6f</tt:Sharpness>", p_req->ImagingSettings.Sharpness);
	}

	if (p_req->ImagingSettings.WideDynamicRangeFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:WideDynamicRange>");
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:Mode>%s</tt:Mode>", onvif_WideDynamicModeToString(p_req->ImagingSettings.WideDynamicRange.Mode));
		if (p_req->ImagingSettings.WideDynamicRange.LevelFlag)
		{
			offset += snprintf(p_buf+offset, mlen-offset, "<tt:Level>%0.6f</tt:Level>", p_req->ImagingSettings.WideDynamicRange.Level);
		}	
		offset += snprintf(p_buf+offset, mlen-offset, "</tt:WideDynamicRange>");	
	}

	if (p_req->ImagingSettings.WhiteBalanceFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:WhiteBalance>");
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:Mode>%s</tt:Mode>", onvif_WhiteBalanceModeToString(p_req->ImagingSettings.WhiteBalance.Mode));
		if (p_req->ImagingSettings.WhiteBalance.CrGainFlag)
		{
			offset += snprintf(p_buf+offset, mlen-offset, "<tt:CrGain>%0.6f</tt:CrGain>", p_req->ImagingSettings.WhiteBalance.CrGain);
		}
		if (p_req->ImagingSettings.WhiteBalance.CbGainFlag)
		{
	    	offset += snprintf(p_buf+offset, mlen-offset, "<tt:CbGain>%0.6f</tt:CbGain>", p_req->ImagingSettings.WhiteBalance.CbGain);
	    }	
		offset += snprintf(p_buf+offset, mlen-offset, "</tt:WhiteBalance>");	
	}
	
	offset += snprintf(p_buf+offset, mlen-offset, "</timg:ImagingSettings>");

	if (p_req->ForcePersistenceFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<timg:ForcePersistence>%s</timg:ForcePersistence>", p_req->ForcePersistence ? "true" : "false");
	}
	
	offset += snprintf(p_buf+offset, mlen-offset, "</timg:SetImagingSettings>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetOptions_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GetOptions_REQ * p_req = (GetOptions_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<timg:GetOptions>"
			"<timg:VideoSourceToken>%s</timg:VideoSourceToken>"
		"</timg:GetOptions>", 
		p_req->VideoSourceToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_img_Move_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset;
	img_Move_REQ * p_req = (img_Move_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<timg:Move>");
	offset += snprintf(p_buf+offset, mlen-offset, 
	    "<timg:VideoSourceToken>%s</timg:VideoSourceToken>",
	    p_req->VideoSourceToken);
    offset += snprintf(p_buf+offset, mlen-offset, "<timg:Focus>");
    if (p_req->Focus.AbsoluteFlag)
    {
        offset += snprintf(p_buf+offset, mlen-offset, "<tt:Absolute>");
        offset += snprintf(p_buf+offset, mlen-offset, 
            "<tt:Position>%0.2f</tt:Position>",
            p_req->Focus.Absolute.Position);
        if (p_req->Focus.Absolute.SpeedFlag)
        {
            offset += snprintf(p_buf+offset, mlen-offset, 
                "<tt:Speed>%0.2f</tt:Speed>",
                p_req->Focus.Absolute.Speed);            
        }    
        offset += snprintf(p_buf+offset, mlen-offset, "</tt:Absolute>");
    }
    if (p_req->Focus.RelativeFlag)
    {
        offset += snprintf(p_buf+offset, mlen-offset, "<tt:Relative>");
        offset += snprintf(p_buf+offset, mlen-offset, 
            "<tt:Distance>%0.2f</tt:Distance>",
            p_req->Focus.Relative.Distance);
        if (p_req->Focus.Relative.SpeedFlag)
        {
            offset += snprintf(p_buf+offset, mlen-offset, 
                "<tt:Speed>%0.2f</tt:Speed>",
                p_req->Focus.Relative.Speed);            
        }    
        offset += snprintf(p_buf+offset, mlen-offset, "</tt:Relative>");
    }
    if (p_req->Focus.ContinuousFlag)
    {
        offset += snprintf(p_buf+offset, mlen-offset, 
            "<tt:Continuous>"
                "<tt:Speed>%0.2f</tt:Speed>"
            "</tt:Continuous>",
            p_req->Focus.Continuous.Speed); 
    }
    offset += snprintf(p_buf+offset, mlen-offset, "</timg:Focus>");
	offset += snprintf(p_buf+offset, mlen-offset, "</timg:Move>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}
  
int build_img_Stop_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset;
	img_Stop_REQ * p_req = (img_Stop_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<timg:Stop>"
			"<timg:VideoSourceToken>%s</timg:VideoSourceToken>"
		"</timg:Stop>", 
		p_req->VideoSourceToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}
 
int build_img_GetStatus_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset;
	img_GetStatus_REQ * p_req = (img_GetStatus_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<timg:GetStatus>"
			"<timg:VideoSourceToken>%s</timg:VideoSourceToken>"
		"</timg:GetStatus>", 
		p_req->VideoSourceToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}
 
int build_img_GetMoveOptions_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset;
	img_GetMoveOptions_REQ * p_req = (img_GetMoveOptions_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<timg:GetMoveOptions>"
			"<timg:VideoSourceToken>%s</timg:VideoSourceToken>"
		"</timg:GetMoveOptions>", 
		p_req->VideoSourceToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}
 
int build_GetOSDs_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GetOSDs_REQ * p_req = (GetOSDs_REQ *) argv;

	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<trt:GetOSDs>");
	if (p_req && p_req->ConfigurationTokenFlag && p_req->ConfigurationToken[0] != '\0')
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<trt:ConfigurationToken>%s</trt:ConfigurationToken>",
			p_req->ConfigurationToken);
	}		
	offset += snprintf(p_buf+offset, mlen-offset, "</trt:GetOSDs>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetOSD_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GetOSD_REQ * p_req = (GetOSD_REQ *) argv;

	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:GetOSD>"
			"<trt:OSDToken>%s</trt:OSDToken>"
		"</trt:GetOSD>",
		p_req->OSDToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_OSD_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, onvif_OSDConfiguration * p_req)
{
	int offset = 0;

	offset += snprintf(p_buf+offset, mlen-offset, "<trt:OSD token=\"%s\">", p_req->token);

	offset += snprintf(p_buf+offset, mlen-offset, "<tt:VideoSourceConfigurationToken>%s</tt:VideoSourceConfigurationToken>", p_req->VideoSourceConfigurationToken);
	offset += snprintf(p_buf+offset, mlen-offset, "<tt:Type>%s</tt:Type>", onvif_OSDTypeToString(p_req->Type));

	offset += snprintf(p_buf+offset, mlen-offset, "<tt:Position>");
	offset += snprintf(p_buf+offset, mlen-offset, "<tt:Type>%s</tt:Type>", onvif_OSDPosTypeToString(p_req->Position.Type));
	if (p_req->Position.PosFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:Pos x=\"%0.2f\" y=\"%0.2f\" />", p_req->Position.Pos.x, p_req->Position.Pos.y);
	}	
	offset += snprintf(p_buf+offset, mlen-offset, "</tt:Position>");

	if (p_req->TextStringFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:TextString>");
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:Type>%s</tt:Type>", onvif_OSDTextTypeToString(p_req->TextString.Type));
		if (p_req->TextString.DateFormatFlag)
		{
			offset += snprintf(p_buf+offset, mlen-offset, "<tt:DateFormat>%s</tt:DateFormat>", p_req->TextString.DateFormat);
		}
		if (p_req->TextString.TimeFormatFlag)
		{
			offset += snprintf(p_buf+offset, mlen-offset, "<tt:TimeFormat>%s</tt:TimeFormat>", p_req->TextString.TimeFormat);
		}
		if (p_req->TextString.FontSizeFlag)
		{
			offset += snprintf(p_buf+offset, mlen-offset, "<tt:FontSize>%d</tt:FontSize>", p_req->TextString.FontSize);
		}
		if (p_req->TextString.FontColorFlag)
		{
			if (p_req->TextString.FontColor.TransparentFlag)
			{
				offset += snprintf(p_buf+offset, mlen-offset, "<tt:FontColor Transparent=\"%d\">", p_req->TextString.FontColor.Transparent);
			}
			else
			{
				offset += snprintf(p_buf+offset, mlen-offset, "<tt:FontColor>");
			}			
			
			offset += snprintf(p_buf+offset, mlen-offset, "<tt:Color X=\"%0.6f\" Y=\"%0.6f\" Z=\"%0.6f\" Colorspace=\"\"></tt:Color>", 
				p_req->TextString.FontColor.X, p_req->TextString.FontColor.X, p_req->TextString.FontColor.Z);
			offset += snprintf(p_buf+offset, mlen-offset, "</tt:FontColor>");				
		}
		if (p_req->TextString.BackgroundColorFlag)
		{
			if (p_req->TextString.BackgroundColor.TransparentFlag)
			{
				offset += snprintf(p_buf+offset, mlen-offset, "<tt:BackgroundColor Transparent=\"%d\">", p_req->TextString.FontColor.Transparent);
			}
			else
			{
				offset += snprintf(p_buf+offset, mlen-offset, "<tt:BackgroundColor>");
			}			
			
			offset += snprintf(p_buf+offset, mlen-offset, "<tt:Color X=\"%0.6f\" Y=\"%0.6f\" Z=\"%0.6f\" Colorspace=\"\"></tt:Color>", 
				p_req->TextString.BackgroundColor.X, p_req->TextString.BackgroundColor.X, p_req->TextString.BackgroundColor.Z);
			offset += snprintf(p_buf+offset, mlen-offset, "</tt:BackgroundColor>");				
		}
		if (p_req->TextString.PlainTextFlag)
		{
			offset += snprintf(p_buf+offset, mlen-offset, "<tt:PlainText>%s</tt:PlainText>", p_req->TextString.PlainText);
		}
		offset += snprintf(p_buf+offset, mlen-offset, "</tt:TextString>");
	}

	if (p_req->ImageFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, 
			"<tt:Image>"
				"<tt:ImgPath>%s</tt:ImgPath>"
			"</tt:Image>",
			p_req->Image.ImgPath);
	}
	
	offset += snprintf(p_buf+offset, mlen-offset, "</trt:OSD>");

	return offset;
}

int build_SetOSD_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	SetOSD_REQ * p_req = (SetOSD_REQ *) argv;
	assert(p_req);

	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<trt:SetOSD>");
	offset += build_OSD_xml(p_buf+offset, mlen-offset, p_dev, &p_req->OSD);
	offset += snprintf(p_buf+offset, mlen-offset, "</trt:SetOSD>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetOSDOptions_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GetOSDOptions_REQ * p_req = (GetOSDOptions_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:GetOSDOptions>"
			"<trt:ConfigurationToken>%s</trt:ConfigurationToken>"
		"</trt:GetOSDOptions>",
		p_req->ConfigurationToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_CreateOSD_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	CreateOSD_REQ * p_req = (CreateOSD_REQ *) argv;
	assert(p_req);

	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<trt:CreateOSD>");
	offset += build_OSD_xml(p_buf+offset, mlen-offset, p_dev, &p_req->OSD);
	offset += snprintf(p_buf+offset, mlen-offset, "</trt:CreateOSD>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_DeleteOSD_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GetOSD_REQ * p_req = (GetOSD_REQ *) argv;

	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:DeleteOSD>"
			"<trt:OSDToken>%s</trt:OSDToken>"
		"</trt:DeleteOSD>",
		p_req->OSDToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetVideoAnalyticsConfigurations_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;

	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<trt:GetVideoAnalyticsConfigurations />");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_AddVideoAnalyticsConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	AddVideoAnalyticsConfiguration_REQ * p_req = (AddVideoAnalyticsConfiguration_REQ *) argv;

	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:AddVideoAnalyticsConfiguration>"
			"<trt:ProfileToken>%s</trt:ProfileToken>"
    		"<trt:ConfigurationToken>%s</trt:ConfigurationToken>"
		"</trt:AddVideoAnalyticsConfiguration>",
		p_req->ProfileToken,
		p_req->ConfigurationToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetVideoAnalyticsConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GetVideoAnalyticsConfiguration_REQ * p_req = (GetVideoAnalyticsConfiguration_REQ *) argv;

	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:GetVideoAnalyticsConfiguration>"
    		"<trt:ConfigurationToken>%s</trt:ConfigurationToken>"
		"</trt:GetVideoAnalyticsConfiguration>",
		p_req->ConfigurationToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_RemoveVideoAnalyticsConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GetVideoAnalyticsConfiguration_REQ * p_req = (GetVideoAnalyticsConfiguration_REQ *) argv;

	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trt:RemoveVideoAnalyticsConfiguration>"
    		"<trt:ConfigurationToken>%s</trt:ConfigurationToken>"
		"</trt:RemoveVideoAnalyticsConfiguration>",
		p_req->ConfigurationToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_SimpleItem_xml(char * p_buf, int mlen, onvif_SimpleItem * p_req)
{
	int offset = 0;
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tt:SimpleItem Name=\"%s\" Value=\"%s\" />",
		p_req->Name, p_req->Value);

	return offset;
}

int build_Config_xml(char * p_buf, int mlen, onvif_Config * p_req)
{
	int offset = 0;
	ONVIF_SimpleItem * p_simpleitem;
	ONVIF_ElementItem * p_elementitem;

	offset += snprintf(p_buf+offset, mlen-offset, "<tt:Parameters>");

	p_simpleitem = p_req->Parameters.SimpleItem;
	while (p_simpleitem)
	{
		offset += build_SimpleItem_xml(p_buf+offset, mlen-offset, &p_simpleitem->SimpleItem);
		
		p_simpleitem = p_simpleitem->next;
	}

	p_elementitem = p_req->Parameters.ElementItem;
	while (p_elementitem)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:ElementItem Name=\"%s\" />", p_elementitem->ElementItem.Name);
		
		p_elementitem = p_elementitem->next;
	}
	
	offset += snprintf(p_buf+offset, mlen-offset, "</tt:Parameters>");
	
	return offset;
}

int build_VideoAnalyticsConfiguration_xml(char * p_buf, int mlen, onvif_VideoAnalyticsConfiguration * p_req)
{
	int offset = 0;
	ONVIF_Config * p_config;
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tt:Name>%s</tt:Name>"
    	"<tt:UseCount>%d</tt:UseCount>",
    	p_req->Name, p_req->UseCount);

	offset += snprintf(p_buf+offset, mlen-offset, "<tt:AnalyticsEngineConfiguration>");

	p_config = p_req->AnalyticsEngineConfiguration.AnalyticsModule;
	while (p_config)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:AnalyticsModule Name=\"%s\" Type=\"%s\">", 
			p_config->Config.Name, p_config->Config.Type);
		offset += build_Config_xml(p_buf+offset, mlen-offset, &p_config->Config);
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:AnalyticsModule>");
	}
	
	offset += snprintf(p_buf+offset, mlen-offset, "</tt:AnalyticsEngineConfiguration>");

	offset += snprintf(p_buf+offset, mlen-offset, "<tt:RuleEngineConfiguration>");

	p_config = p_req->RuleEngineConfiguration.Rule;
	while (p_config)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:Rule Name=\"%s\" Type=\"%s\">", 
			p_config->Config.Name, p_config->Config.Type);
		offset += build_Config_xml(p_buf+offset, mlen-offset, &p_config->Config);
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:Rule>");
	}
	
	offset += snprintf(p_buf+offset, mlen-offset, "</tt:RuleEngineConfiguration>");
	
	return offset;
}

int build_SetVideoAnalyticsConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	SetVideoAnalyticsConfiguration_REQ * p_req = (SetVideoAnalyticsConfiguration_REQ *) argv;

	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<trt:SetVideoAnalyticsConfiguration>");

    offset += snprintf(p_buf+offset, mlen-offset, "<trt:Configuration token=\"%s\">", p_req->Configuration.token);
	offset += build_VideoAnalyticsConfiguration_xml(p_buf+offset, mlen-offset, &p_req->Configuration);
	offset += snprintf(p_buf+offset, mlen-offset, "</trt:Configuration>");

	offset += snprintf(p_buf+offset, mlen-offset, "<trt:ForcePersistence>%s</trt:ForcePersistence>", p_req->ForcePersistence ? "true" : "false");
	
	offset += snprintf(p_buf+offset, mlen-offset, "</trt:SetVideoAnalyticsConfiguration>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetSupportedRules_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GetSupportedRules_REQ * p_req = (GetSupportedRules_REQ *) argv;

	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tan:GetSupportedRules>"
    		"<tan:ConfigurationToken>%s</tan:ConfigurationToken>"
		"</tan:GetSupportedRules>",
		p_req->ConfigurationToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_CreateRules_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	ONVIF_Config * p_config;
	CreateRules_REQ * p_req = (CreateRules_REQ *) argv;

	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tan:CreateRules>");
    offset += snprintf(p_buf+offset, mlen-offset, "<tan:ConfigurationToken>%s</tan:ConfigurationToken>", p_req->ConfigurationToken);

    p_config = p_req->Rule;
	while (p_config)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tan:Rule Name=\"%s\" Type=\"%s\">", p_config->Config.Name, p_config->Config.Type);
		offset += build_Config_xml(p_buf+offset, mlen-offset, &p_config->Config);
		offset += snprintf(p_buf+offset, mlen-offset, "</tan:Rule>");
		
		p_config = p_config->next;
	}
	
	offset += snprintf(p_buf+offset, mlen-offset, "</tan:CreateRules>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_DeleteRules_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int i, offset;
	DeleteRules_REQ * p_req = (DeleteRules_REQ *) argv;

	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);

	offset += snprintf(p_buf+offset, mlen-offset, "<tan:DeleteRules>");
    offset += snprintf(p_buf+offset, mlen-offset, "<tan:ConfigurationToken>%s</tan:ConfigurationToken>", p_req->ConfigurationToken);

	for (i = 0; i < p_req->sizeRuleName; i++)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tan:RuleName>%s</tan:RuleName>", p_req->RuleName[i]);
	}
	
	offset += snprintf(p_buf+offset, mlen-offset, "</tan:DeleteRules>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetRules_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GetRules_REQ * p_req = (GetRules_REQ *) argv;

	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tan:GetRules>"
    		"<tan:ConfigurationToken>%s</tan:ConfigurationToken>"
		"</tan:GetRules>",
		p_req->ConfigurationToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_ModifyRules_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	ONVIF_Config * p_config;
	ModifyRules_REQ * p_req = (ModifyRules_REQ *) argv;

	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);

	offset += snprintf(p_buf+offset, mlen-offset, "<tan:ModifyRules>");
    offset += snprintf(p_buf+offset, mlen-offset, "<tan:ConfigurationToken>%s</tan:ConfigurationToken>", p_req->ConfigurationToken);

    p_config = p_req->Rule;
	while (p_config)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tan:Rule Name=\"%s\" Type=\"%s\">", p_config->Config.Name, p_config->Config.Type);
		offset += build_Config_xml(p_buf+offset, mlen-offset, &p_config->Config);
		offset += snprintf(p_buf+offset, mlen-offset, "</tan:Rule>");
		
		p_config = p_config->next;
	}
	
	offset += snprintf(p_buf+offset, mlen-offset, "</tan:ModifyRules>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_CreateAnalyticsModules_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	ONVIF_Config * p_config;
	CreateAnalyticsModules_REQ * p_req = (CreateAnalyticsModules_REQ *) argv;

	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tan:CreateAnalyticsModules>");
    offset += snprintf(p_buf+offset, mlen-offset, "<tan:ConfigurationToken>%s</tan:ConfigurationToken>", p_req->ConfigurationToken);

    p_config = p_req->AnalyticsModule;
	while (p_config)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tan:AnalyticsModule Name=\"%s\" Type=\"%s\">", p_config->Config.Name, p_config->Config.Type);
		offset += build_Config_xml(p_buf+offset, mlen-offset, &p_config->Config);
		offset += snprintf(p_buf+offset, mlen-offset, "</tan:AnalyticsModule>");
		
		p_config = p_config->next;
	}
	
	offset += snprintf(p_buf+offset, mlen-offset, "</tan:CreateAnalyticsModules>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_DeleteAnalyticsModules_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int i, offset;
	DeleteAnalyticsModules_REQ * p_req = (DeleteAnalyticsModules_REQ *) argv;

	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);

	offset += snprintf(p_buf+offset, mlen-offset, "<tan:DeleteAnalyticsModules>");
    offset += snprintf(p_buf+offset, mlen-offset, "<tan:ConfigurationToken>%s</tan:ConfigurationToken>", p_req->ConfigurationToken);

	for (i = 0; i < p_req->sizeAnalyticsModuleName; i++)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tan:AnalyticsModuleName>%s</tan:AnalyticsModuleName>", p_req->AnalyticsModuleName[i]);
	}
	
	offset += snprintf(p_buf+offset, mlen-offset, "</tan:DeleteAnalyticsModules>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetAnalyticsModules_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GetAnalyticsModules_REQ * p_req = (GetAnalyticsModules_REQ *) argv;

	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tan:GetAnalyticsModules>"
    		"<tan:ConfigurationToken>%s</tan:ConfigurationToken>"
		"</tan:GetAnalyticsModules>",
		p_req->ConfigurationToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_ModifyAnalyticsModules_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	ONVIF_Config * p_config;
	ModifyAnalyticsModules_REQ * p_req = (ModifyAnalyticsModules_REQ *) argv;

	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tan:ModifyAnalyticsModules>");
    offset += snprintf(p_buf+offset, mlen-offset, "<tan:ConfigurationToken>%s</tan:ConfigurationToken>", p_req->ConfigurationToken);

    p_config = p_req->AnalyticsModule;
	while (p_config)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tan:AnalyticsModule Name=\"%s\" Type=\"%s\">", p_config->Config.Name, p_config->Config.Type);
		offset += build_Config_xml(p_buf+offset, mlen-offset, &p_config->Config);
		offset += snprintf(p_buf+offset, mlen-offset, "</tan:AnalyticsModule>");
		
		p_config = p_config->next;
	}
	
	offset += snprintf(p_buf+offset, mlen-offset, "</tan:ModifyAnalyticsModules>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_tr2_GetConfiguration_xml(char * p_buf, int mlen, tr2_GetConfiguration * p_req)
{
	int offset = 0;
	
	if (p_req->ConfigurationTokenFlag)
	{
	    offset += snprintf(p_buf+offset, mlen-offset, 
	    	"<tr2:ConfigurationToken>%s</tr2:ConfigurationToken>", 
	    	p_req->ConfigurationToken);
	}
	
	if (p_req->ProfileTokenFlag)
	{
	    offset += snprintf(p_buf+offset, mlen-offset, 
	    	"<tr2:ProfileToken>%s</tr2:ProfileToken>", 
	    	p_req->ProfileToken);
	}

	return offset;
}

int build_tr2_GetVideoEncoderConfigurations_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset = snprintf(p_buf, mlen, xml_hdr);
    tr2_GetVideoEncoderConfigurations_REQ * p_req = (tr2_GetVideoEncoderConfigurations_REQ *) argv;
    
	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tr2:GetVideoEncoderConfigurations>");
    if (p_req)
    {
    	offset += build_tr2_GetConfiguration_xml(p_buf+offset, mlen-offset, &p_req->GetConfiguration);
	}
	offset += snprintf(p_buf+offset, mlen-offset, "</tr2:GetVideoEncoderConfigurations>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_VideoEncoder2Configuration_xml(char * p_buf, int mlen, onvif_VideoEncoder2Configuration * p_req)
{
    int offset = 0;
    
    offset += snprintf(p_buf+offset, mlen-offset, 
		"<tt:Name>%s</tt:Name>"
		"<tt:UseCount>%d</tt:UseCount>"
	    "<tt:Encoding>%s</tt:Encoding>"
	    "<tt:Resolution>"
	    	"<tt:Width>%d</tt:Width>"
	    	"<tt:Height>%d</tt:Height>"
	    "</tt:Resolution>",
	    p_req->Name, 
	    p_req->UseCount, 
	    p_req->Encoding, 
	    p_req->Resolution.Width, 
	    p_req->Resolution.Height);

	if (p_req->RateControlFlag)
	{
	    offset += snprintf(p_buf+offset, mlen-offset, "<tt:RateControl");
	    if (p_req->RateControl.ConstantBitRateFlag)
	    {
	        offset += snprintf(p_buf+offset, mlen-offset, " ConstantBitRate=\"%s\"",
	            p_req->RateControl.ConstantBitRate ? "true" : "false");
	    }
	    offset += snprintf(p_buf+offset, mlen-offset, ">");
		    
		offset += snprintf(p_buf+offset, mlen-offset, 
		    	"<tt:FrameRateLimit>%0.1f</tt:FrameRateLimit>"
		    	"<tt:BitrateLimit>%d</tt:BitrateLimit>"
		    "</tt:RateControl>",		    
		    p_req->RateControl.FrameRateLimit,
		    p_req->RateControl.BitrateLimit);
	}

    if (p_req->MulticastFlag)
    {
	    offset += build_MulticastConfiguration_xml(p_buf+offset, mlen-offset, &p_req->Multicast);
	}

	offset += snprintf(p_buf+offset, mlen-offset, "<tt:Quality>%0.2f</tt:Quality>", p_req->Quality);

	return offset;  
}

int build_tr2_SetVideoEncoderConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	tr2_SetVideoEncoderConfiguration_REQ * p_req = (tr2_SetVideoEncoderConfiguration_REQ *) argv;
    assert(p_req);
    
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tr2:SetVideoEncoderConfiguration>");
	offset += snprintf(p_buf+offset, mlen-offset, "<tr2:Configuration token=\"%s\"", p_req->Configuration.token);
	if (p_req->Configuration.GovLengthFlag)
	{
	    offset += snprintf(p_buf+offset, mlen-offset, " GovLength=\"%d\"", p_req->Configuration.GovLength);
	}
	if (p_req->Configuration.ProfileFlag)
	{
	    offset += snprintf(p_buf+offset, mlen-offset, " Profile=\"%s\"", p_req->Configuration.Profile);
	}
	offset += snprintf(p_buf+offset, mlen-offset, ">");

	offset += build_VideoEncoder2Configuration_xml(p_buf+offset, mlen-offset, &p_req->Configuration);
		
	offset += snprintf(p_buf+offset, mlen-offset, "</tr2:Configuration>");		
	offset += snprintf(p_buf+offset, mlen-offset, "</tr2:SetVideoEncoderConfiguration>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_tr2_GetVideoEncoderConfigurationOptions_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	tr2_GetVideoEncoderConfigurationOptions_REQ * p_req = (tr2_GetVideoEncoderConfigurationOptions_REQ *) argv;
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tr2:GetVideoEncoderConfigurationOptions>");
	if (p_req)
    {
    	offset += build_tr2_GetConfiguration_xml(p_buf+offset, mlen-offset, &p_req->GetConfiguration);
	}
    offset += snprintf(p_buf+offset, mlen-offset, "</tr2:GetVideoEncoderConfigurationOptions>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_tr2_GetProfiles_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int i;
	tr2_GetProfiles_REQ * p_req = (tr2_GetProfiles_REQ *) argv;
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tr2:GetProfiles>");
	if (p_req)
    {
    	if (p_req->TokenFlag)
    	{
    		offset += snprintf(p_buf+offset, mlen-offset, 
    			"<tr2:Token>%s</tr2:Token>",
    			p_req->Token);
    	}

    	for (i = 0; i < p_req->sizeType; i++)
    	{
    		offset += snprintf(p_buf+offset, mlen-offset, 
    			"<tr2:Type>%s</tr2:Type>",
    			p_req->Type[i]);
    	}
	}
    offset += snprintf(p_buf+offset, mlen-offset, "</tr2:GetProfiles>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_tr2_ConfigurationRef(char * p_buf, int mlen, onvif_ConfigurationRef * p_req)
{
	int offset = 0;
	
	offset += snprintf(p_buf+offset, mlen-offset, 
			"<tr2:Type>%s</tr2:Type>",
			p_req->Type);

	if (p_req->TokenFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, 
			"<tr2:Token>%s</tr2:Token>",
			p_req->Token);
	}

	return offset;
}

int build_tr2_CreateProfile_xml	(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int i;
	tr2_CreateProfile_REQ * p_req = (tr2_CreateProfile_REQ *) argv;
	assert(p_req);
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tr2:CreateProfile>");
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tr2:Name>%s</tr2:Name>", 
		p_req->Name);

	for (i = 0; i < p_req->sizeConfiguration; i++)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tr2:Configuration>");
		
		offset += build_tr2_ConfigurationRef(p_buf+offset, mlen-offset, &p_req->Configuration[i]);

		offset += snprintf(p_buf+offset, mlen-offset, "</tr2:Configuration>");
	}
    offset += snprintf(p_buf+offset, mlen-offset, "</tr2:CreateProfile>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_tr2_DeleteProfile_xml	(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	tr2_DeleteProfile_REQ * p_req = (tr2_DeleteProfile_REQ *) argv;
	assert(p_req);
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tr2:DeleteProfile>"	
			"<tr2:Token>%s</tr2:Token>"
		"</tr2:DeleteProfile>",
		p_req->Token);

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_tr2_GetStreamUri_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	tr2_GetStreamUri_REQ * p_req = (tr2_GetStreamUri_REQ *) argv;
	assert(p_req);
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tr2:GetStreamUri>"
			"<tr2:Protocol>%s</tr2:Protocol>"
			"<tr2:ProfileToken>%s</tr2:ProfileToken>"
		"</tr2:GetStreamUri>",
		p_req->Protocol,
		p_req->ProfileToken);

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_tr2_GetVideoSourceConfigurations_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	tr2_GetVideoSourceConfigurations_REQ * p_req = (tr2_GetVideoSourceConfigurations_REQ *) argv;
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tr2:GetVideoSourceConfigurations>");
	if (p_req)
    {
    	offset += build_tr2_GetConfiguration_xml(p_buf+offset, mlen-offset, &p_req->GetConfiguration);
	}
    offset += snprintf(p_buf+offset, mlen-offset, "</tr2:GetVideoSourceConfigurations>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_tr2_GetVideoSourceConfigurationOptions_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	tr2_GetVideoSourceConfigurationOptions_REQ * p_req = (tr2_GetVideoSourceConfigurationOptions_REQ *) argv;
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tr2:GetVideoSourceConfigurationOptions>");
	if (p_req)
    {
    	offset += build_tr2_GetConfiguration_xml(p_buf+offset, mlen-offset, &p_req->GetConfiguration);
	}
    offset += snprintf(p_buf+offset, mlen-offset, "</tr2:GetVideoSourceConfigurationOptions>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_tr2_SetVideoSourceConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	tr2_SetVideoSourceConfiguration_REQ * p_req = (tr2_SetVideoSourceConfiguration_REQ *) argv;

	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tr2:SetVideoSourceConfiguration>"
		"<tr2:Configuration token=\"%s\">",
		p_req->Configuration.token);
	offset += build_VideoSourceConfiguration_xml(p_buf+offset, mlen-offset, &p_req->Configuration);
	offset += snprintf(p_buf+offset, mlen-offset, 
		"</tr2:Configuration>"
		"</tr2:SetVideoSourceConfiguration>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_tr2_SetSynchronizationPoint_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	tr2_SetSynchronizationPoint_REQ * p_req = (tr2_SetSynchronizationPoint_REQ *) argv;
	assert(p_req);
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tr2:SetSynchronizationPoint>"
			"<tr2:ProfileToken>%s</tr2:ProfileToken>"
		"</tr2:SetSynchronizationPoint>",
		p_req->ProfileToken);

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
	
int build_tr2_GetMetadataConfigurations_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	tr2_GetMetadataConfigurations_REQ * p_req = (tr2_GetMetadataConfigurations_REQ *) argv;
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tr2:GetMetadataConfigurations>");
	if (p_req)
    {
    	offset += build_tr2_GetConfiguration_xml(p_buf+offset, mlen-offset, &p_req->GetConfiguration);
	}
    offset += snprintf(p_buf+offset, mlen-offset, "</tr2:GetMetadataConfigurations>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
	
int build_tr2_GetMetadataConfigurationOptions_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	tr2_GetMetadataConfigurationOptions_REQ * p_req = (tr2_GetMetadataConfigurationOptions_REQ *) argv;
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tr2:GetMetadataConfigurationOptions>");
	if (p_req)
    {
    	offset += build_tr2_GetConfiguration_xml(p_buf+offset, mlen-offset, &p_req->GetConfiguration);
	}
    offset += snprintf(p_buf+offset, mlen-offset, "</tr2:GetMetadataConfigurationOptions>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
	
int build_tr2_SetMetadataConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	tr2_SetMetadataConfiguration_REQ * p_req = (tr2_SetMetadataConfiguration_REQ *) argv;

	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tr2:SetMetadataConfiguration>"
		"<tr2:Configuration token=\"%s\">",
		p_req->Configuration.token);
	offset += build_MetadataConfiguration_xml(p_buf+offset, mlen-offset, &p_req->Configuration);
	offset += snprintf(p_buf+offset, mlen-offset, 
		"</tr2:Configuration>"
		"</tr2:SetMetadataConfiguration>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
	
int build_tr2_GetAudioEncoderConfigurations_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	tr2_GetAudioEncoderConfigurations_REQ * p_req = (tr2_GetAudioEncoderConfigurations_REQ *) argv;
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tr2:GetAudioEncoderConfigurations>");
	if (p_req)
    {
    	offset += build_tr2_GetConfiguration_xml(p_buf+offset, mlen-offset, &p_req->GetConfiguration);
	}
    offset += snprintf(p_buf+offset, mlen-offset, "</tr2:GetAudioEncoderConfigurations>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
	
int build_tr2_GetAudioSourceConfigurations_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	tr2_GetAudioSourceConfigurations_REQ * p_req = (tr2_GetAudioSourceConfigurations_REQ *) argv;
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tr2:GetAudioSourceConfigurations>");
	if (p_req)
    {
    	offset += build_tr2_GetConfiguration_xml(p_buf+offset, mlen-offset, &p_req->GetConfiguration);
	}
    offset += snprintf(p_buf+offset, mlen-offset, "</tr2:GetAudioSourceConfigurations>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
	
int build_tr2_GetAudioSourceConfigurationOptions_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	tr2_GetAudioSourceConfigurationOptions_REQ * p_req = (tr2_GetAudioSourceConfigurationOptions_REQ *) argv;
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tr2:GetAudioSourceConfigurationOptions>");
	if (p_req)
    {
    	offset += build_tr2_GetConfiguration_xml(p_buf+offset, mlen-offset, &p_req->GetConfiguration);
	}
    offset += snprintf(p_buf+offset, mlen-offset, "</tr2:GetAudioSourceConfigurationOptions>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
	
int build_tr2_SetAudioSourceConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	tr2_SetAudioSourceConfiguration_REQ * p_req = (tr2_SetAudioSourceConfiguration_REQ *) argv;

	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tr2:SetAudioSourceConfiguration>"
		"<tr2:Configuration token=\"%s\">",
		p_req->Configuration.token);	
	offset += build_AudioSourceConfiguration_xml(p_buf+offset, mlen-offset, &p_req->Configuration);
	offset += snprintf(p_buf+offset, mlen-offset, 
		"</tr2:Configuration>"
		"</tr2:SetAudioSourceConfiguration>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}

int build_AudioEncoder2Configuration_xml(char * p_buf, int mlen, onvif_AudioEncoder2Configuration * p_req)
{
    int offset = 0;
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tt:Name>%s</tt:Name>"
		"<tt:UseCount>%d</tt:UseCount>"
		"<tt:Encoding>%s</tt:Encoding>"
		"<tt:Bitrate>%d</tt:Bitrate>"
		"<tt:SampleRate>%d</tt:SampleRate>", 
		p_req->Name, 
    	p_req->UseCount, 
    	p_req->Encoding, 
	    p_req->Bitrate, 
	    p_req->SampleRate); 

    if (p_req->MulticastFlag)
    {
	    offset += build_MulticastConfiguration_xml(p_buf+offset, mlen-offset, &p_req->Multicast);
    }
		
	return offset;   
}

int build_tr2_SetAudioEncoderConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	tr2_SetAudioEncoderConfiguration_REQ * p_req = (tr2_SetAudioEncoderConfiguration_REQ *) argv;

	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tr2:SetAudioEncoderConfiguration>"
		"<tr2:Configuration token=\"%s\">",
		p_req->Configuration.token);
	offset += build_AudioEncoder2Configuration_xml(p_buf+offset, mlen-offset, &p_req->Configuration);
	offset += snprintf(p_buf+offset, mlen-offset, 
		"</tr2:Configuration>"
		"</tr2:SetAudioEncoderConfiguration>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
	
int build_tr2_GetAudioEncoderConfigurationOptions_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	tr2_GetAudioEncoderConfigurationOptions_REQ * p_req = (tr2_GetAudioEncoderConfigurationOptions_REQ *) argv;
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tr2:GetAudioEncoderConfigurationOptions>");
	if (p_req)
    {
    	offset += build_tr2_GetConfiguration_xml(p_buf+offset, mlen-offset, &p_req->GetConfiguration);
	}
    offset += snprintf(p_buf+offset, mlen-offset, "</tr2:GetAudioEncoderConfigurationOptions>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}	
	
int build_tr2_AddConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int i;
	tr2_AddConfiguration_REQ * p_req = (tr2_AddConfiguration_REQ *) argv;
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tr2:AddConfiguration>");
	offset += snprintf(p_buf+offset, mlen-offset, 
			"<tr2:ProfileToken>%s</tr2:ProfileToken>",
			p_req->ProfileToken);
	if (p_req->NameFlag)
	{
		offset += snprintf(p_buf+offset, mlen-offset, 
			"<tr2:Name>%s</tr2:Name>",
			p_req->Name);
	}

	for (i = 0; i < p_req->sizeConfiguration; i++)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tr2:Configuration>");
		
		offset += build_tr2_ConfigurationRef(p_buf+offset, mlen-offset, &p_req->Configuration[i]);

		offset += snprintf(p_buf+offset, mlen-offset, "</tr2:Configuration>");
	}
    offset += snprintf(p_buf+offset, mlen-offset, "</tr2:AddConfiguration>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
	
int build_tr2_RemoveConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int i;
	tr2_RemoveConfiguration_REQ * p_req = (tr2_RemoveConfiguration_REQ *) argv;
	assert(p_req);
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tr2:RemoveConfiguration>");
	offset += snprintf(p_buf+offset, mlen-offset, 
			"<tr2:ProfileToken>%s</tr2:ProfileToken>",
			p_req->ProfileToken);

	for (i = 0; i < p_req->sizeConfiguration; i++)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tr2:Configuration>");
		
		offset += build_tr2_ConfigurationRef(p_buf+offset, mlen-offset, &p_req->Configuration[i]);

		offset += snprintf(p_buf+offset, mlen-offset, "</tr2:Configuration>");
	}
    offset += snprintf(p_buf+offset, mlen-offset, "</tr2:RemoveConfiguration>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
	
int build_tr2_GetVideoEncoderInstances_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	tr2_GetVideoEncoderInstances_REQ * p_req = (tr2_GetVideoEncoderInstances_REQ *) argv;
	assert(p_req);
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tr2:GetVideoEncoderInstances>"
			"<tr2:ConfigurationToken>%s</tr2:ConfigurationToken>"
		"</tr2:GetVideoEncoderInstances>",
		p_req->ConfigurationToken);

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}	

#ifdef PROFILE_G_SUPPORT

int build_RecordingConfiguration_xml(char * p_buf, int mlen, onvif_RecordingConfiguration * p_req)
{
    int offset = 0;

    offset += snprintf(p_buf+offset, mlen-offset, 
        "<tt:Source>"
            "<tt:SourceId>%s</tt:SourceId>"
            "<tt:Name>%s</tt:Name>"
            "<tt:Location>%s</tt:Location>"
            "<tt:Description>%s</tt:Description>"
            "<tt:Address>%s</tt:Address>"
        "</tt:Source>"
        "<tt:Content>%s</tt:Content>",
        p_req->Source.SourceId, 
        p_req->Source.Name,
        p_req->Source.Location,
        p_req->Source.Description,
        p_req->Source.Address,
        p_req->Content);

    if (p_req->MaximumRetentionTimeFlag)
    {
        offset += snprintf(p_buf+offset, mlen-offset, 
            "<tt:MaximumRetentionTime>PT%dS</tt:MaximumRetentionTime>",
            p_req->MaximumRetentionTime);
    }

    return offset;
}

int build_CreateRecording_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset;
	CreateRecording_REQ * p_req = (CreateRecording_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<trc:CreateRecording><trc:RecordingConfiguration>");
	offset += build_RecordingConfiguration_xml(p_buf+offset, mlen-offset, &p_req->RecordingConfiguration);
	offset += snprintf(p_buf+offset, mlen-offset, "</trc:RecordingConfiguration></trc:CreateRecording>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}
  
int build_DeleteRecording_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset;
	DeleteRecording_REQ * p_req = (DeleteRecording_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
	    "<trc:DeleteRecording>"
	        "<trc:RecordingToken>%s</trc:RecordingToken>"
	    "</trc:DeleteRecording>",
	    p_req->RecordingToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}
 
int build_GetRecordings_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset;
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<trc:GetRecordings />");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}
 
int build_SetRecordingConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset;
	SetRecordingConfiguration_REQ * p_req = (SetRecordingConfiguration_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);

	offset += snprintf(p_buf+offset, mlen-offset, "<trc:SetRecordingConfiguration>");
	offset += snprintf(p_buf+offset, mlen-offset, 
	    "<trc:RecordingToken>%s</trc:RecordingToken>",
	    p_req->RecordingToken);
	offset += snprintf(p_buf+offset, mlen-offset, "<trc:RecordingConfiguration>");
	offset += build_RecordingConfiguration_xml(p_buf+offset, mlen-offset, &p_req->RecordingConfiguration);
	offset += snprintf(p_buf+offset, mlen-offset, "</trc:RecordingConfiguration>");
	offset += snprintf(p_buf+offset, mlen-offset, "</trc:SetRecordingConfiguration>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}
 
int build_GetRecordingConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset;
	GetRecordingConfiguration_REQ * p_req = (GetRecordingConfiguration_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
	    "<trc:GetRecordingConfiguration>"
	        "<trc:RecordingToken>%s</trc:RecordingToken>"
	    "</trc:GetRecordingConfiguration>",
	    p_req->RecordingToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}
 
int build_GetRecordingOptions_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset;
	GetRecordingConfiguration_REQ * p_req = (GetRecordingConfiguration_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
	    "<trc:GetRecordingOptions>"
	        "<trc:RecordingToken>%s</trc:RecordingToken>"
	    "</trc:GetRecordingOptions>",
	    p_req->RecordingToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_TrackConfiguration_xml(char * p_buf, int mlen, onvif_TrackConfiguration * p_req)
{
    int offset = 0;

    offset += snprintf(p_buf+offset, mlen-offset, 
        "<tt:TrackType>%s</tt:TrackType>"
        "<tt:Description>%s</tt:Description>",
        onvif_TrackTypeToString(p_req->TrackType),
	    p_req->Description);

    return offset;	    
}

int build_CreateTrack_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset;
	CreateTrack_REQ * p_req = (CreateTrack_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<trc:CreateTrack>");
	offset += snprintf(p_buf+offset, mlen-offset, 
	    "<trc:RecordingToken>%s</trc:RecordingToken>",
	    p_req->RecordingToken);
	offset += snprintf(p_buf+offset, mlen-offset, "<trc:TrackConfiguration>");	    
	offset += build_TrackConfiguration_xml(p_buf+offset, mlen-offset, &p_req->TrackConfiguration);
	offset += snprintf(p_buf+offset, mlen-offset, "</trc:TrackConfiguration>");
	offset += snprintf(p_buf+offset, mlen-offset, "</trc:CreateTrack>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}
 
int build_DeleteTrack_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset;
	DeleteTrack_REQ * p_req = (DeleteTrack_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
	    "<trc:DeleteTrack>"
	        "<trc:RecordingToken>%s</trc:RecordingToken>"
	        "<trc:TrackToken>%s</trc:TrackToken>"
	    "</trc:DeleteTrack>",
	    p_req->RecordingToken,
	    p_req->TrackToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}
 
int build_GetTrackConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset;
	GetTrackConfiguration_REQ * p_req = (GetTrackConfiguration_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
	    "<trc:GetTrackConfiguration>"
	        "<trc:RecordingToken>%s</trc:RecordingToken>"
	        "<trc:TrackToken>%s</trc:TrackToken>"
	    "</trc:GetTrackConfiguration>",
	    p_req->RecordingToken,
	    p_req->TrackToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}
 
int build_SetTrackConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset;
	SetTrackConfiguration_REQ * p_req = (SetTrackConfiguration_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<trc:SetTrackConfiguration>");
	offset += snprintf(p_buf+offset, mlen-offset, 
	    "<trc:RecordingToken>%s</trc:RecordingToken>"
	    "<trc:TrackToken>%s</trc:TrackToken>",
	    p_req->RecordingToken,
	    p_req->TrackToken);
    offset += snprintf(p_buf+offset, mlen-offset, "<trc:TrackConfiguration>");	    
	offset += build_TrackConfiguration_xml(p_buf+offset, mlen-offset, &p_req->TrackConfiguration);
	offset += snprintf(p_buf+offset, mlen-offset, "</trc:TrackConfiguration>");
	offset += snprintf(p_buf+offset, mlen-offset, "</trc:SetTrackConfiguration>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_RecordingJobTrack_xml(char * p_buf, int mlen, onvif_RecordingJobTrack * p_req)
{
    int offset = 0;

    offset += snprintf(p_buf+offset, mlen-offset, 
        "<tt:Tracks>"
            "<tt:SourceTag>%s</tt:SourceTag>"
            "<tt:Destination>%s</tt:Destination>"
        "</tt:Tracks>",
        p_req->SourceTag,
        p_req->Destination);

    return offset;        
}

int build_RecordingJobSource_xml(char * p_buf, int mlen, onvif_RecordingJobSource * p_req)
{
    int i;
    int offset = 0;

    if (p_req->SourceTokenFlag)
    {
        offset += snprintf(p_buf+offset, mlen-offset, "<tt:SourceToken");
        if (p_req->SourceToken.TypeFlag)
        {
            offset += snprintf(p_buf+offset, mlen-offset, " Type=\"%s\"", p_req->SourceToken.Type);
        }
        offset += snprintf(p_buf+offset, mlen-offset, ">");
        offset += snprintf(p_buf+offset, mlen-offset, "<tt:Token>%s</tt:Token>", p_req->SourceToken.Token);
        offset += snprintf(p_buf+offset, mlen-offset, "</tt:SourceToken>");      
    }
    
    if (p_req->AutoCreateReceiverFlag)
    {
        offset += snprintf(p_buf+offset, mlen-offset, 
            "<tt:AutoCreateReceiver>%s</tt:AutoCreateReceiver>",
            p_req->AutoCreateReceiver ? "true" : "false");
    }

    for (i = 0; i < p_req->sizeTracks; i++)
    {
        offset += build_RecordingJobTrack_xml(p_buf+offset, mlen-offset, &p_req->Tracks[i]);
    }
    
    return offset;    
}

int build_RecordingJobConfiguration_xml(char * p_buf, int mlen, onvif_RecordingJobConfiguration * p_req)
{
    int i;
    int offset = 0;

    offset += snprintf(p_buf+offset, mlen-offset, 
        "<tt:RecordingToken>%s</tt:RecordingToken>"
        "<tt:Mode>%s</tt:Mode>"
        "<tt:Priority>%d</tt:Priority>",
        p_req->RecordingToken,
        p_req->Mode,
        p_req->Priority);

    for (i = 0; i < p_req->sizeSource; i++)
    {
        offset += build_RecordingJobSource_xml(p_buf+offset, mlen-offset, &p_req->Source[i]);
    }
    
    return offset;
}

int build_CreateRecordingJob_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset;
	CreateRecordingJob_REQ * p_req = (CreateRecordingJob_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<trc:CreateRecordingJob>");
    offset += snprintf(p_buf+offset, mlen-offset, "<trc:JobConfiguration>");	    
	offset += build_RecordingJobConfiguration_xml(p_buf+offset, mlen-offset, &p_req->JobConfiguration);
	offset += snprintf(p_buf+offset, mlen-offset, "</trc:JobConfiguration>");
	offset += snprintf(p_buf+offset, mlen-offset, "</trc:CreateRecordingJob>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}
 
int build_DeleteRecordingJob_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset;
	DeleteRecordingJob_REQ * p_req = (DeleteRecordingJob_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
	    "<trc:DeleteRecordingJob>"
	        "<trc:JobToken>%s</trc:JobToken>"
	    "</trc:DeleteRecordingJob>",
	    p_req->JobToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}
 
int build_GetRecordingJobs_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset;
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);	
	offset += snprintf(p_buf+offset, mlen-offset, "<trc:GetRecordingJobs />");
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
 
int build_SetRecordingJobConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset;
	SetRecordingJobConfiguration_REQ * p_req = (SetRecordingJobConfiguration_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<trc:SetRecordingJobConfiguration>");
	offset += snprintf(p_buf+offset, mlen-offset, 
	    "<trc:JobToken>%s</trc:JobToken>",
	    p_req->JobToken);
    offset += snprintf(p_buf+offset, mlen-offset, "<trc:JobConfiguration>");	    
	offset += build_RecordingJobConfiguration_xml(p_buf+offset, mlen-offset, &p_req->JobConfiguration);
	offset += snprintf(p_buf+offset, mlen-offset, "</trc:JobConfiguration>");
	offset += snprintf(p_buf+offset, mlen-offset, "</trc:SetRecordingJobConfiguration>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}
 
int build_GetRecordingJobConfiguration_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset;
	SetRecordingJobConfiguration_REQ * p_req = (SetRecordingJobConfiguration_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
	    "<trc:GetRecordingJobConfiguration>"
	        "<trc:JobToken>%s</trc:JobToken>"
	    "</trc:GetRecordingJobConfiguration>",
	    p_req->JobToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}
 
int build_SetRecordingJobMode_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset;
	SetRecordingJobMode_REQ * p_req = (SetRecordingJobMode_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
	    "<trc:SetRecordingJobMode>"
	        "<trc:JobToken>%s</trc:JobToken>"
	        "<trc:Mode>%s</trc:Mode>"
	    "</trc:SetRecordingJobMode>",
	    p_req->JobToken,
	    p_req->Mode);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}
 
int build_GetRecordingJobState_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int offset;
	GetRecordingJobState_REQ * p_req = (GetRecordingJobState_REQ *) argv;
	assert(p_req);
	
	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
	    "<trc:GetRecordingJobState>"
	        "<trc:JobToken>%s</trc:JobToken>"
	    "</trc:GetRecordingJobState>",
	    p_req->JobToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetReplayUri_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
    GetReplayUri_REQ * p_req = (GetReplayUri_REQ *) argv;
	assert(p_req);
	
    offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<trp:GetReplayUri>"
			"<trp:StreamSetup>"
				"<tt:Stream>%s</tt:Stream>"
				"<tt:Transport>"
					"<tt:Protocol>%s</tt:Protocol>"
				"</tt:Transport>"
			"</trp:StreamSetup>"
			"<trp:RecordingToken>%s</trp:RecordingToken>"
		"</trp:GetReplayUri>",
		onvif_StreamTypeToString(p_req->StreamSetup.Stream),
		onvif_TransportProtocolToString(p_req->StreamSetup.Transport.Protocol),
		p_req->RecordingToken);

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}


int build_GetRecordingSummary_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{	
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tse:GetRecordingSummary />");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetRecordingInformation_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GetRecordingInformation_REQ * p_req = (GetRecordingInformation_REQ *) argv;
	assert(p_req);

	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tse:GetRecordingInformation>"
			"<tse:RecordingToken>%s</tse:RecordingToken>"
		"</tse:GetRecordingInformation>",
		p_req->RecordingToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetMediaAttributes_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int i;
	int offset;
	char strtime[64] = {'\0'};
	GetMediaAttributes_REQ * p_req = (GetMediaAttributes_REQ *) argv;
	assert(p_req);

	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tse:GetMediaAttributes>");
	for (i = 0; i < 10; i++)
	{
		if (p_req->RecordingTokens[i][0] != '\0')
		{
			offset += snprintf(p_buf+offset, mlen-offset, "<tse:RecordingTokens>%s</tse:RecordingTokens>", p_req->RecordingTokens[i]);
		}
	}
	offset += snprintf(p_buf+offset, mlen-offset, "<tse:Time>%s</tse:Time>", 
	    onvif_format_datetime_str(p_req->Time, 1, "%Y-%m-%dT%H:%M:%SZ", strtime, sizeof(strtime)));
	offset += snprintf(p_buf+offset, mlen-offset, "</tse:GetMediaAttributes>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_FindRecordings_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{	
	int i;
	int offset;
	FindRecordings_REQ * p_req = (FindRecordings_REQ *) argv;
	assert(p_req);

	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tse:FindRecordings>");	
	offset += snprintf(p_buf+offset, mlen-offset, "<tse:Scope>");
	for (i = 0; i < 10; i++)
	{
		if (p_req->IncludedSources[i][0] != '\0')
		{
			offset += snprintf(p_buf+offset, mlen-offset, "<tt:IncludedSources><tt:Token>%s</tt:Token></tt:IncludedSources>", p_req->IncludedSources[i]);	
		}
	}
	for (i = 0; i < 10; i++)
	{
		if (p_req->IncludedRecordings[i][0] != '\0')
		{
			offset += snprintf(p_buf+offset, mlen-offset, "<tt:IncludedRecordings>%s</tt:IncludedRecordings>", p_req->IncludedRecordings[i]);	
		}
	}
	if (p_req->RecordingInformationFilter[0] != '\0')
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:RecordingInformationFilter>%s</tt:RecordingInformationFilter>", p_req->RecordingInformationFilter);
	}	
	offset += snprintf(p_buf+offset, mlen-offset, "</tse:Scope>");
	if (p_req->MaxMatchesFlag && p_req->MaxMatches != 0)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tse:MaxMatches>%d</tse:MaxMatches>", p_req->MaxMatches);
	}	
	offset += snprintf(p_buf+offset, mlen-offset, "<tse:KeepAliveTime>%d</tse:KeepAliveTime>", p_req->KeepAliveTime);
	offset += snprintf(p_buf+offset, mlen-offset, "</tse:FindRecordings>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetRecordingSearchResults_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{	
	int offset;
	GetRecordingSearchResults_REQ * p_req = (GetRecordingSearchResults_REQ *) argv;
	assert(p_req);

	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tse:GetRecordingSearchResults>");	
	offset += snprintf(p_buf+offset, mlen-offset, "<tse:SearchToken>%s</tse:SearchToken>", p_req->SearchToken);
	if (p_req->MinResultsFlag && p_req->MinResults != 0)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tse:MinResults>%d</tse:MinResults>", p_req->MinResults);
	}
	if (p_req->MaxResultsFlag && p_req->MaxResults != 0)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tse:MaxResults>%d</tse:MaxResults>", p_req->MaxResults);
	}
	if (p_req->WaitTimeFlag && p_req->WaitTime != 0)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tse:WaitTime>%d</tse:WaitTime>", p_req->WaitTime);
	}		    
	offset += snprintf(p_buf+offset, mlen-offset, "</tse:GetRecordingSearchResults>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_FindEvents_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{	
	int i;
	int offset;
	char strtime[64] = {'\0'};
	FindEvents_REQ * p_req = (FindEvents_REQ *) argv;
	assert(p_req);

	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tse:FindEvents>");	
	offset += snprintf(p_buf+offset, mlen-offset, "<tse:StartPoint>%s</tse:StartPoint>", 
	    onvif_format_datetime_str(p_req->StartPoint, 1, "%Y-%m-%dT%H:%M:%SZ", strtime, sizeof(strtime)));
	if (p_req->EndPoint != 0)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tse:EndPoint>%s</tse:EndPoint>", 
		    onvif_format_datetime_str(p_req->StartPoint, 1, "%Y-%m-%dT%H:%M:%SZ", strtime, sizeof(strtime)));
	}
	offset += snprintf(p_buf+offset, mlen-offset, "<tse:Scope>");
	for (i = 0; i < 10; i++)
	{
		if (p_req->IncludedSources[i][0] != '\0')
		{
			offset += snprintf(p_buf+offset, mlen-offset, "<tt:IncludedSources><tt:Token>%s</tt:Token></tt:IncludedSources>", p_req->IncludedSources[i]);	
		}
	}
	for (i = 0; i < 10; i++)
	{
		if (p_req->IncludedRecordings[i][0] != '\0')
		{
			offset += snprintf(p_buf+offset, mlen-offset, "<tt:IncludedRecordings>%s</tt:IncludedRecordings>", p_req->IncludedRecordings[i]);	
		}
	}
	if (p_req->RecordingInformationFilter[0] != '\0')
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tt:RecordingInformationFilter>%s</tt:RecordingInformationFilter>", p_req->RecordingInformationFilter);
	}	
	offset += snprintf(p_buf+offset, mlen-offset, "</tse:Scope>");
	offset += snprintf(p_buf+offset, mlen-offset, "<tse:SearchFilter></tse:SearchFilter>");
	offset += snprintf(p_buf+offset, mlen-offset, "<tse:IncludeStartState>%s</tse:IncludeStartState>", p_req->IncludeStartState ? "true" : "false");
	if (p_req->MaxMatchesFlag && p_req->MaxMatches != 0)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tse:MaxMatches>%d</tse:MaxMatches>", p_req->MaxMatches);
	}	
	offset += snprintf(p_buf+offset, mlen-offset, "<tse:KeepAliveTime>%d</tse:KeepAliveTime>", p_req->KeepAliveTime);
	offset += snprintf(p_buf+offset, mlen-offset, "</tse:FindEvents>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetEventSearchResults_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{	
	int offset;
	GetEventSearchResults_REQ * p_req = (GetEventSearchResults_REQ *) argv;
	assert(p_req);

	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tse:GetEventSearchResults>");	
	offset += snprintf(p_buf+offset, mlen-offset, "<tse:SearchToken>%s</tse:SearchToken>", p_req->SearchToken);
	if (p_req->MinResultsFlag && p_req->MinResults != 0)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tse:MinResults>%d</tse:MinResults>", p_req->MinResults);
	}
	if (p_req->MaxResultsFlag && p_req->MaxResults != 0)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tse:MaxResults>%d</tse:MaxResults>", p_req->MaxResults);
	}
	if (p_req->WaitTimeFlag && p_req->WaitTime != 0)
	{
		offset += snprintf(p_buf+offset, mlen-offset, "<tse:WaitTime>%d</tse:WaitTime>", p_req->WaitTime);
	}		    
	offset += snprintf(p_buf+offset, mlen-offset, "</tse:GetEventSearchResults>");
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_GetSearchState_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	GetSearchState_REQ * p_req = (GetSearchState_REQ *) argv;
	assert(p_req);

	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tse:GetSearchState>"
			"<tse:SearchToken>%s</tse:SearchToken>"
		"</tse:GetSearchState>",
		p_req->SearchToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}

int build_EndSearch_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int offset;
	EndSearch_REQ * p_req = (EndSearch_REQ *) argv;
	assert(p_req);

	offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tse:EndSearch>"
			"<tse:SearchToken>%s</tse:SearchToken>"
		"</tse:EndSearch>",
		p_req->SearchToken);
	
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);	
	return offset;
}


#endif // end of PROFILE_G_SUPPORT

#ifdef PROFILE_C_SUPPORT

int build_GetAccessPointInfoList_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    GetAccessPointInfoList_REQ * p_req = (GetAccessPointInfoList_REQ *) argv;

	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tac:GetAccessPointInfoList>");
    if (p_req)
    {
        if (p_req->LimitFlag)
        {
            offset += snprintf(p_buf+offset, mlen-offset, 
                "<tac:Limit>%d</tac:Limit>", 
                p_req->Limit);
        }

        if (p_req->StartReferenceFlag)
        {
            offset += snprintf(p_buf+offset, mlen-offset, 
                "<tac:StartReference>%s</tac:StartReference>", 
                p_req->StartReference);
        }
    }
	offset += snprintf(p_buf+offset, mlen-offset, "</tac:GetAccessPointInfoList>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
   
int build_GetAccessPointInfo_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
    int i;
	GetAccessPointInfo_REQ * p_req = (GetAccessPointInfo_REQ *) argv;
	assert(p_req);
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tac:GetAccessPointInfo>");
	for (i = 0; i < ACCESS_CTRL_MAX_LIMIT; i++)
	{
	    if (p_req->token[i][0] != '\0')
	    {
	        offset += snprintf(p_buf+offset, mlen-offset, 
	            "<tac:Token>%s</tac:Token>",
	            p_req->token[i]);
	    }
	}
	offset += snprintf(p_buf+offset, mlen-offset, "</tac:GetAccessPointInfo>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
 
int build_GetDoorInfoList_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	GetDoorInfoList_REQ * p_req = (GetDoorInfoList_REQ *) argv;

	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tdc:GetDoorInfoList>");
    if (p_req)
    {
        if (p_req->LimitFlag)
        {
            offset += snprintf(p_buf+offset, mlen-offset, 
                "<tdc:Limit>%d</tdc:Limit>", 
                p_req->Limit);
        }

        if (p_req->StartReferenceFlag)
        {
            offset += snprintf(p_buf+offset, mlen-offset, 
                "<tdc:StartReference>%s</tdc:StartReference>", 
                p_req->StartReference);
        }
    }
	offset += snprintf(p_buf+offset, mlen-offset, "</tdc:GetDoorInfoList>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
 
int build_GetDoorInfo_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int i;
	GetDoorInfo_REQ * p_req = (GetDoorInfo_REQ *) argv;
	assert(p_req);
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tdc:GetDoorInfo>");
	for (i = 0; i < DOOR_CTRL_MAX_LIMIT; i++)
	{
	    if (p_req->token[i][0] != '\0')
	    {
	        offset += snprintf(p_buf+offset, mlen-offset, 
	            "<tdc:Token>%s</tdc:Token>",
	            p_req->token[i]);
	    }
	}
	offset += snprintf(p_buf+offset, mlen-offset, "</tdc:GetDoorInfo>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
 
int build_GetAreaInfoList_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	GetAreaInfoList_REQ * p_req = (GetAreaInfoList_REQ *) argv;

	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tac:GetAreaInfoList>");
    if (p_req)
    {
        if (p_req->LimitFlag)
        {
            offset += snprintf(p_buf+offset, mlen-offset, 
                "<tac:Limit>%d</tac:Limit>", 
                p_req->Limit);
        }

        if (p_req->StartReferenceFlag)
        {
            offset += snprintf(p_buf+offset, mlen-offset, 
                "<tac:StartReference>%s</tac:StartReference>", 
                p_req->StartReference);
        }
    }
	offset += snprintf(p_buf+offset, mlen-offset, "</tac:GetAreaInfoList>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
 
int build_GetAreaInfo_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	int i;
	GetAreaInfo_REQ * p_req = (GetAreaInfo_REQ *) argv;
	assert(p_req);
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tac:GetAreaInfo>");
	for (i = 0; i < ACCESS_CTRL_MAX_LIMIT; i++)
	{
	    if (p_req->token[i][0] != '\0')
	    {
	        offset += snprintf(p_buf+offset, mlen-offset, 
	            "<tac:Token>%s</tac:Token>",
	            p_req->token[i]);
	    }
	}
	offset += snprintf(p_buf+offset, mlen-offset, "</tac:GetAreaInfo>");

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
 
int build_GetAccessPointState_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	GetAccessPointState_REQ * p_req = (GetAccessPointState_REQ *) argv;
	assert(p_req);
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tac:GetAccessPointState>"
			"<tac:Token>%s</tac:Token>"
		"</tac:GetAccessPointState>",
		p_req->Token);

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
 
int build_GetDoorState_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	GetDoorState_REQ * p_req = (GetDoorState_REQ *) argv;
	assert(p_req);
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tdc:GetDoorState>"
			"<tdc:Token>%s</tdc:Token>"
		"</tdc:GetDoorState>",
		p_req->Token);

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
 
int build_AccessDoor_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	AccessDoor_REQ * p_req = (AccessDoor_REQ *) argv;
	assert(p_req);
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, "<tdc:AccessDoor>");
	offset += snprintf(p_buf+offset, mlen-offset, "<tdc:Token>%s</tdc:Token>", p_req->Token);
    if (p_req->UseExtendedTimeFlag)
    {
        offset += snprintf(p_buf+offset, mlen-offset, 
	        "<tdc:UseExtendedTime>%s</tdc:UseExtendedTime>",
		    p_req->UseExtendedTime ? "true" : "false");
    }
    if (p_req->AccessTimeFlag)
    {
        offset += snprintf(p_buf+offset, mlen-offset, 
	        "<tdc:AccessTime>PT%dS</tdc:AccessTime>",
		    p_req->AccessTime);
    }
    if (p_req->OpenTooLongTimeFlag)
    {
        offset += snprintf(p_buf+offset, mlen-offset, 
	        "<tdc:OpenTooLongTime>PT%dS</tdc:OpenTooLongTime>",
		    p_req->OpenTooLongTime);
    }
    if (p_req->PreAlarmTimeFlag)
    {
        offset += snprintf(p_buf+offset, mlen-offset, 
	        "<tdc:PreAlarmTime>PT%dS</tdc:PreAlarmTime>",
		    p_req->PreAlarmTime);
    }
    offset += snprintf(p_buf+offset, mlen-offset, "</tdc:AccessDoor>");
	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
 
int build_LockDoor_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	LockDoor_REQ * p_req = (LockDoor_REQ *) argv;
	assert(p_req);
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tdc:LockDoor>"
			"<tdc:Token>%s</tdc:Token>"
		"</tdc:LockDoor>",
		p_req->Token);

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
 
int build_UnlockDoor_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	UnlockDoor_REQ * p_req = (UnlockDoor_REQ *) argv;
	assert(p_req);
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tdc:UnlockDoor>"
			"<tdc:Token>%s</tdc:Token>"
		"</tdc:UnlockDoor>",
		p_req->Token);

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
 
int build_DoubleLockDoor_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	DoubleLockDoor_REQ * p_req = (DoubleLockDoor_REQ *) argv;
	assert(p_req);
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tdc:DoubleLockDoor>"
			"<tdc:Token>%s</tdc:Token>"
		"</tdc:DoubleLockDoor>",
		p_req->Token);

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
 
int build_BlockDoor_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	BlockDoor_REQ * p_req = (BlockDoor_REQ *) argv;
	assert(p_req);
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tdc:BlockDoor>"
			"<tdc:Token>%s</tdc:Token>"
		"</tdc:BlockDoor>",
		p_req->Token);

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
 
int build_LockDownDoor_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	LockDownDoor_REQ * p_req = (LockDownDoor_REQ *) argv;
	assert(p_req);
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tdc:LockDownDoor>"
			"<tdc:Token>%s</tdc:Token>"
		"</tdc:LockDownDoor>",
		p_req->Token);

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
 
int build_LockDownReleaseDoor_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	LockDownReleaseDoor_REQ * p_req = (LockDownReleaseDoor_REQ *) argv;
	assert(p_req);
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tdc:LockDownReleaseDoor>"
			"<tdc:Token>%s</tdc:Token>"
		"</tdc:LockDownReleaseDoor>",
		p_req->Token);

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
 
int build_LockOpenDoor_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	LockOpenDoor_REQ * p_req = (LockOpenDoor_REQ *) argv;
	assert(p_req);
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tdc:LockOpenDoor>"
			"<tdc:Token>%s</tdc:Token>"
		"</tdc:LockOpenDoor>",
		p_req->Token);

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
 
int build_LockOpenReleaseDoor_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	LockOpenReleaseDoor_REQ * p_req = (LockOpenReleaseDoor_REQ *) argv;
	assert(p_req);
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tdc:LockOpenReleaseDoor>"
			"<tdc:Token>%s</tdc:Token>"
		"</tdc:LockOpenReleaseDoor>",
		p_req->Token);

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
 
int build_EnableAccessPoint_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	EnableAccessPoint_REQ * p_req = (EnableAccessPoint_REQ *) argv;
	assert(p_req);
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tac:EnableAccessPoint>"
			"<tac:Token>%s</tac:Token>"
		"</tac:EnableAccessPoint>",
		p_req->Token);

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
}
 
int build_DisableAccessPoint_xml(char * p_buf, int mlen, ONVIF_DEVICE * p_dev, void * argv)
{
	DisableAccessPoint_REQ * p_req = (DisableAccessPoint_REQ *) argv;
	assert(p_req);
        
	int offset = snprintf(p_buf, mlen, xml_hdr);

	offset += snprintf(p_buf+offset, mlen-offset, onvif_xmlns);
	offset += build_onvif_req_header(p_buf+offset, mlen-offset, p_dev, NULL);
	offset += snprintf(p_buf+offset, mlen-offset, soap_body);
	
	offset += snprintf(p_buf+offset, mlen-offset, 
		"<tac:DisableAccessPoint>"
			"<tac:Token>%s</tac:Token>"
		"</tac:DisableAccessPoint>",
		p_req->Token);

	offset += snprintf(p_buf+offset, mlen-offset, soap_tailer);
	return offset;
} 

#endif // end of PROFILE_C_SUPPORT

int build_onvif_req_xml(char * p_buf, int mlen, eOnvifAction type, ONVIF_DEVICE * p_dev, void * p_req)
{
	int rlen = 0;

	switch(type)
	{
	case eGetCapabilities:
        rlen = build_GetCapabilities_xml(p_buf, mlen, p_dev, p_req);
        break;

    case eGetServices:
        rlen = build_GetServices_xml(p_buf, mlen, p_dev, p_req);
        break;
        
	case eGetDeviceInformation:
		rlen = build_GetDeviceInformation_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetUsers:
		rlen = build_GetUsers_xml(p_buf, mlen, p_dev, p_req);
		break;

	case eCreateUsers:
		rlen = build_CreateUsers_xml(p_buf, mlen, p_dev, p_req);
		break;

	case eDeleteUsers:
		rlen = build_DeleteUsers_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eSetUser:
		rlen = build_SetUser_xml(p_buf, mlen, p_dev, p_req);
		break;

	case eGetRemoteUser:
		rlen = build_GetRemoteUser_xml(p_buf, mlen, p_dev, p_req);
		break;

	case eSetRemoteUser:
		rlen = build_SetRemoteUser_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetNetworkInterfaces:
        rlen = build_GetNetworkInterfaces_xml(p_buf, mlen, p_dev, p_req);
        break;

	case eSetNetworkInterfaces:
        rlen = build_SetNetworkInterfaces_xml(p_buf, mlen, p_dev, p_req);
        break;

	case eGetNTP:
		rlen = build_GetNTP_xml(p_buf, mlen, p_dev, p_req);
		break;

	case eSetNTP:
		rlen = build_SetNTP_xml(p_buf, mlen, p_dev, p_req);
		break;

	case eGetHostname:
		rlen = build_GetHostname_xml(p_buf, mlen, p_dev, p_req);
		break;

	case eSetHostname:
		rlen = build_SetHostname_xml(p_buf, mlen, p_dev, p_req);
		break;

	case eSetHostnameFromDHCP:
		rlen = build_SetHostnameFromDHCP_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetDNS:
		rlen = build_GetDNS_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eSetDNS:
		rlen = build_SetDNS_xml(p_buf, mlen, p_dev, p_req);
		break;	
		
	case eGetDynamicDNS:
		rlen = build_GetDynamicDNS_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eSetDynamicDNS:
		rlen = build_SetDynamicDNS_xml(p_buf, mlen, p_dev, p_req);
		break;

	case eGetNetworkProtocols:
		rlen = build_GetNetworkProtocols_xml(p_buf, mlen, p_dev, p_req);
		break;

	case eSetNetworkProtocols:
		rlen = build_SetNetworkProtocols_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetDiscoveryMode:
		rlen = build_GetDiscoveryMode_xml(p_buf, mlen, p_dev, p_req);
		break;

	case eSetDiscoveryMode:
		rlen = build_SetDiscoveryMode_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetNetworkDefaultGateway:
		rlen = build_GetNetworkDefaultGateway_xml(p_buf, mlen, p_dev, p_req);
		break;

	case eSetNetworkDefaultGateway:
		rlen = build_SetNetworkDefaultGateway_xml(p_buf, mlen, p_dev, p_req);
		break;

	case eGetZeroConfiguration:
	    rlen = build_GetZeroConfiguration_xml(p_buf, mlen, p_dev, p_req);
	    break;
	    
	case eSetZeroConfiguration:
	    rlen = build_SetZeroConfiguration_xml(p_buf, mlen, p_dev, p_req);
	    break;

	case eGetEndpointReference:
	    rlen = build_GetEndpointReference_xml(p_buf, mlen, p_dev, p_req);
	    break;
	    
	case eGetSystemDateAndTime:
		rlen = build_GetSystemDateAndTime_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eSetSystemDateAndTime:
		rlen = build_SetSystemDateAndTime_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eSystemReboot:
		rlen = build_SystemReboot_xml(p_buf, mlen, p_dev, p_req);
		break;

	case eSetSystemFactoryDefault:
		rlen = build_SetSystemFactoryDefault_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetSystemLog:
		rlen = build_GetSystemLog_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetScopes:
		rlen = build_GetScopes_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eSetScopes:
		rlen = build_SetScopes_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eAddScopes:
		rlen = build_AddScopes_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eRemoveScopes:
		rlen = build_RemoveScopes_xml(p_buf, mlen, p_dev, p_req);
		break;

	case eStartFirmwareUpgrade:
	    rlen = build_StartFirmwareUpgrade_xml(p_buf, mlen, p_dev, p_req);
	    break;

	case eGetSystemUris:
	    rlen = build_GetSystemUris_xml(p_buf, mlen, p_dev, p_req);
	    break;

	case eStartSystemRestore:
	    rlen = build_StartSystemRestore_xml(p_buf, mlen, p_dev, p_req);
	    break;
	    
	case eGetVideoSources:
		rlen = build_GetVideoSources_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetAudioSources:
		rlen = build_GetAudioSources_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eCreateProfile:
		rlen = build_CreateProfile_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetProfile:
		rlen = build_GetProfile_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetProfiles:
		rlen = build_GetProfiles_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eAddVideoEncoderConfiguration:
		rlen = build_AddVideoEncoderConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eAddVideoSourceConfiguration:
		rlen = build_AddVideoSourceConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eAddAudioEncoderConfiguration:
		rlen = build_AddAudioEncoderConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eAddAudioSourceConfiguration:
		rlen = build_AddAudioSourceConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;

	case eGetVideoSourceModes:
		rlen = build_GetVideoSourceModes_xml(p_buf, mlen, p_dev, p_req);
		break;

	case eSetVideoSourceMode:
		rlen = build_SetVideoSourceMode_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eAddPTZConfiguration:
		rlen = build_AddPTZConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eRemoveVideoEncoderConfiguration:
		rlen = build_RemoveVideoEncoderConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eRemoveVideoSourceConfiguration:
		rlen = build_RemoveVideoSourceConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eRemoveAudioEncoderConfiguration:
		rlen = build_RemoveAudioEncoderConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eRemoveAudioSourceConfiguration:
		rlen = build_RemoveAudioSourceConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eRemovePTZConfiguration:
		rlen = build_RemovePTZConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eDeleteProfile:
		rlen = build_DeleteProfile_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetVideoSourceConfigurations:
		rlen = build_GetVideoSourceConfigurations_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetVideoEncoderConfigurations:
		rlen = build_GetVideoEncoderConfigurations_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetAudioSourceConfigurations:
		rlen = build_GetAudioSourceConfigurations_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetAudioEncoderConfigurations:
		rlen = build_GetAudioEncoderConfigurations_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetVideoSourceConfiguration:
		rlen = build_GetVideoSourceConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetVideoEncoderConfiguration:
		rlen = build_GetVideoEncoderConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetAudioSourceConfiguration:
		rlen = build_GetAudioSourceConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetAudioEncoderConfiguration:
		rlen = build_GetAudioEncoderConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eSetVideoSourceConfiguration:
		rlen = build_SetVideoSourceConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eSetVideoEncoderConfiguration:
		rlen = build_SetVideoEncoderConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eSetAudioSourceConfiguration:
		rlen = build_SetAudioSourceConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eSetAudioEncoderConfiguration:
		rlen = build_SetAudioEncoderConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetVideoSourceConfigurationOptions:
		rlen = build_GetVideoSourceConfigurationOptions_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetVideoEncoderConfigurationOptions:
		rlen = build_GetVideoEncoderConfigurationOptions_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetAudioSourceConfigurationOptions:
		rlen = build_GetAudioSourceConfigurationOptions_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetAudioEncoderConfigurationOptions:
		rlen = build_GetAudioEncoderConfigurationOptions_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetStreamUri:
		rlen = build_GetStreamUri_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eSetSynchronizationPoint:
		rlen = build_SetSynchronizationPoint_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetSnapshotUri:
		rlen = build_GetSnapshotUri_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case eGetNodes:
    	rlen = build_GetNodes_xml(p_buf, mlen, p_dev, p_req);
    	break;
    	
	case eGetNode:
		rlen = build_GetNode_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetPresets:
		rlen = build_GetPresets_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eSetPreset:
		rlen = build_SetPreset_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eRemovePreset:
		rlen = build_RemovePreset_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGotoPreset:
		rlen = build_GotoPreset_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGotoHomePosition:
		rlen = build_GotoHomePosition_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eSetHomePosition:
		rlen = build_SetHomePosition_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetStatus:
		rlen = build_GetStatus_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eContinuousMove:
        rlen = build_ContinuousMove_xml(p_buf, mlen, p_dev, p_req);
        break;
        
	case eRelativeMove:
		rlen = build_RelativeMove_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eAbsoluteMove:
		rlen = build_AbsoluteMove_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case ePTZStop:
        rlen = build_ptz_Stop_xml(p_buf, mlen, p_dev, p_req);
        break;
        
	case eGetConfigurations:
        rlen = build_GetConfigurations_xml(p_buf, mlen, p_dev, p_req);
        break;
        
	case eGetConfiguration:
		rlen = build_GetConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eSetConfiguration:
		rlen = build_SetConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
			
	case eGetConfigurationOptions:
        rlen = build_GetConfigurationOptions_xml(p_buf, mlen, p_dev, p_req);
        break;

	case eGetPresetTours:
		rlen = build_GetPresetTours_xml(p_buf, mlen, p_dev, p_req);
		break;
	
	case eGetPresetTour:
		rlen = build_GetPresetTour_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetPresetTourOptions:
		rlen = build_GetPresetTourOptions_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eCreatePresetTour:
		rlen = build_CreatePresetTour_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eModifyPresetTour:
		rlen = build_ModifyPresetTour_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eOperatePresetTour:
		rlen = build_OperatePresetTour_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eRemovePresetTour:
		rlen = build_RemovePresetTour_xml(p_buf, mlen, p_dev, p_req);
		break;
    
	case eGetEventProperties:
        rlen = build_GetEventProperties_xml(p_buf, mlen, p_dev, p_req);
        break;
    
	case eRenew:
        rlen = build_Renew_xml(p_buf, mlen, p_dev, p_req);
        break;
    
	case eUnsubscribe:
        rlen = build_Unsubscribe_xml(p_buf, mlen, p_dev, p_req);
        break;
    
	case eSubscribe:
        rlen = build_Subscribe_xml(p_buf, mlen, p_dev, p_req);
        break;

    case eCreatePullPointSubscription:
    	rlen = build_CreatePullPointSubscription_xml(p_buf, mlen, p_dev, p_req);
    	break;
    	
    case ePullMessages:
    	rlen = build_PullMessages_xml(p_buf, mlen, p_dev, p_req);
    	break;
    
	case eGetImagingSettings:
        rlen = build_GetImagingSettings_xml(p_buf, mlen, p_dev, p_req);
        break;
    
	case eSetImagingSettings:
        rlen = build_SetImagingSettings_xml(p_buf, mlen, p_dev, p_req);
        break;    

	case eGetOptions:
		rlen = build_GetOptions_xml(p_buf, mlen, p_dev, p_req);
        break;
           
    case eimgMove:
		rlen = build_img_Move_xml(p_buf, mlen, p_dev, p_req);
        break;
        
	case eimgStop:
		rlen = build_img_Stop_xml(p_buf, mlen, p_dev, p_req);
        break;
        
	case eimgGetStatus:
		rlen = build_img_GetStatus_xml(p_buf, mlen, p_dev, p_req);
        break;
        
	case eimgGetMoveOptions:
		rlen = build_img_GetMoveOptions_xml(p_buf, mlen, p_dev, p_req);
        break;        
	
	case eGetOSDs:
		rlen = build_GetOSDs_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetOSD:
		rlen = build_GetOSD_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eSetOSD:
		rlen = build_SetOSD_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetOSDOptions:
		rlen = build_GetOSDOptions_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eCreateOSD:
		rlen = build_CreateOSD_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eDeleteOSD:
		rlen = build_DeleteOSD_xml(p_buf, mlen, p_dev, p_req);
		break;

	case eGetVideoAnalyticsConfigurations:
		rlen = build_GetVideoAnalyticsConfigurations_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eAddVideoAnalyticsConfiguration:
		rlen = build_AddVideoAnalyticsConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetVideoAnalyticsConfiguration:
		rlen = build_GetVideoAnalyticsConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eRemoveVideoAnalyticsConfiguration:
		rlen = build_RemoveVideoAnalyticsConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eSetVideoAnalyticsConfiguration:
		rlen = build_SetVideoAnalyticsConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetSupportedRules:
		rlen = build_GetSupportedRules_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eCreateRules:
		rlen = build_CreateRules_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eDeleteRules:
		rlen = build_DeleteRules_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetRules:
		rlen = build_GetRules_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eModifyRules:
		rlen = build_ModifyRules_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eCreateAnalyticsModules:
		rlen = build_CreateAnalyticsModules_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eDeleteAnalyticsModules:
		rlen = build_DeleteAnalyticsModules_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eGetAnalyticsModules:
		rlen = build_GetAnalyticsModules_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case eModifyAnalyticsModules:
		rlen = build_ModifyAnalyticsModules_xml(p_buf, mlen, p_dev, p_req);
		break;		

	case etr2GetVideoEncoderConfigurations:
		rlen = build_tr2_GetVideoEncoderConfigurations_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case etr2SetVideoEncoderConfiguration:
		rlen = build_tr2_SetVideoEncoderConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
	case etr2GetVideoEncoderConfigurationOptions:
		rlen = build_tr2_GetVideoEncoderConfigurationOptions_xml(p_buf, mlen, p_dev, p_req);
		break;

	case etr2GetProfiles:
		rlen = build_tr2_GetProfiles_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case etr2CreateProfile:
		rlen = build_tr2_CreateProfile_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case etr2DeleteProfile:
		rlen = build_tr2_DeleteProfile_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case etr2GetStreamUri:
		rlen = build_tr2_GetStreamUri_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case etr2GetVideoSourceConfigurations:
		rlen = build_tr2_GetVideoSourceConfigurations_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case etr2GetVideoSourceConfigurationOptions:
		rlen = build_tr2_GetVideoSourceConfigurationOptions_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case etr2SetVideoSourceConfiguration:
		rlen = build_tr2_SetVideoSourceConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case etr2SetSynchronizationPoint:
		rlen = build_tr2_SetSynchronizationPoint_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case etr2GetMetadataConfigurations:
		rlen = build_tr2_GetMetadataConfigurations_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case etr2GetMetadataConfigurationOptions:
		rlen = build_tr2_GetMetadataConfigurationOptions_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case etr2SetMetadataConfiguration:
		rlen = build_tr2_SetMetadataConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case etr2GetAudioEncoderConfigurations:
		rlen = build_tr2_GetAudioEncoderConfigurations_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case etr2GetAudioSourceConfigurations:
		rlen = build_tr2_GetAudioSourceConfigurations_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case etr2GetAudioSourceConfigurationOptions:
		rlen = build_tr2_GetAudioSourceConfigurationOptions_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case etr2SetAudioSourceConfiguration:
		rlen = build_tr2_SetAudioSourceConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case etr2SetAudioEncoderConfiguration:
		rlen = build_tr2_SetAudioEncoderConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case etr2GetAudioEncoderConfigurationOptions:
		rlen = build_tr2_GetAudioEncoderConfigurationOptions_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case etr2AddConfiguration:
		rlen = build_tr2_AddConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case etr2RemoveConfiguration:
		rlen = build_tr2_RemoveConfiguration_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case etr2GetVideoEncoderInstances:
		rlen = build_tr2_GetVideoEncoderInstances_xml(p_buf, mlen, p_dev, p_req);
		break;		

#ifdef PROFILE_G_SUPPORT
    case eCreateRecording:
		rlen = build_CreateRecording_xml(p_buf, mlen, p_dev, p_req);
        break;
          
    case eDeleteRecording:
		rlen = build_DeleteRecording_xml(p_buf, mlen, p_dev, p_req);
        break;
        
    case eGetRecordings:
		rlen = build_GetRecordings_xml(p_buf, mlen, p_dev, p_req);
        break;
        
    case eSetRecordingConfiguration:
		rlen = build_SetRecordingConfiguration_xml(p_buf, mlen, p_dev, p_req);
        break;
        
    case eGetRecordingConfiguration:
		rlen = build_GetRecordingConfiguration_xml(p_buf, mlen, p_dev, p_req);
        break;
        
    case eGetRecordingOptions:
		rlen = build_GetRecordingOptions_xml(p_buf, mlen, p_dev, p_req);
        break;
        
    case eCreateTrack:
		rlen = build_CreateTrack_xml(p_buf, mlen, p_dev, p_req);
        break;
        
    case eDeleteTrack:
		rlen = build_DeleteTrack_xml(p_buf, mlen, p_dev, p_req);
        break;
        
    case eGetTrackConfiguration:
		rlen = build_GetTrackConfiguration_xml(p_buf, mlen, p_dev, p_req);
        break;
        
    case eSetTrackConfiguration:
		rlen = build_SetTrackConfiguration_xml(p_buf, mlen, p_dev, p_req);
        break;
        
    case eCreateRecordingJob:
		rlen = build_CreateRecordingJob_xml(p_buf, mlen, p_dev, p_req);
        break;
        
    case eDeleteRecordingJob:
		rlen = build_DeleteRecordingJob_xml(p_buf, mlen, p_dev, p_req);
        break;
        
    case eGetRecordingJobs:
		rlen = build_GetRecordingJobs_xml(p_buf, mlen, p_dev, p_req);
        break;
        
    case eSetRecordingJobConfiguration:
		rlen = build_SetRecordingJobConfiguration_xml(p_buf, mlen, p_dev, p_req);
        break;
        
    case eGetRecordingJobConfiguration:
		rlen = build_GetRecordingJobConfiguration_xml(p_buf, mlen, p_dev, p_req);
        break;
        
    case eSetRecordingJobMode:
		rlen = build_SetRecordingJobMode_xml(p_buf, mlen, p_dev, p_req);
        break;
        
    case eGetRecordingJobState:
		rlen = build_GetRecordingJobState_xml(p_buf, mlen, p_dev, p_req);
        break;

    case eGetReplayUri:
		rlen = build_GetReplayUri_xml(p_buf, mlen, p_dev, p_req);
        break;

    case eGetRecordingSummary:
    	rlen = build_GetRecordingSummary_xml(p_buf, mlen, p_dev, p_req);
        break;

    case eGetRecordingInformation:
    	rlen = build_GetRecordingInformation_xml(p_buf, mlen, p_dev, p_req);
        break;
        
	case eGetMediaAttributes:
    	rlen = build_GetMediaAttributes_xml(p_buf, mlen, p_dev, p_req);
        break;
        
	case eFindRecordings:
    	rlen = build_FindRecordings_xml(p_buf, mlen, p_dev, p_req);
        break;
        
	case eGetRecordingSearchResults:
    	rlen = build_GetRecordingSearchResults_xml(p_buf, mlen, p_dev, p_req);
        break;
        
	case eFindEvents:
    	rlen = build_FindEvents_xml(p_buf, mlen, p_dev, p_req);
        break;
        
	case eGetEventSearchResults:
    	rlen = build_GetEventSearchResults_xml(p_buf, mlen, p_dev, p_req);
        break;
        
	case eGetSearchState:
    	rlen = build_GetSearchState_xml(p_buf, mlen, p_dev, p_req);
        break;
        
	case eEndSearch:
    	rlen = build_EndSearch_xml(p_buf, mlen, p_dev, p_req);
        break;        

#endif // end of PROFILE_G_SUPPORT

#ifdef PROFILE_C_SUPPORT
    case eGetAccessPointInfoList:
		rlen = build_GetAccessPointInfoList_xml(p_buf, mlen, p_dev, p_req);
		break;
		  
    case eGetAccessPointInfo:
		rlen = build_GetAccessPointInfo_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case eGetDoorInfoList:
		rlen = build_GetDoorInfoList_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case eGetDoorInfo:
		rlen = build_GetDoorInfo_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case eGetAreaInfoList:
		rlen = build_GetAreaInfoList_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case eGetAreaInfo:
		rlen = build_GetAreaInfo_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case eGetAccessPointState:
		rlen = build_GetAccessPointState_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case eGetDoorState:
		rlen = build_GetDoorState_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case eAccessDoor:
		rlen = build_AccessDoor_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case eLockDoor:
		rlen = build_LockDoor_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case eUnlockDoor:
		rlen = build_UnlockDoor_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case eDoubleLockDoor:
		rlen = build_DoubleLockDoor_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case eBlockDoor:
		rlen = build_BlockDoor_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case eLockDownDoor:
		rlen = build_LockDownDoor_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case eLockDownReleaseDoor:
		rlen = build_LockDownReleaseDoor_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case eLockOpenDoor:
		rlen = build_LockOpenDoor_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case eLockOpenReleaseDoor:
		rlen = build_LockOpenReleaseDoor_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case eEnableAccessPoint:
		rlen = build_EnableAccessPoint_xml(p_buf, mlen, p_dev, p_req);
		break;
		
    case eDisableAccessPoint:
		rlen = build_DisableAccessPoint_xml(p_buf, mlen, p_dev, p_req);
		break;		
#endif // end of PROFILE_C_SUPPORT

	default:
		assert(FALSE);
	    break;
	}

	return rlen;
}




