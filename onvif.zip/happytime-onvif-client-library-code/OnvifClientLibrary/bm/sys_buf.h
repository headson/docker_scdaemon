/***************************************************************************************
 *
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
 *
 *  By downloading, copying, installing or using the software you agree to this license.
 *  If you do not agree to this license, do not download, install, 
 *  copy or use the software.
 *
 *  Copyright (C) 2010-2016, Happytimesoft Corporation, all rights reserved.
 *
 *  Redistribution and use in binary forms, with or without modification, are permitted.
 *
 *  Unless required by applicable law or agreed to in writing, software distributed 
 *  under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 *  language governing permissions and limitations under the License.
 *
****************************************************************************************/

#ifndef	__H_SYS_BUF_H__
#define	__H_SYS_BUF_H__

/***************************************************************************************/
#define MAX_AVN				16	
#define MAX_AVDESCLEN		280	
#define MAX_USRL			64	
#define MAX_PWDL			32	
#define MAX_NUML			64
#define MAX_UA_ALT_NUM		8


/***************************************************************************************/
typedef struct header_value
{
	char	header[32];
	char *	value_string;
} HDRV;

typedef struct http_digest_auth_info
{
	char			auth_name[MAX_USRL];
	char			auth_pwd[64];
	char			auth_uri[256];			
	char			auth_qop[32];
	char			auth_nonce[128];
	char			auth_cnonce[128];
	char			auth_realm[128];
	int				auth_nc;
	char			auth_ncstr[12];
	char			auth_response[36];
} HD_AUTH_INFO;

extern  PPSN_CTX * hdrv_buf_fl;

#ifdef __cplusplus
extern "C" {
#endif

/***********************************************************************/
ONVIF_API BOOL      net_buf_fl_init(int num, int size);
ONVIF_API void      net_buf_fl_deinit();

ONVIF_API char    * get_idle_net_buf();
ONVIF_API void      free_net_buf(char * rbuf);
ONVIF_API uint32    idle_net_buf_num();

/***********************************************************************/
ONVIF_API BOOL      hdrv_buf_fl_init(int num);
ONVIF_API void 	    hdrv_buf_fl_deinit();

ONVIF_API HDRV    * get_hdrv_buf();
ONVIF_API void      free_hdrv_buf(HDRV * pHdrv);
ONVIF_API uint32    idle_hdrv_buf_num();

ONVIF_API void      init_ul_hdrv_ctx(PPSN_CTX * ul_ctx);

ONVIF_API void      free_ctx_hdrv(PPSN_CTX * p_ctx);

/***********************************************************************/
ONVIF_API BOOL      sys_buf_init();
ONVIF_API void      sys_buf_deinit();
/***********************************************************************/


#ifdef __cplusplus
}
#endif

#endif	//	__H_SYS_BUF_H__



